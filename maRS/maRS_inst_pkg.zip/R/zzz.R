#####################
# Create_shortcuts
#####################

create_shortcuts <- function() {
  app_dir <- system.file("app", package = "maRSpkg")
  if (app_dir == "")
    return(FALSE)
  
  os <- Sys.info()["sysname"]
  
  if (os == "Windows") {
    ps_script <- normalizePath(file.path(app_dir, "maRS.ps1"),
                               winslash = "\\",
                               mustWork = TRUE)
    
    icon_path <- normalizePath(
      file.path(app_dir, "www", "logo_maRS.ico"),
      winslash = "\\",
      mustWork = TRUE
    )
    
    app_dir_win <- normalizePath(app_dir, winslash = "\\", mustWork = TRUE)
    
    ps_code <- sprintf(
      "
      $Wscript = New-Object -ComObject WScript.Shell;
      $StartMenu = Join-Path $env:APPDATA 'Microsoft\\Windows\\Start Menu\\Programs\\maRS';
      $Desktop = [Environment]::GetFolderPath('Desktop');

      if (-not (Test-Path $StartMenu)) {
        New-Item -Path $StartMenu -ItemType Directory -Force | Out-Null
      }

      $s1 = $Wscript.CreateShortcut((Join-Path $StartMenu 'maRS.lnk'));
      $s1.TargetPath = 'powershell.exe';
      $s1.Arguments = '-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File \"%s\"';
      $s1.WorkingDirectory = '%s';
      $s1.IconLocation = '%s';
      $s1.WindowStyle = 7;
      $s1.Save();

      $s2 = $Wscript.CreateShortcut((Join-Path $Desktop 'maRS.lnk'));
      $s2.TargetPath = 'powershell.exe';
      $s2.Arguments = '-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File \"%s\"';
      $s2.WorkingDirectory = '%s';
      $s2.IconLocation = '%s';
      $s2.WindowStyle = 7;
      $s2.Save();
    ",
      ps_script,
      app_dir_win,
      icon_path,
      ps_script,
      app_dir_win,
      icon_path
    )
    
    result <- system2(
      "powershell",
      args = c(
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        ps_code
      ),
      stdout = FALSE,
      stderr = FALSE
    )
    
    return(result == 0)
    
  } else if (os == "Linux") {
    sh_script <- file.path(app_dir, "maRS.sh")
    icon_path <- file.path(app_dir, "www", "logo_maRS.png")
    desktop_dir <- file.path(Sys.getenv("HOME"), ".local", "share", "applications")
    desktop_file <- file.path(desktop_dir, "maRS.desktop")
    
    if (!file.exists(sh_script) || !file.exists(icon_path)) {
      return(FALSE)
    }
    
    dir.create(desktop_dir,
               recursive = TRUE,
               showWarnings = FALSE)
    
    if (!dir.exists(desktop_dir)) {
      return(FALSE)
    }
    
    Sys.chmod(sh_script, "0755")
    
    content <- c(
      "[Desktop Entry]",
      "Version=1.0",
      "Type=Application",
      "Name=maRS",
      sprintf("Exec=bash \"%s\"", sh_script),
      sprintf("Icon=%s", icon_path),
      sprintf("Path=%s", app_dir),
      "Terminal=false",
      "Categories=Science;Education;"
    )
    
    writeLines(content, desktop_file)
    
    if (!file.exists(desktop_file)) {
      return(FALSE)
    }
    
    Sys.chmod(desktop_file, "0755")
    
    if (nzchar(Sys.which("update-desktop-database"))) {
      system2(
        "update-desktop-database",
        args = shQuote(desktop_dir),
        stdout = FALSE,
        stderr = FALSE
      )
    }
    
    return(TRUE)
    
  } else if (os == "Darwin") {
    sh_script <- file.path(app_dir, "maRS.sh")
    app_dir_mac <- file.path(Sys.getenv("HOME"), "Applications")
    app_bundle <- file.path(app_dir_mac, "maRS.app")
    
    if (!file.exists(sh_script)) {
      return(FALSE)
    }
    
    dir.create(app_dir_mac,
               recursive = TRUE,
               showWarnings = FALSE)
    
    if (!dir.exists(app_dir_mac)) {
      return(FALSE)
    }
    
    Sys.chmod(sh_script, "0755")
    
    if (!nzchar(Sys.which("osacompile"))) {
      return(FALSE)
    }
    
    script <- sprintf('do shell script "bash \\"%s\\" > /dev/null 2>&1 &"', sh_script)
    
    result <- system2(
      "osacompile",
      args = c("-o", shQuote(app_bundle), "-e", shQuote(script)),
      stdout = FALSE,
      stderr = FALSE
    )
    
    return(result == 0 && dir.exists(app_bundle))
  }
  
  FALSE
}

#####################
# Remove_shortcuts
#####################

remove_shortcuts <- function() {
  os <- Sys.info()["sysname"]
  
  if (os == "Windows") {
    cmd <- 'powershell -NoProfile -ExecutionPolicy Bypass -Command "
      $Desktop = [Environment]::GetFolderPath(\'Desktop\');
      $StartMenu = Join-Path $env:APPDATA \'Microsoft\\Windows\\Start Menu\\Programs\\maRS\';
      Remove-Item \"$Desktop\\maRS.lnk\" -Force -ErrorAction SilentlyContinue;
      Remove-Item $StartMenu -Recurse -Force -ErrorAction SilentlyContinue;
    "'
    system(cmd, show.output.on.console = FALSE)
  } else if (os == "Linux") {
    unlink(file.path(
      Sys.getenv("HOME"),
      ".local",
      "share",
      "applications",
      "maRS.desktop"
    ))
  } else if (os == "Darwin") {
    unlink(file.path(Sys.getenv("HOME"), "Applications", "maRS.app"),
           recursive = TRUE)
  }
  
  message("maRS shortcuts removed from the system.")
}

#####################
# Uninstall
#####################

uninstall_mars <- function() {
  remove_shortcuts()
  if ("maRSpkg" %in% loadedNamespaces()) {
    unloadNamespace("maRSpkg")
  }
  remove.packages("maRSpkg")
  message("maRS and its shortcuts have been successfully uninstalled!")
}

.onUnload <- function(libpath) {
  calls <- sys.calls()
  call_names <- unlist(lapply(calls, function(x) {
    tryCatch(
      deparse(x[[1]])[1],
      error = function(e)
        ""
    )
  }))
  
  if (any(c("remove.packages", "utils::remove.packages") %in% call_names)) {
    remove_shortcuts()
  }
}

#####################
# Startup Message
#####################

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("maRS ready for use.")
}

#####################
# Update
#####################

.onAttach <- function(libname, pkgname) {
  if (interactive()) {
    app_file <- file.path(getwd(), "app.R")
    if (file.exists(app_file)) {
      app_lines <- readLines(app_file, n = 2, warn = FALSE)
      LOCAL_VERSION <- sub('.*"(.*)".*', '\\1', app_lines[2])
    } else {
      LOCAL_VERSION <- as.character(utils::packageVersion(pkgname))
    }
    
    remote_url <- "https://laquali-ufla.github.io/maRS/version.R"
    
    tryCatch({
      old_timeout <- getOption("timeout")
      options(timeout = 3)
      on.exit(options(timeout = old_timeout), add = TRUE)
      
      con <- url(remote_url)
      suppressWarnings(open(con, open = "r"))
      remote_lines <- readLines(con, warn = FALSE)
      close(con)
      
      version_line <- grep("Version\\s*=", remote_lines, value = TRUE)
      
      if (length(version_line) > 0) {
        remote_version_str <- trimws(sub(".*Version\\s*=\\s*", "", version_line[1]))
        
        if (package_version(LOCAL_VERSION) < package_version(remote_version_str)) {
          
          packageStartupMessage(sprintf(
            "\n[maRS] A new version is available! (Current: %s | New: %s)",
            LOCAL_VERSION, remote_version_str
          ))
          
          ans <- readline(prompt = "Do you want to update now? [Y/n]: ")
          
          if (trimws(tolower(ans)) %in% c("y", "yes", "")) {
            packageStartupMessage("Starting update...")
            source("https://laquali-ufla.github.io/maRS/install.R")
          } else {
            packageStartupMessage("Update skipped by user.\n")
          }
        }
      }
    }, error = function(e) {
    })
  }
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.