run_mars <- function() {
  start_script <- system.file("app", "start.R", package = "maRSpkg")
  
  if (start_script == "") {
    stop("The start.R file was not found in the app folder. Try reinstalling the maRS package.", call. = FALSE)
  }
  
  suppressMessages(source(start_script, chdir = TRUE))
}

runmars <- run_mars
mars_gui <- run_mars
marsgui <- run_mars

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.