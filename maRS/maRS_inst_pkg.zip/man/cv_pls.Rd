\name{cv_pls}
\alias{cv_pls}
\title{Partial Least Squares Regression with Cross-Validation}
\description{
Calibrates Partial Least Squares (PLS) regression models on structured datasets with external train/test splitting, configurable cross-validation, and automatic determination of optimal latent variables.
}
\usage{
cv_pls(
  df,
  ncomp = 1,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5
)
}
\arguments{
  \item{df}{A structured list object (from \code{\link{format_df}} or \code{\link{pre_pro}}) containing \code{xdat} (predictor data frame) and \code{resp} (response data frame).}

  \item{ncomp}{Integer. Maximum number of latent variables/components to fit. Defaults to \code{1}.}

  \item{scale}{Logical. If \code{TRUE}, scales variables to unit variance. Defaults to \code{FALSE}.}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"SPXY"} (Sample distances on X and Y), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric. Percentage of samples assigned to the test set. Defaults to \code{25}.}

  \item{cv}{Character string specifying the cross-validation strategy: \code{"LOO"} (Leave-One-Out), \code{"VB"} (Venetian Blinds), or \code{"RND"} (Random). Defaults to \code{"LOO"}.}

  \item{folds}{Integer. Number of cross-validation segments when \code{cv} is \code{"VB"} or \code{"RND"}. Defaults to \code{5}.}
}
\details{
\code{cv_pls} splits the input dataset into training and testing partitions via \code{split_dataset}. It then calls \code{\link[pls]{plsr}} on the training subset using the specified validation scheme. The function computes Root Mean Squared Error of Cross-Validation (RMSECV) across components.
}
\value{
An object of class \code{\link[pls]{mvr}} extended with metadata elements:
  \item{opt_ncomp}{Integer. Optimal number of components selected based on cross-validation performance.}
  \item{prop_var}{Numeric vector of explained variance per component.}
  \item{df_train}{Training dataset partition.}
  \item{df_test}{Testing dataset partition.}
  \item{model_type}{Character string set to \code{"PLS"}.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 7. Fit final 5-component PLS regression model with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(plscv, ncomp = 5, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 9. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 10. Plot regression coefficients profile across variables (wavelengths)
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", bars = F, orlines = F)

# 11. Plot Variable Importance in Projection (VIP) scores across variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 12. Inspect PLS regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 13. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 14. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)

# 15. Plot parity diagram for prediction results colored by dataset set
plot_parity(plspred, colPa = "set")
}
}