\name{plot_lv_reg}
\alias{plot_lv_reg}
\title{Plot Latent Variable Regression Curves (RMSE and R-squared)}
\description{
Generates diagnostic curves showing regression performance metrics (RMSE or R²) as a function of the number of latent variables (LVs) across calibration, cross-validation, and external test sets.
}
\usage{
plot_lv_reg(
  plsmod,
  plot_cal = TRUE,
  plot_cv = TRUE,
  plot_test = FALSE,
  plot_type = "RMSE",
  val_cex = 0.7
)
}
\arguments{
  \item{plsmod}{A fitted PLS model object (from \code{\link{mod_pls}} or cross-validation routines \code{\link{cv_pls}}, \code{\link{cv_ipls}}, or \code{\link{cv_bvepls}}) containing model predictions across latent variables.}

  \item{plot_cal}{Logical. If \code{TRUE}, plots calibration performance curves. Defaults to \code{TRUE}.}

  \item{plot_cv}{Logical. If \code{TRUE}, plots cross-validation performance curves. Defaults to \code{TRUE}.}

  \item{plot_test}{Logical. If \code{TRUE}, plots external test set performance curves. Automatically forced to \code{FALSE} if no test split was evaluated. Defaults to \code{FALSE}.}

  \item{plot_type}{Character string specifying the metric to plot: \code{"RMSE"} for Root Mean Squared Error or \code{"R2"} for Coefficient of Determination (R²). Defaults to \code{"RMSE"}.}

  \item{val_cex}{Numeric scaling factor controlling font sizes for axis labels, numbers, and legends. Defaults to \code{0.7}.}
}
\details{
\code{plot_lv_reg} computes and plots performance metrics for each component from 1 to the maximum fitted latent variables:
\enumerate{
  \item Evaluates prediction errors for calibration and cross-validation at each component level.
  \item Optionally predicts external test set target values via \code{pred_pls} for each component if \code{plot_test = TRUE}.
  \item Plots line traces for selected partitions with distinct colors (blue for calibration, red for CV, green for test set).
  \item Draws a horizontal legend positioned outside the main plotting region.
}
}

\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")
}
}