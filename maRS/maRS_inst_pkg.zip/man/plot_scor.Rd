\name{plot_scor}
\alias{plot_scor}
\title{Plot Scores for PCA models}
\description{
Generates 2D or 3D scatter plots of sample scores with options for group color-coding, confidence ellipses, marker sizing, and supplementary sample plotting.
}
\usage{
plot_scor(
  mvmod,
  x = 1,
  y = 2,
  z = 0,
  vrot = 25,
  hrot = 40,
  marker = TRUE,
  labels = TRUE,
  group = FALSE,
  elips = FALSE,
  fillelip = TRUE,
  mrksiz = FALSE,
  mrkcol = FALSE,
  adsupscor = FALSE,
  colPa = "Hue",
  val_cex = 0.7,
  grids = FALSE,
  orlines = FALSE
)
}
\arguments{
  \item{mvmod}{A fitted PCA model object obtained using \code{\link{mod_pca}}.}

  \item{x}{Integer. Component index for the x-axis. Defaults to \code{1}.}

  \item{y}{Integer. Component index for the y-axis. Defaults to \code{2}.}

  \item{z}{Integer. Component index for the z-axis. If \code{z > 0}, a 3D score plot is drawn. Defaults to \code{0}.}

  \item{vrot}{Numeric. Vertical rotation angle for 3D plots. Defaults to \code{25}.}

  \item{hrot}{Numeric. Horizontal rotation angle for 3D plots. Defaults to \code{40}.}

  \item{marker}{Logical. Whether to draw point symbols for samples. Defaults to \code{TRUE}.}

  \item{labels}{Logical. Whether to draw sample identifier labels. Defaults to \code{TRUE}.}

  \item{group}{Logical. Whether to color points by group factor levels. Defaults to \code{FALSE}.}

  \item{elips}{Logical. Whether to draw 95\% confidence ellipses per group in 2D plots. Defaults to \code{FALSE}.}

  \item{fillelip}{Logical. Whether to fill confidence ellipses with semi-transparent colors. Defaults to \code{TRUE}.}

  \item{mrksiz}{Logical. Whether to scale marker size proportionally to a continuous feature (\code{scalecol}). Defaults to \code{FALSE}.}

  \item{mrkcol}{Logical. Whether to color markers using a continuous color scale. Defaults to \code{FALSE}.}

  \item{adsupscor}{Logical. Whether to plot supplementary scores if present in \code{mvmod}. Defaults to \code{FALSE}.}

  \item{colPa}{Character. Name of color palette scheme ("hue", "dark", "prism", "spec", "set", "tab"). Defaults to \code{"Hue"}.}

  \item{val_cex}{Numeric. Character expansion factor for labels and axes. Defaults to \code{0.7}.}

  \item{grids}{Logical. Whether to render grid lines. Defaults to \code{FALSE}.}

  \item{orlines}{Logical. Whether to draw zero-reference axes. Defaults to \code{FALSE}.}
}
\details{
\code{plot_scor} handles sample score representations.
}

\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "avocado.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'Variety' and class labels from 'Maturation'
ex_data <- format_df(df = ex_data, headers = T, col_names = "Variety", col_classes = "Maturation")

# 3. Fit PCA model on auto-scaled data with supplementary columns ('Flesh Firmness (N)') and continuous bubble sizing variable ('Oil (\%)')
pcamod <- mod_pca(df = ex_data, scale = T, supcols = "Flesh Firmness (N)", scalecol = "Oil (\%)")

# 4. Plot explained variance across principal components
plot_variance(pcamod)

# 5. Plot 3D score plot (PC1, PC2, PC3) with custom view angles, sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 3, vrot = 25, hrot = 40, marker = T, labels = T, group = T)

# 6. Plot 2D score plot (PC1 vs PC2) with sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, group = T)

# 7. Plot 2D score plot with marker sizes/colors mapped to continuous variable ('Oil (\%)'), origin reference lines, and custom palette
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, mrksiz = T, mrkcol = T, colPa = "spec", orlines = T)

# 8. Plot 3D loadings plot (PC1, PC2, PC3) as loading vectors, including supplementary column loadings
plot_load(pcamod, 1, 2, 3, vectors = T, vrot = 25, hrot = 40, labels = T, adsupload = T)

# 9. Plot 2D loadings plot (PC1 vs PC2) as point markers, including origin lines and supplementary column loadings
plot_load(pcamod, 1, 2, 0, vectors = F, marker = T, adsupload = T, orlines = T)

# 10. Plot 3D biplot combining sample scores and variable loadings (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, z = 3, vrot = 25, hrot = 40, scormarker = T, scorlabels = T, group = T, vectors = T, adsupload = T)

# 11. Plot 2D biplot with score markers sized/colored by continuous variable ('Oil (\%)') and loading vectors (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, mrksiz = T, mrkcol = T, colPa = "spec", vectors = T, adsupload = T)
}
}