\name{cla_metrics}
\alias{cla_metrics}
\title{Calculate Multiclass Classification Diagnostics and Metrics}
\description{
Computes per-class and global performance statistics—including Precision, Specificity, Sensitivity, Accuracy, Efficiency, F1-Score, and Matthews Correlation Coefficient (MCC)—from a confusion matrix.
}
\usage{
cla_metrics(
  cm,
  mod_typ = "NULL"
)
}
\arguments{
  \item{cm}{A square confusion matrix or contingency table where rows represent reference classes and columns represent predicted classes.}

  \item{mod_typ}{Character string indicating model type (e.g., \code{"simca"} to adapt output structure for SIMCA classification models). Defaults to \code{"NULL"}.}
}
\details{
\code{cla_metrics} decomposes multi-class confusion matrices into binary confusion parameters for each class:
\itemize{
  \item \bold{TP}: True Positives
  \item \bold{FP}: False Positives
  \item \bold{FN}: False Negatives
  \item \bold{TN}: True Negatives
}
Using these binary parameters, the following performance metrics are computed for each class:
\itemize{
  \item \bold{PRE} (Precision)
  \item \bold{SPE} (Specificity)
  \item \bold{SEN} (Sensitivity / Recall)
  \item \bold{ACU} (Accuracy)
  \item \bold{EFI} (Efficiency)
  \item \bold{F1S} (F1-Score)
  \item \bold{MCC} (Matthews Correlation Coefficient)
}
Global statistics are calculated by taking macro-averages across per-class metrics alongside overall accuracy and multiclass MCC.
}
\value{
A named list containing:
  \item{per_class}{Numeric matrix containing 11 classification metrics evaluated per class.}
  \item{global}{Numeric vector of macro-averaged global classification performance statistics.}
  \item{confusion}{The input confusion matrix as a numeric matrix.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform cross-validation for PLS-DA modeling (up to 10 LVs) using a random 25\% test set split and LOO-CV
plsdacv <- cv_plsda(df = ex_data, ncomp = 10, spl_type = "RND", pro_test = 25, cv = "LOO")

# 5. Plot classification sensitivity (SEN) across latent variables for calibration and cross-validation sets
plot_lv_da(plsdacv, plot_cal = T, plot_cv = T, plot_type = "SEN")

# 6. Fit final 3-component PLS-DA model with Y-randomization testing (10 repetitions)
plsdamod <- mod_plsda(plsdacv, ncomp = 3, yrand = T, nrep = 10)

# 7. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers and labels
plot_diag(plsdamod, x = "y_hat", y = "leverage", marker = T, labels = T)

# 8. Plot regression coefficients profile for the 'high' target class across descriptors with reference lines
plot_var_imprt(plsdamod, clas = "high", plot_type = "coefficients", xlabel = "descriptors", orlines = T)

# 9. Plot Variable Importance in Projection (VIP) scores across descriptors
plot_var_imprt(plsdamod, plot_type = "VIP", xlabel = "descriptors")

# 10. Plot Discrimination Power / Fractional Rank (FR) values across descriptors
plot_var_imprt(plsdamod, plot_type = "FR", xlabel = "descriptors")

# 11. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsdamod$cal_metrics
plsdamod$cv_metrics
plsdamod$yrand_metrics
plsdamod$test_metrics

# 12. Predict class membership for holdout test dataset
plsdapred <- pred_plsda(plsdamod, plsdamod$df_test)
# Note: You can replace plsdamod$df_test with any new dataset formatted via format_df()

# 13. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(plsdapred$cm)
}
}