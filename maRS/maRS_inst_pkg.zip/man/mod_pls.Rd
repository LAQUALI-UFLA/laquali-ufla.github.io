\name{mod_pls}
\alias{mod_pls}
\alias{pred_pls}
\alias{mv_diag_pls}
\alias{yrand_pls}
\title{Final Calibration, Performance Metrics, and Diagnostics for PLS Models}
\description{
Constructs a final Partial Least Squares (PLS) regression model object from cross-validation outputs (\code{cv_pls}, \code{cv_ipls}, or \code{cv_bvepls}). Computes calibration, cross-validation, and external test metrics, regression coefficients, sample leverage, Studentized residuals, Limit of Detection (LOD), and optional Y-randomization validation.
}
\usage{
mod_pls(
  plscv,
  ncomp = 1,
  yrand = FALSE,
  nrep = 10,
  q_lod = 1
)
}
\arguments{
  \item{plscv}{A fitted cross-validation object produced by \code{\link{cv_pls}}, \code{\link{cv_ipls}}, or \code{\link{cv_bvepls}}.}

  \item{ncomp}{Integer. Selected number of latent variables/components for final predictions and diagnostic calculations. Defaults to \code{1}.}

  \item{yrand}{Logical. If \code{TRUE}, performs Y-randomization iterations to evaluate over-fitting risks. Defaults to \code{FALSE}.}

  \item{nrep}{Integer. Number of Y-randomization permutations executed when \code{yrand = TRUE}. Defaults to \code{10}.}

  \item{q_lod}{Numeric. Coverage factor multiplier used in Limit of Detection (LOD) calculations. Defaults to \code{1}.}
}
\details{
\code{mod_pls} extracts model components at the specified number of latent variables (\code{ncomp}) and performs thorough model evaluation:
\enumerate{
  \item Extracts fitted calibration values (\code{mvcal}) and cross-validation predictions (\code{mvcv}).
  \item Evaluates model predictions on external test set data (\code{mvtes}) using \code{pred_pls} if external splitting was performed.
  \item Extracts regression coefficients including the intercept (\code{b0}).
  \item Computes multivariate sample diagnostics (sample leverage, Studentized residuals, and leverage limits).
  \item Calculates goodness-of-fit regression metrics for calibration, CV, and test sets using \code{reg_metrics}, alongside LOD.
  \item Runs permutation testing if \code{yrand = TRUE}.
  \item The Limit of Detection (LOD) is calculated using the pseudounivariate approach proposed by Ortiz et al. (2003), who implements the definition of the ISO norm 11843 for univariate calibration to multivariate calibration. The method fits a linear regression between predicted and reference values and estimates the LOD from the residual standard error and analytical sensitivity (slope) of this regression, scaled by a Student’s t-based factor that accounts for the desired confidence level and the number of replicates used to obtain the mean signal of the unknown sample. \url{https://doi.org/10.1016/S0169-7439(03)00110-2}
}
}
\value{
An updated PLS model object containing:
  \item{ncomp_sel}{Selected component count used for model evaluation.}
  \item{mvcal}{List containing actual and predicted target values for calibration.}
  \item{mvcv}{List containing actual and predicted target values for cross-validation.}
  \item{mvtes}{List containing actual and predicted target values for external test dataset (or \code{NULL} if no test split was used).}
  \item{coefs}{Vector of regression coefficients including the intercept.}
  \item{mdiag}{List of diagnostic metrics including sample leverages, Studentized residuals, and leverage limits.}
  \item{mvcal_met}{Data frame or vector of calibration regression performance metrics and LOD.}
  \item{mvcv_met}{Data frame or vector of cross-validation performance metrics.}
  \item{mvtes_met}{Data frame or vector of test set performance metrics.}
  \item{mvyrand_met}{Y-randomization performance metrics (present if \code{yrand = TRUE}).}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 7. Fit final 5-component PLS regression model with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(plscv, ncomp = 5, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 9. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 10. Plot regression coefficients profile across variables (wavelengths)
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", bars = F, orlines = F)

# 11. Plot Variable Importance in Projection (VIP) scores across variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 12. Inspect PLS regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 13. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 14. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)

# 15. Plot parity diagram for prediction results colored by dataset set
plot_parity(plspred, colPa = "set")
}
}