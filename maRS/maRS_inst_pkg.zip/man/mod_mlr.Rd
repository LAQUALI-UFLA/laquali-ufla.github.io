\name{mod_mlr}
\alias{mod_mlr}
\alias{pred_mlr}
\alias{mv_diag_mlr}
\alias{yrand_mlr}
\title{Multiple Linear Regression Calibration and Model Diagnostics}
\description{
Calibrates Multiple Linear Regression (MLR) models on structured datasets with automatic train/test dataset splitting, feature preprocessing, cross-validation, Y-randomization, and regression diagnostic calculations.
}
\usage{
mod_mlr(
  df,
  center = FALSE,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5,
  yrand = FALSE,
  nrep = 10,
  q_lod = 1
)
}
\arguments{
  \item{df}{A structured list object (from \code{\link{format_df}} or \code{\link{pre_pro}}) containing \code{xdat} (predictor matrix/data frame) and \code{resp} (single-column response data frame).}

  \item{center}{Logical. If \code{TRUE}, mean-centers the training predictor matrix prior to model fitting. Defaults to \code{FALSE}.}

  \item{scale}{Logical. If \code{TRUE}, scales training predictor variables to unit variance. Automatically forces \code{center = TRUE} when set to \code{TRUE}. Defaults to \code{FALSE}.}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"SPXY"} (Sample distances on X and Y), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric. Percentage of dataset samples reserved for external testing. Defaults to \code{25}.}

  \item{cv}{Character string specifying the cross-validation strategy: \code{"LOO"} (Leave-One-Out), \code{"VB"} (Venetian Blinds), \code{"RND"} (Random segments), or \code{"none"}. Defaults to \code{"LOO"}.}

  \item{folds}{Integer. Number of CV splits or segments used when \code{cv = "VB"} or \code{cv = "RND"}. Defaults to \code{5}.}

  \item{yrand}{Logical. If \code{TRUE}, carries out Y-randomization validation iterations. Defaults to \code{FALSE}.}

  \item{nrep}{Integer. Number of permutations to run when \code{yrand = TRUE}. Defaults to \code{10}.}

  \item{q_lod}{Numeric. Coverage factor multiplier for Limit of Detection (LOD) estimation. Defaults to \code{1}.}
}
\details{
\code{mod_mlr} executes a full quantitative modeling pipeline:
\enumerate{
  \item Splits input dataset into training and testing partitions.
  \item Applies optional mean-centering or unit-variance scaling on training predictor columns.
  \item Fits an ordinary least squares regression model using \code{\link[stats]{lm}}.
  \item Evaluates cross-validation performance with fold-wise preprocessing to prevent data leakage.
  \item Executes external validation on the test set (\code{df_test}) using \code{pred_mlr}.
  \item Computes diagnostic indicators, including sample leverage, Studentized residuals, and threshold limits.
  \item The Limit of Detection (LOD) is calculated using the pseudounivariate approach proposed by Ortiz et al. (2003), who implements the definition of the ISO norm 11843 for univariate calibration to multivariate calibration. The method fits a linear regression between predicted and reference values and estimates the LOD from the residual standard error and analytical sensitivity (slope) of this regression, scaled by a Student’s t-based factor that accounts for the desired confidence level and the number of replicates used to obtain the mean signal of the unknown sample. \url{https://doi.org/10.1016/S0169-7439(03)00110-2}
}
}
\value{
An object \code{"mlrmod"} containing:
  \item{model}{Model details and reference calibration response values.}
  \item{coefficients}{Array of estimated regression coefficients.}
  \item{fitted.values}{Array of calibration fitted target values.}
  \item{mvcal_met}{Performance metrics calculated on calibration data.}
  \item{mvcv_met}{Cross-validation performance metrics (if \code{cv} is not \code{"none"}).}
  \item{mvtes_met}{Test set validation metrics (if test samples exist).}
  \item{mvyrand_met}{Y-randomization performance metrics (if \code{yrand = TRUE}).}
  \item{mdiag}{Diagnostic output list containing leverage values, Studentized residuals, and limits.}
  \item{df_train}{Training dataset split list.}
  \item{df_test}{Testing dataset split list.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "breads.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'acceptance'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "acceptance")

# 3. Fit Multiple Linear Regression (MLR) model on auto-scaled data using Kennard-Stone 25\% test split, LOO-CV, and Y-randomization (10 reps)
mlrmod <- mod_mlr(df = ex_data, scale = T, spl_type = "KS", pro_test = 25, cv = "LOO", yrand = T, nrep = 10)

# 4. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(mlrmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 5. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(mlrmod, cal = T, cv = T, test = T, colPa = "hue")

# 6. Plot variable importance bar chart based on regression coefficients
plot_var_imprt(mlrmod, plot_type = "coefficients", bars = T)

# 7. Inspect multivariate regression performance metrics for calibration, Y-randomization, cross-validation, and test sets
mlrmod$mvcal_met
mlrmod$mvyrand_met
mlrmod$mvcv_met
mlrmod$mvtes_met

# 8. Predict response values for holdout test dataset
mlrpred <- pred_mlr(mlrmod, mlrmod$df_test)
# Note: You can replace mlrmod$df_test with any new dataset formatted via format_df()

# 9. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(mlrpred)

# 10. Plot parity diagram for prediction results colored by dataset set
plot_parity(mlrpred, colPa = "set")
}
}