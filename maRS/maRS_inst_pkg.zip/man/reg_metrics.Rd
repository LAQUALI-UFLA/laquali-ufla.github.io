\name{reg_metrics}
\alias{reg_metrics}
\title{Calculate Regression Performance Metrics}
\description{
Computes quantitative regression metrics—including Root Mean Squared Error (RMSE), Coefficient of Determination (R²), zero-intercept R²0, modified R²m, Relative Standard Deviation (RSD), Residual Predictive Deviation (RPD), and Y-randomization penalized cR²p — for calibration, cross-validation, test sets, or Y-randomization iterations.
}
\usage{
reg_metrics(res)
}
\arguments{
  \item{res}{A list containing observed and predicted response vectors. For standard evaluations, it must contain \code{y_actual} and \code{y_hat}. For Y-randomization evaluations, it contains \code{y_actual}, \code{y_hat_cal}, and permutation vectors named with the prefix \code{"yr"}.}
}
\details{
When passed standard evaluation lists (\code{length(res) == 2}), \code{reg_metrics} calculates performance statistics metrics.

When passed Y-randomization outputs, it averages these metrics across permutations and computes the penalized metric cR²p.
}
\value{
A named numeric vector containing performance statistics:
  \item{R2}{Coefficient of determination.}
  \item{R02}{Zero-intercept coefficient of determination.}
  \item{Rm2}{Modified R² metric.}
  \item{RMSE}{Root mean squared error.}
  \item{RSD}{Relative standard deviation (\%).}
  \item{RPD}{Residual predictive deviation.}
  \item{cR2p}{Penalized Y-randomization metric (returned only for Y-randomization inputs).}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 7. Fit final 5-component PLS regression model with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(plscv, ncomp = 5, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 9. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 10. Plot regression coefficients profile across variables (wavelengths)
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", bars = F, orlines = F)

# 11. Plot Variable Importance in Projection (VIP) scores across variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 12. Inspect PLS regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 13. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 14. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)
}
}