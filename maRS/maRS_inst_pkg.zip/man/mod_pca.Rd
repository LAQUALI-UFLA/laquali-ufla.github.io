\name{mod_pca}
\alias{mod_pca}
\title{Principal Component Analysis}
\description{
Computes Principal Component Analysis (PCA) on a structured list input containing data matrices and metadata. Supports active and supplementary (illustrative) rows and columns, custom scaling variables, automatic explained variance calculation, and metadata tracking.
}
\usage{
mod_pca(
  df,
  ncomp = NULL,
  center = TRUE,
  scale = FALSE,
  suprows = NULL,
  supcols = NULL,
  scalecol = NULL
)
}
\arguments{
  \item{df}{A structured list dataset (derived from \code{\link{format_df}} or \code{\link{pre_pro}}). Must include an element named \code{xdat} (a matrix or data frame of numerical variables). May optionally include \code{groups} (a vector or factor of group classifications, with length equal to \code{nrow(df$xdat)}), \code{row_names} (a vector of row identifiers), and \code{val_col} (a vector of column metadata or labels).}

  \item{ncomp}{An integer specifying the maximum number of principal components to calculate and retain, or \code{NULL}. If \code{NULL}, defaults to \code{min(10, nrow(x) - 1, ncol(x))}, where \code{x} represents the matrix of active rows and columns.}

  \item{center}{Logical. If \code{TRUE}, active variables are centered to zero mean before PCA. Defaults to \code{TRUE}. Note that if \code{scale = TRUE}, \code{center} is automatically forced to \code{TRUE}.}

  \item{scale}{Logical. If \code{TRUE}, active variables are scaled to unit variance before PCA. Defaults to \code{FALSE}.}

  \item{suprows}{A vector of group names (matching values in \code{df$groups}) identifying observations to be treated as supplementary (illustrative) rows. Supplementary rows are excluded from model fitting and are subsequently projected into the principal component space. Requires \code{df$groups} to be defined.}

  \item{supcols}{A vector of column names present in \code{df$xdat} identifying variables to be treated as supplementary (illustrative) columns. Supplementary columns are excluded from active PCA and their loadings are estimated via least-squares projection into the principal component space.}

  \item{scalecol}{A character string indicating the column name in \code{df$xdat} to be extracted as a reference/scale variable. If specified, this column is removed from the active data matrix and saved in the output structure.}
}
\details{
The \code{mod_pca} function wraps R's \code{\link[stats]{prcomp}} engine while providing an integrated workflow for multivariate analysis with metadata preservation:
\itemize{
  \item Active observations and variables construct the core orthogonal axes.
  \item Supplementary rows (\code{suprows}) are projected onto the established principal components using \code{\link[stats]{predict.prcomp}}.
  \item Supplementary columns (\code{supcols}) are centered/scaled consistently and their loadings are projected using matrix regression against the active component scores.
  \item Percentage and cumulative variance explained are calculated and stored directly in percentage format (0-100\%).
}
}
\value{
An object of class \code{\link[stats]{prcomp}} augmented with the following elements:
  \item{prop_var}{Numeric vector containing the percentage of variance explained by each principal component.}
  \item{prop_var_cum}{Numeric vector containing the cumulative percentage of variance explained.}
  \item{row_names}{Vector of row identifiers corresponding to active observations.}
  \item{groups}{Vector/factor of group labels corresponding to active observations.}
  \item{val_col}{Vector of column metadata/values corresponding to active variables.}
  \item{col_names}{Names of active variables used in PCA.}
  \item{suprows}{Vector of group levels designated as supplementary rows.}
  \item{supcols}{Vector of column names designated as supplementary columns.}
  \item{supscor}{Matrix of component scores for supplementary rows (if \code{suprows} is provided).}
  \item{sup_row_names}{Identifiers for supplementary rows.}
  \item{sup_groups}{Group labels for supplementary rows.}
  \item{suprows_supcols}{Matrix containing raw values of supplementary rows across supplementary columns (if both \code{suprows} and \code{supcols} are specified).}
  \item{supload}{Matrix of projected loadings for supplementary variables (if \code{supcols} is provided).}
  \item{sup_col_names}{Names of supplementary columns.}
  \item{scalecol}{Vector of values for the \code{scalecol} variable corresponding to active rows.}
  \item{scalecol_name}{Character string with the name of the \code{scalecol} variable.}
  \item{scalecol_sup}{Vector of values for the \code{scalecol} variable corresponding to supplementary rows.}
}

\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "avocado.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'Variety' and class labels from 'Maturation'
ex_data <- format_df(df = ex_data, headers = T, col_names = "Variety", col_classes = "Maturation")

# 3. Fit PCA model on auto-scaled data with supplementary columns ('Flesh Firmness (N)') and continuous bubble sizing variable ('Oil (\%)')
pcamod <- mod_pca(df = ex_data, scale = T, supcols = "Flesh Firmness (N)", scalecol = "Oil (\%)")

# 4. Plot explained variance across principal components
plot_variance(pcamod)

# 5. Plot 3D score plot (PC1, PC2, PC3) with custom view angles, sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 3, vrot = 25, hrot = 40, marker = T, labels = T, group = T)

# 6. Plot 2D score plot (PC1 vs PC2) with sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, group = T)

# 7. Plot 2D score plot with marker sizes/colors mapped to continuous variable ('Oil (\%)'), origin reference lines, and custom palette
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, mrksiz = T, mrkcol = T, colPa = "spec", orlines = T)

# 8. Plot 3D loadings plot (PC1, PC2, PC3) as loading vectors, including supplementary column loadings
plot_load(pcamod, 1, 2, 3, vectors = T, vrot = 25, hrot = 40, labels = T, adsupload = T)

# 9. Plot 2D loadings plot (PC1 vs PC2) as point markers, including origin lines and supplementary column loadings
plot_load(pcamod, 1, 2, 0, vectors = F, marker = T, adsupload = T, orlines = T)

# 10. Plot 3D biplot combining sample scores and variable loadings (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, z = 3, vrot = 25, hrot = 40, scormarker = T, scorlabels = T, group = T, vectors = T, adsupload = T)

# 11. Plot 2D biplot with score markers sized/colored by continuous variable ('Oil (\%)') and loading vectors (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, mrksiz = T, mrkcol = T, colPa = "spec", vectors = T, adsupload = T)
}
}