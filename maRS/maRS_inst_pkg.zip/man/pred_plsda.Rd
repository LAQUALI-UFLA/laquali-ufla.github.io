\name{pred_plsda}
\alias{pred_plsda}
\title{Predict Class Membership Using Trained PLS-DA Models}
\description{
Predicts categorical target classes for new observations using fitted PLS-DA, BVE-PLS-DA, or iPLS-DA models, supporting automatic preprocessing and variable selection filtering.
}
\usage{
pred_plsda(
  plsdamod,
  df,
  ncomp = NULL,
  prepro = FALSE,
  varsel = FALSE
)
}
\arguments{
  \item{plsdamod}{A fitted PLS-DA model object (from \code{\link{mod_plsda}}, \code{\link{cv_plsda}}, \code{\link{cv_bveplsda}}, or \code{\link{cv_iplsda}}).}

  \item{df}{A dataset list (derived from \code{\link{format_df}} or \code{\link{pre_pro}}) containing predictor matrix \code{xdat} and optionally class vector \code{groups}.}

  \item{ncomp}{Integer. Number of components to use for predictions. If \code{NULL}, uses \code{ncomp_sel} saved within \code{plsdamod}.}

  \item{prepro}{Logical. If \code{TRUE}, transforms \code{df} using saved model preprocessing configurations (\code{ppmet}, \code{sgstp}, \code{mx}).}

  \item{varsel}{Logical. If \code{TRUE}, subsets \code{df$xdat} to match selected variables stored in \code{plsmod$bestVars$vars} (used when predicting with iPLS or BVE-PLS models). Defaults to \code{FALSE}.}
}
\details{
\code{pred_plsda} projects new observation matrices onto trained PLS discriminant spaces:
\enumerate{
  \item Applies saved pre-processing and variable selection parameters to \code{df} if requested.
  \item Obtains raw continuous score matrix predictions.
  \item Computes class label assignments based on maximum predicted continuous score.
  \item Constructs comparative confusion matrices if reference target labels exist in \code{df$groups}.
}
}
\value{
A named list containing:
  \item{class_hat}{Factor vector of predicted class assignments.}
  \item{class_ref}{Factor vector of actual reference classes (returned if \code{df$groups} is present).}
  \item{cm}{Confusion matrix table comparing reference and predicted classes (returned if \code{df$groups} is present).}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform cross-validation for PLS-DA modeling (up to 10 LVs) using a random 25\% test set split and LOO-CV
plsdacv <- cv_plsda(df = ex_data, ncomp = 10, spl_type = "RND", pro_test = 25, cv = "LOO")

# 5. Plot classification sensitivity (SEN) across latent variables for calibration and cross-validation sets
plot_lv_da(plsdacv, plot_cal = T, plot_cv = T, plot_type = "SEN")

# 6. Fit final 3-component PLS-DA model with Y-randomization testing (10 repetitions)
plsdamod <- mod_plsda(plsdacv, ncomp = 3, yrand = T, nrep = 10)

# 7. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers and labels
plot_diag(plsdamod, x = "y_hat", y = "leverage", marker = T, labels = T)

# 8. Plot regression coefficients profile for the 'high' target class across descriptors with reference lines
plot_var_imprt(plsdamod, clas = "high", plot_type = "coefficients", xlabel = "descriptors", orlines = T)

# 9. Plot Variable Importance in Projection (VIP) scores across descriptors
plot_var_imprt(plsdamod, plot_type = "VIP", xlabel = "descriptors")

# 10. Plot Discrimination Power / Fractional Rank (FR) values across descriptors
plot_var_imprt(plsdamod, plot_type = "FR", xlabel = "descriptors")

# 11. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsdamod$cal_metrics
plsdamod$cv_metrics
plsdamod$yrand_metrics
plsdamod$test_metrics

# 12. Predict class membership for holdout test dataset
plsdapred <- pred_plsda(plsdamod, plsdamod$df_test)
# Note: You can replace plsdamod$df_test with any new dataset formatted via format_df()

# 13. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(plsdapred$cm)
}
}