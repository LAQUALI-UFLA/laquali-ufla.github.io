\name{plot_parity}
\alias{plot_parity}
\title{Plot Parity Diagrams (Actual vs. Predicted Response)}
\description{
Generates parity scatter plots comparing observed ground-truth values against predicted target values across calibration, cross-validation, and external testing partitions with an ideal 1:1 reference line.
}
\usage{
plot_parity(
  mvmod,
  cal = TRUE,
  cv = FALSE,
  test = FALSE,
  rnames = FALSE,
  colPa = "Hue",
  val_cex = 0.7
)
}
\arguments{
  \item{mvmod}{A fitted model object (\code{mlrmod} or \code{plsmod}) or a standalone prediction list object.}

  \item{cal}{Logical. If \code{TRUE}, plots calibration predictions (\code{mvmod$mvcal}). Defaults to \code{TRUE}.}

  \item{cv}{Logical. If \code{TRUE}, plots cross-validation predictions (\code{mvmod$mvcv}). Defaults to \code{FALSE}.}

  \item{test}{Logical. If \code{TRUE}, plots external test predictions (\code{mvmod$mvtes}). Defaults to \code{FALSE}.}

  \item{rnames}{Logical. If \code{TRUE}, annotates individual sample points with row names. Defaults to \code{FALSE}.}

  \item{colPa}{Character string indicating the color palette ("hue", "dark", "prism", "spec", "set", "tab"). Defaults to \code{"Hue"}.}

  \item{val_cex}{Numeric scaling factor controlling font and label sizes. Defaults to \code{0.7}.}
}
\details{
\code{plot_parity} aggregates target and predicted values across specified partitions (\code{cal}, \code{cv}, \code{test}) to construct a unified coordinate space. It overlays a solid black 1:1 diagonal line indicating perfect prediction. Points from each dataset partition are colored using distinct palette shades, and an automatic legend is rendered in the top-left corner.
}
\value{
Returns \code{NULL} invisibly.
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 7. Fit final 5-component PLS regression model with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(plscv, ncomp = 5, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 9. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")
}
}