\name{cv_iplsda}
\alias{cv_iplsda}
\title{Interval PLS-DA (iPLS-DA) Variable Selection}
\description{
Performs interval Partial Least Squares Discriminant Analysis (iPLS-DA) using forward selection or backward elimination across sub-intervals of predictor variables to isolate discriminatory spectral regions.
}
\usage{
cv_iplsda(
  df,
  ncomp = 1,
  nint = 10,
  sel_mode = "forward",
  comb_full = TRUE,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5
)
}
\arguments{
  \item{df}{A structured list dataset (derived from \code{\link{format_df}} or \code{\link{pre_pro}}) containing predictor matrix \code{xdat} and target factor \code{groups}.}

  \item{ncomp}{Integer. Maximum number of PLS components to evaluate per interval model.}

  \item{nint}{Integer. Number of equal-width contiguous intervals to partition predictor variables into.}

  \item{sel_mode}{Character string specifying interval selection direction: \code{"forward"} (sequential addition) or \code{"backward"} (sequential elimination).}

  \item{comb_full}{Logical. If \code{TRUE}, evaluates all interval combinations through \code{nint} iterations regardless of local accuracy drops.}

  \item{scale}{Logical. If \code{TRUE}, scales predictor matrix \code{X} to unit variance.}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric value specifying percentage of samples allocated to external testing.}

  \item{cv}{Character string indicating cross-validation scheme: \code{"LOO"} (Leave-One-Out) or \code{"RND"} (Random K-Fold).}

  \item{folds}{Integer specifying the number of folds when \code{cv = "RND"}.}
}
\details{
\code{cv_iplsda} partitions spectral/multivariate data into contiguous intervals to identify informative feature spaces:
\enumerate{
  \item Divides total predictor variables into \code{nint} sub-intervals.
  \item Evaluates individual cross-validated classification performance for each isolated interval.
  \item Sequentially adds (\code{sel_mode = "forward"}) or removes (\code{sel_mode = "backward"}) intervals based on cross-validation accuracy.
  \item Identifies optimal combination of intervals maximizing classification accuracy.
  \item Reconstructs final PLS-DA model restricted to selected interval variables.
}
}
\value{
An enriched PLS-DA model object containing interval selection metadata:
  \item{bestVars}{List containing selected interval indices (\code{ints}), combined variable indices (\code{vars}), optimal latent components (\code{lv}), and optimal accuracy (\code{acu}).}
  \item{intMet}{List detailing combined interval performance metrics per selection iteration.}
  \item{intMet_ind}{Data frame containing standalone baseline performance metrics for each isolated interval.}
  \item{globMet}{List detailing baseline metrics using all predictor variables.}
  \item{cal_metrics}{Calibration metrics across components for selected interval space.}
  \item{cv_metrics}{Cross-validation metrics across components for selected interval space.}
  \item{test_metrics}{External test set metrics for selected interval space (if test set exists).}
  \item{df_train}{Training dataset list updated with reduced predictor matrix.}
  \item{df_test}{Test dataset list updated with reduced predictor matrix.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform interval PLS-DA (iPLS-DA) cross-validation using forward selection (5 intervals, up to 10 LVs, random 25\% test split, LOO-CV)
iplsdacv <- cv_iplsda(df = ex_data, ncomp = 10, nint = 5, sel_mode = "forward", spl_type = "RND", pro_test = 25, cv = "LOO", folds = 5)

# 5. Plot interval PLS-DA performance across evaluated sub-intervals
plot_ipls(iplsdacv, xlabel = 'nm')

# 6. Plot classification accuracy (ACU) across latent variables for calibration and cross-validation sets
plot_lv_da(iplsdacv, plot_cal = T, plot_cv = T, plot_type = "ACU")

# 7. Fit final 4-component PLS-DA model using selected iPLS-DA sub-intervals with Y-randomization testing (10 repetitions)
plsdamod <- mod_plsda(iplsdacv, ncomp = 4, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers and labels
plot_diag(plsdamod, x = "y_hat", y = "leverage", marker = T, labels = T)

# 9. Plot regression coefficients profile for the 'high' target class across descriptors with reference lines
plot_var_imprt(plsdamod, clas = "high", plot_type = "coefficients", xlabel = "descriptors", orlines = T)

# 10. Plot Variable Importance in Projection (VIP) scores across descriptors
plot_var_imprt(plsdamod, plot_type = "VIP", xlabel = "descriptors")

# 11. Plot Discrimination Power / Fractional Rank (FR) values across descriptors
plot_var_imprt(plsdamod, plot_type = "FR", xlabel = "descriptors")

# 12. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsdamod$cal_metrics
plsdamod$cv_metrics
plsdamod$yrand_metrics
plsdamod$test_metrics

# 13. Predict class membership for holdout test dataset
plsdapred <- pred_plsda(plsdamod, plsdamod$df_test)
# Note: You can replace plsdamod$df_test with any new dataset formatted via format_df()

# 14. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(plsdapred$cm)
}
}