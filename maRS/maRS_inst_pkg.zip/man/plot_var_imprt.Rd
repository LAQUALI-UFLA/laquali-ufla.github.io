\name{plot_var_imprt}
\alias{plot_var_imprt}
\title{Plot Variable Importance, Regression Coefficients, or Fisher Ratio}
\description{
Displays feature importance profiles—such as Variable Importance in Projection (VIP), estimated regression coefficients, or Fisher Ratios—across predictor variables or spectral channels for fitted models (\code{mlrmod}, \code{plsmod}, \code{iplsmod}, or \code{bveplsmod}).
}
\usage{
plot_var_imprt(
  mvmod,
  plot_type = "coefficients",
  xlabel = "Variables",
  clas = NULL,
  val_cex = 0.7,
  bars = FALSE,
  grids = FALSE,
  orlines = FALSE
)
}
\arguments{
  \item{mvmod}{A fitted model object created via \code{\link{mod_mlr}} or \code{\link{mod_pls}} (including outputs originating from \code{\link{cv_ipls}} or \code{\link{cv_bvepls}}).}

  \item{plot_type}{Character string specifying the metric to display: \code{"coefficients"} (regression weights), \code{"VIP"} (Variable Importance in Projection), or \code{"FR"} (Fisher Ratio). Defaults to \code{"coefficients"}.}

  \item{xlabel}{Character string for x-axis label. Defaults to \code{"Variables"}.}

  \item{clas}{Integer or character index specifying the target class or column when plotting multi-class coefficients. Defaults to \code{NULL}.}

  \item{val_cex}{Numeric scaling factor controlling font and axis sizes. Defaults to \code{0.7}.}

  \item{bars}{Logical. If \code{TRUE}, renders variable importance as bar charts. If \code{FALSE}, renders a line plot. Defaults to \code{FALSE}.}

  \item{grids}{Logical. If \code{TRUE}, superimposes background grid lines. Defaults to \code{FALSE}.}

  \item{orlines}{Logical. If \code{TRUE}, draws a horizontal line at zero when \code{plot_type = "coefficients"}. Defaults to \code{FALSE}.}
}
\details{
\code{plot_var_imprt} extracts variable-level importance metrics derived from model fits

If variable selection was previously performed (e.g., via iPLS or BVE-PLS), unselected variables are set to zero to highlight retained features along the original predictor grid.
}

\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 7. Fit final 5-component PLS regression model with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(plscv, ncomp = 5, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 9. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 10. Plot regression coefficients profile across variables (wavelengths)
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", bars = F, orlines = F)

# 11. Plot Variable Importance in Projection (VIP) scores across variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")
}
}