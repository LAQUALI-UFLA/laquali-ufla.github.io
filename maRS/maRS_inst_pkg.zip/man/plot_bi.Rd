\name{plot_bi}
\alias{plot_bi}
\title{Biplot Visualization for PCA Models}
\description{
Constructs 2D or 3D biplots overlaying score and loading distributions for multivariate models. Supports automatic loading scaling to match score dimensions and supplementary observations/variables.
}
\usage{
plot_bi(
  mvmod,
  x = 1,
  y = 2,
  z = 0,
  vrot = 25,
  hrot = 40,
  scormarker = TRUE,
  scorlabels = TRUE,
  group = FALSE,
  elips = FALSE,
  fillelip = FALSE,
  mrksiz = FALSE,
  mrkcol = FALSE,
  colPa = "Hue",
  vectors = FALSE,
  loadmarker = TRUE,
  loadlabels = TRUE,
  adsupscor = FALSE,
  adsupload = FALSE,
  val_cex = 0.7,
  grids = FALSE,
  orlines = FALSE
)
}
\arguments{
  \item{mvmod}{A fitted PCA model object obtained using \code{\link{mod_pca}}.}

  \item{x}{Integer. Component index for the x-axis. Defaults to \code{1}.}

  \item{y}{Integer. Component index for the y-axis. Defaults to \code{2}.}

  \item{z}{Integer. Component index for the z-axis. If \code{z > 0}, a 3D biplot is created. Defaults to \code{0} (2D plot).}

  \item{vrot}{Numeric. Vertical rotation angle (phi) for 3D plotting. Defaults to \code{25}.}

  \item{hrot}{Numeric. Horizontal rotation angle (theta) for 3D plotting. Defaults to \code{40}.}

  \item{scormarker}{Logical. Whether to display score markers. Defaults to \code{TRUE}.}

  \item{scorlabels}{Logical. Whether to display score sample names. Defaults to \code{TRUE}.}

  \item{group}{Logical. Whether to color scores by group classifications. Defaults to \code{FALSE}.}

  \item{elips}{Logical. Whether to draw confidence ellipses around groups in 2D. Defaults to \code{FALSE}.}

  \item{fillelip}{Logical. Whether to fill confidence ellipses. Defaults to \code{FALSE}.}

  \item{mrksiz}{Logical. Whether to scale score point sizes based on numeric metadata. Defaults to \code{FALSE}.}

  \item{mrkcol}{Logical. Whether to color score points by a continuous metadata variable. Defaults to \code{FALSE}.}

  \item{colPa}{Character. Color palette ("hue", "dark", "prism", "spec", "set", "tab"). Defaults to \code{"Hue"}.}

  \item{vectors}{Logical. If \code{TRUE}, loadings are displayed as directional vectors/arrows. Defaults to \code{FALSE}.}

  \item{loadmarker}{Logical. Whether to display loading markers. Defaults to \code{TRUE}.}

  \item{loadlabels}{Logical. Whether to display variable names for loadings. Defaults to \code{TRUE}.}

  \item{adsupscor}{Logical. Whether to include supplementary scores if available. Defaults to \code{FALSE}.}

  \item{adsupload}{Logical. Whether to include supplementary loadings if available. Defaults to \code{FALSE}.}

  \item{val_cex}{Numeric. Text magnification factor. Defaults to \code{0.7}.}

  \item{grids}{Logical. Whether to draw background grid lines. Defaults to \code{FALSE}.}

  \item{orlines}{Logical. Whether to draw origin reference lines at zero. Defaults to \code{FALSE}.}
}
\details{
\code{plot_bi} calls \code{plot_scor} internally to render score distributions and automatically scales loadings so that both scores and loadings comfortably fit on the same coordinate axes without visual distortion.
}

\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "avocado.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'Variety' and class labels from 'Maturation'
ex_data <- format_df(df = ex_data, headers = T, col_names = "Variety", col_classes = "Maturation")

# 3. Fit PCA model on auto-scaled data with supplementary columns ('Flesh Firmness (N)') and continuous bubble sizing variable ('Oil (\%)')
pcamod <- mod_pca(df = ex_data, scale = T, supcols = "Flesh Firmness (N)", scalecol = "Oil (\%)")

# 4. Plot explained variance across principal components
plot_variance(pcamod)

# 5. Plot 3D score plot (PC1, PC2, PC3) with custom view angles, sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 3, vrot = 25, hrot = 40, marker = T, labels = T, group = T)

# 6. Plot 2D score plot (PC1 vs PC2) with sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, group = T)

# 7. Plot 2D score plot with marker sizes/colors mapped to continuous variable ('Oil (\%)'), origin reference lines, and custom palette
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, mrksiz = T, mrkcol = T, colPa = "spec", orlines = T)

# 8. Plot 3D loadings plot (PC1, PC2, PC3) as loading vectors, including supplementary column loadings
plot_load(pcamod, 1, 2, 3, vectors = T, vrot = 25, hrot = 40, labels = T, adsupload = T)

# 9. Plot 2D loadings plot (PC1 vs PC2) as point markers, including origin lines and supplementary column loadings
plot_load(pcamod, 1, 2, 0, vectors = F, marker = T, adsupload = T, orlines = T)

# 10. Plot 3D biplot combining sample scores and variable loadings (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, z = 3, vrot = 25, hrot = 40, scormarker = T, scorlabels = T, group = T, vectors = T, adsupload = T)

# 11. Plot 2D biplot with score markers sized/colored by continuous variable ('Oil (\%)') and loading vectors (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, mrksiz = T, mrkcol = T, colPa = "spec", vectors = T, adsupload = T)
}
}