\name{plot_lv_da}
\alias{plot_lv_da}
\title{Plot Performance Metrics Across Latent Variables}
\description{
Generates line plots illustrating classification performance metrics across increasing counts of latent variables (or principal components) for calibration, cross-validation, and test partitions.
}
\usage{
plot_lv_da(
  mvcv,
  plot_cal = TRUE,
  plot_cv = TRUE,
  plot_test = FALSE,
  plot_type = "SEN",
  val_cex = 0.7
)
}
\arguments{
  \item{mvcv}{A cross-validated discriminant model object (e.g., from \code{\link{cv_plsda}}, \code{\link{cv_bveplsda}}, or \code{\link{cv_iplsda}}).}

  \item{plot_cal}{Logical. If \code{TRUE}, plots calibration performance curve.}

  \item{plot_cv}{Logical. If \code{TRUE}, plots cross-validation performance curve.}

  \item{plot_test}{Logical. If \code{TRUE}, plots external test set performance curve.}

  \item{plot_type}{Character string specifying classification metric to display. Options: \code{"PRE"}, \code{"SPE"}, \code{"SEN"}, \code{"ACU"}, \code{"EFI"}, or \code{"F1S"}. Default is \code{"SEN"}.}

  \item{val_cex}{Numeric character expansion multiplier for axis text, labels, and legends.}
}
\details{
\code{plot_lv_da} plots classification performance metric dynamics relative to model complexity (number of components):
\itemize{
  \item Displays metric trends.
  \item Differentiates data partitions via color coding: Blue (Calibration), Red (Cross-Validation), Green (Test).
  \item Adapts x-axis labels depending on model type (\code{"LV"} for PLS-DA models or \code{"PC"} for SIMCA models).
}
}

\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform cross-validation for PLS-DA modeling (up to 10 LVs) using a random 25\% test set split and LOO-CV
plsdacv <- cv_plsda(df = ex_data, ncomp = 10, spl_type = "RND", pro_test = 25, cv = "LOO")

# 5. Plot classification sensitivity (SEN) across latent variables for calibration and cross-validation sets
plot_lv_da(plsdacv, plot_cal = T, plot_cv = T, plot_type = "SEN")
)
}
}