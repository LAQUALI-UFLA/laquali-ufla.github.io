\name{pred_mlr}
\alias{pred_mlr}
\title{Predict Response Values Using a Fitted MLR Model}
\description{
Predicts target response values for new or validation datasets using a fitted Multiple Linear Regression model object.
}
\usage{
pred_mlr(
  mlrmod,
  df,
  prepro = FALSE
)
}
\arguments{
  \item{mlrmod}{A fitted model object of class \code{"mlrmod"} (created via \code{\link{mod_mlr}}).}

  \item{df}{A structured list object (from \code{\link{format_df}} or \code{\link{pre_pro}}) containing \code{xdat} (predictor data frame) and optionally \code{resp} (reference response values).}

  \item{prepro}{Logical. If \code{TRUE}, applies the preprocessing pipeline parameters stored in \code{mlrmod} (\code{ppmet}, \code{sgstp}, and \code{mx}) to \code{df} via \code{\link{pre_pro}} before predicting. Defaults to \code{FALSE}.}
}
\details{
\code{pred_mlr} applies the regression coefficients and data transformations derived during model training to external samples:
\enumerate{
  \item If \code{prepro = TRUE}, executes identical spectral/data preprocessing on \code{df} using parameters saved within \code{mlrmod}.
  \item Centers and scales predictor matrix \code{X} using training offsets (\code{mlrmod$Xmeans}) and scaling factors (\code{mlrmod$scale}).
  \item Computes predicted values (\code{y_hat}) via matrix multiplication with trained regression coefficients (\code{mlrmod$b0} and \code{mlrmod$coefficients}).
  \item Extracts ground-truth reference values (\code{y_actual}) if present in \code{df$resp}.
}
}
\value{
A named list containing:
  \item{y_hat}{Numeric vector of predicted response values.}
  \item{y_actual}{Numeric vector of reference ground-truth values (returned only if \code{df$resp} is available).}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "breads.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'acceptance'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "acceptance")

# 3. Fit Multiple Linear Regression (MLR) model on auto-scaled data using Kennard-Stone 25\% test split, LOO-CV, and Y-randomization (10 reps)
mlrmod <- mod_mlr(df = ex_data, scale = T, spl_type = "KS", pro_test = 25, cv = "LOO", yrand = T, nrep = 10)

# 4. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(mlrmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 5. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(mlrmod, cal = T, cv = T, test = T, colPa = "hue")

# 6. Plot variable importance bar chart based on regression coefficients
plot_var_imprt(mlrmod, plot_type = "coefficients", bars = T)

# 7. Inspect multivariate regression performance metrics for calibration, Y-randomization, cross-validation, and test sets
mlrmod$mvcal_met
mlrmod$mvyrand_met
mlrmod$mvcv_met
mlrmod$mvtes_met

# 8. Predict response values for holdout test dataset
mlrpred <- pred_mlr(mlrmod, mlrmod$df_test)
# Note: You can replace mlrmod$df_test with any new dataset formatted via format_df()

# 9. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(mlrpred)

# 10. Plot parity diagram for prediction results colored by dataset set
plot_parity(mlrpred, colPa = "set")
}
}