\name{cv_bveplsda}
\alias{cv_bveplsda}
\title{Backward Variable Elimination PLS-DA (BVE-PLS-DA)}
\description{
Performs Backward Variable Elimination Partial Least Squares Discriminant Analysis (BVE-PLS-DA) using Variable Importance in Projection (VIP) thresholds to select relevant predictor variables.
}
\usage{
cv_bveplsda(
  df,
  ncomp = 1,
  vip_lim = 1,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5
)
}
\arguments{
  \item{df}{A structured list dataset (derived from \code{\link{format_df}} or \code{\link{pre_pro}}) containing predictor matrix \code{xdat} and target factor \code{groups}.}

  \item{ncomp}{Integer. Maximum number of PLS latent components to evaluate.}

  \item{vip_lim}{Numeric threshold limit for Variable Importance in Projection (VIP). Variables with VIP values below this cutoff are iteratively eliminated.}

  \item{scale}{Logical. If \code{TRUE}, scales predictor matrix \code{X} to unit variance.}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric value specifying percentage of samples allocated to external testing.}

  \item{cv}{Character string indicating cross-validation scheme: \code{"LOO"} (Leave-One-Out) or \code{"RND"} (Random K-Fold).}

  \item{folds}{Integer specifying the number of folds when \code{cv = "RND"}.}
}
\details{
\code{cv_bveplsda} combines PLS discriminant analysis with iterative backward feature elimination:
\enumerate{
  \item Splits input dataset into class-balanced training and testing partitions.
  \item Evaluates baseline cross-validation accuracy across all available variables.
  \item Iteratively computes VIP scores across retained variables.
  \item Removes variables with VIP values \code{vip_lim} at each iteration while safeguarding minimum latent dimension constraints.
  \item Identifies optimal iteration subset yielding peak cross-validation accuracy.
  \item Refits final PLS-DA model using reduced variable subset and records global classification diagnostics.
}
}
\value{
An enriched PLS-DA model object containing variable selection outputs:
  \item{bestVars}{List containing selected variable indices (\code{vars}), optimal latent components (\code{lv}), and achieved accuracy (\code{acu}).}
  \item{varMet}{List detailing variable subsets and performance metric trajectory per elimination step.}
  \item{globMet}{List detailing full-spectrum baseline metrics.}
  \item{cal_metrics}{List of calibration metrics across latent components for reduced space.}
  \item{cv_metrics}{List of cross-validation metrics across latent components for reduced space.}
  \item{test_metrics}{List of test metrics for reduced space (if test set exists).}
  \item{opt_ncomp}{Numeric optimal latent component count detected.}
  \item{df_train}{Training dataset list updated with reduced predictor matrix.}
  \item{df_test}{Test dataset list updated with reduced predictor matrix.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform Bi-Vector Elimination PLS-DA (BVE-PLS-DA) cross-validation for variable selection (VIP threshold = 0.5, up to 10 LVs, random 25\% test split, LOO-CV)
bveplsdacv <- cv_bveplsda(df = ex_data, ncomp = 10, vip_lim = 0.5, spl_type = "RND", pro_test = 25, cv = "LOO")

# 5. Plot BVE-PLS-DA variable selection profile showing selected variables across elimination rounds
plot_bvepls(bveplsdacv, xlabel = 'nm', ylabel = 'absorbance')

# 6. Plot classification accuracy (ACU) across latent variables for calibration and cross-validation sets
plot_lv_da(bveplsdacv, plot_cal = T, plot_cv = T, plot_type = "ACU")

# 7. Fit final 3-component PLS-DA model using BVE-PLS-DA selected variables with Y-randomization testing (10 repetitions)
plsdamod <- mod_plsda(bveplsdacv, ncomp = 3, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers and labels
plot_diag(plsdamod, x = "y_hat", y = "leverage", marker = T, labels = T)

# 9. Plot regression coefficients profile for the 'high' target class across descriptors with reference lines
plot_var_imprt(plsdamod, clas = "high", plot_type = "coefficients", xlabel = "descriptors", orlines = T)

# 10. Plot Variable Importance in Projection (VIP) scores across descriptors
plot_var_imprt(plsdamod, plot_type = "VIP", xlabel = "descriptors")

# 11. Plot Discrimination Power / Fractional Rank (FR) values across descriptors
plot_var_imprt(plsdamod, plot_type = "FR", xlabel = "descriptors")

# 12. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsdamod$cal_metrics
plsdamod$cv_metrics
plsdamod$yrand_metrics
plsdamod$test_metrics

# 13. Predict class membership for holdout test dataset
plsdapred <- pred_plsda(plsdamod, plsdamod$df_test)
# Note: You can replace plsdamod$df_test with any new dataset formatted via format_df()

# 14. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(plsdapred$cm)
}
}