\name{cv_bvepls}
\alias{cv_bvepls}
\title{Backward Variable Elimination PLS (BVE-PLS)}
\description{
Performs Backward Variable Elimination Partial Least Squares (BVE-PLS) variable selection based on Variable Importance in Projection (VIP) threshold filtering.
}
\usage{
cv_bvepls(
  df,
  ncomp = 1,
  vip_lim = 1,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5
)
}
\arguments{
  \item{df}{A structured list object (from \code{\link{format_df}} or \code{\link{pre_pro}}) containing \code{xdat} and \code{resp}.}

  \item{ncomp}{Integer. Maximum number of latent variables to consider. Defaults to \code{1}.}

  \item{vip_lim}{Numeric. Threshold value for VIP scores below which variables are iteratively eliminated. Defaults to \code{1}.}

  \item{scale}{Logical. If \code{TRUE}, scales variables to unit variance. Defaults to \code{FALSE}.}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"SPXY"} (Sample distances on X and Y), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric. Percentage of samples set aside for external testing. Defaults to \code{25}.}

  \item{cv}{Character string specifying the cross-validation strategy: \code{"LOO"} (Leave-One-Out), \code{"VB"} (Venetian Blinds), or \code{"RND"} (Random). Defaults to \code{"LOO"}.}

  \item{folds}{Integer. CV segments when \code{cv} is \code{"VB"} or \code{"RND"}. Defaults to \code{5}.}
}
\details{
\code{cv_bvepls} iteratively fits PLS models, calculates VIP scores for active variables, and discards predictors with VIP scores under \code{vip_lim}. It tracks RMSECV across iteration cycles and refits a final PLS model using the variable subset that minimizes cross-validation error.
}
\value{
An \code{\link[pls]{mvr}} object with embedded BVE elimination results:
  \item{varMet}{List detailing variable subsets, optimal LVs, RMSECV, and R² across elimination iterations.}
  \item{bestVars}{List containing the optimal retained variable indices, component counts, and metrics.}
  \item{globMet}{Baseline PLS metrics calculated on the complete variable set.}
  \item{df_train}{Training data subsetted to retained variables.}
  \item{df_test}{Testing data subsetted to retained variables.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform Bi-Vector Elimination PLS (BVE-PLS) cross-validation for variable selection (VIP threshold = 0.3, up to 15 LVs, Kennard-Stone 25\% test split, 5-fold Venetian Blind CV)
bveplscv <- cv_bvepls(df = ex_data, ncomp = 15, vip_lim = 0.3, spl_type = "KS", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot BVE-PLS variable selection profile showing selected variables across elimination rounds
plot_bvepls(bveplscv, xlabel = 'nm', ylabel = 'absorbance')

# 6. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(bveplscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 7. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(bveplscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 8. Fit final 7-component PLS model using BVE-PLS selected variables with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(bveplscv, ncomp = 7, yrand = T, nrep = 10)

# 9. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 10. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 11. Plot regression coefficients profile across selected variables (wavelengths) with reference lines
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", orlines = T)

# 12. Plot Variable Importance in Projection (VIP) scores across selected variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 13. Inspect PLS regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 14. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 15. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)

# 16. Plot parity diagram for prediction results colored by dataset set
plot_parity(plspred, colPa = "set")
}
}