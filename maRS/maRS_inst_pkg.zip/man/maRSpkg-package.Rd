\name{maRSpkg-package}
\alias{maRSpkg-package}
\alias{maRSpkg}
\docType{package}
\title{
  maRS
}
\description{
maRS provides tools for multivariate data analysis, including pattern recognition, classification, regression, and other related analytical applications.

\subsection{Accessing maRS}{
The maRS package can be accessed through either its graphical interface
or as a traditional R package.

\itemize{
  \item \strong{Graphical interface:}
  Launch maRS from the shortcut available in the Start Menu or Application
  Launcher, or start the graphical interface from R with:

  \preformatted{
  library(maRSpkg)
  mars_gui()
  }

  \item \strong{Traditional R package:}
  Use maRS as a regular R package and access its documentation with:

  \preformatted{
  library(maRSpkg)
  help(maRSpkg)
  }
}
}

\subsection{Data Import and Formatting}{
All analysis functions of maRS rely on datasets formatted using the \code{format_df} function. The first step is to import a data file, such as \code{.xls}, \code{.xlsx}, \code{.txt}, \code{.dat}, or \code{.csv}. The first row of the dataset must contain the column headers. After import, the dataset must be formatted using the \code{format_df} function by specifying the following columns:
\itemize{
\item \code{col_names}: Selects the column containing the identifiers for the samples (optional).
\item \code{col_classes}: Selects the column containing categorical group labels or classes (optional, but required for classification methods, coloring graphs by class, or selecting supplementary rows in PCA). For SIMCA, the dataset may contain both target and non-target objects. However, only target-class objects are used to build the model, whereas non-target objects are used for prediction and model evaluation.
\item \code{col_resp}: Selects the column containing the dependent or target quantitative variable (optional, but required for regression methods).
\item \code{col_split}: Selects the column indicating the assignment of samples to the calibration and test sets (optional). This column must contain only the lowercase values \code{"train"} and \code{"test"}. Any other entries will trigger an error.
}
}
\subsection{Oversampling}{
maRS provides functions to address class imbalance in datasets by generating synthetic samples for minority classes using either the SMOTE (Synthetic Minority Over-sampling Technique) or ADASYN (Adaptive Synthetic) algorithms. The function calls the respective algorithm from the \code{SMOTEWB} R package to dynamically generate new synthetic feature vectors and their corresponding class labels.
}
\subsection{Hierarchical Cluster Analysis}{
The core distance calculations and hierarchical linkage procedures in Hierarchical Cluster Analysis (HCA) are performed using the base R \code{stats} package, while advanced customization of the resulting dendrogram is provided by the \code{dendextend} package.
}
\subsection{Principal Component Analysis}{
Principal Component Analysis (PCA) uses the \code{prcomp} function from the base R \code{stats} package, which centers the data (mean = 0) and optionally scales it (variance = 1) before applying Singular Value Decomposition (SVD) to obtain scores and loadings. In addition to standard PCA, the functions support supplementary rows and columns, with the model computed solely from active data and supplementary observations subsequently projected into the established component space without influencing the model structure.
}
\subsection{MLR and PLS}{
Multiple Linear Regression (MLR) modeling is performed using the standard \code{lm} function from the base R \code{stats} package. Partial Least Squares (PLS) regression is implemented using the \code{pls} R package with the default Kernel PLS algorithm, which yields results equivalent to NIPALS while requiring less computational time. For Multiple Linear Regression--Discriminant Analysis (MLR-DA) and Partial Least Squares--Discriminant Analysis (PLS-DA), class labels are first converted into a binary indicator (dummy) matrix, where each column represents a class. The model establishes a relationship between the predictor variables and the dummy responses, generating a predicted response for each class. Classification is then performed by assigning each sample to the class associated with the highest predicted response (FERREIRA, 2026).
}
\subsection{Interval PLS (iPLS)}{
The implemented procedure begins by dividing the predictor matrix into a user-defined number of intervals. The predictive performance (RMSE for regression or accuracy for classification) of each interval is first evaluated individually using cross-validated PLS models. Depending on the selected search strategy, the algorithm iteratively constructs an optimal variable subset either by progressively adding the most informative intervals (Forward mode) or by systematically removing intervals that negatively affect model performance (Backward mode).
In Forward mode, each interval is initially evaluated individually, and the one providing the best predictive performance is selected as the starting point. This interval is then combined, one at a time, with each of the remaining intervals, retaining the combination that provides the best performance. The procedure is repeated by adding one new interval at each iteration until no additional intervals are available for inclusion.
In Backward mode, the algorithm starts with a model containing all intervals. At each iteration, the removal of each interval is individually simulated, and the predictive performance of the model built with the remaining intervals is evaluated. The interval whose exclusion provides the best performance is permanently removed, and the procedure is repeated until only one interval remains.
In both modes, all iterations are performed regardless of changes in predictive performance during the search. Finally, the complete search history is analyzed, and the interval combination that achieved the best predictive performance is selected (NØRGAARD et al., 2000).
}
\subsection{Backward Variable Elimination PLS (BVE-PLS)}{
The implemented procedure begins by training a baseline PLS model using the full dataset to calculate the Variable Importance in Projection (VIP) score for each variable. Variables with VIP scores below a predefined threshold are systematically removed, and the model is retrained using the remaining variables. This process is repeated until the number of retained variables is less than or equal to the specified maximum number of latent variables plus one.
After completion, the algorithm reviews the entire iteration history, selects the variable subset associated with the best-performing iteration (lowest RMSE in regression or highest accuracy in classification), and builds the final PLS model using this optimal subset.
}
\subsection{SIMCA}{
The SIMCA functions provide a framework for one-class classification using the Soft Independent Modeling of Class Analogy (SIMCA) method. Three classification approaches are available: classical SIMCA, based on Hotelling's (T²) and Jackson--Mudholkar (Q) decision limits (JACKSON and MUDHOLKAR, 1979; JACKSON, 1991); Data-Driven SIMCA (DD-SIMCA); and robust DD-SIMCA (POMERANTSEV and RODIONOVA, 2020; KUCHERYAVSKIY et al., 2024). The implementation is based on methods available in the \code{mdatools} R package (KUCHERYAVSKIY, 2020).
}
\subsection{Data Partitioning (Test Set Selection)}{
To evaluate the model's external predictive capability, the dataset can be partitioned into calibration and test sets using one of four distinct selection methods. Kennard--Stone is a deterministic algorithm that selects samples by maximizing the Euclidean distance between them in the X-space. SPXY (Sample set Partitioning based on joint X-y distances) extends this approach by calculating distances using both the predictor (X) and response (y) variables simultaneously. Alternatively, the Randomized method assigns samples purely by chance according to the defined test-set percentage, while the Split Indicator offers full manual control, enabling the exact partition to be specified by selecting a pre-configured categorical column directly from the dataset (Split Indicator column in the Data function).
}
\subsection{Cross-Validation Strategies}{
For internal model validation and optimal complexity selection, the calibration set undergoes resampling using three available cross-validation strategies. Leave-One-Out is an exhaustive method in which a single sample is held out as the validation set while the model is trained on the remaining data, repeating this process until every sample has been predicted exactly once.
Venetian Blinds is a systematic cross-validation approach that divides the samples into interleaved folds according to their order in the dataset. This ensures that each fold contains samples distributed across the entire data range, allowing the validation sets to capture the overall gradient of the dataset, for example, when samples are arranged according to increasing values of the response variable (Y).
Finally, the Randomized approach randomly shuffles and divides the samples into a user-specified number of mutually exclusive folds.
}
\subsection{Performance Metrics for Classification}{
The calculation of classification metrics is fundamentally based on the evaluation of a confusion matrix. For multiclass problems, a One-vs-Rest approach is used, decomposing the task into a set of binary evaluations. The procedure computes True Positives, True Negatives, False Positives, and False Negatives. Using these four foundational components, it computes a set of performance metrics for each individual class (SOKOLOVA and LAPALME, 2009), including Sensitivity (SEN), Specificity (SPE), Precision (PRE), Efficiency (EFI), Accuracy (ACU), F1-Score (F1S), and Matthews Correlation Coefficient (MCC).
EFI is calculated as the arithmetic mean of sensitivity and specificity. Global PRE, SPE, SEN, EFI, and F1S are obtained by macro-averaging the class-wise values. Global ACU is calculated as the proportion of correctly classified samples, and global MCC is computed using the formulation proposed by Gorodkin (2004).
The procedure includes a conditional adaptation for one-class models, such as SIMCA, by automatically isolating and reporting only the performance metrics of the modeled target class. Fisher Ratio is also computed as a global measure that considers all classes simultaneously. For each variable, it is defined as the ratio between the between-class variance and the within-class variance, both computed across all classes.
}
\subsection{Performance Metrics for Regression}{
The regression metrics include RMSE (Root Mean Squared Error) and R² (coefficient of determination). Furthermore, the procedure normalizes the absolute error to allow for practical assessment using RSD (Relative Standard Deviation) and RPD (Residual Predictive Deviation). To rigorously verify that the model's predictions align closely with the ideal 1:1 target line, it calculates R²0 (forcing the linear fit through the origin) and r²m, which mathematically penalizes the model if its trend line deviates significantly from the perfect diagonal.
When evaluating y-randomization (permutation) tests, the procedure averages these metrics across all shuffled datasets and computes the specialized cR²p metric (ROY and MITRA, 2011). The Limit of Detection (LOD) is calculated using the pseudounivariate approach proposed by Ortiz et al. (2003), which implements the definition of the ISO 11843 standard for univariate calibration in multivariate calibration. The method fits a linear regression between predicted and reference values and estimates the LOD from the residual standard error and analytical sensitivity (slope) of this regression, scaled by a Student's t-based factor that accounts for the desired confidence level and the number of replicates used to obtain the mean signal of the unknown sample.
}
\if{html}{\out{
  <p><b><a href="00Index.html">Index of functions</a></b></p>
}}
}
\references{
\itemize{
\item FERREIRA, M. M. C. Chemometrics IV. Pattern recognition: discriminant and class modelling methods. When to use them and which one. Química Nova, v. 49, e-20260072, p. 1--16, 2026.
\url{https://doi.org/10.21577/0100-4042.20260072}
\item GORODKIN, J. Comparing two K-category assignments by a K-category correlation coefficient. Computational Biology and Chemistry, v. 28, n. 5--6, p. 367--374, 2004.
\url{https://doi.org/10.1016/j.compbiolchem.2004.09.006}
\item JACKSON, J. E. A User's Guide to Principal Components. New York: John Wiley \& Sons, 1991.
\url{https://doi.org/10.1002/0471725331}
\item JACKSON, J. E.; MUDHOLKAR, G. S. Control Procedures for Residuals Associated with Principal Component Analysis. Technometrics, v. 21, p. 341--349, 1979.
\url{https://doi.org/10.1080/00401706.1979.10489779}
\item KUCHERYAVSKIY, S. mdatools -- R package for chemometrics. Chemometrics and Intelligent Laboratory Systems, v. 198, art. 103937, 2020.
\url{https://doi.org/10.1016/j.chemolab.2020.103937}
\item KUCHERYAVSKIY, S.; RODIONOVA, O.; POMERANTSEV, A. A comprehensive tutorial on Data-Driven SIMCA: Theory and implementation in web. Journal of Chemometrics, v. 38, e3556, 2024.
\url{https://doi.org/10.1002/cem.3556}
\item NØRGAARD, L.; SAUDLAND, A.; WAGNER, J.; NIELSEN, J. P.; MUNCK, L.; ENGELSEN, S. B. Interval Partial Least-Squares Regression (iPLS): A Comparative Chemometric Study with an Example from Near-Infrared Spectroscopy. Applied Spectroscopy, v. 54, p. 413--419, 2000.
\url{https://doi.org/10.1366/0003702001949500}
\item ORTIZ, M. C.; SARABIA, L. A.; HERRERO, A.; SÁNCHEZ, M. S.; SANZ, M. B.; ROCA, M. Capability of detection of an analytical method evaluating false positive and false negative decisions (ISO 11843) by partial least squares calibration in multivariate analysis. Chemometrics and Intelligent Laboratory Systems, v. 69, p. 21--33, 2003.
\url{https://doi.org/10.1016/S0169-7439(03)00110-2}
\item POMERANTSEV, A. L.; RODIONOVA, O. Y. Popular decision rules in SIMCA: Critical review. Journal of Chemometrics, v. 34, e3250, 2020.
\url{https://doi.org/10.1002/cem.3250}
\item ROY, K.; MITRA, I. On Various Metrics Used for Validation of Predictive QSAR Models with Applications in Virtual Screening and Focused Library Design. Combinatorial Chemistry \& High Throughput Screening, v. 14, p. 450--474, 2011.
\url{https://doi.org/10.2174/138620711795767893}
\item SOKOLOVA, M.; LAPALME, G. A Systematic Analysis of Performance Measures for Classification Tasks. Information Processing \& Management, v. 45, p. 427--437, 2009.
\url{https://doi.org/10.1016/j.ipm.2009.03.002}
}
}
\examples{
\dontrun{
#############################################
# Format data frame structure for use in maRS
#############################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "avocado.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'Variety' and class labels from 'Maturation'
ex_data <- format_df(df = ex_data, headers = T, col_names = "Variety", col_classes = "Maturation")

# -----------------------

# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "breads.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'acceptance'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "acceptance")

# -----------------------

# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample classes from 'quality' column
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# -----------------------

# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# -----------------------

# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'brand' and class labels from 'status'
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

##########################################################
# Plot profile or spectral lines for standardized datasets
##########################################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample classes from 'quality' column
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Plot raw spectra (unscaled) colored by class groups with custom axis labels
plot_lines(df = ex_data, scale = F, xlabel = "nm", ylabel = "absorbance", col_groups = TRUE)

##########################################################
# Spectral data preprocessing for standardized data frames
##########################################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

############################################
# Synthetic oversampling for class imbalance
############################################
# Step A: Import and Raw Data 
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

# Step B: Generate Synthetic Samples 
df_synth <- synt_oversamp(ex_data, method = "ADASYN", k = 3)

# Step C: Save Oversampled Dataset to Excel 
writexl::write_xlsx(as.data.frame(df_synth), path = "oversampleddataset.xlsx")

# Step D: Read and Restructure Saved Excel Dataset 
ovrs_data <- readxl::read_excel("oversampleddataset.xlsx")
ovrs_data <- format_df(df = ovrs_data, headers = T, col_names = "obj", col_classes = "classes")

#####################################
# Hierarchical Cluster Analysis - HCA
#####################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "avocado.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'Variety' and class labels from 'Maturation'
ex_data <- format_df(df = ex_data, headers = T, col_names = "Variety", col_classes = "Maturation")

# 3. Perform Hierarchical Cluster Analysis (HCA) using auto-scaled data, average linkage, custom color palette, and vertical dendrogram layout
run_hca(df = ex_data, scale = T, linkage='average', ngroups=1, horiz=F, colPa="spec")

####################################
# Principal Component Analysis - PCA
####################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "avocado.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'Variety' and class labels from 'Maturation'
ex_data <- format_df(df = ex_data, headers = T, col_names = "Variety", col_classes = "Maturation")

# 3. Fit PCA model on auto-scaled data with supplementary columns ('Flesh Firmness (N)') and continuous bubble sizing variable ('Oil (\%)')
pcamod <- mod_pca(df = ex_data, scale = T, supcols = "Flesh Firmness (N)", scalecol = "Oil (\%)")

# 4. Plot explained variance across principal components
plot_variance(pcamod)

# 5. Plot 3D score plot (PC1, PC2, PC3) with custom view angles, sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 3, vrot = 25, hrot = 40, marker = T, labels = T, group = T)

# 6. Plot 2D score plot (PC1 vs PC2) with sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, group = T)

# 7. Plot 2D score plot with marker sizes/colors mapped to continuous variable ('Oil (\%)'), origin reference lines, and custom palette
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, mrksiz = T, mrkcol = T, colPa = "spec", orlines = T)

# 8. Plot 3D loadings plot (PC1, PC2, PC3) as loading vectors, including supplementary column loadings
plot_load(pcamod, 1, 2, 3, vectors = T, vrot = 25, hrot = 40, labels = T, adsupload = T)

# 9. Plot 2D loadings plot (PC1 vs PC2) as point markers, including origin lines and supplementary column loadings
plot_load(pcamod, 1, 2, 0, vectors = F, marker = T, adsupload = T, orlines = T)

# 10. Plot 3D biplot combining sample scores and variable loadings (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, z = 3, vrot = 25, hrot = 40, scormarker = T, scorlabels = T, group = T, vectors = T, adsupload = T)

# 11. Plot 2D biplot with score markers sized/colored by continuous variable ('Oil (\%)') and loading vectors (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, mrksiz = T, mrkcol = T, colPa = "spec", vectors = T, adsupload = T)

##################################
# Multiple Linear Regression - MLR
##################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "breads.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'acceptance'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "acceptance")

# 3. Fit Multiple Linear Regression (MLR) model on auto-scaled data using Kennard-Stone 25\% test split, LOO-CV, and Y-randomization (10 reps)
mlrmod <- mod_mlr(df = ex_data, scale = T, spl_type = "KS", pro_test = 25, cv = "LOO", yrand = T, nrep = 10)

# 4. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(mlrmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 5. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(mlrmod, cal = T, cv = T, test = T, colPa = "hue")

# 6. Plot variable importance bar chart based on regression coefficients
plot_var_imprt(mlrmod, plot_type = "coefficients", bars = T)

# 7. Inspect multivariate regression performance metrics for calibration, Y-randomization, cross-validation, and test sets
mlrmod$mvcal_met
mlrmod$mvyrand_met
mlrmod$mvcv_met
mlrmod$mvtes_met

# 8. Predict response values for holdout test dataset
mlrpred <- pred_mlr(mlrmod, mlrmod$df_test)
# Note: You can replace mlrmod$df_test with any new dataset formatted via format_df()

# 9. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(mlrpred)

# 10. Plot parity diagram for prediction results colored by dataset set
plot_parity(mlrpred, colPa = "set")

#############################
# Partial Least Squares - PLS
#############################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 7. Fit final 5-component PLS regression model with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(plscv, ncomp = 5, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 9. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 10. Plot regression coefficients profile across variables (wavelengths)
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", bars = F, orlines = F)

# 11. Plot Variable Importance in Projection (VIP) scores across variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 12. Inspect PLS regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 13. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 14. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)

# 15. Plot parity diagram for prediction results colored by dataset set
plot_parity(plspred, colPa = "set")

#####################
# Interval PLS - iPLS
#####################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform interval PLS (iPLS) cross-validation using forward selection (10 intervals, up to 10 LVs, Kennard-Stone 25\% test split, 5-fold Venetian Blind CV)
iplscv <- cv_ipls(df = ex_data, ncomp = 10, nint = 10, sel_mode = "forward", spl_type = "KS", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot interval PLS performance (RMSECV) across evaluated sub-intervals
plot_ipls(iplscv, xlabel = 'nm')

# 6. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(iplscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 7. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(iplscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 8. Fit final 5-component PLS model using the selected iPLS sub-intervals with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(iplscv, ncomp = 5, yrand = T, nrep = 10)

# 9. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 10. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 11. Plot regression coefficients profile across variables (wavelengths) with reference lines
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", orlines = T)

# 12. Plot Variable Importance in Projection (VIP) scores across variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 13. Inspect regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 14. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 15. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)

# 16. Plot parity diagram for prediction results colored by dataset set
plot_parity(plspred, colPa = "set")

#############################################
# Backward Variable Elimination PLS - BVE/PLS
#############################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform Bi-Vector Elimination PLS (BVE-PLS) cross-validation for variable selection (VIP threshold = 0.3, up to 15 LVs, Kennard-Stone 25\% test split, 5-fold Venetian Blind CV)
bveplscv <- cv_bvepls(df = ex_data, ncomp = 15, vip_lim = 0.3, spl_type = "KS", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot BVE-PLS variable selection profile showing selected variables across elimination rounds
plot_bvepls(bveplscv, xlabel = 'nm', ylabel = 'absorbance')

# 6. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(bveplscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 7. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(bveplscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 8. Fit final 7-component PLS model using BVE-PLS selected variables with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(bveplscv, ncomp = 7, yrand = T, nrep = 10)

# 9. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 10. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 11. Plot regression coefficients profile across selected variables (wavelengths) with reference lines
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", orlines = T)

# 12. Plot Variable Importance in Projection (VIP) scores across selected variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 13. Inspect PLS regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 14. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 15. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)

# 16. Plot parity diagram for prediction results colored by dataset set
plot_parity(plspred, colPa = "set")

####################################
# MLR Discriminant Analysis - MLR-DA
####################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'brand' and class labels from 'status'
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

# 3. Fit Multiple Linear Regression Discriminant Analysis (MLR-DA) model on auto-scaled data using Kennard-Stone 25\% test split, LOO-CV, and Y-randomization (10 reps)
mlrdamod <- mod_mlrda(df = ex_data, scale = T, spl_type = "KS", pro_test = 25, cv = "LOO", yrand = T, nrep = 10)

# 4. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers, labels, and reference lines
plot_diag(mlrdamod, x = "y_hat", y = "leverage", marker = T, labels = T, orlines = T)

# 5. Plot variable importance bar chart based on regression coefficients for the 'expired' target class
plot_var_imprt(mlrdamod, clas = "expired", plot_type = "coefficients", bars = T)

# 6. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
mlrdamod$cal_metrics
mlrdamod$cv_metrics
mlrdamod$yrand_metrics
mlrdamod$test_metrics

# 7. Predict class membership for holdout test dataset
ldapred <- pred_mlrda(mlrdamod, mlrdamod$df_test)
# Note: You can replace mlrdamod$df_test with any new dataset formatted via format_df()

# 8. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(ldapred$cm)

######################################################
# Partial Least Squares Discriminant Analysis - PLS-DA
######################################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform cross-validation for PLS-DA modeling (up to 10 LVs) using a random 25\% test set split and LOO-CV
plsdacv <- cv_plsda(df = ex_data, ncomp = 10, spl_type = "RND", pro_test = 25, cv = "LOO")

# 5. Plot classification sensitivity (SEN) across latent variables for calibration and cross-validation sets
plot_lv_da(plsdacv, plot_cal = T, plot_cv = T, plot_type = "SEN")

# 6. Fit final 3-component PLS-DA model with Y-randomization testing (10 repetitions)
plsdamod <- mod_plsda(plsdacv, ncomp = 3, yrand = T, nrep = 10)

# 7. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers and labels
plot_diag(plsdamod, x = "y_hat", y = "leverage", marker = T, labels = T)

# 8. Plot regression coefficients profile for the 'high' target class across descriptors with reference lines
plot_var_imprt(plsdamod, clas = "high", plot_type = "coefficients", xlabel = "descriptors", orlines = T)

# 9. Plot Variable Importance in Projection (VIP) scores across descriptors
plot_var_imprt(plsdamod, plot_type = "VIP", xlabel = "descriptors")

# 10. Plot Discrimination Power / Fractional Rank (FR) values across descriptors
plot_var_imprt(plsdamod, plot_type = "FR", xlabel = "descriptors")

# 11. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsdamod$cal_metrics
plsdamod$cv_metrics
plsdamod$yrand_metrics
plsdamod$test_metrics

# 12. Predict class membership for holdout test dataset
plsdapred <- pred_plsda(plsdamod, plsdamod$df_test)
# Note: You can replace plsdamod$df_test with any new dataset formatted via format_df()

# 13. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(plsdapred$cm)

###########################
# Interval PLS-DA - iPLS-DA
###########################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform interval PLS-DA (iPLS-DA) cross-validation using forward selection (5 intervals, up to 10 LVs, random 25\% test split, LOO-CV)
iplsdacv <- cv_iplsda(df = ex_data, ncomp = 10, nint = 5, sel_mode = "forward", spl_type = "RND", pro_test = 25, cv = "LOO", folds = 5)

# 5. Plot interval PLS-DA performance across evaluated sub-intervals
plot_ipls(iplsdacv, xlabel = 'nm')

# 6. Plot classification accuracy (ACU) across latent variables for calibration and cross-validation sets
plot_lv_da(iplsdacv, plot_cal = T, plot_cv = T, plot_type = "ACU")

# 7. Fit final 4-component PLS-DA model using selected iPLS-DA sub-intervals with Y-randomization testing (10 repetitions)
plsdamod <- mod_plsda(iplsdacv, ncomp = 4, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers and labels
plot_diag(plsdamod, x = "y_hat", y = "leverage", marker = T, labels = T)

# 9. Plot regression coefficients profile for the 'high' target class across descriptors with reference lines
plot_var_imprt(plsdamod, clas = "high", plot_type = "coefficients", xlabel = "descriptors", orlines = T)

# 10. Plot Variable Importance in Projection (VIP) scores across descriptors
plot_var_imprt(plsdamod, plot_type = "VIP", xlabel = "descriptors")

# 11. Plot Discrimination Power / Fractional Rank (FR) values across descriptors
plot_var_imprt(plsdamod, plot_type = "FR", xlabel = "descriptors")

# 12. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsdamod$cal_metrics
plsdamod$cv_metrics
plsdamod$yrand_metrics
plsdamod$test_metrics

# 13. Predict class membership for holdout test dataset
plsdapred <- pred_plsda(plsdamod, plsdamod$df_test)
# Note: You can replace plsdamod$df_test with any new dataset formatted via format_df()

# 14. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(plsdapred$cm)

###################################################
# Backward Variable Elimination PLS-DA - BVE/PLS-DA
###################################################
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform Bi-Vector Elimination PLS-DA (BVE-PLS-DA) cross-validation for variable selection (VIP threshold = 0.5, up to 10 LVs, random 25\% test split, LOO-CV)
bveplsdacv <- cv_bveplsda(df = ex_data, ncomp = 10, vip_lim = 0.5, spl_type = "RND", pro_test = 25, cv = "LOO")

# 5. Plot BVE-PLS-DA variable selection profile showing selected variables across elimination rounds
plot_bvepls(bveplsdacv, xlabel = 'nm', ylabel = 'absorbance')

# 6. Plot classification accuracy (ACU) across latent variables for calibration and cross-validation sets
plot_lv_da(bveplsdacv, plot_cal = T, plot_cv = T, plot_type = "ACU")

# 7. Fit final 3-component PLS-DA model using BVE-PLS-DA selected variables with Y-randomization testing (10 repetitions)
plsdamod <- mod_plsda(bveplsdacv, ncomp = 3, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers and labels
plot_diag(plsdamod, x = "y_hat", y = "leverage", marker = T, labels = T)

# 9. Plot regression coefficients profile for the 'high' target class across descriptors with reference lines
plot_var_imprt(plsdamod, clas = "high", plot_type = "coefficients", xlabel = "descriptors", orlines = T)

# 10. Plot Variable Importance in Projection (VIP) scores across descriptors
plot_var_imprt(plsdamod, plot_type = "VIP", xlabel = "descriptors")

# 11. Plot Discrimination Power / Fractional Rank (FR) values across descriptors
plot_var_imprt(plsdamod, plot_type = "FR", xlabel = "descriptors")

# 12. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsdamod$cal_metrics
plsdamod$cv_metrics
plsdamod$yrand_metrics
plsdamod$test_metrics

# 13. Predict class membership for holdout test dataset
plsdapred <- pred_plsda(plsdamod, plsdamod$df_test)
# Note: You can replace plsdamod$df_test with any new dataset formatted via format_df()

# 14. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(plsdapred$cm)

####################################################
# Soft Independent Modeling of Class Analogy - SIMCA
####################################################
# 1. Load sample dataset from the 'maRS' package
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'brand' and class labels from 'status'
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

# 3. Perform cross-validation for SIMCA modeling on target class ('fresh') using auto-scaled data, LOO-CV, and a 20\% test set split
simcacv <- cv_simca(df = ex_data, ncomp = 10, scale = T, spl_type = "RND", pro_test = 20, cv = "LOO", targetclass = "fresh", method = "ddcla")

# 4. Plot classification performance across principal components for calibration and cross-validation sets
plot_lv_da(simcacv, plot_cal = T, plot_cv = T)

# 5. Fit final 2-component SIMCA model for target class 'fresh' using data-driven classic limits ('ddcla')
simcamod <- mod_simca(simcacv, targetclass = "fresh", ncomp = 2, scale = T, method = "ddcla")

# 6. Plot expected vs. observed extremes to evaluate distributional fit of distance limits
plot_extremes(simcacv, ncomp = 2)

# 7. Plot calibration acceptance diagram (Q residuals vs T2 distance) with normalized and log-scaled axes
plot_accep(simcamod, norm_scale = T, log_scale = T, marker = T, labels = T, colPa = "Hue")

# 8. Predict target class membership and distance statistics for the holdout test dataset
simcapred <- pred_simca(simcamod, simcacv$df_test, ncomp = 2)
# Note: You can replace simcacv$df_test with any new dataset formatted via format_df()

# 9. Plot acceptance diagram for test set predictions overlaid with model boundaries and group coloring
plot_data <- plot_accep(simcamod, simcapred, norm_scale = T, log_scale = T, marker = T, labels = T, group = T, colPa = "Hue")

# 10. Calculate classification performance metrics (sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(simcapred$cm, mod_typ = "simca")

}
}