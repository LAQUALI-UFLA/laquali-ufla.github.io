\name{cv_ipls}
\alias{cv_ipls}
\title{Interval Partial Least Squares Regression (iPLS)}
\description{
Performs Interval Partial Least Squares (iPLS) feature selection by dividing the predictor space into equal intervals and selecting optimal sub-regions via forward or backward selection.
}
\usage{
cv_ipls(
  df,
  ncomp = 1,
  nint = 10,
  sel_mode = "forward",
  comb_full = TRUE,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5
)
}
\arguments{
  \item{df}{A structured list object (from \code{\link{format_df}} or \code{\link{pre_pro}}) containing \code{xdat} and \code{resp}.}

  \item{ncomp}{Integer. Maximum number of latent variables to evaluate. Defaults to \code{1}.}

  \item{nint}{Integer. Number of equal intervals into which the predictor variables are split. Defaults to \code{10}.}

  \item{sel_mode}{Character string specifying selection mode: \code{"forward"} or \code{"backward"}. Defaults to \code{"forward"}.}

  \item{comb_full}{Logical. If \code{TRUE}, evaluates all combinations before choosing the global minimum RMSECV. Defaults to \code{TRUE}.}

  \item{scale}{Logical. If \code{TRUE}, scales variables to unit variance. Defaults to \code{FALSE}.}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"SPXY"} (Sample distances on X and Y), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric. Percentage of samples held out for testing. Defaults to \code{25}.}

  \item{cv}{Character string specifying the cross-validation strategy: \code{"LOO"} (Leave-One-Out), \code{"VB"} (Venetian Blinds), or \code{"RND"} (Random). Defaults to \code{"LOO"}.}

  \item{folds}{Integer. Number of CV folds for \code{"VB"} or \code{"RND"}. Defaults to \code{5}.}
}
\details{
\code{cv_ipls} divides the p variables into \code{nint} contiguous segments. In \code{"forward"} mode, it iteratively adds intervals that yield the greatest reduction in cross-validation error. In \code{"backward"} mode, it sequentially removes intervals. The final PLS model is calibrated exclusively on the chosen variable subsets.
}
\value{
An \code{\link[pls]{mvr}} object containing model outputs and iPLS attributes:
  \item{bestVars}{List containing indices of selected intervals, variables, optimal latent variables, and associated error metrics.}
  \item{intMet}{Iterative step metrics recorded during interval selection.}
  \item{intMet_ind}{Data frame summarizing performance metrics for each standalone interval.}
  \item{globMet}{Full-spectrum global baseline metrics prior to interval selection.}
  \item{df_train}{Training dataset restricted to selected variables.}
  \item{df_test}{Test dataset restricted to selected variables.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform interval PLS (iPLS) cross-validation using forward selection (10 intervals, up to 10 LVs, Kennard-Stone 25\% test split, 5-fold Venetian Blind CV)
iplscv <- cv_ipls(df = ex_data, ncomp = 10, nint = 10, sel_mode = "forward", spl_type = "KS", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot interval PLS performance (RMSECV) across evaluated sub-intervals
plot_ipls(iplscv, xlabel = 'nm')

# 6. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(iplscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 7. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(iplscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 8. Fit final 5-component PLS model using the selected iPLS sub-intervals with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(iplscv, ncomp = 5, yrand = T, nrep = 10)

# 9. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 10. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 11. Plot regression coefficients profile across variables (wavelengths) with reference lines
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", orlines = T)

# 12. Plot Variable Importance in Projection (VIP) scores across variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 13. Inspect regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 14. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 15. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)

# 16. Plot parity diagram for prediction results colored by dataset set
plot_parity(plspred, colPa = "set")
}
}