\name{plot_diag}
\alias{plot_diag}
\title{Plot Multivariate Model Diagnostic Indicators}
\description{
Generates diagnostic scatter plots (such as sample Leverage vs. Studentized Residuals or Predicted vs. Residuals) for fitted regression models (\code{mlrmod} or \code{plsmod}), including reference decision limits and sample labels.
}
\usage{
plot_diag(
  mvmod,
  x = "leverage",
  y = "r_student",
  marker = TRUE,
  labels = TRUE,
  orlines = FALSE,
  val_cex = 0.7
)
}
\arguments{
  \item{mvmod}{A fitted regression model object containing a diagnostic list element, such as objects produced by \code{\link{mod_mlr}} or \code{\link{mod_pls}}.}

  \item{x}{Character string specifying the parameter to plot on the x-axis (e.g., \code{"leverage"}, \code{"r_student"}, \code{"residuals"}, \code{"y_actual"}, or \code{"y_hat"}). Defaults to \code{"leverage"}.}

  \item{y}{Character string specifying the parameter to plot on the y-axis (e.g., \code{"leverage"}, \code{"r_student"}, \code{"residuals"}, \code{"y_actual"}, or \code{"y_hat"}). Defaults to \code{"r_student"}.}

  \item{marker}{Logical. If \code{TRUE}, draws point markers for each sample. Defaults to \code{TRUE}.}

  \item{labels}{Logical. If \code{TRUE}, displays row name labels next to sample points. Defaults to \code{TRUE}.}

  \item{orlines}{Logical. If \code{TRUE}, adds a horizontal zero-reference line. Defaults to \code{FALSE}.}

  \item{val_cex}{Numeric character expansion factor controlling plot text and axis sizes. Defaults to \code{0.7}.}
}
\details{
\code{plot_diag} extracts diagnostic metrics calculated during model fitting (\code{mvmod$mdiag}):
\enumerate{
  \item Maps diagnostic variables to user-friendly axis titles.
}
}

\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 7. Fit final 5-component PLS regression model with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(plscv, ncomp = 5, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)
}
}