\name{mod_simca}
\alias{mod_simca}
\title{Fit Final SIMCA Model and Critical Acceptance Limits}
\description{
Fits a Soft Independent Modeling of Class Analogy (SIMCA) model on target class samples, calculating Hotelling's T², Q residuals, and decision acceptance boundaries.
}
\usage{
mod_simca(
  simcacv,
  targetclass = NULL,
  ncomp = NULL,
  center = TRUE,
  scale = FALSE,
  method = "smcla",
  alpha = 0.05,
  gamma = 0.01
)
}
\arguments{
  \item{simcacv}{A cross-validated SIMCA object from \code{\link{cv_simca}} or a structured dataset list (\code{df}) containing predictor matrix \code{xdat}.}

  \item{targetclass}{Character string or factor level defining target class. Required if \code{simcacv} is a raw dataset list.}

  \item{ncomp}{Integer. Selected number of principal components. If \code{NULL}, extracts optimal components from \code{simcacv}.}

  \item{center}{Logical. If \code{TRUE}, centers data matrix to zero mean.}

  \item{scale}{Logical. If \code{TRUE}, scales data matrix to unit variance.}

  \item{method}{Character string specifying critical limit algorithm: \code{"smcla"} (Classic SIMCA), \code{"ddcla"} (Data-Driven), or \code{"ddrob"} (Robust Data-Driven).}

  \item{alpha}{Numeric significance level for extreme limits (default 0.05).}

  \item{gamma}{Numeric significance level for outlier limits (default 0.01).}
}
\details{
\code{mod_simca} builds the target class acceptance space:
\enumerate{
  \item Filters training dataset to retain target class observations.
  \item Performs principal component decomposition using \code{\link{mod_pca}}.
  \item Computes Hotelling's score distance and residual squared errors for training samples across 1 to \code{ncomp} components.
  \item Determines critical decision boundaries based on selected \code{method}:
    \itemize{
      \item \code{"smcla"}: Uses classical F-distribution limits for T² and Jackson-Mudholkar approximations for Q.
      \item \code{"ddcla"}: Applies classical moment estimators (mean, standard deviation) to fit limits.
      \item \code{"ddrob"}: Applies robust estimators (median, interquartile range) to fit limits.
    }
}
}
\value{
An enriched PCA model object containing SIMCA distance properties:
  \item{T2}{Vector of T² statistics for training target observations at selected component count.}
  \item{Q}{Vector of Q statistics for training target observations at selected component count.}
  \item{T2lim}{Matrix of calculated T² critical limits across components (Extremes, Outliers, Mean, DoF).}
  \item{Qlim}{Matrix of calculated Q critical limits across components (Extremes, Outliers, Mean, DoF).}
  \item{ncomp_sel}{Selected number of principal components.}
  \item{method}{Critical limit algorithm employed.}
  \item{targetclass}{Target class label.}
  \item{cal_metrics}{Calibration metric statistics inherited from cross-validation.}
  \item{cv_metrics}{Cross-validation metric statistics inherited from cross-validation.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'brand' and class labels from 'status'
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

# 3. Perform cross-validation for SIMCA modeling on target class ('fresh') using auto-scaled data, LOO-CV, and a 20\% test set split
simcacv <- cv_simca(df = ex_data, ncomp = 10, scale = T, spl_type = "RND", pro_test = 20, cv = "LOO", targetclass = "fresh", method = "ddcla")

# 4. Plot classification performance across principal components for calibration and cross-validation sets
plot_lv_da(simcacv, plot_cal = T, plot_cv = T)

# 5. Fit final 2-component SIMCA model for target class 'fresh' using data-driven classic limits ('ddcla')
simcamod <- mod_simca(simcacv, targetclass = "fresh", ncomp = 2, scale = T, method = "ddcla")

# 6. Plot expected vs. observed extremes to evaluate distributional fit of distance limits
plot_extremes(simcacv, ncomp = 2)

# 7. Plot calibration acceptance diagram (Q residuals vs T2 distance) with normalized and log-scaled axes
plot_accep(simcamod, norm_scale = T, log_scale = T, marker = T, labels = T, colPa = "Hue")

# 8. Predict target class membership and distance statistics for the holdout test dataset
simcapred <- pred_simca(simcamod, simcacv$df_test, ncomp = 2)
# Note: You can replace simcacv$df_test with any new dataset formatted via format_df()

# 9. Plot acceptance diagram for test set predictions overlaid with model boundaries and group coloring
plot_data <- plot_accep(simcamod, simcapred, norm_scale = T, log_scale = T, marker = T, labels = T, group = T, colPa = "Hue")

# 10. Calculate classification performance metrics (sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(simcapred$cm, mod_typ = "simca")
}
}