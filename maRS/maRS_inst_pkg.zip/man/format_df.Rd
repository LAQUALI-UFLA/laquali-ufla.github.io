\name{format_df}
\alias{format_df}
\title{Format and Standardize Data Frame Structure for use in maRS}
\description{
Processes and standardizes a raw data frame by extracting specific columns designated for row identifiers, group labels, response variables, and data split indicators. Returns a structured list containing predictors (\code{xdat}), response (\code{resp}), and associated metadata.
}
\usage{
format_df(
  df,
  headers = TRUE,
  col_names = NULL,
  col_classes = NULL,
  col_resp = NULL,
  col_split = NULL
)
}
\arguments{
  \item{df}{A data frame or matrix to be standardized.}

  \item{headers}{Logical. If \code{FALSE}, existing column names of \code{df} are replaced with numerical sequence headers (\code{"1"}, \code{"2"}, ...). Defaults to \code{TRUE}.}

  \item{col_names}{A character string specifying the column name in \code{df} containing observation/sample identifiers. If specified and found, the column is extracted as \code{row_names} and removed from predictor variables.}

  \item{col_classes}{A character string specifying the column name in \code{df} containing class/group classifications. If specified and found, the column is extracted as \code{groups} and removed from predictor variables.}

  \item{col_resp}{A character string specifying the column name in \code{df} containing the numeric target/response variable. If specified and found, the column is extracted into \code{resp} as a single-column numeric data frame and removed from predictor variables.}

  \item{col_split}{A character string specifying the column name in \code{df} containing dataset split information (e.g., \code{"train"}, \code{"test"}). If specified and found, the column is extracted as \code{split_info} and removed from predictor variables.}
}
\details{
The \code{format_df} function prepares raw datasets for use in maRS modules. It strips metadata columns from the main predictor matrix \code{xdat} while maintaining consistency across all extracted components.

If variable names in \code{df} represent numerical values (e.g., spectral wavelengths like \code{"400"}, \code{"402"}), \code{val_col} automatically converts column names to a numeric vector; otherwise, an integer sequence \code{1:ncol(df)} is assigned.
}
\value{
A named list with the following elements:
  \item{xdat}{Data frame containing only predictor variables.}
  \item{resp}{Data frame with a single column containing the numeric response variable (or \code{NULL}).}
  \item{row_names}{Character vector of observation/sample identifiers.}
  \item{groups}{Character vector of class/group labels (or \code{NULL}).}
  \item{col_classes}{Character string with the column name used for \code{groups}.}
  \item{val_col}{Numeric vector representing variable labels or column indices.}
  \item{mx}{Placeholder initialized to \code{NULL} (reserved for mean centering/scaling parameters).}
  \item{sgstp}{Placeholder initialized to \code{NULL} (reserved for Savitzky-Golay or preprocessing parameters).}
  \item{ppmet}{Placeholder initialized to \code{NULL} (reserved for preprocessing method metadata).}
  \item{split_info}{Character vector with data split information (or \code{NULL}).}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "avocado.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'Variety' and class labels from 'Maturation'
ex_data <- format_df(df = ex_data, headers = T, col_names = "Variety", col_classes = "Maturation")

# -----------------------

# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "breads.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'acceptance'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "acceptance")

# -----------------------

# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample classes from 'quality' column
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# -----------------------

# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# -----------------------

# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'brand' and class labels from 'status'
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

}
}