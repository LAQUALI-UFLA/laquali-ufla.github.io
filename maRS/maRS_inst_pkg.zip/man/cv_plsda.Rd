\name{cv_plsda}
\alias{cv_plsda}
\title{Cross-Validation for Partial Least Squares Discriminant Analysis (PLS-DA)}
\description{
Performs Partial Least Squares Discriminant Analysis (PLS-DA) with class-balanced dataset splitting, binary dummy encoding, internal cross-validation, and multi-component classification metric evaluations.
}
\usage{
cv_plsda(
  df,
  ncomp = 1,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5
)
}
\arguments{
  \item{df}{A structured list dataset (derived from \code{\link{format_df}} or \code{\link{pre_pro}}) containing predictor matrix \code{xdat} and target class factor \code{groups}.}

  \item{ncomp}{Integer. Maximum number of Partial Least Squares latent variables (components) to evaluate.}

  \item{scale}{Logical. If \code{TRUE}, scales predictor matrix to unit variance.}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric value specifying the percentage of samples allocated to the external test set.}

  \item{cv}{Character string indicating cross-validation scheme: \code{"LOO"} (Leave-One-Out) or \code{"RND"} (Random K-Fold).}

  \item{folds}{Integer specifying the number of folds when \code{cv = "RND"}.}
}
\details{
\code{cv_plsda} executes cross-validated PLS-DA workflow:
\enumerate{
  \item Splits input data into balanced training and test partitions per target category.
  \item Converts categorical target factor \code{groups} into a binary dummy matrix.
  \item Fits PLS regression model across 1 to \code{ncomp} latent variables using \code{\link[pls]{plsr}}.
  \item Assigns predicted class labels per latent variable using maximum score prediction decision.
  \item Computes global classification performance metrics (Precision, Specificity, Sensitivity, Accuracy, Efficiency, F1-Score, MCC) across calibration, cross-validation, and test partitions.
}
}
\value{
An object of class \code{"mvr"} enriched with cross-validation and classification metadata:
  \item{class.fitted.values}{Array of predicted class labels for calibration across components.}
  \item{validation$class.fitted.values}{Array of predicted class labels for cross-validation across components.}
  \item{cal_metrics}{List of calibration performance metric vectors across components.}
  \item{cv_metrics}{List of cross-validation performance metric vectors across components.}
  \item{test_metrics}{List of test set performance metric vectors across components (if external test set exists).}
  \item{opt_ncomp}{Numeric optimal number of latent variables detected.}
  \item{df_train}{Training dataset list containing predictor matrix and factors.}
  \item{df_test}{Test dataset list containing predictor matrix and factors.}
  \item{classes}{Vector of target class names.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "coffee.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining class labels from 'quality'
ex_data <- format_df(df = ex_data, headers = T, col_classes = "quality")

# 3. Apply preprocessing (Savitzky-Golay 1st derivative with an 11-point window and 1st-degree polynomial)
ex_data <- pre_pro(df = ex_data, ppmet = c("Savitzky-Golay"), sgstp = c(11, 1, 1))

# 4. Perform cross-validation for PLS-DA modeling (up to 10 LVs) using a random 25\% test set split and LOO-CV
plsdacv <- cv_plsda(df = ex_data, ncomp = 10, spl_type = "RND", pro_test = 25, cv = "LOO")

# 5. Plot classification sensitivity (SEN) across latent variables for calibration and cross-validation sets
plot_lv_da(plsdacv, plot_cal = T, plot_cv = T, plot_type = "SEN")

# 6. Fit final 3-component PLS-DA model with Y-randomization testing (10 repetitions)
plsdamod <- mod_plsda(plsdacv, ncomp = 3, yrand = T, nrep = 10)

# 7. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers and labels
plot_diag(plsdamod, x = "y_hat", y = "leverage", marker = T, labels = T)

# 8. Plot regression coefficients profile for the 'high' target class across descriptors with reference lines
plot_var_imprt(plsdamod, clas = "high", plot_type = "coefficients", xlabel = "descriptors", orlines = T)

# 9. Plot Variable Importance in Projection (VIP) scores across descriptors
plot_var_imprt(plsdamod, plot_type = "VIP", xlabel = "descriptors")

# 10. Plot Discrimination Power / Fractional Rank (FR) values across descriptors
plot_var_imprt(plsdamod, plot_type = "FR", xlabel = "descriptors")

# 11. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsdamod$cal_metrics
plsdamod$cv_metrics
plsdamod$yrand_metrics
plsdamod$test_metrics

# 12. Predict class membership for holdout test dataset
plsdapred <- pred_plsda(plsdamod, plsdamod$df_test)
# Note: You can replace plsdamod$df_test with any new dataset formatted via format_df()

# 13. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(plsdapred$cm)
}
}