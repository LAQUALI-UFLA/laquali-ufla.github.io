\name{pred_simca}
\alias{pred_simca}
\title{Predict Class Membership Using Trained SIMCA Model}
\description{
Predicts target class membership ("in" or "out") and calculates Hotelling's T² and Q residual distances for new observations using a trained SIMCA model.
}
\usage{
pred_simca(simcamod, df, ncomp = NULL, prepro = FALSE)
}
\arguments{
  \item{simcamod}{A fitted SIMCA model object created by \code{\link{mod_simca}}.}

  \item{df}{A dataset list (derived from \code{\link{format_df}} or \code{\link{pre_pro}}) containing predictor matrix \code{xdat} and optionally class metadata (\code{groups}, \code{row_names}).}

  \item{ncomp}{Integer. Number of principal components to use for projections. If \code{NULL}, defaults to \code{simcamod$ncomp}.}

  \item{prepro}{Logical. If \code{TRUE}, applies the saved pre-processing transformations from \code{simcamod} to \code{df}.}
}
\details{
\code{pred_simca} evaluates new observations against a single-class SIMCA decision boundary:
\enumerate{
  \item Pre-processes predictor matrix X using stored model parameters (\code{ppmet}, \code{sgstp}, \code{mx}) if \code{prepro = TRUE}.
  \item Projects centered/scaled observations onto target PCA loadings to obtain score vectors and reconstruct fitted matrices.
  \item Computes Hotelling's T² score distances and Q² squared residual errors.
  \item Classifies samples as target ("in") or non-target ("out") using critical decision limits depending on model strategy.
  \item Generates a binary confusion matrix if target class reference factors (\code{df$groups}) are provided.
}
}
\value{
An object of class \code{"pred_simca"} containing:
  \item{T2}{Vector of calculated Hotelling's T² values.}
  \item{Q}{Vector of calculated Q residual distances.}
  \item{class_hat}{Factor vector of predicted class assignments (\code{"in"} or \code{"out"}).}
  \item{class_ref}{Factor vector of actual reference binary targets (returned if \code{df$groups} is present).}
  \item{groups}{Original class labels from \code{df$groups} (if present).}
  \item{row_names}{Sample identifier names.}
  \item{cm}{Confusion matrix comparing reference and predicted target memberships (returned if \code{df$groups} is present).}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'brand' and class labels from 'status'
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

# 3. Perform cross-validation for SIMCA modeling on target class ('fresh') using auto-scaled data, LOO-CV, and a 20\% test set split
simcacv <- cv_simca(df = ex_data, ncomp = 10, scale = T, spl_type = "RND", pro_test = 20, cv = "LOO", targetclass = "fresh", method = "ddcla")

# 4. Plot classification performance across principal components for calibration and cross-validation sets
plot_lv_da(simcacv, plot_cal = T, plot_cv = T)

# 5. Fit final 2-component SIMCA model for target class 'fresh' using data-driven classic limits ('ddcla')
simcamod <- mod_simca(simcacv, targetclass = "fresh", ncomp = 2, scale = T, method = "ddcla")

# 6. Plot expected vs. observed extremes to evaluate distributional fit of distance limits
plot_extremes(simcacv, ncomp = 2)

# 7. Plot calibration acceptance diagram (Q residuals vs T2 distance) with normalized and log-scaled axes
plot_accep(simcamod, norm_scale = T, log_scale = T, marker = T, labels = T, colPa = "Hue")

# 8. Predict target class membership and distance statistics for the holdout test dataset
simcapred <- pred_simca(simcamod, simcacv$df_test, ncomp = 2)
# Note: You can replace simcacv$df_test with any new dataset formatted via format_df()

# 9. Plot acceptance diagram for test set predictions overlaid with model boundaries and group coloring
plot_data <- plot_accep(simcamod, simcapred, norm_scale = T, log_scale = T, marker = T, labels = T, group = T, colPa = "Hue")

# 10. Calculate classification performance metrics (sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(simcapred$cm, mod_typ = "simca")
}
}