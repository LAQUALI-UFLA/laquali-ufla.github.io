\name{pred_pls}
\alias{pred_pls}
\title{Predict Response Values Using Fitted PLS Models}
\description{
Predicts target response values for new or validation datasets using a fitted PLS, iPLS, or BVE-PLS model object, with support for automatic preprocessing and variable selection matching.
}
\usage{
pred_pls(
  plsmod,
  df,
  ncomp = NULL,
  prepro = FALSE,
  varsel = FALSE
)
}
\arguments{
  \item{plsmod}{A fitted PLS model object (created via \code{\link{mod_pls}} or cross-validation functions).}

  \item{df}{A structured list object (from \code{\link{format_df}} or \code{\link{pre_pro}}) containing predictor data \code{xdat} and optionally target responses \code{resp}.}

  \item{ncomp}{Integer. Number of latent variables used for prediction. If \code{NULL}, defaults to the selected component count \code{plsmod$ncomp_sel}.}

  \item{prepro}{Logical. If \code{TRUE}, applies the preprocessing pipeline stored in \code{plsmod} (\code{ppmet}, \code{sgstp}, and \code{mx}) to \code{df} prior to prediction. Defaults to \code{FALSE}.}

  \item{varsel}{Logical. If \code{TRUE}, subsets \code{df$xdat} to match selected variables stored in \code{plsmod$bestVars$vars} (used when predicting with iPLS or BVE-PLS models). Defaults to \code{FALSE}.}
}
\details{
\code{pred_pls} executes model predictions on external datasets:
\enumerate{
  \item Transforms \code{df} using saved training preprocessing parameters if \code{prepro = TRUE}.
  \item Filters predictor variables in \code{df} to match the retained feature set if \code{varsel = TRUE}.
  \item Applies the trained PLS model at the specified latent variable count (\code{ncomp}) using \code{\link[pls]{predict}}.
  \item Extracts reference ground-truth values if available in \code{df$resp}.
}
}
\value{
A named list containing:
  \item{y_hat}{Numeric vector of predicted response values.}
  \item{y_actual}{Numeric vector of actual reference values (returned only if \code{df$resp} is present).}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "methanol.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining the continuous response variable from 'meOH\%'
ex_data <- format_df(df = ex_data, headers = T, col_resp = "meOH\%")

# 3. Apply preprocessing (SNV followed by Savitzky-Golay 2nd derivative with a 9-point window)
ex_data <- pre_pro(df = ex_data, ppmet = c("SNV", "Savitzky-Golay"), sgstp = c(9, 2, 2))

# 4. Perform cross-validation for PLS regression (up to 15 LVs) using a random 25\% test set split and 5-fold Venetian Blind CV
plscv <- cv_pls(df = ex_data, ncomp = 15, spl_type = "RND", pro_test = 25, cv = "VB", folds = 5)

# 5. Plot R² performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "R2")

# 6. Plot RMSE performance across latent variables for calibration and cross-validation sets
plot_lv_reg(plscv, plot_cal = T, plot_cv = T, plot_type = "RMSE")

# 7. Fit final 5-component PLS regression model with Y-randomization testing (10 repetitions)
plsmod <- mod_pls(plscv, ncomp = 5, yrand = T, nrep = 10)

# 8. Plot diagnostic plot (Studentized residuals vs. Leverage) with sample markers, labels, and reference lines
plot_diag(plsmod, x = "leverage", y = "r_student", marker = T, labels = T, orlines = T)

# 9. Plot parity diagram (measured vs. predicted values) for calibration, cross-validation, and test sets
plot_parity(plsmod, cal = T, cv = T, test = T, colPa = "hue")

# 10. Plot regression coefficients profile across variables (wavelengths)
plot_var_imprt(plsmod, plot_type = "coefficients", xlabel = "nm", bars = F, orlines = F)

# 11. Plot Variable Importance in Projection (VIP) scores across variables
plot_var_imprt(plsmod, plot_type = "VIP", xlabel = "nm")

# 12. Inspect PLS regression performance metrics for calibration, cross-validation, Y-randomization, and test sets
plsmod$mvcal_met
plsmod$mvcv_met
plsmod$mvyrand_met
plsmod$mvtes_met

# 13. Predict response values for holdout test dataset
plspred <- pred_pls(plsmod, plsmod$df_test)
# Note: You can replace plsmod$df_test with any new dataset formatted via format_df()

# 14. Calculate regression performance metrics (e.g., R², RMSE, MAE) for test predictions
reg_metrics(plspred)

# 15. Plot parity diagram for prediction results colored by dataset set
plot_parity(plspred, colPa = "set")
}
}