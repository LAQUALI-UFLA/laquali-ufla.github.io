\name{plot_load}
\alias{plot_load}
\title{Plot Loadings for PCA models}
\description{
Visualizes variable loadings from PCA models in 1D line format, 2D scatter/vector plots, or 3D space.
}
\usage{
plot_load(
  mvmod,
  x = 1,
  y = 2,
  z = 0,
  mlines = FALSE,
  vectors = FALSE,
  vrot = 25,
  hrot = 40,
  marker = TRUE,
  labels = TRUE,
  var_lab = NULL,
  adsupload = FALSE,
  val_cex = 0.7,
  grids = FALSE,
  orlines = FALSE
)
}
\arguments{
  \item{mvmod}{A fitted PCA model object obtained using \code{\link{mod_pca}}.}

  \item{x}{Integer. Component index for the x-axis (or primary PC for line plots). Defaults to \code{1}.}

  \item{y}{Integer. Component index for the y-axis. Defaults to \code{2}.}

  \item{z}{Integer. Component index for the z-axis. Defaults to \code{0}.}

  \item{mlines}{Logical. If \code{TRUE}, produces a 1D spectral/line plot of loadings across variables. Defaults to \code{FALSE}.}

  \item{vectors}{Logical. If \code{TRUE}, loadings are rendered as arrows starting from the origin. Defaults to \code{FALSE}.}

  \item{vrot}{Numeric. Vertical viewing angle for 3D plots. Defaults to \code{25}.}

  \item{hrot}{Numeric. Horizontal viewing angle for 3D plots. Defaults to \code{40}.}

  \item{marker}{Logical. Whether to draw point markers at loading coordinates. Defaults to \code{TRUE}.}

  \item{labels}{Logical. Whether to display variable name labels. Defaults to \code{TRUE}.}

  \item{var_lab}{Character. Optional custom label for the x-axis when \code{mlines = TRUE}.}

  \item{adsupload}{Logical. Whether to plot supplementary variable loadings if present. Defaults to \code{FALSE}.}

  \item{val_cex}{Numeric. Character expansion factor for text and labels. Defaults to \code{0.7}.}

  \item{grids}{Logical. Whether to display background grid lines. Defaults to \code{FALSE}.}

  \item{orlines}{Logical. Whether to draw origin lines at zero. Defaults to \code{FALSE}.}
}
\details{
When \code{mlines = TRUE}, loading values are plotted against variable metadata (\code{mvmod$val_col}), which is useful for spectral continuous data. When \code{z = 0} and \code{mlines = FALSE}, a standard 2D loading scatter/vector plot is produced.
}

\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "avocado.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'Variety' and class labels from 'Maturation'
ex_data <- format_df(df = ex_data, headers = T, col_names = "Variety", col_classes = "Maturation")

# 3. Fit PCA model on auto-scaled data with supplementary columns ('Flesh Firmness (N)') and continuous bubble sizing variable ('Oil (\%)')
pcamod <- mod_pca(df = ex_data, scale = T, supcols = "Flesh Firmness (N)", scalecol = "Oil (\%)")

# 4. Plot explained variance across principal components
plot_variance(pcamod)

# 5. Plot 3D score plot (PC1, PC2, PC3) with custom view angles, sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 3, vrot = 25, hrot = 40, marker = T, labels = T, group = T)

# 6. Plot 2D score plot (PC1 vs PC2) with sample markers, labels, and group coloring
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, group = T)

# 7. Plot 2D score plot with marker sizes/colors mapped to continuous variable ('Oil (\%)'), origin reference lines, and custom palette
plot_scor(pcamod, 1, 2, 0, marker = T, labels = T, mrksiz = T, mrkcol = T, colPa = "spec", orlines = T)

# 8. Plot 3D loadings plot (PC1, PC2, PC3) as loading vectors, including supplementary column loadings
plot_load(pcamod, 1, 2, 3, vectors = T, vrot = 25, hrot = 40, labels = T, adsupload = T)

# 9. Plot 2D loadings plot (PC1 vs PC2) as point markers, including origin lines and supplementary column loadings
plot_load(pcamod, 1, 2, 0, vectors = F, marker = T, adsupload = T, orlines = T)

# 10. Plot 3D biplot combining sample scores and variable loadings (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, z = 3, vrot = 25, hrot = 40, scormarker = T, scorlabels = T, group = T, vectors = T, adsupload = T)

# 11. Plot 2D biplot with score markers sized/colored by continuous variable ('Oil (\%)') and loading vectors (including supplementary variables)
plot_bi(pcamod, x = 1, y = 2, mrksiz = T, mrkcol = T, colPa = "spec", vectors = T, adsupload = T)
}
}