\name{synt_oversamp}
\alias{synt_oversamp}
\title{Synthetic Oversampling for Class Imbalance}
\description{
Applies synthetic oversampling algorithms (SMOTE or ADASYN) to balance multi-class datasets derived from \code{\link{format_df}} or \code{\link{pre_pro}}.
}
\usage{
synt_oversamp(df, method = "SMOTE", k = 5)
}
\arguments{
  \item{df}{A structured dataset list (derived from \code{\link{format_df}} or \code{\link{pre_pro}}) containing predictor matrix \code{xdat}, class target vector \code{groups}, and sample names \code{row_names}.}

  \item{method}{Character string specifying the oversampling algorithm: \code{"SMOTE"} (Synthetic Minority Over-sampling Technique) or \code{"ADASYN"} (Adaptive Synthetic). Default is \code{"SMOTE"}.}

  \item{k}{Integer specifying the number of nearest neighbors used to generate synthetic observations. Default is 5.}
}
\details{
\code{synt_oversamp} addresses class imbalance in multivariate datasets:
\enumerate{
  \item Extracts predictor matrix \code{xdat} and class factor \code{groups} from the input list object.
  \item Invokes \code{\link[SMOTEWB]{SMOTE}} or \code{\link[SMOTEWB]{ADASYN}} to generate synthetic observations for minority classes.
  \item Appends synthetic identifiers (\code{"syn1"}, \code{"syn2"}, ...) to original sample row names.
  \item Returns a tabular \code{data.frame} where the first two columns are automatically structured as \code{obj} (sample IDs) and \code{classes} (group labels), followed by feature columns.
}
}
\value{
A \code{data.frame} containing:
  \item{obj}{Character column combining original sample names with synthetic labels (\code{"syn1"}, \code{"syn2"}, ...).}
  \item{classes}{Character column combining original class labels with synthetic class assignments.}
  \item{\dots}{Remaining columns containing original and synthetically generated feature data.}
}
\examples{
\donttest{
# Step A: Import and Raw Data 
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

# Step B: Generate Synthetic Samples 
df_synth <- synt_oversamp(ex_data, method = "ADASYN", k = 3)

# Step C: Save Oversampled Dataset to Excel 
writexl::write_xlsx(as.data.frame(df_synth), path = "oversampleddataset.xlsx")

# Step D: Read and Restructure Saved Excel Dataset 
ovrs_data <- readxl::read_excel("oversampleddataset.xlsx")
ovrs_data <- format_df(df = ovrs_data, headers = T, col_names = "obj", col_classes = "classes")
}
}