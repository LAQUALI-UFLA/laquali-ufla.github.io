\name{cv_simca}
\alias{cv_simca}
\title{Cross-Validation for Soft Independent Modeling of Class Analogy (SIMCA)}
\description{
Performs cross-validation for one-class SIMCA modeling on a specified target class, calculating cross-validated sensitivity metrics, optimal principal components, and distance statistics.
}
\usage{
cv_simca(
  df,
  ncomp = 1,
  center = TRUE,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5,
  targetclass = NULL,
  method = "smcla",
  alpha = 0.05,
  gamma = 0.01
)
}
\arguments{
  \item{df}{A structured list dataset (derived from \code{\link{import_df}} or \code{\link{pre_pro}}) containing predictor matrix \code{xdat} and class labels \code{groups}.}

  \item{ncomp}{Integer. Maximum number of principal components to evaluate.}

  \item{center}{Logical. If \code{TRUE}, centers data to zero mean.}

  \item{scale}{Logical. If \code{TRUE}, scales data to unit variance.}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric value specifying percentage of target samples allocated to external test set.}

  \item{cv}{Character string defining cross-validation scheme: \code{"LOO"} (Leave-One-Out) or \code{"RND"} (Random K-Fold).}

  \item{folds}{Integer specifying fold count when \code{cv = "RND"}.}

  \item{targetclass}{Character string or factor level defining the target class for single-class modeling.}

  \item{method}{Character string defining critical limit calculation scheme: \code{"smcla"} (Classic SIMCA), \code{"ddcla"} (Data-driven), or \code{"ddrob"} (Robust Data-driven).}

  \item{alpha}{Numeric significance level for extreme limits (default 0.05).}

  \item{gamma}{Numeric significance level for outlier limits (default 0.01).}
}
\details{
\code{cv_simca} executes cross-validated single-class model selection:
\enumerate{
  \item Isolates target class observations from non-target samples.
  \item Splits target observations into training and testing partitions using \code{spl_type}.
  \item Performs internal cross-validation on target training samples to compute out-of-fold statistics.
  \item Evaluates model sensitivity across components.
  \item Identifies optimal component count maximizing target class sensitivity.
  \item Fits final SIMCA model on training data and projects external test samples (if \code{pro_test > 0}).
}
}
\value{
An object of class \code{"simcacv"} containing cross-validation parameters and metrics:
  \item{inout_cv}{Binary matrix indicating inside/outside assignments during internal cross-validation.}
  \item{cal_metrics}{List containing calibration sensitivity statistics across components.}
  \item{cv_metrics}{List containing cross-validated sensitivity statistics across components.}
  \item{test_metrics}{List containing test set sensitivity statistics (if test samples exist).}
  \item{opt_ncomp}{Integer optimal number of principal components.}
  \item{calMet}{List containing calibration distance statistics.}
  \item{cvMet}{List containing cross-validation distance statistics.}
  \item{testMet}{List containing test distance statistics.}
  \item{df_train}{Training partition dataset list.}
  \item{df_test}{Test partition dataset list.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRS' package
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'brand' and class labels from 'status'
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

# 3. Perform cross-validation for SIMCA modeling on target class ('fresh') using auto-scaled data, LOO-CV, and a 20\% test set split
simcacv <- cv_simca(df = ex_data, ncomp = 10, scale = T, spl_type = "RND", pro_test = 20, cv = "LOO", targetclass = "fresh", method = "ddcla")

# 4. Plot classification performance across principal components for calibration and cross-validation sets
plot_lv_da(simcacv, plot_cal = T, plot_cv = T)

# 5. Fit final 2-component SIMCA model for target class 'fresh' using data-driven classic limits ('ddcla')
simcamod <- mod_simca(simcacv, targetclass = "fresh", ncomp = 2, scale = T, method = "ddcla")

# 6. Plot expected vs. observed extremes to evaluate distributional fit of distance limits
plot_extremes(simcacv, ncomp = 2)

# 7. Plot calibration acceptance diagram (Q residuals vs T2 distance) with normalized and log-scaled axes
plot_accep(simcamod, norm_scale = T, log_scale = T, marker = T, labels = T, colPa = "Hue")

# 8. Predict target class membership and distance statistics for the holdout test dataset
simcapred <- pred_simca(simcamod, simcacv$df_test, ncomp = 2)
# Note: You can replace simcacv$df_test with any new dataset formatted via format_df()

# 9. Plot acceptance diagram for test set predictions overlaid with model boundaries and group coloring
plot_data <- plot_accep(simcamod, simcapred, norm_scale = T, log_scale = T, marker = T, labels = T, group = T, colPa = "Hue")

# 10. Calculate classification performance metrics (sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(simcapred$cm, mod_typ = "simca")
}
}