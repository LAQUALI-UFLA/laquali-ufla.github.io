\name{mod_mlrda}
\alias{mod_mlrda}
\title{Multiple Linear Regression Discriminant Analysis (MLR-DA)}
\description{
Fits a Multiple Linear Regression Discriminant Analysis (MLR-DA) classification model with support for class-balanced dataset splitting, cross-validation, external test set validation, Y-randomization testing, and leverage diagnostic calculations.
}
\usage{
mod_mlrda(
  df,
  center = FALSE,
  scale = FALSE,
  spl_type = "KS",
  pro_test = 25,
  cv = "LOO",
  folds = 5,
  yrand = FALSE,
  nrep = 10
)
}
\arguments{
  \item{df}{A structured list dataset (derived from \code{\link{format_df}} or \code{\link{pre_pro}}) containing predictor matrix \code{xdat} and target class factor \code{groups}.}

  \item{center}{Logical. If \code{TRUE}, mean-centers predictor matrix \code{X}.}

  \item{scale}{Logical. If \code{TRUE}, auto-scales predictor matrix \code{X} to unit variance (automatically enforces \code{center = TRUE}).}

  \item{spl_type}{Character string specifying target dataset partitioning method: \code{"KS"} (Kennard-Stone), \code{"RND"} (Random split), \code{"SPE"} (User-defined split using \code{split_info} metadata), or \code{"NONE"} (No test split). Default is \code{"KS"}.}

  \item{pro_test}{Numeric value specifying the percentage of samples allocated to the external test set.}

  \item{cv}{Character string indicating the cross-validation scheme: \code{"LOO"} (Leave-One-Out), \code{"RND"} (Random K-Fold), or \code{"none"}.}

  \item{folds}{Integer specifying the number of folds when \code{cv = "RND"}.}

  \item{yrand}{Logical. If \code{TRUE}, performs Y-randomization validation over \code{nrep} iterations.}

  \item{nrep}{Integer. Number of Y-randomization iterations to evaluate.}
}
\details{
\code{mod_mlrda} performs linear discriminant analysis via dummy-coded multivariate regression:
\enumerate{
  \item Splits the dataset into training and test sets independently for each class to ensure class balance.
  \item Converts class factors into a binary dummy target matrix.
  \item Estimates model regression weights.
  \item Predicts class assignments based on the highest fitted dummy value across classes.
  \item Evaluates model performance across calibration, cross-validation, and test partitions.
}
}
\value{
An object of class \code{"mlrdamod"} containing:
  \item{classes}{Factor levels of target categories.}
  \item{coefficients}{Matrix of fitted regression coefficients.}
  \item{b0}{Vector of model intercepts.}
  \item{mvcal}{List containing predicted and reference classes for calibration.}
  \item{cmCal}{Calibration confusion matrix.}
  \item{cal_metrics}{Classification metrics object for calibration.}
  \item{mvcv}{List containing cross-validation prediction results (if \code{cv} is active).}
  \item{cmCV}{Cross-validation confusion matrix.}
  \item{cv_metrics}{Classification metrics object for cross-validation.}
  \item{mvtest}{List containing test set predictions (if test partition exists).}
  \item{cmTest}{External test confusion matrix.}
  \item{test_metrics}{Classification metrics object for external testing.}
  \item{mdiag}{List of leverage diagnostic measures and threshold limits.}
}
\examples{
\donttest{
# 1. Load sample dataset from the 'maRSpkg' package
ex_data <- readxl::read_excel(system.file("extdata", "tea.xlsx", package = "maRSpkg"))

# 2. Format dataset into standard structure, defining sample IDs from 'brand' and class labels from 'status'
ex_data <- format_df(df = ex_data, headers = T, col_names = "brand", col_classes = "status")

# 3. Fit Multiple Linear Regression Discriminant Analysis (MLR-DA) model on auto-scaled data using Kennard-Stone 25\% test split, LOO-CV, and Y-randomization (10 reps)
mlrdamod <- mod_mlrda(df = ex_data, scale = T, spl_type = "KS", pro_test = 25, cv = "LOO", yrand = T, nrep = 10)

# 4. Plot diagnostic plot (Leverage vs. Fitted values) with sample markers, labels, and reference lines
plot_diag(mlrdamod, x = "y_hat", y = "leverage", marker = T, labels = T, orlines = T)

# 5. Plot variable importance bar chart based on regression coefficients for the 'expired' target class
plot_var_imprt(mlrdamod, clas = "expired", plot_type = "coefficients", bars = T)

# 6. Inspect classification performance metrics for calibration, cross-validation, Y-randomization, and test sets
mlrdamod$cal_metrics
mlrdamod$cv_metrics
mlrdamod$yrand_metrics
mlrdamod$test_metrics

# 7. Predict class membership for holdout test dataset
ldapred <- pred_mlrda(mlrdamod, mlrdamod$df_test)
# Note: You can replace mlrdamod$df_test with any new dataset formatted via format_df()

# 8. Calculate classification performance metrics (e.g., sensitivity, specificity, accuracy) from prediction confusion matrix
cla_metrics(ldapred$cm)
}
}