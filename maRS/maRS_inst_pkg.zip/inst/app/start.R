# =========================
# start.R
# =========================

# 1. Ensures that the working directory is ALWAYS the folder where this file is installed
script_dir <- tryCatch({
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg) > 0) {
    dirname(normalizePath(sub("^--file=", "", file_arg[1])))
  } else {
    getwd()
  }
}, error = function(e) getwd())

setwd(script_dir)

# Force the creation/use of a personal library (prevents administrator errors)
user_lib <- Sys.getenv("R_LIBS_USER")
if (!dir.exists(user_lib)) {
  dir.create(user_lib, recursive = TRUE)
}
.libPaths(c(user_lib, .libPaths()))

# Function to select available port
getFreePort <- function(min = 3000, max = 9000, tries = 100) {
  for (i in 1:tries) {
    p <- sample(min:max, 1)
    con <- try(socketConnection("127.0.0.1", port = p, open = "r+", timeout = 1), silent = TRUE)
    if (inherits(con, "try-error")) {
      return(p)
    } else {
      close(con)
    }
  }
  stop("No free port could be found.")
}

# Required packages
pkgs <- c(
  "Matrix", "MASS", "scales", "readxl", "writexl", 
  "pls", "plot3D", "car", "officer", "rvg", 
  "dendextend", "shiny", "DT", "SMOTEWB"
)

options(repos = c(CRAN = "https://cloud.r-project.org"))

miss <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]

# Choose dynamic port
port <- getFreePort()

# If there are any missing packages, open the loader and install them
if (length(miss) > 0) {
  loader <- file.path(script_dir, "www", "loader.html")
  
  if (file.exists(loader)) {
    html <- readLines(loader, warn = FALSE)
    html <- gsub("\\{\\{PORT\\}\\}", port, html)
    
    safe_base <- ifelse(.Platform$OS.type == "unix", Sys.getenv("HOME"), tempdir())
    loader_dir <- file.path(safe_base, "maRS_setup_temp")
    
    if (!dir.exists(loader_dir)) {
      dir.create(loader_dir, recursive = TRUE)
    }
    
    tmp_loader <- file.path(loader_dir, "loader.html")
    writeLines(html, tmp_loader)
    
    browseURL(tmp_loader)
  } else {
    loader_dir <- tempdir()
  }
  
  install_error <- FALSE
  failed_pkg <- ""
  full_log_text <- ""
  
  for (i in seq_along(miss)) {
    pkg <- miss[i]
    
    js_code <- sprintf('updateStatus(%d, %d, "%s");', i, length(miss), pkg)
    writeLines(js_code, file.path(loader_dir, paste0("status", i, ".js")))
    
    if (!requireNamespace(pkg, quietly = TRUE)) {
      temp_script <- tempfile(fileext = ".R")
      log_file <- tempfile(fileext = ".log")
      
      clean_user_lib <- normalizePath(user_lib, winslash = "/", mustWork = FALSE)
      
      script_content <- c(
        sprintf(".libPaths(c('%s', .libPaths()))", clean_user_lib),
        "options(repos = c(CRAN = 'https://cloud.r-project.org'))",
        sprintf("install.packages('%s', quiet = FALSE)", pkg)
      )
      writeLines(script_content, temp_script)
      
      rscript_executable <- ifelse(.Platform$OS.type == "windows", "Rscript.exe", "Rscript")
      rscript_bin <- file.path(R.home("bin"), rscript_executable)
      
      if (!file.exists(rscript_bin) && .Platform$OS.type == "windows") {
        rscript_bin <- file.path(R.home("bin"), .Platform$r_arch, "Rscript.exe")
      }
      
      system2(
        rscript_bin,
        args = shQuote(temp_script),
        stdout = log_file,
        stderr = log_file
      )
      
      if (file.exists(log_file)) {
        full_log_text <- paste(readLines(log_file, warn = FALSE), collapse = "\n")
        unlink(log_file)
      }
      
      if (file.exists(temp_script)) {
        unlink(temp_script)
      }
      
      if (!requireNamespace(pkg, quietly = TRUE)) {
        install_error <- TRUE
        failed_pkg <- pkg
        break
      }
    }
  }
  
  if (install_error) {
    safe_log <- gsub("&", "&amp;", full_log_text)
    safe_log <- gsub("<", "&lt;", safe_log)
    safe_log <- gsub(">", "&gt;", safe_log)
    
    error_html_path <- file.path(loader_dir, "error.html")
    error_html_content <- sprintf(
      '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Installation Error</title>
      <style>body { font-family: sans-serif; padding: 30px; background-color: #f8f9fa; }
      .card { background: #ffffff; border: 1px solid #d6d8db; border-radius: 8px; padding: 25px; }
      h2 { color: #d9534f; margin-top: 0; }
      pre { background: #212529; color: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; max-height: 500px; white-space: pre-wrap; }</style>
      </head><body><div class="card"><h2>Error installing package: %s</h2><pre>%s</pre></div></body></html>',
      failed_pkg, safe_log
    )
    
    writeLines(error_html_content, error_html_path)
    browseURL(error_html_path)
    Sys.sleep(1)
    
    stop(sprintf("Failed to install package '%s'. Check the error log opened in your browser.", failed_pkg))
  } else {
    writeLines(
      'updateStatus("All", "All", "Finishing setup...");',
      file.path(loader_dir, paste0("status", length(miss) + 1, ".js"))
    )
  }
}

# Check for Updates
updt_script <- file.path(script_dir, "mars_updt.R")
if (file.exists(updt_script)) {
  try(source(updt_script), silent = TRUE)
}

# Run Shiny on the dynamic port
library(shiny)

runApp(
  appDir = script_dir,
  host = "127.0.0.1",
  port = port,
  launch.browser = TRUE
)

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.