pred_pls <- function(plsmod,
                     df,
                     ncomp = NULL,
                     prepro = FALSE,
                     varsel = FALSE)
{
  # Initialize output object as a list
  plspred <- list()
  
  # Automatically detects whether the model was trained with variable selection
  if (!is.null(plsmod$bestVars$vars) &&
      sum(plsmod$bestVars$vars, na.rm = TRUE) > 0) {
    varsel <- TRUE
  }
  
  # Apply preprocessing using the parameters from the training model
  if (prepro) {
    if (varsel && !is.null(plsmod$mxFull)) {
      mx <- plsmod$mxFull
    } else {
      mx <- plsmod$mx
    }
    
    df <- pre_pro(df,
                  ppmet = plsmod$ppmet,
                  sgstp = plsmod$sgstp,
                  mx = mx)
  }
  
  # Select variables (if iPLS / BVE) only if df$xdat has not been subsetted yet
  if (varsel && !is.null(plsmod$bestVars$vars) &&
      sum(plsmod$bestVars$vars, na.rm = TRUE) > 0) {
    selVar <- plsmod$bestVars$vars
    n_sel  <- if (is.logical(selVar)) sum(selVar, na.rm = TRUE) else length(selVar)
    
    if (ncol(df$xdat) != n_sel) {
      df$xdat <- df$xdat[, selVar, drop = FALSE]
      
      if (!is.null(df$val_col)) {
        df$val_col <- df$val_col[selVar]
      }
      
      if (!is.null(df$mx)) {
        df$mx <- df$mx[selVar]
      }
    }
  }
  
  # Force the column names from the training set onto the prediction set
  if (!is.null(plsmod$col_names) &&
      ncol(df$xdat) == length(plsmod$col_names)) {
    colnames(df$xdat) <- plsmod$col_names
  }
  
  # Predict using the PLS model
  if (is.null(ncomp))
    ncomp <- plsmod$ncomp_sel
  
  x_pred <- data.frame(df$xdat)
  plspred$y_hat <- as.numeric(predict(plsmod, x_pred, ncomp = ncomp))
  
  # Get actual y values
  if (!is.null(df$resp)) {
    plspred$y_actual <- drop(df$resp[, 1])
  }
  
  return(plspred)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.