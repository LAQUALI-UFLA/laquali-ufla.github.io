pred_plsda <- function(plsdamod,
                       df,
                       ncomp = NULL,
                       prepro = FALSE,
                       varsel = FALSE)
{
  lev <- plsdamod$classes
  
  # Automatically detects whether the model was trained with variable selection
  if (!is.null(plsdamod$bestVars$vars) &&
      sum(plsdamod$bestVars$vars, na.rm = TRUE) > 0) {
    varsel <- TRUE
  }
  
  # Apply preprocessing using the parameters from the training model
  if (prepro) {
    if (varsel && !is.null(plsdamod$mxFull)) {
      mx <- plsdamod$mxFull
    } else {
      mx <- plsdamod$mx
    }
    
    df <- pre_pro(df,
                  ppmet = plsdamod$ppmet,
                  sgstp = plsdamod$sgstp,
                  mx = mx)
  }
  
  # Select variables (if iPLS-DA / BVE/PLS-DA) only if df$xdat has not been subsetted yet
  if (varsel && !is.null(plsdamod$bestVars$vars) &&
      sum(plsdamod$bestVars$vars, na.rm = TRUE) > 0) {
    selVar <- plsdamod$bestVars$vars
    n_sel  <- if (is.logical(selVar)) sum(selVar, na.rm = TRUE) else length(selVar)
    
    if (ncol(df$xdat) != n_sel) {
      df$xdat <- df$xdat[, selVar, drop = FALSE]
      
      if (!is.null(df$val_col)) {
        df$val_col <- df$val_col[selVar]
      }
      
      if (!is.null(df$mx)) {
        df$mx <- df$mx[selVar]
      }
    }
  }
  
  # Force the column names from the training set onto the prediction set
  if (!is.null(plsdamod$col_names) &&
      ncol(df$xdat) == length(plsdamod$col_names)) {
    colnames(df$xdat) <- plsdamod$col_names
  }
  
  Xnew <- as.matrix(df$xdat)
  
  newdata <- data.frame(X = I(Xnew))
  
  if (is.null(ncomp))
    ncomp <- plsdamod$ncomp_sel
  
  yp <- predict(plsdamod, newdata = newdata, ncomp = ncomp)
  # yp: n x nclass x 1
  
  yp <- yp[, , 1, drop = FALSE]
  
  idx <- max.col(yp[, , 1], ties.method = "first")
  class_hat <- factor(lev[idx], levels = lev)
  
  # =================================================
  # If reference exists -> return confusion matrix
  # =================================================
  
  if (!is.null(df$groups)) {
    class_ref <- factor(df$groups, levels = lev)
    
    if (length(class_hat) != length(class_ref))
      stop("Prediction did not return a row per sample.")
    
    cm <- table(Reference = class_ref, Predicted = class_hat)
    
    out <- list(class_hat = class_hat,
                class_ref = class_ref,
                cm        = cm)
    
  } else {
    out <- list(class_hat = class_hat)
  }
  
  return(out)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.