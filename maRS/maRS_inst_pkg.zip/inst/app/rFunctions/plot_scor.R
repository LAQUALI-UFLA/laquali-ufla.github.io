plot_scor <- function(mvmod,
                      x = 1,
                      y = 2,
                      z = 0,
                      vrot = 25,
                      hrot = 40,
                      marker = TRUE,
                      labels = TRUE,
                      group = FALSE,
                      elips = FALSE,
                      fillelip = TRUE,
                      mrksiz = FALSE,
                      mrkcol = FALSE,
                      adsupscor = FALSE,
                      biplot = FALSE,
                      colPa = "Hue",
                      val_cex = 0.7,
                      grids = FALSE,
                      orlines = FALSE) {
  # Get data
  scores <- if (!is.null(mvmod$scores))
    mvmod$scores
  else
    mvmod$x
  row_names <- mvmod$row_names
  groups <- mvmod$groups
  expand = 0.1
  
  # Get marker size
  if (mrksiz && !is.null(mvmod$scalecol)) {
    all_vals <- mvmod$scalecol
    if (!is.null(mvmod$scalecol_sup))
      all_vals <- c(all_vals, mvmod$scalecol_sup)
    
    rng <- range(all_vals, na.rm = TRUE)
    
    cex_pts <- scales::rescale(mvmod$scalecol, to = c(0.7, 3))
    
    if (!is.null(mvmod$scalecol_sup)) {
      cex_pts_sup <- scales::rescale(mvmod$scalecol_sup,
                                     to = c(0.7, 3),
                                     from = rng)
    }
    else{
      cex_pts_sup <- 1
    }
    
  } else {
    cex_pts <- 1
    cex_pts_sup <- 1
  }
  
  # Check supplementary scores
  has_sup <- FALSE
  if (adsupscor) {
    if (!is.null(mvmod$supscor)) {
      if (nrow(mvmod$supscor) > 0 &&
          ncol(mvmod$supscor) >= max(x, y, z)) {
        has_sup <- TRUE
      } else {
        warning("Supplementary scores not available or dimensions are insufficient")
      }
    }
  }
  
  # Color setup
  if (group && !is.null(groups)) {
    colfac <- factor(groups, levels = unique(groups))
    if (adsupscor) {
      pal <- make_palette(length(levels(colfac)) + 1, colPa)
      col_sup <- pal[length(pal)]
      pal <- pal[-length(pal)]
      col <- pal[colfac]
      
    } else{
      pal <- make_palette(length(levels(colfac)), colPa)
      col <- pal[colfac]
    }
    
    
  } else if (mrkcol && !is.null(mvmod$scalecol)) {
    ncol_pal <- 256
    pal <- make_palette(ncol_pal, colPa)
    
    all_vals <- mvmod$scalecol
    if (!is.null(mvmod$scalecol_sup))
      all_vals <- c(all_vals, mvmod$scalecol_sup)
    
    rng <- range(all_vals, na.rm = TRUE)
    
    col_idx <- scales::rescale(mvmod$scalecol, to = c(1, ncol_pal))
    
    col_idx <- pmin(pmax(round(col_idx), 1), ncol_pal)
    col <- pal[col_idx]
    
    if (!is.null(mvmod$scalecol_sup)) {
      col_idx_sup <- scales::rescale(mvmod$scalecol_sup,
                                     to   = c(1, ncol_pal),
                                     from = rng)
      
      col_idx_sup <- pmin(pmax(round(col_idx_sup), 1), ncol_pal)
      col_sup <- pal[col_idx_sup]
    }
    
  } else {
    pal <- make_palette(2, colPa)
    col <- pal[1]
    col_sup <- pal[2]
  }
  
  # layout if colorbar
  use_cbar <- mrkcol &&
    !group && !biplot && !is.null(mvmod$scalecol)
  
  if (use_cbar) {
    oldpar <- par(no.readonly = TRUE)
    on.exit({
      layout(1)
      par(oldpar)
    }, add = TRUE)
    
    layout(matrix(c(2, 1), nrow = 2), heights = c(1, 8))
    mar <- par("mar")
    mar[3] <- 1.82
    par(mar = mar)
  }
  
  # 3D score plot
  if (z > 0) {
    if (!is.null(mvmod$call[[1]]) && mvmod$call[[1]] == "plsr") {
      xlab_txt <- sprintf("LV%d (%.1f%%)", x, mvmod$prop_var[x])
      ylab_txt <- sprintf("LV%d (%.1f%%)", y, mvmod$prop_var[y])
      zlab_txt <- sprintf("LV%d (%.1f%%)", z, mvmod$prop_var[z])
    }
    else{
      xlab_txt <- sprintf("PC%d (%.1f%%)", x, mvmod$prop_var[x])
      ylab_txt <- sprintf("PC%d (%.1f%%)", y, mvmod$prop_var[y])
      zlab_txt <- sprintf("PC%d (%.1f%%)", z, mvmod$prop_var[z])
    }
    
    # Asymmetric limits for 3D plot
    if (has_sup) {
      xlim <- range(c(scores[, x], mvmod$supscor[, x]), na.rm = TRUE)
      ylim <- range(c(scores[, y], mvmod$supscor[, y]), na.rm = TRUE)
      zlim <- range(c(scores[, z], mvmod$supscor[, z]), na.rm = TRUE)
    } else {
      xlim <- range(scores[, x], na.rm = TRUE)
      ylim <- range(scores[, y], na.rm = TRUE)
      zlim <- range(scores[, z], na.rm = TRUE)
    }
    
    # Expand limits with margin
    xlim <- xlim + c(-1, 1) * expand * diff(xlim)
    ylim <- ylim + c(-1, 1) * expand * diff(ylim)
    zlim <- zlim + c(-1, 1) * expand * diff(zlim)
    
    # Safe offset helper for labels
    safe_offset <- function(pos, offset_frac, limits) {
      offset <- sign(pos) * offset_frac * diff(limits)
      new_pos <- pos + offset
      margin <- 0.02 * diff(limits)
      pmax(pmin(new_pos, limits[2] - margin), limits[1] + margin)
    }
    
    # Z range used for label offset
    if (has_sup) {
      z_rng <- range(c(scores[, z], mvmod$supscor[, z]), na.rm = TRUE)
    } else {
      z_rng <- range(scores[, z], na.rm = TRUE)
    }
    
    # Allow drawing outside plot region
    par(xpd = TRUE)
    
    # Main 3D scatter plot
    plot3D::scatter3D(
      x = scores[, x],
      y = scores[, y],
      z = scores[, z],
      pch = if (marker)
        21
      else
        NA,
      lwd = 1.5,
      col = col,
      bg = if (marker)
        mix_with_white(col, alpha = if (has_sup)
          0.1
          else
            0.2)
      else
        NA,
      colvar = NULL,
      theta = hrot,
      phi = vrot,
      cex = cex_pts,
      cex.axis = val_cex,
      cex.lab = val_cex,
      bty = if (grids)
        "u"
      else
        "b",
      col.grid = "gray90",
      lwd.grid = 1,
      xlab = paste("\n", xlab_txt),
      ylab = paste("\n", ylab_txt),
      zlab = paste("\n", zlab_txt),
      ticktype = "detailed",
      xlim = xlim,
      ylim = ylim,
      zlim = zlim
    )
    
    # Supplementary points
    if (has_sup) {
      sup_col <- col_sup
      sup_bg <- if (marker)
        mix_with_white(sup_col, alpha = 0.2)
      else
        NA
      
      plot3D::scatter3D(
        x = mvmod$supscor[, x],
        y = mvmod$supscor[, y],
        z = mvmod$supscor[, z],
        add = TRUE,
        pch = if (marker)
          21
        else
          NA,
        col = sup_col,
        bg = sup_bg,
        cex = cex_pts_sup,
        colvar = NULL
      )
    }
    
    # Labels for active scores
    if (labels) {
      if (marker) {
        z_pos <- scores[, z] + 0.06 * diff(z_rng)
      } else {
        z_pos <- scores[, z]
      }
      
      plot3D::text3D(
        x = scores[, x],
        y = scores[, y],
        z = z_pos,
        labels = row_names,
        add = TRUE,
        cex = val_cex,
        adj = 0.5,
        col = if (group && !marker)
          col
        else
          "black"
      )
    }
    
    # Labels for supplementary scores
    if (has_sup && labels) {
      if (marker) {
        z_pos <- mvmod$supscor[, z] + 0.06 * diff(z_rng)
      } else {
        z_pos <- mvmod$supscor[, z]
      }
      
      plot3D::text3D(
        x = mvmod$supscor[, x],
        y = mvmod$supscor[, y],
        z = z_pos,
        labels = mvmod$sup_row_names,
        add = TRUE,
        cex = val_cex,
        adj = 0.5,
        col = col_sup
      )
    }
    
    # Legend for 3D plot
    if (group && !is.null(groups)) {
      leg_labels <- if (has_sup)
        c(levels(colfac), mvmod$suprows)
      else
        levels(colfac)
      leg_cols <- if (has_sup)
        c(pal, col_sup)
      else
        pal
      leg_bg <- if (has_sup)
        c(mix_with_white(pal, alpha = 0.2),
          mix_with_white(col_sup, alpha = 0.2))
      else
        mix_with_white(pal, alpha = 0.2)
      
      legend(
        "top",
        inset = -0.1,
        legend = leg_labels,
        col = leg_cols,
        pt.bg = leg_bg,
        pch = 21,
        pt.lwd = 1.5,
        pt.cex = 1,
        cex = val_cex * 0.8,
        horiz = TRUE,
        bty = "n"
      )
    } else if (has_sup && !group && marker  && !mrkcol) {
      legend(
        "top",
        inset = -0.1,
        legend = c("Active", mvmod$suprows),
        col = c(col, col_sup),
        pt.bg = c(
          mix_with_white(col, alpha = 0.2),
          mix_with_white(col_sup, alpha = 0.2)
        ),
        pch = 21,
        pt.lwd = 1.5,
        pt.cex = 1,
        cex = val_cex * 0.8,
        horiz = TRUE,
        bty = "n"
      )
    }
    
  } else {
    # 2D score plot
    
    # Asymmetric limits
    if (has_sup) {
      xlim <- range(c(scores[, x], mvmod$supscor[, x]), na.rm = TRUE)
      ylim <- range(c(scores[, y], mvmod$supscor[, y]), na.rm = TRUE)
    } else {
      xlim <- range(scores[, x], na.rm = TRUE)
      ylim <- range(scores[, y], na.rm = TRUE)
    }
    
    # Expand limits
    xlim <- xlim + c(-1, 1) * expand * diff(xlim)
    ylim <- ylim + c(-1, 1) * expand * diff(ylim)
    
    # Include complete ellipses
    if (group && elips && !is.null(groups)) {
      for (g in levels(colfac)) {
        xy <- scores[groups == g, c(x, y)]
        
        if (nrow(xy) >= 3) {
          center <- colMeans(xy)
          S <- cov(xy)
          radius <- sqrt(qchisq(0.95, df = 2))
          
          # Maximum displacement from the center
          dx <- radius * sqrt(S[1, 1])
          dy <- radius * sqrt(S[2, 2])
          
          xlim[1] <- min(xlim[1], center[1] - dx)
          xlim[2] <- max(xlim[2], center[1] + dx)
          
          ylim[1] <- min(ylim[1], center[2] - dy)
          ylim[2] <- max(ylim[2], center[2] + dy)
        }
      }
      
      # Additional margin
      xlim <- xlim + c(-1, 1) * expand / 10 * diff(xlim)
      ylim <- ylim + c(-1, 1) * expand / 10 * diff(ylim)
    }
    
    if (!is.null(mvmod$call[[1]]) && mvmod$call[[1]] == "plsr") {
      xlab_txt <- sprintf("LV%d (%.1f%%)", x, mvmod$prop_var[x])
      ylab_txt <- sprintf("LV%d (%.1f%%)", y, mvmod$prop_var[y])
    }
    else
    {
      xlab_txt <- sprintf("PC%d (%.1f%%)", x, mvmod$prop_var[x])
      ylab_txt <- sprintf("PC%d (%.1f%%)", y, mvmod$prop_var[y])
    }
    # Allow drawing outside plot region
    par(xpd = TRUE)
    
    # Main 2D scatter plot
    plot(
      scores[, x],
      scores[, y],
      xlab = xlab_txt,
      ylab = ylab_txt,
      las = 1,
      cex = cex_pts,
      pch = if (marker)
        21
      else
        NA,
      col = col,
      bg = if (marker)
        mix_with_white(col, alpha = 0.2)
      else
        NA,
      lwd = 1.5,
      cex.axis = val_cex,
      cex.lab = val_cex,
      xlim = xlim,
      ylim = ylim
    )
    
    # Supplementary points
    if (has_sup) {
      sup_col <- col_sup
      sup_bg <- if (marker)
        mix_with_white(sup_col, alpha = 0.2)
      else
        NA
      
      points(
        mvmod$supscor[, x],
        mvmod$supscor[, y],
        pch = if (marker)
          21
        else
          NA,
        cex = cex_pts_sup,
        col = sup_col,
        bg = sup_bg,
        lwd = 1.5
      )
    }
    
    # Labels for active scores
    if (labels) {
      if (marker) {
        text(
          scores[, x],
          scores[, y],
          labels = row_names,
          pos = 3,
          cex = val_cex,
          offset = 0.3
        )
      } else {
        text(
          scores[, x],
          scores[, y],
          labels = row_names,
          col = if (group && !marker)
            col
          else
            "black",
          cex = val_cex
        )
      }
    }
    
    # Labels for supplementary scores
    if (has_sup && labels) {
      if (marker) {
        text(
          mvmod$supscor[, x],
          mvmod$supscor[, y],
          labels = mvmod$sup_row_names,
          pos = 3,
          cex = val_cex,
          col = "black",
          offset = 0.3
        )
      } else {
        text(
          mvmod$supscor[, x],
          mvmod$supscor[, y],
          labels = mvmod$sup_row_names,
          cex = val_cex,
          col = col_sup
        )
      }
    }
    
    # Group ellipses
    if (group && elips && !is.null(groups)) {
      for (i in seq_along(levels(colfac))) {
        g <- levels(colfac)[i]
        xy <- scores[groups == g, c(x, y)]
        if (nrow(xy) >= 3) {
          car::ellipse(
            center = colMeans(xy),
            shape = cov(xy),
            radius = sqrt(qchisq(0.95, df = 2)),
            segments = 100,
            draw = TRUE,
            add = TRUE,
            col = pal[i],
            lwd = 1.5,
            center.pch = FALSE,
            fill = fillelip,
            fill.alpha = 0.1
          )
        }
      }
    }
    
    # Legend for 2D plot
    if (group && !is.null(groups)) {
      leg_labels <- if (has_sup)
        c(levels(colfac), mvmod$suprows)
      else
        levels(colfac)
      leg_cols <- if (has_sup)
        c(pal, col_sup)
      else
        pal
      leg_bg <- if (has_sup)
        c(mix_with_white(pal, alpha = 0.2),
          mix_with_white(col_sup, alpha = 0.2))
      else
        mix_with_white(pal, alpha = 0.2)
      
      legend(
        "top",
        inset = -0.1,
        legend = leg_labels,
        col = leg_cols,
        pt.bg = leg_bg,
        pch = 21,
        pt.lwd = 1.5,
        pt.cex = 1,
        cex = val_cex * 0.8,
        horiz = TRUE,
        bty = "n"
      )
    } else if (has_sup && !group && marker && !mrkcol) {
      legend(
        "top",
        inset = -0.1,
        legend = c("Active", mvmod$suprows),
        col = c(col, col_sup),
        pt.bg = c(
          mix_with_white(col, alpha = 0.2),
          mix_with_white(col_sup, alpha = 0.2)
        ),
        pch = 21,
        pt.lwd = 1.5,
        pt.cex = 1,
        cex = val_cex * 0.8,
        horiz = TRUE,
        bty = "n"
      )
    }
    
    # Reference axes
    if (orlines) {
      usr <- par("usr")
      segments(0, usr[3], 0, usr[4], col = "gray60", lwd = 1)
      segments(usr[1], 0, usr[2], 0, col = "gray60", lwd = 1)
    }
    
    # Grid lines
    if (grids) {
      par(xpd = FALSE)
      abline(
        h = pretty(ylim),
        v = pretty(xlim),
        col = "gray90",
        lty = "solid",
        lwd = .5
      )
    }
  }
  
  # colorbar
  if (use_cbar) {
    par(mar = c(.1, 4, 0.5, 2))
    
    plot.new()
    plot.window(xlim = rng, ylim = c(0, 1))
    
    pal_cbar <- mix_with_white(colorRampPalette(pal)(20), alpha = 0.7)
    xs <- seq(rng[1], rng[2], length.out = length(pal_cbar) + 1)
    
    for (i in seq_along(pal_cbar)) {
      rect(xs[i], 0.35, xs[i + 1], 0.65, col = pal_cbar[i], border = NA)
    }
    
    ticks <- pretty(rng)
    ticks <- ticks[ticks >= rng[1] & ticks <= rng[2]]
    
    par(mgp = c(1.2, 0.2, 0))
    
    axis(
      1,
      at = ticks,
      labels = ticks,
      pos = 0.35,
      cex.axis = val_cex,
      tcl = -0.3,
      lwd = 0,
      lwd.ticks = 1
    )
    
    segments(rng[1], 0.35, rng[2], 0.35, lwd = 1)
    
    text(mean(rng), 0.9, mvmod$scalecol_name, cex = val_cex)
  }
  
  par(xpd = FALSE)
  
  if (exists("rng") && exists("pal")) {
    invisible(list(rng = rng, pal = pal))
  } else if (exists("rng")) {
    invisible(list(rng = rng))
  } else if (exists("pal")) {
    invisible(list(pal = pal))
  } else {
    invisible()
  }
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.