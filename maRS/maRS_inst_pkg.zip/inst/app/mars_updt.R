app_file <- file.path(getwd(), "app.R")
if (file.exists(app_file)) {
  app_lines <- readLines(app_file, n = 2, warn = FALSE)
  LOCAL_VERSION <- sub('.*"(.*)".*', '\\1', app_lines[2])
} else {
  LOCAL_VERSION <- as.character(utils::packageVersion("maRS"))
}

remote_url <- "https://laquali-ufla.github.io/maRS/version.R"

tryCatch({
  old_timeout <- getOption("timeout")
  options(timeout = 3)
  on.exit(options(timeout = old_timeout), add = TRUE)
  
  con <- url(remote_url)
  suppressWarnings(open(con, open = "r"))
  remote_lines <- readLines(con, warn = FALSE)
  close(con)
  
  version_line <- grep("Version\\s*=", remote_lines, value = TRUE)
  
  if (length(version_line) > 0) {
    remote_version_str <- trimws(sub(".*Version\\s*=\\s*", "", version_line[1]))
    
    if (package_version(LOCAL_VERSION) < package_version(remote_version_str)) {
      message("A new version has been found. Running the update installer...")
      
      updater <- file.path(getwd(), "www", "updater.html")
      
      if (file.exists(updater)) {
        safe_base <- ifelse(.Platform$OS.type == "unix",
                            Sys.getenv("HOME"),
                            tempdir())
        loader_dir <- file.path(safe_base, "maRS_setup_temp")
        
        if (!dir.exists(loader_dir)) {
          dir.create(loader_dir, recursive = TRUE)
        }
        
        status_file <- file.path(loader_dir, "update_status.js")
        writeLines('var updateDone = false;', status_file)
        
        html <- readLines(updater, warn = FALSE)
        if (exists("port")) {
          html <- gsub("\\{\\{PORT\\}\\}", port, html)
        }
        
        tmp_updater <- file.path(loader_dir, "updater.html")
        writeLines(html, tmp_updater)
        
        browseURL(tmp_updater)
        Sys.sleep(1)
      }
      
      source("https://laquali-ufla.github.io/maRS/install.R")
      
      if (exists("loader_dir") && dir.exists(loader_dir)) {
        writeLines('var updateDone = true;',
                   file.path(loader_dir, "update_status.js"))
      }
    }
  }
}, error = function(e) {
  message("Unable to check for updates. Proceeding with startup...")
})