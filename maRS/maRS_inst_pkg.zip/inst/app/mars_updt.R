# Determine current local version
app_file <- file.path(getwd(), "app.R")
if (file.exists(app_file)) {
  app_lines <- readLines(app_file, n = 2, warn = FALSE)
  LOCAL_VERSION <- sub('.*"(.*)".*', '\\1', app_lines[2])
} else {
  LOCAL_VERSION <- as.character(utils::packageVersion("maRSpkg"))
}

remote_url <- "https://laquali-ufla.github.io/maRS/version.R"

tryCatch({
  old_timeout <- getOption("timeout")
  options(timeout = 2)
  on.exit(options(timeout = old_timeout), add = TRUE)
  
  con <- url(remote_url)
  suppressWarnings(open(con, open = "r"))
  remote_lines <- readLines(con, warn = FALSE)
  close(con)
  
  version_line <- grep("Version\\s*=", remote_lines, value = TRUE)
  
  if (length(version_line) > 0) {
    remote_version_str <- trimws(sub(".*Version\\s*=\\s*", "", version_line[1]))
    
    # Check if remote version is newer than local version
    if (package_version(LOCAL_VERSION) < package_version(remote_version_str)) {
      # Log update notification in R console
      message(
        sprintf(
          "\n[maRS] A new version is available! (Current: %s | New: %s)",
          LOCAL_VERSION,
          remote_version_str
        )
      )
      message("[maRS] To update, close the app and run:")
      message("       source(\"https://laquali-ufla.github.io/maRS/install.R\")\n")
      
      # Locate updater template
      updater_template <- file.path(getwd(), "www", "updater.html")
      if (!file.exists(updater_template)) {
        updater_template <- file.path(getwd(), "updater.html")
      }
      
      if (file.exists(updater_template)) {
        # Store default browser handler
        default_browser <- getOption("browser")
        
        # Intercept Shiny's browser launch trigger
        options(
          browser = function(shiny_url) {
            # Restore default browser handler for future calls
            options(browser = default_browser)
            
            # Extract port from environment or fallback to default
            app_port <- if (exists("port"))
              port
            else
              3838
            
            safe_base <- ifelse(.Platform$OS.type == "unix",
                                Sys.getenv("HOME"),
                                tempdir())
            loader_dir <- file.path(safe_base, "maRS_setup_temp")
            if (!dir.exists(loader_dir))
              dir.create(loader_dir, recursive = TRUE)
            
            html_content <- readLines(updater_template, warn = FALSE)
            
            # Inject dynamic variables into HTML template
            html_content <- gsub("\\{\\{PORT\\}\\}", app_port, html_content)
            html_content <- gsub("\\{\\{LOCAL_VERSION\\}\\}",
                                 LOCAL_VERSION,
                                 html_content)
            html_content <- gsub("\\{\\{REMOTE_VERSION\\}\\}",
                                 remote_version_str,
                                 html_content)
            
            tmp_updater <- file.path(loader_dir, "updater.html")
            writeLines(html_content, tmp_updater)
            
            # Open updater.html INSTEAD of opening the Shiny application directly
            utils::browseURL(tmp_updater)
          }
        )
      }
    }
  }
}, error = function(e) {
  # Proceed silently if offline or network connection fails
  message("Proceeding with current version...")
})