# Version
LOCAL_VERSION <- "0.5"

# Load packages
requireNamespace("pls", quietly = TRUE)
suppressMessages(library(maRSpkg))

# Set upload limit
options(shiny.maxRequestSize = 100 * 1024^2)

# Graphic resolution
renderPlot96 <- function(expr, ..., res = 96) {
  expr <- substitute(expr)
  env  <- parent.frame()
  shiny::renderPlot(expr = eval(expr, env), ..., res = res)
}

assign("renderPlot", renderPlot96, envir = .GlobalEnv)

# # Load R functions
# if ("rFunctions" %in% search())
#   detach("rFunctions")
# 
# .fun <- new.env()
# files <- sort(list.files(
#   file.path("rFunctions"),
#   pattern = "\\.R$",
#   full.names = TRUE
# ))
# invisible(lapply(files, source, local = .fun))
# attach(.fun, name = "rFunctions")
# 
# # Load tab functions
# if ("rTabs" %in% search())
#   detach("rTabs")
# 
# .fun <- new.env()
# files <- sort(list.files(
#   file.path("rTabs"),
#   pattern = "\\.R$",
#   full.names = TRUE
# ))
# invisible(lapply(files, source, local = .fun))
# attach(.fun, name = "rTabs")

# Import modules
source("appData.R")
source("appPlot.R")
source("appHCA.R")
source("appPCA.R")
source("appMLR.R")
source("appPLS.R")
source("appMLRDA.R")
source("appPLSDA.R")
source("appSIMCA.R")
source("appOver.R")

# =========================
# UI
# =========================
ui <- tagList(
  tags$head(
    # Tell translators that this page must not be translated
    tags$meta(name = "google", content = "notranslate"),
    
    tags$script(
      HTML(
        "
        function disableTranslation() {
          document.documentElement.setAttribute('translate', 'no');
          document.documentElement.classList.add('notranslate');

          if (document.body) {
            document.body.setAttribute('translate', 'no');
            document.body.classList.add('notranslate');
          }
        }

        disableTranslation();

        document.addEventListener('DOMContentLoaded', function() {

          disableTranslation();

          const observer = new MutationObserver(function() {
            disableTranslation();
          });

          observer.observe(document.body, {
            childList: true,
            subtree: true
          });

        });
        "
      )
    ),
    
    tags$title("maRS"),
    
    tags$style(
      HTML(
        "
      hr {border-top: 1px solid #B3B3B3;}

      body { font-size: 12px; }
      h3 { font-size: 16px; }
      h4 { font-size: 14px; }
      label { font-size: 12px; }
      .form-control { font-size: 12px; }

      .form-group { margin-bottom: 0px !important; }

      .btn:focus, .btn:active, .btn:active:focus {
        outline: none !important;
        box-shadow: none !important;
      }

      .btn:hover {
        background-color: #e2e2e2 !important;
        transition: background-color 0.2s ease;
      }

      #menu_dataset + .selectize-control .selectize-input,
      #menu_exploratory + .selectize-control .selectize-input,
      #menu_classification + .selectize-control .selectize-input,
      #menu_regression + .selectize-control .selectize-input {
        border: none !important;
        border-radius: 0px !important;
        box-shadow: none !important;
        background-color: #f5f5f5;
        display: flex;
        align-items: center;
        height: 100%;
        padding-right: 20px !important;
      }

      #menu_dataset + .selectize-control .selectize-input {
        width: 100px !important;
      }

      #menu_exploratory + .selectize-control .selectize-input {
        width: 110px !important;
      }

      #menu_classification + .selectize-control .selectize-input {
        width: 120px !important;
      }

      #menu_regression + .selectize-control .selectize-input {
        width: 110px !important;
      }

      .selectize-control { height: 100%; }

      .selectize-dropdown-content {
        max-height: 250px !important;
      }

      .selectize-dropdown {
        z-index: 9999 !important;
      }
    "
      )
    )
  ),
  fluidPage(
    # Control line
    fluidRow(
      style = "height: 34px; display: flex; align-items: stretch; margin-top: 0px; margin-bottom: 10px; background-color: #f5f5f5;",
      # Main title
      div(
        style = "padding-left: 20px;
             padding-right: 10px;
             font-size: 20px;
             font-weight: bold;
             height: 100%;
             display: flex;
             align-items: center;
             white-space: nowrap;",
        
        span(style = "color: #0070C0;", "ma"),
        span(style = "color: #00B050;", "R"),
        span(style = "color: #FFC000;", "S")
      ),
      uiOutput("estilo_botoes"),
      
      # Dropdown
      div(
        style = "display: flex; gap: 0px; padding: 0px; width: auto;",
        
        div(
          style = "display:inline-block;",
          selectInput(
            "menu_dataset",
            NULL,
            choices = c("Dataset" = "", "Plot", "Oversampling"),
            width = "100%"
          )
        ),
        
        div(
          style = "display:inline-block;",
          selectInput(
            "menu_exploratory",
            NULL,
            choices = c("Exploratory" = "", "HCA", "PCA"),
            width = "100%"
          )
        ),
        
        div(
          style = "display:inline-block;",
          selectInput(
            "menu_classification",
            NULL,
            choices = c("Classification" = "", "MLR-DA", "PLS-DA", "SIMCA"),
            width = "100%"
          )
        ),
        
        div(
          style = "display:inline-block;",
          selectInput(
            "menu_regression",
            NULL,
            choices = c("Regression" = "", "MLR", "PLS"),
            width = "100%"
          )
        )
      ),
      
      # Data button
      column(
        1,
        style = "padding: 0px;",
        actionButton("btn_data", "Data", width = "100%", style = "height: 100%; border-radius: 0px; border: none;background-color: #f5f5f5;")
      ),
      
      # Analysis button
      column(
        1,
        style = "padding: 0px;",
        actionButton("btn_analysis", "...", width = "100%", style = "height: 100%; border-radius: 0px; border: none; background-color: #f5f5f5;")
      ),
      
      # help & About
      div(
        style = "margin-left: auto; padding-right: 15px; height: 100%; display: flex; align-items: center; gap: 15px;",
        tags$a(
          "Help",
          href = "userGuide.pdf",
          target = "_blank",
          style = "font-size: 12px; color: #333; text-decoration: none; cursor: pointer;"
        ),
        actionLink("btn_about", "About", style = "font-size: 12px; color: #333;")
      )
    ),
    
    # Dynamic space of interfaces
    conditionalPanel(condition = "output.aba_ativa == 'Data' || typeof output.aba_ativa === 'undefined'", appDataUI),
    conditionalPanel(condition = "output.aba_ativa == 'Plot'", appPlotUI),
    conditionalPanel(condition = "output.aba_ativa == 'HCA'", appHCAUI),
    conditionalPanel(condition = "output.aba_ativa == 'PCA'", appPCAUI),
    conditionalPanel(condition = "output.aba_ativa == 'MLR'", appMLRUI),
    conditionalPanel(condition = "output.aba_ativa == 'PLS'", appPLSUI),
    conditionalPanel(condition = "output.aba_ativa == 'MLR-DA'", appMLRDAUI),
    conditionalPanel(condition = "output.aba_ativa == 'PLS-DA'", appPLSDAUI),
    conditionalPanel(condition = "output.aba_ativa == 'SIMCA'", appSIMCAUI),
    conditionalPanel(condition = "output.aba_ativa == 'Oversampling'", appOverUI),
  )
)

# =========================
# Server
# =========================
server <- function(input, output, session) {
  session$onSessionEnded(function() {
    shiny::stopApp()
  })
  
  df_shared <- reactiveVal(NULL)
  
  # Flags para lazy load
  data_loaded <- FALSE
  plot_loaded <- FALSE
  hca_loaded <- FALSE
  pca_loaded <- FALSE
  mlr_loaded <- FALSE
  pls_loaded <- FALSE
  mlrda_loaded <- FALSE
  plsda_loaded <- FALSE
  simca_loaded <- FALSE
  over_loaded <- FALSE
  
  # Variable for the current screen
  tela_selecionada <- reactiveVal("Data")
  output$aba_ativa <- reactive({
    tela_selecionada()
  })
  outputOptions(output, "aba_ativa", suspendWhenHidden = FALSE)
  
  # Saves which analysis the second button is currently representing
  analise_no_botao <- reactiveVal(NULL)
  
  # Update the button, change the screen instantly, and reset the dropdown
  observe({
    escolha <- NULL
    
    if (!is.null(input$menu_dataset) && input$menu_dataset != "")
      escolha <- input$menu_dataset
    
    if (!is.null(input$menu_exploratory) &&
        input$menu_exploratory != "")
      escolha <- input$menu_exploratory
    
    if (!is.null(input$menu_classification) &&
        input$menu_classification != "")
      escolha <- input$menu_classification
    
    if (!is.null(input$menu_regression) &&
        input$menu_regression != "")
      escolha <- input$menu_regression
    
    if (!is.null(escolha)) {
      analise_no_botao(escolha)
      updateActionButton(session, "btn_analysis", label = escolha)
      tela_selecionada(escolha)
      
      # reset todos
      updateSelectInput(session, "menu_dataset", selected = "")
      updateSelectInput(session, "menu_exploratory", selected = "")
      updateSelectInput(session, "menu_classification", selected = "")
      updateSelectInput(session, "menu_regression", selected = "")
    }
  })
  
  # Navegation
  observeEvent(input$btn_data, {
    tela_selecionada("Data")
  })
  
  observeEvent(input$btn_analysis, {
    if (!is.null(analise_no_botao())) {
      tela_selecionada(analise_no_botao())
    }
  })
  
  # Start the modules
  observeEvent(tela_selecionada(), {
    tela <- tela_selecionada()
    
    if (tela == "Data" && !data_loaded) {
      appDataServer(input, output, session, df_shared)
      data_loaded <<- TRUE
    }
    
    if (tela == "Plot" && !plot_loaded) {
      appPlotServer(input, output, session, df_shared)
      plot_loaded <<- TRUE
    }
    
    if (tela == "HCA" && !hca_loaded) {
      appHCAServer(input, output, session, df_shared)
      hca_loaded <<- TRUE
    }
    
    if (tela == "PCA" && !pca_loaded) {
      appPCAServer(input, output, session, df_shared)
      pca_loaded <<- TRUE
    }
    
    if (tela == "MLR" && !mlr_loaded) {
      appMLRServer(input, output, session, df_shared)
      mlr_loaded <<- TRUE
    }
    
    if (tela == "PLS" && !pls_loaded) {
      appPLSServer(input, output, session, df_shared)
      pls_loaded <<- TRUE
    }
    
    if (tela == "MLR-DA" && !mlrda_loaded) {
      appMLRDAServer(input, output, session, df_shared)
      mlrda_loaded <<- TRUE
    }
    
    if (tela == "PLS-DA" && !plsda_loaded) {
      appPLSDAServer(input, output, session, df_shared)
      plsda_loaded <<- TRUE
    }
    
    if (tela == "SIMCA" && !simca_loaded) {
      appSIMCAServer(input, output, session, df_shared)
      simca_loaded <<- TRUE
    }
    
    if (tela == "Oversampling" && !over_loaded) {
      appOverServer(input, output, session, df_shared)
      over_loaded <<- TRUE
    }
    
  })
  
  # Button color control
  output$estilo_botoes <- renderUI({
    tela <- tela_selecionada()
    
    # Defines which button should be colored blue.
    botao_ativo <- if (tela == "Data")
      "#btn_data"
    else
      "#btn_analysis"
    
    # Create CSS styles dynamically.
    tags$style(HTML(
      paste0(
        botao_ativo,
        " {
        background-color: #337ab7 !important;
        color: white !important;
      }
    "
      )
    ))
  })
  
  # About pop-up
  observeEvent(input$btn_about, {
    showModal(modalDialog(title = "About", tagList(
      # PNG no topo
      tags$div(
        style = "text-align:center; margin-bottom:10px;",
        tags$img(
          src = "logo_maRS.png",
          height = "48px",
          width = "48px"
        )
      ),
      HTML(
        sprintf(
          "<div style='text-align: center; font-size: 14px;'>
          <b>
            <b><span style='color:#0070C0;'>ma</span><span style='color:#00B050;'>R</span><span style='color:#FFC000;'>S</span></b>
          </b><br>

          <span style='font-weight:bold; color:#0070C0;'>m</span>ultivariate
          <span style='font-weight:bold; color:#0070C0;'>a</span>nalysis in
          <span style='font-weight:bold; color:#00B050;'>R</span> and
          <span style='font-weight:bold; color:#FFC000;'>S</span>hiny<br>

          Version %s<br>
          <br>
          Cleiton A. Nunes<br>
          Federal University of Lavras<br>
          Brazil<br>
          2026<br>
          <br>
          cleiton.nunes@ufla.br<br>
          <br>
          <span style='font-size: 11px;'>
            This software is provided &quot;as is&quot;, without warranty of any kind, and is distributed under the terms of the GNU General Public License v3.0 (GPL-3.0).
          </span>
        </div>",
          LOCAL_VERSION
        )
      )
    )))
  })
  
}
shinyApp(ui, server)

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.