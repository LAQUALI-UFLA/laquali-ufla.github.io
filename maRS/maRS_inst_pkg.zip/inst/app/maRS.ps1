# Gets the path of the current directory where this script is located
$AppDataPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$RFile = Join-Path $AppDataPath "start.R"

$Rscript = $null

# 1. Tries to find it in the system PATH
$cmd = Get-Command Rscript -ErrorAction SilentlyContinue
if ($cmd) { $Rscript = $cmd.Source }

# 2. Searches the Windows Registry (where the official R is registered)
if (-not $Rscript) {
    $regPaths = @(
        "HKLM:\SOFTWARE\R-core\R",
        "HKLM:\SOFTWARE\WOW6432Node\R-core\R",
        "HKCU:\SOFTWARE\R-core\R"
    )
    foreach ($reg in $regPaths) {
        if (Test-Path $reg) {
            $rPath = (Get-ItemProperty -Path $reg -ErrorAction SilentlyContinue).InstallPath
            if ($rPath) {
                $possibleRscript = Join-Path $rPath "bin\Rscript.exe"
                if (Test-Path $possibleRscript) {
                    $Rscript = $possibleRscript
                    break
                }
            }
        }
    }
}

# 3. Searches in known folders
if (-not $Rscript) {
    $searchPaths = @(
        "C:\Program Files\R",
        "C:\Program Files (x86)\R",
        "$env:LOCALAPPDATA\Programs\R",
        "C:\R"
    )
    foreach ($path in $searchPaths) {
        if (Test-Path $path) {
            $found = Get-ChildItem -Path $path -Filter "Rscript.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($found) {
                $Rscript = $found.FullName
                break
            }
        }
    }
}

# 4. Executes the R application
if ($Rscript -and (Test-Path $RFile)) {
    Set-Location $AppDataPath
    Start-Process -FilePath $Rscript -ArgumentList "`"$RFile`"" -WorkingDirectory "`"$AppDataPath`"" -WindowStyle Hidden
} else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show(
        "Could not locate Rscript.exe or the start.R file.`nCheck your R installation.",
        "Error Executing maRS",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )
}