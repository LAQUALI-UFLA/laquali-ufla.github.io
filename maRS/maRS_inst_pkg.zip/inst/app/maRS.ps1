$AppDataPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$RFile = Join-Path $AppDataPath "start.R"

function Find-Rscript {

    $candidates = @()

    # R instalado pelo usuário
    if ($env:LOCALAPPDATA) {
        $candidates += Join-Path $env:LOCALAPPDATA "Programs\R"
    }

    # R instalado para todos os usuários
    if ($env:ProgramFiles) {
        $candidates += Join-Path $env:ProgramFiles "R"
    }

    # R 32-bit
    $programFilesX86 = [Environment]::GetEnvironmentVariable("ProgramFiles(x86)")
    if ($programFilesX86) {
        $candidates += Join-Path $programFilesX86 "R"
    }

    # Instalação alternativa
    $candidates += "C:\R"

    foreach ($base in $candidates) {

        if (-not (Test-Path -LiteralPath $base)) {
            continue
        }

        $versions = Get-ChildItem `
            -LiteralPath $base `
            -Directory `
            -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -match "^R-\d+(\.\d+)+$"
            } |
            Sort-Object {
                [version]($_.Name -replace "^R-","")
            } -Descending

        foreach ($version in $versions) {

            $rscript = Join-Path `
                $version.FullName `
                "bin\x64\Rscript.exe"

            if (Test-Path -LiteralPath $rscript) {
                return $rscript
            }

            $rscript = Join-Path `
                $version.FullName `
                "bin\Rscript.exe"

            if (Test-Path -LiteralPath $rscript) {
                return $rscript
            }
        }
    }

    return $null
}

$Rscript = Find-Rscript

if ($Rscript -and (Test-Path -LiteralPath $Rscript)) {

    Start-Process `
        -FilePath $Rscript `
        -ArgumentList "`"$RFile`"" `
        -WorkingDirectory $AppDataPath `
        -WindowStyle Hidden

} else {

    Add-Type -AssemblyName System.Windows.Forms

    [System.Windows.Forms.MessageBox]::Show(
        "R was not found on this computer. Please install R and try again.",
        "maRS - R not found",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )
}