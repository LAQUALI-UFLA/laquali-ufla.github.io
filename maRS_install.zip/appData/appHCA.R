# =========================
# UI
# =========================

appHCAUI <- tagList(fluidRow(column(
  width = 3,
  wellPanel(
    style = "padding-top:0px;",
    h3("HCA settings"),
    
    checkboxInput("hca_scale", "Scale", FALSE),
    
    selectInput(
      "hca_linkage",
      "Linkage:",
      c("single", "complete", "average"),
      selected = "average"
    ),
    
    numericInput(
      "hca_ngroups",
      "Number of groups:",
      value = 1,
      min = 0,
      max = 20,
      step = 1
    ),
    
    checkboxInput("hca_horiz", "Horizontal", FALSE),
    
    selectInput(
      "hca_palette",
      "Colors:",
      c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
    ),
    
    br(),
    actionButton(
      "run_hca_btn",
      "Run",
      icon = icon("play"),
      class = "btn-primary"
    )
  )
), column(width = 9, fluidRow(
  column(width = 9, uiOutput("hca_plot_container")), column(
    width = 3,
    wellPanel(
      style = "padding-top:0px;",
      h3("Export graph"),
      numericInput(
        "hca_fontsize",
        "Font factor:",
        value = 0.7,
        min = 0.3,
        max = 2,
        step = 0.1
      ),
      exportPlotUI("hca_export")
    )
  )
))))

# =========================
# SERVER
# =========================

appHCAServer <- function(input, output, session, df_shared) {
  # Run HCA
  
  hca_ran <- reactiveVal(FALSE)
  
  observeEvent(input$run_hca_btn, {
    req(df_shared())
    hca_ran(TRUE)
  })
  
  # Run HCA
  make_hca_plot <- function() {
    run_hca(
      df       = df_shared(),
      scale    = input$hca_scale,
      linkage  = input$hca_linkage,
      ngroups  = input$hca_ngroups,
      horiz    = input$hca_horiz,
      colPa    = input$hca_palette,
      val_cex  = input$hca_fontsize
    )
    
  }
  
  # Dendrogram
  output$main_hca_plot <- renderPlot({
    req(df_shared())
    req(hca_ran())
    
    make_hca_plot()
    
  })
  
  export_controls <- exportPlotServer("hca_export", plot_fun = make_hca_plot)
  
  output$hca_plot_container <- renderUI({
    plotOutput(
      "main_hca_plot",
      width  = paste0(export_controls$width(), "px"),
      height = paste0(export_controls$height(), "px")
    )
    
  })
  
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.