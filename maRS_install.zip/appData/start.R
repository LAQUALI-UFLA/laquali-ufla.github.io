# =========================
# start.R with dynamic port and loader
# =========================

# Force the creation/use of a personal library (prevents administrator errors)
user_lib <- Sys.getenv("R_LIBS_USER")
if (!dir.exists(user_lib)) {
  dir.create(user_lib, recursive = TRUE)
}
.libPaths(c(user_lib, .libPaths()))

# Function to select available port
getFreePort <- function(min = 3000,
                        max = 9000,
                        tries = 100) {
  for (i in 1:tries) {
    p <- sample(min:max, 1)
    con <- try(socketConnection("127.0.0.1",
                                port = p,
                                open = "r+",
                                timeout = 1),
               silent = TRUE)
    if (inherits(con, "try-error")) {
      # available port
      return(p)
    } else {
      close(con)
    }
  }
  stop("No free port could be found.")
}

# Required packages
pkgs <- c(
  "Matrix",
  "MASS",
  "scales",
  "readxl",
  "writexl",
  "pls",
  "plot3D",
  "car",
  "officer",
  "rvg",
  "dendextend",
  "shiny",
  "DT",
  "SMOTEWB"
)

options(repos = c(CRAN = "https://cloud.r-project.org"))

miss <- pkgs[!pkgs %in% installed.packages()[, "Package"]]

# Choose dynamic port
port <- getFreePort()
# port <- httpuv::randomPort()
# port = 3838

# If there are any missing packages, open the loader and install them
if (length(miss) > 0) {
  loader <- file.path(getwd(), "www", "loader.html")
  
  # read HTML
  html <- readLines(loader)
  
  # replace placeholder {{PORT}} with port[cite: 2]
  html <- gsub("\\{\\{PORT\\}\\}", port, html)
  
  # Creates an isolated temporary directory specifically for the loader and the .js files
  loader_dir <- tempfile("mars_loader")
  dir.create(loader_dir)
  
  # saves the temporary file in the new isolated directory
  tmp_loader <- file.path(loader_dir, "loader.html")
  writeLines(html, tmp_loader)
  
  # Open loader in browser[cite: 2]
  browseURL(tmp_loader)
  
  # Error control variables
  install_error <- FALSE
  failed_pkg <- ""
  error_log <- ""
  
  # Install missing packages one by one to update the progress[cite: 1]
  for (i in seq_along(miss)) {
    pkg <- miss[i]
    
    # 1. Create a JS script that tells the loader which package we are currently installing[cite: 1]
    js_code <- sprintf('updateStatus(%d, %d, "%s");', i, length(miss), pkg)
    writeLines(js_code, file.path(loader_dir, paste0("status", i, ".js")))
    
    # 2. Installs the package only if it has NOT been installed as a dependency of a previous one.[cite: 1]
    if (!requireNamespace(pkg, quietly = TRUE)) {
      
      # Captures the installation messages and warnings log (quiet = FALSE to generate log)
      out <- capture.output({
        msg <- capture.output({
          suppressWarnings(install.packages(pkg, quiet = FALSE))
        }, type = "message")
      }, type = "output")
      
      # Consolidates the log
      full_log <- c(out, msg)
      
      # 3. Checks if the package was successfully installed
      if (!requireNamespace(pkg, quietly = TRUE)) {
        install_error <- TRUE
        failed_pkg <- pkg
        
        # Formats the log to be safely inserted into HTML via JavaScript
        error_log <- paste(full_log, collapse = "<br>")
        error_log <- gsub("'", "\\\\'", error_log)
        error_log <- gsub('"', '\\\\"', error_log)
        error_log <- gsub("\\\\", "\\\\\\\\", error_log)
        
        break # Breaks the loop on the first error
      }
    }
  }
  
  if (install_error) {
    # Creates a JS script that replaces the loading screen with the error log
    js_error <- sprintf(
      "document.body.innerHTML = '<div style=\"padding: 30px; font-family: sans-serif;\"><h2 style=\"color: #d9534f;\">Error installing: %s</h2><p>The application could not be started. Below is the installation log:</p><div style=\"background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; font-family: monospace; font-size: 13px; overflow-y: auto; max-height: 500px; border: 1px solid #f5c6cb;\">%s</div></div>';",
      failed_pkg, error_log
    )
    
    # Writes the error JS to the current status file for the browser to read immediately
    writeLines(js_error, file.path(loader_dir, paste0("status", i, ".js")))
    
    # Stops the execution of the R script
    stop(sprintf("Failed to install package '%s'. Check the log opened in your browser.", failed_pkg))
    
  } else {
    # Informs the loader that we have finished the installations[cite: 1]
    writeLines('updateStatus("All", "All", "Finishing setup...");', 
               file.path(loader_dir, paste0("status", length(miss) + 1, ".js")))
  }
}

# Run Shiny on the dynamic port[cite: 1]
library(shiny)

runApp(
  appDir = file.path(getwd()),
  host = "127.0.0.1",
  port = port,
  launch.browser = TRUE
)

# Cleiton A. Nunes, 2026[cite: 1]
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.[cite: 1]