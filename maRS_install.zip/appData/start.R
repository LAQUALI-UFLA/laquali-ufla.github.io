# =========================
# start.R with dynamic port and loader
# =========================

# Force the creation/use of a personal library (prevents administrator errors)
user_lib <- Sys.getenv("R_LIBS_USER")
if (!dir.exists(user_lib)) {
  dir.create(user_lib, recursive = TRUE)
}
.libPaths(c(user_lib, .libPaths()))

# Function to select available port
getFreePort <- function(min = 3000,
                        max = 9000,
                        tries = 100) {
  for (i in 1:tries) {
    p <- sample(min:max, 1)
    con <- try(socketConnection("127.0.0.1",
                                port = p,
                                open = "r+",
                                timeout = 1),
               silent = TRUE)
    if (inherits(con, "try-error")) {
      # available port
      return(p)
    } else {
      close(con)
    }
  }
  stop("No free port could be found.")
}

# Required packages
pkgs <- c(
  "pls",
  "scales",
  "MASS",
  "plot3D",
  "car",
  "Matrix",
  "dendextend",
  "shiny",
  "readxl",
  "writexl",
  "officer",
  "rvg",
  "SMOTEWB",
  "DT"
)#"export"

options(repos = c(CRAN = "https://cloud.r-project.org"))

miss <- pkgs[!pkgs %in% installed.packages()[, "Package"]]

# Choose dynamic port
port <- getFreePort()
# port <- httpuv::randomPort()
# port = 3838

# If there are any missing packages, open the loader and install them.
if (length(miss) > 0) {
  loader <- file.path(getwd(), "www", "loader.html")
  
  # read HTML
  html <- readLines(loader)
  
  # replace placeholder {{PORT}} with port[cite: 2]
  html <- gsub("\\{\\{PORT\\}\\}", port, html)
  
  # Cria um diretório temporário isolado específico para o loader e os arquivos .js
  loader_dir <- tempfile("mars_loader")
  dir.create(loader_dir)
  
  # saves temporary file no novo diretório isolado
  tmp_loader <- file.path(loader_dir, "loader.html")
  writeLines(html, tmp_loader)
  
  # Open loader in browser[cite: 2]
  browseURL(tmp_loader)
  
  # Install missing packages UM POR UM para atualizar o progresso
  for (i in seq_along(miss)) {
    # 1. Cria um script JS que diz ao loader qual pacote estamos instalando agora
    js_code <- sprintf('updateStatus(%d, %d, "%s");', i, length(miss), miss[i])
    writeLines(js_code, file.path(loader_dir, paste0("status", i, ".js")))
    
    # 2. Instala o pacote
    install.packages(miss[i], dependencies = TRUE, quiet = TRUE)
  }
  
  # Informa ao loader que finalizamos as instalações
  writeLines('updateStatus("All", "All", "Finishing setup...");', 
             file.path(loader_dir, paste0("status", length(miss) + 1, ".js")))
}

# Run Shiny on the dynamic port
library(shiny)

runApp(
  appDir = file.path(getwd()),
  host = "127.0.0.1",
  port = port,
  launch.browser = TRUE
)

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.