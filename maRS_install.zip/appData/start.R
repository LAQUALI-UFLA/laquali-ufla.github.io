# =========================
# start.R with dynamic port and loader
# =========================

# Force the creation/use of a personal library (prevents administrator errors)
user_lib <- Sys.getenv("R_LIBS_USER")
if (!dir.exists(user_lib)) {
  dir.create(user_lib, recursive = TRUE)
}
.libPaths(c(user_lib, .libPaths()))

# Function to select available port
getFreePort <- function(min = 3000,
                        max = 9000,
                        tries = 100) {
  for (i in 1:tries) {
    p <- sample(min:max, 1)
    con <- try(socketConnection("127.0.0.1",
                                port = p,
                                open = "r+",
                                timeout = 1),
               silent = TRUE)
    if (inherits(con, "try-error")) {
      # available port
      return(p)
    } else {
      close(con)
    }
  }
  stop("No free port could be found.")
}

# Required packages
pkgs <- c(
  "Matrix",
  "MASS",
  "scales",
  "readxl",
  "writexl",
  "pls",
  "plot3D",
  "car",
  "officer",
  "rvg",
  "dendextend",
  "shiny",
  "DT",
  "SMOTEWB"
)

options(repos = c(CRAN = "https://cloud.r-project.org"))

miss <- pkgs[!pkgs %in% installed.packages()[, "Package"]]

# Choose dynamic port
port <- getFreePort()
# port <- httpuv::randomPort()
# port = 3838

# If there are any missing packages, open the loader and install them
if (length(miss) > 0) {
  loader <- file.path(getwd(), "www", "loader.html")
  
  # read HTML
  html <- readLines(loader)
  
  # replace placeholder {{PORT}} with port[cite: 2]
  html <- gsub("\\{\\{PORT\\}\\}", port, html)
  
  # Creates an isolated temporary directory specifically for the loader and the .js files
  loader_dir <- tempfile("mars_loader")
  dir.create(loader_dir)
  
  # saves the temporary file in the new isolated directory
  tmp_loader <- file.path(loader_dir, "loader.html")
  writeLines(html, tmp_loader)
  
  # Open loader in browser[cite: 2]
  browseURL(tmp_loader)
  
  # Install missing packages one by one to update the progress
  for (i in seq_along(miss)) {
    # 1. Create a JS script that tells the loader which package we are currently installing
    js_code <- sprintf('updateStatus(%d, %d, "%s");', i, length(miss), miss[i])
    writeLines(js_code, file.path(loader_dir, paste0("status", i, ".js")))
    
    # 2. Installs the package only if it has NOT been installed as a dependency of a previous one.
    if (!requireNamespace(miss[i], quietly = TRUE)) {
      install.packages(miss[i], quiet = TRUE)
    }
  }
  
  # Informs the loader that we have finished the installations
  writeLines('updateStatus("All", "All", "Finishing setup...");', 
             file.path(loader_dir, paste0("status", length(miss) + 1, ".js")))
}

# Run Shiny on the dynamic port
library(shiny)

runApp(
  appDir = file.path(getwd()),
  host = "127.0.0.1",
  port = port,
  launch.browser = TRUE
)

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.