# =========================
# start.R with dynamic port and loader
# =========================

# Force the creation/use of a personal library (prevents administrator errors)
user_lib <- Sys.getenv("R_LIBS_USER")
if (!dir.exists(user_lib)) {
  dir.create(user_lib, recursive = TRUE)
}
.libPaths(c(user_lib, .libPaths()))

# Function to select available port
getFreePort <- function(min = 3000,
                        max = 9000,
                        tries = 100) {
  for (i in 1:tries) {
    p <- sample(min:max, 1)
    con <- try(socketConnection("127.0.0.1",
                                port = p,
                                open = "r+",
                                timeout = 1),
               silent = TRUE)
    if (inherits(con, "try-error")) {
      # available port
      return(p)
    } else {
      close(con)
    }
  }
  stop("No free port could be found.")
}

# Required packages
pkgs <- c(
  "Matrix",
  "MASS",
  "scales",
  "readxl",
  "writexl",
  "pls",
  "plot3D",
  "car",
  "officer",
  "rvg",
  "dendextend",
  "shiny",
  "DT",
  "SMOTEWB"
)

options(repos = c(CRAN = "https://cloud.r-project.org"))

miss <- pkgs[!pkgs %in% installed.packages()[, "Package"]]

# Choose dynamic port
port <- getFreePort()

# If there are any missing packages, open the loader and install them
if (length(miss) > 0) {
  loader <- file.path(getwd(), "www", "loader.html")
  
  # Read HTML
  html <- readLines(loader)
  
  # Replace placeholder {{PORT}} with port
  html <- gsub("\\{\\{PORT\\}\\}", port, html)
  
  # Creates an isolated temporary directory specifically for the loader and the .js files
  loader_dir <- tempfile("mars_loader")
  dir.create(loader_dir)
  
  # Saves the temporary file in the new isolated directory
  tmp_loader <- file.path(loader_dir, "loader.html")
  writeLines(html, tmp_loader)
  
  # Open loader in browser
  browseURL(tmp_loader)
  
  # Error control variables
  install_error <- FALSE
  failed_pkg <- ""
  full_log_text <- ""
  
  # Install missing packages one by one to update the progress
  for (i in seq_along(miss)) {
    pkg <- miss[i]
    
    # 1. Create a JS script that tells the loader which package we are currently installing
    js_code <- sprintf('updateStatus(%d, %d, "%s");', i, length(miss), pkg)
    writeLines(js_code, file.path(loader_dir, paste0("status", i, ".js")))
    
    # 2. Installs the package only if it has NOT been installed as a dependency of a previous one
    if (!requireNamespace(pkg, quietly = TRUE)) {
      
      # Temporary files for script and log execution (Cross-platform safe)
      temp_script <- tempfile(fileext = ".R")
      log_file <- tempfile(fileext = ".log")
      
      # Normalize user library path for cross-platform compatibility
      clean_user_lib <- normalizePath(user_lib, winslash = "/", mustWork = FALSE)
      
      # Write clean R commands to temporary script file
      script_content <- c(
        sprintf(".libPaths(c('%s', .libPaths()))", clean_user_lib),
        "options(repos = c(CRAN = 'https://cloud.r-project.org'))",
        sprintf("install.packages('%s', quiet = FALSE)", pkg)
      )
      writeLines(script_content, temp_script)
      
      # Resolves Rscript binary path dynamically from the active R session
      rscript_executable <- ifelse(.Platform$OS.type == "windows", "Rscript.exe", "Rscript")
      rscript_bin <- file.path(R.home("bin"), rscript_executable)
      
      # Fallback check in case Rscript is inside an architecture subfolder (e.g., bin/x64 on older R versions)
      if (!file.exists(rscript_bin) && .Platform$OS.type == "windows") {
        rscript_bin <- file.path(R.home("bin"), .Platform$r_arch, "Rscript.exe")
      }
      
      # Run installation in isolated subprocess to capture standard output & C/C++ errors
      system2(rscript_bin, args = shQuote(temp_script), stdout = log_file, stderr = log_file)
      
      # Read captured log output from temporary log file
      if (file.exists(log_file)) {
        full_log_text <- paste(readLines(log_file, warn = FALSE), collapse = "\n")
        unlink(log_file)
      }
      
      # Clean up temporary R script
      if (file.exists(temp_script)) {
        unlink(temp_script)
      }
      
      # 3. Checks if the package was successfully installed
      if (!requireNamespace(pkg, quietly = TRUE)) {
        install_error <- TRUE
        failed_pkg <- pkg
        break # Breaks the loop on the first error
      }
    }
  }
  
  if (install_error) {
    # Sanitize log for safe HTML rendering without external dependencies
    safe_log <- gsub("&", "&amp;", full_log_text)
    safe_log <- gsub("<", "&lt;", safe_log)
    safe_log <- gsub(">", "&gt;", safe_log)
    
    # Generate standalone error HTML file
    error_html_path <- file.path(loader_dir, "error.html")
    error_html_content <- sprintf('<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Installation Error</title>
  <style>
    body { font-family: sans-serif; padding: 30px; background-color: #f8f9fa; }
    .card { background: #ffffff; border: 1px solid #d6d8db; border-radius: 8px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    h2 { color: #d9534f; margin-top: 0; }
    p { color: #495057; }
    pre { background: #212529; color: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 13px; max-height: 500px; white-space: pre-wrap; word-wrap: break-word; }
  </style>
</head>
<body>
  <div class="card">
    <h2>Error installing package: %s</h2>
    <p>The application setup could not be completed. Below is the error log captured during installation:</p>
    <pre>%s</pre>
  </div>
</body>
</html>', failed_pkg, safe_log)
    
    writeLines(error_html_content, error_html_path)
    
    # Force browser to navigate directly to the new error page
    browseURL(error_html_path)
    Sys.sleep(1) # Allow OS time to trigger browser open
    
    # Stop execution in R console
    stop(sprintf("Failed to install package '%s'. Check the error log opened in your browser.", failed_pkg))
    
  } else {
    # Informs the loader that we have finished the installations
    writeLines('updateStatus("All", "All", "Finishing setup...");',
               file.path(loader_dir, paste0("status", length(miss) + 1, ".js")))
  }
}

# Run Shiny on the dynamic port
library(shiny)

runApp(
  appDir = file.path(getwd()),
  host = "127.0.0.1",
  port = port,
  launch.browser = TRUE
)

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.