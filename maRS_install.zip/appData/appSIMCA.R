# =========================
# UI
# =========================

appSIMCAUI <- div(
  id = "simca_module",
  
  # lockInput
  tags$script(
    HTML(
      "
        Shiny.addCustomMessageHandler('lockInput', function(x) {
          var ids = Array.isArray(x.id) ? x.id : [x.id];

          ids.forEach(function(id) {
            var el = document.getElementById(id);
            if (el) el.closest('.shiny-input-container').style.pointerEvents = 'none';
          });
        });
        "
    )
  ),
  
  tags$script(
    HTML(
      "
    Shiny.addCustomMessageHandler('unlockInput', function(x) {
      var ids = Array.isArray(x.id) ? x.id : [x.id];

      ids.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.closest('.shiny-input-container').style.pointerEvents = 'auto';
      });
    });
    "
    )
  ),
  
  compactNavbarStyle("simca_module"),
  
  navbarPage(
    "SIMCA",
    
    # TAB CROSS-VALIDATION
    cvUI("simca_cv", mode = "1clas"),
    
    # TAB MODEL
    tabPanel("Model", fluidRow(
      column(
        3,
        wellPanel(
          numericInput("simcam_ncomp", "N of PCs:", 1, 1, 50, 1),
          
          br(),
          
          div(
            style = "display:flex; gap:10px;",
            actionButton(
              "run_simcam_btn",
              "Run",
              icon = icon("play"),
              class = "btn-primary",
              style = "flex:1;"
            ),
            actionButton(
              "simcam_reset",
              "Reset",
              icon = icon("sync"),
              class = "btn-primary",
              style = "flex:1;"
            )
          ),
          
          br(),
          
          # div(
          #   style = "display:flex; gap:10px;",
          #   uiOutput("save_simca_results"),
          #   uiOutput("save_simca_model")
          # )
          
          div(
            style = "display:flex; gap:10px;",
            uiOutput("save_simca_results", style = "flex:1;"),
            uiOutput("save_simca_model", style = "flex:1;")
          ),
          
          hr(),
          
          fileInput("simcam_load_model", "Load model (.rds)", accept = ".rds")
        )
      ),
      
      column(
        6,
        uiOutput("simca_model_plot_container"),
        br(),
        uiOutput("simca_sensitivity")
      ),
      
      column(
        3,
        wellPanel(
          selectInput(
            "simcam_plot",
            "Plot:",
            c("Acceptance", "Extremes", "Variance")
          ),
          br(),
          uiOutput("simca_model_controls")
        ),
        wellPanel(
          style = "padding-top:0px;",
          h3("Export graph"),
          numericInput("simcam_fontsize", "Font factor:", 0.7, 0.3, 2, 0.1),
          exportPlotUI("simca_model_export")
        )
      )
    )),
    
    # TAB TEST
    tabPanel("Test", fluidRow(
      column(
        3,
        wellPanel(
          checkboxInput("simcat_group", "Groups", TRUE),
          checkboxInput("simcat_log_scale", "Log scale", TRUE),
          checkboxInput("simcat_marker", "Markers", TRUE),
          checkboxInput("simcat_labels", "Labels", FALSE),
          
          selectInput(
            "simcat_palette",
            "Colors:",
            c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
          ),
        )
      ),
      
      column(
        6,
        uiOutput("simca_test_plot_container"),
        br(),
        tableOutput("simca_test_metrics"),
        br(),
        tableOutput("simca_test_conf")
      ),
      
      column(
        3,
        wellPanel(
          style = "padding-top:0px;",
          h3("Export graph"),
          numericInput("simcat_fontsize", "Font factor:", 0.7, 0.3, 2, 0.1),
          exportPlotUI("simca_test_export")
        )
      )
    )),
    
    # TAB PREDICTION
    predictionUI("simca_pred", type = "1cla")
  )
)

# =========================
# SERVER
# =========================

appSIMCAServer <- function(input, output, session, df_shared) {
  simcacv   <- reactiveVal(NULL)
  simcamod  <- reactiveVal(NULL)
  simcatest <- reactiveVal(NULL)
  accep_m_data <- reactiveVal(NULL)
  
  # =========================
  # LOAD & RESET
  # =========================
  
  # LOAD MODEL
  observeEvent(input$simcam_load_model, {
    req(input$simcam_load_model)
    mod_loaded <- readRDS(input$simcam_load_model$datapath)
    
    if (!is.null(mod_loaded$simcamod) &&
        !is.null(mod_loaded$simcacv)) {
      modTemp <- mod_loaded$simcamod
      modTemp$loaded <- TRUE
      simcamod(modTemp)
      
      cvTemp <- mod_loaded$simcacv
      cvTemp$loaded <- TRUE
      simcacv(cvTemp)
      
      showNotification("SIMCA Model successfully loaded.", type = "message")
    } else {
      showNotification("Invalid SIMCA model file.", type = "error")
    }
  })
  
  # RESET
  observeEvent(input$simcam_reset, {
    req(simcamod())
    
    modTemp <- simcamod()
    modTemp$loaded <- FALSE
    simcamod(modTemp)
    
    if (!is.null(simcacv())) {
      cvTemp <- simcacv()
      cvTemp$loaded <- FALSE
      simcacv(cvTemp)
    }
    
    later::later(function() {
      simcamod(NULL)
      simcacv(NULL)
      simcatest(NULL)
    }, delay = 1)
    
    showNotification("SIMCA Model reset successfully.", type = "warning")
  })
  
  # =========================
  # CROSS-VALIDATION
  # =========================
  cvServer(
    "simca_cv",
    df_reactive = df_shared,
    cv_fun = cv_simca,
    cv_reactive = simcacv,
    mode        = "1clas"
  )
  
  # Uptade N of PCs:
  observe({
    req(simcacv())
    req(simcacv()$opt_ncomp)
    
    if (!is.null(simcacv()$loaded) && isTRUE(simcacv()$loaded)) {
      updateNumericInput(session, "simcam_ncomp", value = simcacv()$opt_ncomp)
      session$sendCustomMessage("lockInput", list(id = session$ns(c(
        "simcam_ncomp"
      ))))
    }
    
    else if (!is.null(simcacv()$loaded) &&
             isFALSE(simcacv()$loaded)) {
      updateNumericInput(session, "simcam_ncomp", value = 1)
      session$sendCustomMessage("unlockInput", list(id = session$ns(c(
        "simcam_ncomp"
      ))))
    }
    else{
      updateNumericInput(session, "simcam_ncomp", value = simcacv()$opt_ncomp)
    }
  })
  
  # =========================
  # MODEL
  # =========================
  observeEvent(input$run_simcam_btn, {
    req(simcacv())
    
    simcamod(
      mod_simca(
        simcacv(),
        targetclass = simcacv()$targetclass,
        ncomp = input$simcam_ncomp,
        scale = simcacv()$scale,
        method = simcacv()$method,
        alpha = simcacv()$alpha,
        gamma = simcacv()$gamma
      )
    )
  })
  
  # Dinamic controls
  output$simca_model_controls <- renderUI({
    if (input$simcam_plot == "Acceptance") {
      div(
        checkboxInput("simcam_log_scale", "Log scale", TRUE),
        checkboxInput("simcam_marker", "Markers", TRUE),
        checkboxInput("simcam_labels", "Labels", FALSE),
        selectInput(
          "simcam_palette",
          "Colors:",
          c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
        )
      )
    }
  })
  
  make_simca_model <- function() {
    req(simcamod(), simcacv(), input$simcam_plot)
    
    if (input$simcam_plot == "Acceptance") {
      req(input$simcam_palette, input$simcam_fontsize)
      
      tmp <- plot_accep(
        simcamod(),
        log_scale = input$simcam_log_scale,
        marker = input$simcam_marker,
        labels = input$simcam_labels,
        colPa = input$simcam_palette,
        val_cex = input$simcam_fontsize
      )
      
      accep_m_data(tmp)
    }
    
    if (input$simcam_plot == "Extremes") {
      req(input$simcam_fontsize)
      plot_extremes(
        simcacv(),
        ncomp = simcamod()$ncomp_sel,
        val_cex = input$simcam_fontsize
      )
    }
    
    if (input$simcam_plot == "Variance") {
      req(input$simcam_fontsize)
      plot_variance(
        simcacv(),
        ncomp = simcamod()$ncomp_sel,
        val_cex = input$simcam_fontsize
      )
    }
  }
  
  output$simca_model_plot_container <- renderUI({
    w <- exp_mod$width()
    h <- exp_mod$height()
    if (is.null(w) || w == "")
      w <- 600
    if (is.null(h) || h == "")
      h <- 400
    
    div(
      style = paste0("width:", w, "px;"),
      plotOutput(
        "simca_model_plot",
        width = paste0(w, "px"),
        height = paste0(h, "px")
      )
    )
  })
  
  output$simca_model_plot <- renderPlot({
    req(simcamod())
    make_simca_model()
  })
  
  exp_mod <- exportPlotServer("simca_model_export", plot_fun = make_simca_model)
  
  # Sensitivity
  output$simca_sensitivity <- renderUI({
    req(simcamod())
    tagList(
      strong("Sensitivity:"),
      br(),
      paste("Calibration:", round(simcamod()$cal_metrics$SEN[simcamod()$ncomp_sel], 4)),
      br(),
      paste("CV:", round(simcamod()$cv_metrics$SEN[simcamod()$ncomp_sel], 4))
    )
  })
  
  # =========================
  # TEST
  # =========================
  observe({
    req(simcamod())
    req(simcacv())
    
    
    if (!is.null(simcacv()$loaded) && isFALSE(simcacv()$loaded)) {
      simcatest(NULL)
    }
    
    else if (!is.null(simcamod()$df_test$xdat)) {
      simcatest(pred_simca(simcamod(), simcamod()$df_test, ncomp = simcamod()$ncomp_sel))
    }
  })
  
  output$simca_test_plot_container <- renderUI({
    w <- exp_test$width()
    h <- exp_test$height()
    if (is.null(w) || w == "")
      w <- 600
    if (is.null(h) || h == "")
      h <- 400
    
    div(
      style = paste0("width:", w, "px;"),
      plotOutput(
        "simca_test_plot",
        width = paste0(w, "px"),
        height = paste0(h, "px")
      )
    )
  })
  
  output$simca_test_plot <- renderPlot({
    req(simcatest())
    
    plot_accep(
      simcamod(),
      simcatest(),
      group = input$simcat_group,
      log_scale = input$simcat_log_scale,
      marker = input$simcat_marker,
      labels = input$simcat_labels,
      colPa = input$simcat_palette,
      val_cex = input$simcat_fontsize
    )
  })
  
  output$simca_test_metrics <- renderTable({
    req(simcatest())
    met <- cla_metrics(simcatest()$cm, mod_typ = "simca")
    t(met$global)
  }, rownames = FALSE)
  
  output$simca_test_conf <- renderTable({
    req(simcatest())
    met <- cla_metrics(simcatest()$cm, mod_typ = "simca")
    as.data.frame.matrix(met$confusion)
  }, rownames = TRUE)
  
  # Plot export
  exp_test <- exportPlotServer(
    "simca_test_export",
    plot_fun = function() {
      req(simcatest())
      
      plot_accep(
        simcamod(),
        simcatest(),
        group = input$simcat_group,
        log_scale = input$simcat_log_scale,
        marker = input$simcat_marker,
        labels = input$simcat_labels,
        colPa = input$simcat_palette,
        val_cex = input$simcat_fontsize
      )
    }
  )
  
  # =========================
  # SAVE MODEL
  # =========================
  output$save_simca_model <- renderUI({
    if (is.null(simcamod()))
      downloadLink(
        "save_simca_model_btn",
        "Save model",
        class = "btn btn-success",
        onclick = "return false;",
        style = "width:100%;"
      )
    else
      downloadLink("save_simca_model_btn",
                   "Save model",
                   class = "btn btn-success",
                   style = "width:100%;")
  })
  
  output$save_simca_model_btn <- downloadHandler(
    filename = function() {
      paste0("SIMCA_model_", Sys.Date(), ".rds")
    },
    content = function(file) {
      saveRDS(list(simcamod = simcamod(), simcacv  = simcacv()), file)
    }
  )
  
  # =========================
  # SAVE RESULTS
  # =========================
  output$save_simca_results <- renderUI({
    if (is.null(simcamod()))
      downloadLink(
        "save_simca_results_btn",
        "Save results",
        class = "btn btn-success",
        onclick = "return false;",
        style = "width:100%;"
      )
    else
      downloadLink("save_simca_results_btn",
                   "Save results",
                   class = "btn btn-success",
                   style = "width:100%;")
  })
  
  output$save_simca_results_btn <- downloadHandler(
    filename = function() {
      paste0("SIMCA_results_", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      mod <- simcamod()
      sheets <- list()
      
      # Scores
      sheets$scores <-
        cbind(obj = mod$row_names, as.data.frame(mod$x))
      
      # Loadings
      sheets$loadings <-
        cbind(Variable = mod$col_names, as.data.frame(mod$rotation))
      
      # VAR
      names(mod$prop_var) <- paste0("PC", 1:length(mod$prop_var))
      var_df <- as.data.frame(t(mod$prop_var))
      var_df <- var_df[, -ncol(var_df)]
      sheets$var <- var_df
      
      # CUMVAR
      names(mod$prop_var_cum) <- paste0("PC", 1:length(mod$prop_var_cum))
      cumvar_df <- as.data.frame(t(mod$prop_var_cum))
      cumvar_df <- cumvar_df[, -ncol(cumvar_df)]
      sheets$cumVar <- cumvar_df
      
      # Dist
      sheets$dist <- data.frame(
        obj = mod$row_names,
        T2 = accep_m_data()$xh,
        Q = accep_m_data()$yq,
        stringsAsFactors = FALSE
      )
      
      # Limits
      lims <- cbind(T2_lim = accep_m_data()$line_h_lim,
                    Q_lim = accep_m_data()$line_q_lim)
      sheets$lims <- as.data.frame(lims)
      
      # Test (if it exists)
      if (!is.null(simcatest())) {
        pred <- simcatest()
        
        tmp_test <- plot_accep(
          simcamod(),
          simcatest(),
          group = FALSE,
          log_scale = input$simcat_log_scale,
          marker = input$simcat_marker,
          labels = input$simcat_labels,
          colPa = input$simcat_palette,
          val_cex = input$simcat_fontsize
        )
        
        test_df <- cbind(
          obj = pred$row_names,
          class = pred$groups,
          actual = as.character(pred$class_ref),
          predicted = as.character(pred$class_hat),
          T2 = tmp_test$xh,
          Q = tmp_test$yq
        )
        
        sheets$test <- as.data.frame(test_df)
        
        # Test metrics
        
        simcatest_met <- cla_metrics(pred$cm, mod_typ = "simca")
        
        global_df <- as.data.frame(t(simcatest_met$global))
        
        confusion_df <- as.data.frame.matrix(simcatest_met$confusion)
        confusion_df <- cbind(Ref = rownames(confusion_df), confusion_df)
        rownames(confusion_df) <- NULL
        
        max_cols <- max(ncol(global_df), ncol(confusion_df))
        
        padronizar <- function(df, titulo, max_cols) {
          matriz <- matrix(NA, nrow = nrow(df) + 2, ncol = max_cols)
          
          colnames(matriz) <- rep(" ", max_cols)
          
          matriz[1, 1] <- titulo
          matriz[2, 1:ncol(df)] <- names(df)
          
          for (i in 1:nrow(df)) {
            matriz[i + 2, 1:ncol(df)] <- as.character(unlist(df[i, ]))
          }
          
          as.data.frame(matriz, stringsAsFactors = FALSE)
          
        }
        
        global_pad <- padronizar(global_df, "GLOBAL", max_cols)
        
        confusion_pad <- padronizar(confusion_df, "CONFUSION MATRIX", max_cols)
        
        tudo_em_uma_aba <- rbind(global_pad, confusion_pad)
        
        sheets$testMet <- tudo_em_uma_aba
      }
      
      # WRITE FILE
      writexl::write_xlsx(sheets, file)
      
    }
  )
  
  # =========================
  # PREDICTION
  # =========================
  
  predictionServer(
    "simca_pred",
    model_reactive = simcamod,
    cv_reactive    = simcacv,
    model_setter   = function(x) {
      simcamod(x$simcamod)
      simcacv(x$simcacv)
    },
    pred_fun       = pred_simca,
    type           = "1cla",
    output_fun     = make_da_pred_output
  )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.