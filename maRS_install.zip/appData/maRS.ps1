# Gets the current directory path (appData) where this script and start.R reside
$AppDataPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$RFile = Join-Path $AppDataPath "start.R"

# 1. Try to find Rscript in the system PATH
$Rscript = (Get-Command Rscript -ErrorAction SilentlyContinue).Source

# 2. If it is not in the PATH, it searches in known directories
if (-not $Rscript) {
    $searchPaths = @(
        "C:\Program Files\R",
        "C:\Program Files (x86)\R",
        "$env:LOCALAPPDATA\Programs\R",
        "C:\R"
    )
    foreach ($path in $searchPaths) {
        if (Test-Path $path) {
            $found = Get-ChildItem -Path $path -Filter "Rscript.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($found) {
                $Rscript = $found.FullName
                break
            }
        }
    }
}

# 3. Runs the app or displays an error box
if ($Rscript) {
    Set-Location $AppDataPath
    Start-Process -FilePath $Rscript -ArgumentList "`"$RFile`"" -WindowStyle Hidden
} else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show(
        "R was not found on this computer. Please install R to continue.",
        "Dependency Error",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )
}