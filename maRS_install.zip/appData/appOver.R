# =========================
# UI
# =========================

appOverUI <- tagList(fluidRow(column(
  width = 4,
  wellPanel(
    style = "padding-top:0px;",
    h3("Oversampling"),
    
    selectInput("ov_method", "Method:", choices = c("SMOTE", "ADASYN")),
    
    numericInput(
      "ov_k",
      "k-neighbors:",
      value = 5,
      min = 2,
      step = 1
    ),
    
    checkboxInput("view_ov_dataset", "View oversampled dataset", value = FALSE),
    
    br(),
    
    fluidRow(column(
      width = 6,
      
      # Apply
      div(
        style = "margin-bottom:10px;",
        actionButton(
          "apply_ov",
          "Apply",
          icon = icon("play"),
          class = "btn-primary"
        )
      ),
      
      # Save
      div(uiOutput("save_ov_ui"))
      
    ))
  )
), column(
  width = 8,
  wellPanel(style = "padding-top:0px;", h3("Information"), verbatimTextOutput("ov_info"),
            conditionalPanel(
              condition = "input.view_ov_dataset == true", 
              br(), 
              DT::dataTableOutput("ov_dataset_table")
            ))
)))

# =========================
# SERVER
# =========================

appOverServer <- function(input, output, session, df_shared) {
  sdf_val <- reactiveVal(NULL)
  
  # =========================
  # APPLY OVERSAMPLING
  # =========================
  
  observeEvent(input$apply_ov, {
    req(df_shared())
    
    df <- df_shared()
    req(df$groups)
    
    # smallest class size
    tbl <- table(as.factor(df$groups))
    n_min <- min(tbl)
    
    # update the maximum limit of k
    updateNumericInput(
      session,
      "ov_k",
      min = 2,
      max = n_min - 1,
      value = min(input$ov_k, n_min - 1)
    )
    
    # apply oversampling
    sdf <- synt_oversamp(df, method = input$ov_method, k = input$ov_k)
    
    sdf_val(sdf)
  })
  
  # =========================
  # INFO TEXT
  # =========================
  
  output$ov_info <- renderText({
    req(df_shared())
    
    df <- df_shared()
    
    before_txt <- paste("Before oversampling:\n",
                        paste(capture.output(table(
                          as.factor(df$groups)
                        )), collapse = "\n"))
    
    if (input$apply_ov == 0 || is.null(sdf_val())) {
      return(before_txt)
    }
    
    sdf <- sdf_val()
    
    after_txt <- paste("After oversampling:\n",
                       paste(capture.output(table(sdf[, "classes"])), collapse = "\n"))
    
    paste(before_txt, "\n\n", after_txt)
  })
  
  # =========================
  # DATA TABLE OUTPUT
  # =========================
  
  output$ov_dataset_table <- DT::renderDataTable({
    req(sdf_val())
    
    final_df <- as.data.frame(sdf_val())
    
    num_cols <- unname(which(sapply(final_df, is.numeric)))
    fixed_width <- "50px"
    
    DT::datatable(
      final_df,
      rownames = TRUE,
      selection = "none",
      options = list(
        pageLength = 10,
        scrollX = TRUE,
        autoWidth = FALSE,
        searching = FALSE,
        ordering = FALSE,
        columnDefs = list(
          list(
            targets = num_cols,
            width = fixed_width,
            render = htmlwidgets::JS(
              paste0(
                "function(data, type, row, meta) {",
                "  if(type === 'display' && data !== null){",
                "    return '<div style=\"width:",
                fixed_width,
                "; overflow:hidden; text-overflow:clip; white-space:nowrap;\">' + data + '</div>';",
                "  }",
                "  return data;",
                "}"
              )
            )
          )
        ),
        initComplete = htmlwidgets::JS(
          "function(settings, json) {",
          "  $(this.api().table().node()).css('table-layout', 'fixed');",
          "  $(this.api().table().node()).css({",
          "    '-webkit-user-select': 'none',",
          "    '-moz-user-select': 'none',",
          "    '-ms-user-select': 'none',",
          "    'user-select': 'none',",
          "    'cursor': 'default'",
          "  });",
          "}"
        )
      )
    )
  }, server = TRUE)
  
  # =========================
  # EXPORT
  # =========================
  
  output$save_ov_ui <- renderUI({
    disabled <- input$apply_ov == 0
    
    tagList(div(
      style = "display:flex; gap:8px; align-items:flex-end;",
      
      if (disabled) {
        downloadButton(
          "save_ov",
          "Export dataset as",
          icon = icon("save"),
          class = "btn-success",
          onclick = "return false;"
        )
      } else {
        downloadButton("save_ov",
                       "Export dataset as",
                       icon = icon("save"),
                       class = "btn-success")
      },
      
      div(
        style = "flex-shrink:0; width:80px;",
        selectInput(
          "save_ov_type",
          NULL,
          choices = c(".xlsx", ".txt"),
          width = "100%",
          selectize = FALSE
        )
      )
    ))
  })
  
  output$save_ov <- downloadHandler(
    filename = function() {
      paste0("oversampled_data_", Sys.Date(), input$save_ov_type)
    },
    
    content = function(file) {
      req(sdf_val())
      sdf <- sdf_val()
      
      sdf <- as.data.frame(sdf)
      
      if (input$save_ov_type == ".xlsx") {
        writexl::write_xlsx(sdf, file)
        
      } else {
        write.table(
          sdf,
          file,
          sep = "\t",
          dec = ".",
          row.names = FALSE,
          quote = FALSE
        )
        
      }
    }
  )
  
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.