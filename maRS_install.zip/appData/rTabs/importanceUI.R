importanceUI <- function(id, mode = c("mlr", "pls", "mlrda", "plsda")) {
  ns <- NS(id)
  
  tabPanel("Importance", fluidRow(column(
    width = 3,
    wellPanel(
      style = "padding-top:0px;",
      
      if (mode %in% c("pls")) {
        selectInput(ns("plot_type"),
                    "Parameter:",
                    c("Coefficients" = "coefficients", "VIP"))
      },
      
      if (mode %in% c("plsda")) {
        selectInput(
          ns("plot_type"),
          "Parameter:",
          c(
            "Coefficients" = "coefficients",
            "VIP",
            "Fisher Ratio" = "FR"
          )
        )
      },
      
      if (mode %in% c("mlrda")) {
        selectInput(
          ns("plot_type"),
          "Parameter:",
          c("Coefficients" = "coefficients", "Fisher Ratio" = "FR")
        )
      },
      
      if (mode %in% c("mlrda", "plsda")) {
        conditionalPanel(
          condition = "input.plot_type == 'coefficients'",
          ns = ns,
          selectInput(ns("clas"), "Class:", choices = NULL)
        )
      },
      
      textInput(ns("xlabel"), "X label:", "Variables"),
      
      checkboxInput(ns("bars"), "Bars", FALSE),
      checkboxInput(ns("orlines"), "Origin line", FALSE)
    )
  ), column(width = 9, fluidRow(
    column(9, uiOutput(ns(
      "imp_plot_container"
    ))), column(
      3,
      wellPanel(
        style = "padding-top:0px;",
        h3("Export graph"),
        numericInput(
          ns("fontsize"),
          "Font factor:",
          value = 0.7,
          min = 0.3,
          max = 2,
          step = 0.1
        ),
        exportPlotUI(ns("imp_export"))
      )
    )
  ))))
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.