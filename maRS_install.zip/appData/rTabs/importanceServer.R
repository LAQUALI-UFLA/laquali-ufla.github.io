importanceServer <- function(id,
                             model_reactive,
                             mode = c("mlr", "pls", "mlrda", "plsda")) {
  moduleServer(id, function(input, output, session) {
    observe({
      req(model_reactive())
      
      if (mode %in% c("mlrda", "plsda")) {
        mod <- model_reactive()
        
        cls <- NULL
        
        if (!is.null(mod$class_levels)) {
          cls <- mod$class_levels
        } else if (!is.null(mod$classes)) {
          cls <- unique(mod$classes)
        }
        
        if (!is.null(cls)) {
          updateSelectInput(session,
                            "clas",
                            choices = cls,
                            selected = cls[1])
        }
      }
    })
    
    make_imp_plot <- function() {
      args <- list(
        model_reactive(),
        xlabel   = input$xlabel,
        val_cex  = input$fontsize,
        bars     = input$bars,
        orlines  = input$orlines
      )
      
      if (mode %in% c("mlrda","pls", "plsda")) {
        args$plot_type <- input$plot_type
      }
      
      if (mode %in% c("mlrda", "plsda")) {
        args$clas <- input$clas
      }
      
      do.call(plot_var_imprt, args)
    }
    
    output$main_imp_plot <- renderPlot({
      req(model_reactive())
      make_imp_plot()
    })
    
    exp_imp <- exportPlotServer("imp_export", plot_fun = make_imp_plot)
    
    output$imp_plot_container <- renderUI({
      ns <- session$ns
      
      w <- exp_imp$width()
      h <- exp_imp$height()
      
      if (is.null(w) || w == "")
        w <- 600
      if (is.null(h) || h == "")
        h <- 400
      
      div(style = paste0("width:", w, "px;"),
          
          plotOutput(
            ns("main_imp_plot"),
            width  = paste0(w, "px"),
            height = paste0(h, "px")
          ))
    })
    
  })
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.