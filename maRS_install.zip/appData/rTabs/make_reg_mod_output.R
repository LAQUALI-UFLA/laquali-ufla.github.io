make_reg_mod_output <- function(mod) {
  sheets <- list()
  
  # COEFS
  sheets$coefs <- data.frame(
    Parameter = names(mod$coefs),
    Value = mod$coefs,
    row.names = NULL,
    check.names = FALSE
  )
  
  # CAL
  sheets$cal <- data.frame(
    obj       = mod$df_train$row_names,
    actual    = mod$mvcal$y_actual,
    predicted = mod$mvcal$y_hat
  )
  
  sheets$calMet <- data.frame(Metric = names(mod$mvcal_met),
                              Value  = as.numeric(unlist(mod$mvcal_met)))
  
  # DIAG
  save_diag <- as.data.frame(mod$mdiag)
  save_diag <- save_diag[, c(6, 4, 5, 1, 2, 3, 7)]
  colnames(save_diag) <- c("obj",
                           "actual",
                           "predicted",
                           "leverage",
                           "studRes",
                           "residuals",
                           "levLim")
  sheets$diag <- save_diag
  
  # CV
  if (!is.null(mod$mvcv)) {
    sheets$cv <- data.frame(
      obj       = mod$df_train$row_names,
      actual    = mod$mvcv$y_actual,
      predicted = mod$mvcv$y_hat
    )
    
    if (!is.null(mod$mvcv_met)) {
      sheets$cvMet <- data.frame(Metric = names(mod$mvcv_met),
                                 Value  = as.numeric(unlist(mod$mvcv_met)))
    }
  }
  
  # YRAND
  if (!is.null(mod$mvyrand)) {
    save_yrand <- do.call(cbind, mod$mvyrand)
    save_yrand <- cbind(obj = mod$df_train$row_names, save_yrand)
    colnames(save_yrand)[2:3] <- c("actual", "predicted_cal")
    
    sheets$yrand <- as.data.frame(save_yrand)
    
    if (!is.null(mod$mvyrand_met)) {
      sheets$yrandMet <- data.frame(Metric = names(mod$mvyrand_met),
                                    Value  = as.numeric(unlist(mod$mvyrand_met)))
    }
  }
  
  # TEST
  if (!is.null(mod$mvtes)) {
    sheets$test <- data.frame(
      obj       = mod$df_test$row_names,
      actual    = mod$mvtes$y_actual,
      predicted = mod$mvtes$y_hat
    )
    
    if (!is.null(mod$mvtes_met)) {
      sheets$testMet <- data.frame(Metric = names(mod$mvtes_met),
                                   Value  = as.numeric(unlist(mod$mvtes_met)))
    }
  }
  
  return(sheets)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.