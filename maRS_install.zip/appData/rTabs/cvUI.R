cvUI <- function(id, mode = c("reg", "cla", "1clas")) {
  ns <- NS(id)
  
  tabPanel(
    "Cross-validation",
    
    # lockInput
    tags$script(
      HTML(
        "
        Shiny.addCustomMessageHandler('lockInput', function(x) {
          var ids = Array.isArray(x.id) ? x.id : [x.id];

          ids.forEach(function(id) {
            var el = document.getElementById(id);
            if (el) el.closest('.shiny-input-container').style.pointerEvents = 'none';
          });
        });
        "
      )
    ),
    
    tags$script(
      HTML(
        "
    Shiny.addCustomMessageHandler('unlockInput', function(x) {
      var ids = Array.isArray(x.id) ? x.id : [x.id];

      ids.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.closest('.shiny-input-container').style.pointerEvents = 'auto';
      });
    });
    "
      )
    ),
    
    fluidRow(
      # LEFT
      column(
        3,
        wellPanel(
          if (mode == "1clas") {
            tagList(selectInput(
              ns("method"),
              "Method:",
              c(
                "SIMCA" = "smcla",
                "DD-SIMCA" = "ddcla",
                "Robust DD-SIMCA" = "ddrob"
              )
            ),
            
            selectInput(ns("targetclass"), "Target:", NULL))
          }
          else if (mode == "reg")
            selectInput(ns("sel_met"), "Method:", c("PLS", "iPLS", "BVE/PLS"))
          else if (mode == "cla")
            selectInput(
              ns("sel_met"),
              "Method:",
              c("PLS-DA", "iPLS-DA", "BVE/PLS-DA")
            ),
          uiOutput(ns("extra_controls")),
          numericInput(
            ns("ncomp"),
            label = if (mode == "1clas")
              "Max. n of PCs:"
            else
              "Max. n of LVs:",
            value = 2,
            min = 2,
            max = 100,
            step = 1
          ),
          
          checkboxInput(ns("scale"), "Scale", FALSE),
          
          selectInput(ns("spl_type"), "Split type:", choices = if (mode == "reg") {
            c(
              "None" = "None",
              "Kennard-Stone" = "KS",
              "SPXY" = "SPXY",
              "Randomized" = "RND",
              "Split indicator" = "SPE"
            )
          } else {
            c(
              "None" = "None",
              "Kennard-Stone" = "KS",
              "Randomized" = "RND",
              "Split indicator" = "SPE"
            )
          }),
          
          numericInput(ns("pro_test"), "Test set (%):", 25, 0, 95, 1),
          
          selectInput(ns("cv"), "CV type:", choices = if (mode == "reg") {
            c(
              "Leave-One-Out" = "LOO",
              "Venetian Blinds" = "VB",
              "Randomized" = "RND"
            )
          } else {
            c("Leave-One-Out" = "LOO", "Randomized" = "RND")
          }),
          
          numericInput(ns("folds"), "Folds:", 5, 1, 50, 1),
          
          if (mode == "1clas") {
            tagList(
              numericInput(ns("alpha"), "Alpha (%):", 5, 0.1, 10, 0.1),
              numericInput(ns("gamma"), "Gamma (%):", 1, 0.01, 5, 0.01)
            )
          },
          
          br(),
          
          actionButton(
            ns("run_btn"),
            "Run",
            icon = icon("play"),
            class = "btn-primary"
          )
        )
      ),
      
      # PLOT
      column(6, uiOutput(ns(
        "cv_plot_container"
      ))),
      
      # RIGHT
      column(3, uiOutput(ns("right_panel")))
      
    )
  )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.