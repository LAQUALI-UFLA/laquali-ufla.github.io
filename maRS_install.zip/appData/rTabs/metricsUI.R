metricsUI <- function(id) {
  ns <- NS(id)
  
  tabPanel(
    "Metrics",
    
    fluidRow(column(12, uiOutput(ns(
      "met_cal"
    )))),
    br(),
    
    fluidRow(column(12, uiOutput(ns(
      "met_test"
    )))),
    br(),
    
    fluidRow(column(12, uiOutput(ns(
      "met_cv"
    )))),
    br(),
    
    fluidRow(column(12, uiOutput(ns(
      "met_yrand"
    ))))
  )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.