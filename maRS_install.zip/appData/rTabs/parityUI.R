parityUI <- function(id) {
  ns <- NS(id)
  
  tabPanel("Parity", fluidRow(column(
    width = 3,
    wellPanel(
      style = "padding-top:0px;",
      
      checkboxInput(ns("par_cal"), "Calibration", TRUE),
      checkboxInput(ns("par_cv"), "Cross-validation", TRUE),
      checkboxInput(ns("par_test"), "Test", TRUE),
      br(),
      checkboxInput(ns("rnames"), "Show names", FALSE),
      
      selectInput(
        ns("par_palette"),
        "Colors:",
        c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
      ),
      
    )
  ), column(width = 9, fluidRow(
    column(9, uiOutput(ns(
      "par_plot_container"
    ))), column(
      3,
      wellPanel(
        style = "padding-top:0px;",
        h3("Export graph"),
        numericInput(
          ns("par_fontsize"),
          "Font factor:",
          value = 0.7,
          min = 0.3,
          max = 2,
          step = 0.1
        ),
        exportPlotUI(ns("par_export"))
      )
    )
  ))))
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.