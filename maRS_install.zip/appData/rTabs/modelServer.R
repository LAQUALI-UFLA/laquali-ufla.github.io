modelServer <- function(id,
                        model_fun,
                        model_reactive,
                        mode = c("reg", "cla"),
                        engine = c("lm", "pls"),
                        df_reactive = NULL,
                        cv_reactive = NULL,
                        update_class = NULL) {
  moduleServer(id, function(input, output, session) {
    # =========================
    # UPDATE UI FROM MODEL
    # =========================
    
    observe({
      req(model_reactive())
      
      mod <- model_reactive()
      if (isTRUE(mod$loaded)) {
        # SELECTS
        
        if (!is.null(mod$spl_type)) {
          updateSelectInput(session, "spl_type", selected = mod$spl_type)
        }
        
        if (!is.null(mod$cv)) {
          updateSelectInput(session, "cv", selected = mod$cv)
        }
        
        # NUMERIC
        if (!is.null(mod$ncomp_sel)) {
          updateNumericInput(session, "ncomp", value = mod$ncomp_sel)
        }
        
        if (!is.null(mod$pro_test)) {
          updateNumericInput(session, "pro_test", value = mod$pro_test)
        }
        
        if (!is.null(mod$folds)) {
          updateNumericInput(session, "folds", value = mod$folds)
        }
        
        if (!is.null(mod$nrep)) {
          updateNumericInput(session, "nrep", value = mod$nrep)
        }
        
        # CHECKBOX
        if (!is.null(mod$scale)) {
          updateCheckboxInput(session, "scale", value = mod$scale)
        }
        
        if (!is.null(mod$yrand)) {
          updateCheckboxInput(session, "yrand", value = mod$yrand)
        }
        
        if (!is.null(mod$q_lod)) {
          updateCheckboxInput(session, "q_lod", value = mod$q_lod)
        }
        
        # LOCK
        session$sendCustomMessage("lockInput", list(id = session$ns(
          c(
            "ncomp",
            "spl_type",
            "cv",
            "pro_test",
            "folds",
            "nrep",
            "scale",
            "yrand",
            "q_lod"
          )
        )))
      }
      
      else if (isFALSE(mod$loaded)) {
        session$sendCustomMessage("unlockInput", list(id = session$ns(
          c(
            "ncomp",
            "spl_type",
            "cv",
            "pro_test",
            "folds",
            "nrep",
            "scale",
            "yrand"
          )
        )))
        
        # SELECTS
        updateSelectInput(session, "spl_type", selected = "None")
        updateSelectInput(session, "cv", selected = "None")
        
        # NUMERIC
        updateNumericInput(session, "pro_test", value = 25)
        updateNumericInput(session, "folds", value = 5)
        updateNumericInput(session, "nrep", value = 10)
        updateNumericInput(session, "ncomp", value = 1)
        
        # CHECKBOX
        updateCheckboxInput(session, "scale", value = FALSE)
        updateCheckboxInput(session, "yrand", value = FALSE)
        
      }
      
    })
    
    # AUTO UPDATE NCOMP FROM CV
    observe({
      req(engine == "pls")
      req(cv_reactive())
      req(cv_reactive()$opt_ncomp)
      
      if (is.null(cv_reactive()$loaded))
        updateNumericInput(session, "ncomp", value = cv_reactive()$opt_ncomp)
    })
    
    # =========================
    # LOAD & RESET
    # =========================
    
    # LOAD MODEL
    observeEvent(input$model_file, {
      req(input$model_file)
      mod_loaded <- readRDS(input$model_file$datapath)
      key <- paste(engine, mode, sep = "_")
      
      if (key == "lm_reg" || key == "lm_cla") {
        mod_loaded$loaded <- TRUE
        model_reactive(mod_loaded)
      }
      
      else if (key == "pls_reg") {
        mod_loaded$plsmod$loaded <- TRUE
        mod_loaded$plscv$loaded <- TRUE
        model_reactive(mod_loaded$plsmod)
        cv_reactive(mod_loaded$plscv)
      }
      
      else if (key == "pls_cla") {
        mod_loaded$plsdamod$loaded <- TRUE
        mod_loaded$plsdacv$loaded <- TRUE
        model_reactive(mod_loaded$plsdamod)
        cv_reactive(mod_loaded$plsdacv)
      }
      
      showNotification("Model successfully loaded.", type = "message")
    })
    
    # RESET
    observeEvent(input$reset, {
      req(model_reactive())
      
      modTemp <- model_reactive()
      modTemp$loaded <- FALSE
      model_reactive(modTemp)
      
      if (!is.null(cv_reactive)) {
        if (!is.null(cv_reactive())) {
          cvTemp <- cv_reactive()
          cvTemp$loaded <- FALSE
          cv_reactive(cvTemp)
        }
      }
      
      later::later(function() {
        model_reactive(NULL)
        if (!is.null(cv_reactive))
          cv_reactive(NULL)
      }, delay = 1)
      
      showNotification("Model reset successfully.", type = "warning")
    })
    
    # RUN
    observeEvent(input$run_btn, {
      id_notif <- showNotification("Running...", duration = NULL, type = "message")
      
      if (engine == "lm") {
        req(df_reactive())
        
        model_reactive(
          model_fun(
            df        = df_reactive(),
            scale     = input$scale,
            spl_type  = input$spl_type,
            pro_test  = input$pro_test,
            cv        = input$cv,
            folds     = input$folds,
            yrand     = input$yrand,
            nrep      = input$nrep,
            q_lod     = input$q_lod
          )
        )
        
      }
      
      if (engine == "pls") {
        req(cv_reactive())
        
        model_reactive(
          model_fun(
            cv_reactive(),
            ncomp = input$ncomp,
            yrand = input$yrand,
            nrep  = input$nrep,
            q_lod = input$q_lod
          )
        )
        
        if (!is.null(update_class)) {
          update_class(model_reactive())
        }
      }
      
      removeNotification(id_notif)
      
    })
    
    # AUX
    make_table <- function(x) {
      if (mode == "reg")
        x
      else
        as.data.frame.matrix(x)
    }
    
    # TRIGGER
    trigger <- reactive({
      req(model_reactive())
      TRUE
    })
    
    
    output$matrix_legend <- renderUI({
      trigger()
      
      req(mode == "cla")
      
      tags$p("Actual in rows and predicted in columns", style = "color: #555; margin-bottom: 10px;")
    })
    
    # CAL
    output$cal_ui <- renderUI({
      trigger()
      ns <- session$ns
      
      tagList(h4("Calibration"), tableOutput(ns("cal_tab")))
    })
    
    output$cal_tab <- renderTable({
      req(model_reactive())
      
      if (mode == "reg") {
        model_reactive()$mvcal_met
      } else {
        make_table(model_reactive()$cmCal)
      }
    }, rownames = TRUE, colnames = TRUE)
    
    # TEST
    output$test_ui <- renderUI({
      trigger()
      ns <- session$ns
      
      if (mode == "reg") {
        if (!is.null(model_reactive()$mvtes_met))
          return(tagList(h4("Test"), tableOutput(ns("test_tab"))))
      } else {
        if (!is.null(model_reactive()$cmTest))
          return(tagList(h4("Test"), tableOutput(ns("test_tab"))))
      }
      
      NULL
    })
    
    output$test_tab <- renderTable({
      req(model_reactive())
      
      if (mode == "reg") {
        model_reactive()$mvtes_met
      } else {
        make_table(model_reactive()$cmTest)
      }
    }, rownames = TRUE, colnames = TRUE)
    
    # CV
    output$cv_ui <- renderUI({
      trigger()
      ns <- session$ns
      
      if (mode == "reg") {
        if (!is.null(model_reactive()$mvcv_met))
          return(tagList(h4("Cross-validation"), tableOutput(ns("cv_tab"))))
      } else {
        if (!is.null(model_reactive()$cmCV))
          return(tagList(h4("Cross-validation"), tableOutput(ns("cv_tab"))))
      }
      
      NULL
    })
    
    output$cv_tab <- renderTable({
      req(model_reactive())
      
      if (mode == "reg") {
        model_reactive()$mvcv_met
      } else {
        make_table(model_reactive()$cmCV)
      }
    }, rownames = TRUE, colnames = TRUE)
    
    # YRAND
    output$yrand_ui <- renderUI({
      trigger()
      ns <- session$ns
      
      if (mode == "reg") {
        if (!is.null(model_reactive()$mvyrand_met))
          return(tagList(h4("y-randomization"), tableOutput(ns(
            "yrand_tab"
          ))))
      } else {
        if (engine == "pls") {
          if (!is.null(model_reactive()$yrand_metrics))
            return(tagList(h4("y-randomization"), tableOutput(ns(
              "yrand_tab"
            ))))
        } else {
          if (!is.null(model_reactive()$cmYrand))
            return(tagList(h4("y-randomization"), tableOutput(ns(
              "yrand_tab"
            ))))
        }
      }
      
      NULL
    })
    
    output$yrand_tab <- renderTable({
      req(model_reactive())
      
      if (mode == "reg") {
        model_reactive()$mvyrand_met
      } else {
        if (engine == "pls") {
          as.data.frame.matrix(model_reactive()$yrand_metrics$confusion)
        } else {
          make_table(model_reactive()$cmYrand)
        }
      }
    }, rownames = TRUE, colnames = TRUE)
    
    # SAVE MODEL UI
    output$save_model <- renderUI({
      ns <- session$ns
      
      ready <- !is.null(model_reactive())
      
      downloadLink(
        ns("save_model_btn"),
        "Save model",
        icon = icon("save"),
        class = "btn btn-success",
        style = "width: 100%;",
        onclick = if (!ready)
          "return false;"
      )
    })
    
    # SAVE RESULTS UI
    output$save_results <- renderUI({
      ns <- session$ns
      
      ready <- !is.null(model_reactive())
      
      downloadLink(
        ns("save_results_btn"),
        "Save results",
        icon = icon("save"),
        class = "btn btn-success",
        style = "width: 100%;",
        onclick = if (!ready)
          "return false;"
      )
    })
    
    # DOWNLOAD MODEL
    output$save_model_btn <- downloadHandler(
      filename = function() {
        prefix <- switch(
          paste(engine, mode, sep = "_"),
          "lm_reg"   = "MLR_model_",
          "lm_cla" = "MLRDA_model_",
          "pls_reg"  = "PLS_model_",
          "pls_cla" = "PLSDA_model_"
        )
        
        paste0(prefix, Sys.Date(), ".rds")
      },
      
      content = function(file) {
        key <- paste(engine, mode, sep = "_")
        
        if (key == "lm_reg") {
          saveRDS(model_reactive(), file)  # MLR
        }
        
        if (key == "lm_cla") {
          saveRDS(model_reactive(), file)  # MLR-DA
        }
        
        if (key == "pls_reg") {
          saveRDS(list(plsmod = model_reactive(), plscv  = cv_reactive()),
                  file)
        }
        
        if (key == "pls_cla") {
          saveRDS(list(plsdamod = model_reactive(), plsdacv  = cv_reactive()),
                  file)
        }
      }
    )
    
    # DOWNLOAD RESULTS
    output$save_results_btn <- downloadHandler(
      filename = function() {
        prefix <- switch(
          paste(engine, mode, sep = "_"),
          "lm_reg"   = "MLR_results_",
          "lm_cla" = "MLRDA_results_",
          "pls_reg"  = "PLS_results_",
          "pls_cla" = "PLSDA_results_"
        )
        
        paste0(prefix, Sys.Date(), ".xlsx")
      },
      
      content = function(file) {
        req(model_reactive())
        
        key <- paste(engine, mode, sep = "_")
        mod <- model_reactive()
        
        if (mode == "reg") {
          sheets <- make_reg_mod_output(mod)
        } else {
          sheets <- make_da_mod_output(mod)
        }
        
        writexl::write_xlsx(sheets, file)
      }
    )
    
  })
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.