compactNavbarStyle <- function(id,
                               height = 20,
                               padding = 5,
                               fontsize = 12) {
  
  css <- sprintf(
    "
    #%s > .navbar {
      min-height: %dpx !important;
    }
    #%s > .navbar .navbar-nav > li > a {
      padding-top: %dpx !important;
      padding-bottom: %dpx !important;
      font-size: %dpx !important;
    }
    #%s > .navbar .navbar-brand {
      padding-top: %dpx !important;
      padding-bottom: %dpx !important;
      height: %dpx !important;
      font-size: %dpx !important;
    }
    ",
    id, height,
    id, padding, padding, fontsize,
    id, padding, padding, height, fontsize
  )
  
  tags$head(tags$style(HTML(css)))
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.