predictionUI <- function(id, type = c("reg", "cla", "1cla")) {
  ns <- NS(id)
  
  tabPanel("Prediction", fluidRow(
    # LEFT
    column(
      3,
      wellPanel(
        style = "padding-top:0px;",
        
        h4("Load"),
        
        # fileInput(ns("model_file"), "Load model (.rds)", accept = ".rds"),
        fileInput(ns("data_file"), "Load data (.xlsx)", accept = ".xlsx"),
        
        br(),
        uiOutput(ns("selects")),
        
        br(),
        actionButton(
          ns("apply"),
          "Apply",
          icon = icon("play"),
          class = "btn-primary",
          style = "width: calc(50% - 10px);"
        ),
        
        br(),
        br(),
        
        div(
          style = "display:flex; gap:10px;",
          actionButton(
            ns("run"),
            "Predict",
            icon = icon("chart-line"),
            class = "btn-success",
            style = "flex:1;"
          ),
          
          uiOutput(ns("save_ui"), style = "flex:1; display:flex;")
        ),
        
        # br(),
        # actionButton(
        #   ns("reset"),
        #   "Reset",
        #   icon = icon("chart-line"),
        #   class = "btn-primary"
        # ),
      )
    ),
    
    # CENTER
    column(
      if (type == "reg" || type == "1cla")
        6
      else
        9,
      uiOutput(ns("model_info")),
      br(),
      if (type == "reg" || type == "1cla")
        uiOutput(ns("plot_container")),
      uiOutput(ns("center_extra"))
    ),
    
    # RIGHT
    if (type == "reg" || type == "1cla")
      column(
        3,
        wellPanel(if (type == "reg") {
          tagList(selectInput(
            ns("palette"),
            "Colors:",
            c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
          ))
        } else if (type == "1cla") {
          tagList(
            checkboxInput(ns("group"), "Groups", TRUE),
            checkboxInput(ns("log_scale"), "Log scale", TRUE),
            checkboxInput(ns("marker"), "Markers", TRUE),
            checkboxInput(ns("labels"), "Labels", FALSE),
            selectInput(
              ns("palette"),
              "Colors:",
              c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
            ),
            
          )
        }),
        br(),
        wellPanel(
          style = "padding-top:0px;",
          h3("Export graph"),
          numericInput(ns("fontsize"), "Font factor:", 0.7, 0.3, 2, 0.1),
          exportPlotUI(ns("plot_export"))
        )
      )
  ))
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.