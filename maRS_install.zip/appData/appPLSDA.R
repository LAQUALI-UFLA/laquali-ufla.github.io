# =========================
# UI
# =========================

appPLSDAUI <- div(
  id = "plsda_module",
  
  compactNavbarStyle("plsda_module"),
  
  navbarPage(
    "PLS-DA",

    # CROSS-VALIDATION
    cvUI("plsda_cv", mode = "cla"),

    # MODEL
    modelUI(
      "plsda_model",
      engine = "pls",
      mode = "cla",
      title = "PLS-DA settings"
    ),

    # DIAGNOSTICS
    diagnosticsUI("plsda_diag", mode = "da"),

    # METRICS
    metricsUI("plsda_met"),

    # IMPORTANCE
    importanceUI("plsda_imp", mode = "plsda"),

    # PREDICTION
    predictionUI("plsda_pred", type = "cla")
    
  )
)

# =========================
# SERVER
# =========================

appPLSDAServer <- function(input, output, session, df_shared) {
  plsdacv  <- reactiveVal(NULL)
  plsdamod <- reactiveVal(NULL)

  # CROSS-VALIDATION
  cvServer(
    "plsda_cv",
    df_reactive = df_shared,
    cv_fun = list(
      "PLS-DA"     = cv_plsda,
      "iPLS-DA"    = cv_iplsda,
      "BVE/PLS-DA" = cv_bveplsda
    ),
    cv_reactive = plsdacv,
    mode        = "cla"
  )

  # MODEL
  modelServer(
    "plsda_model",
    model_fun       = mod_plsda,
    cv_reactive   = plsdacv,
    model_reactive  = plsdamod,
    mode            = "cla",
    engine          = "pls",
    
    update_class = function(mod) {
      updateSelectInput(session, "plsdaimp_clas", choices = mod$classes)
    }
  )

  # DIAGNOSTICS
  diagnosticsServer("plsda_diag", model_reactive = plsdamod, mode = "da")

  # METRICS
  metricsServer("plsda_met", model_reactive = plsdamod)

  # IMPORTANCE
  importanceServer("plsda_imp", plsdamod, mode = "plsda")

  # PREDICTION
  predictionServer(
    "plsda_pred",
    model_reactive = plsdamod,
    cv_reactive   = plsdacv,
    model_setter   = function(x) {
      plsdamod(x$plsdamod)
      plsdacv(x$plsdacv)
    },
    pred_fun       = pred_plsda,
    type           = "cla",
    output_fun     = make_da_pred_output
  )
  
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.