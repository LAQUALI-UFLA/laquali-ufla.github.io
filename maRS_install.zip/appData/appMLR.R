# =========================
# UI
# =========================

appMLRUI <- div(
  id = "mlr_module",
  
  compactNavbarStyle("mlr_module"),
  
  navbarPage(
    "MLR",

    # MODEL
    modelUI(
      "mlr_model",
      engine = "lm",
      mode = "reg",
      title = "MLR settings"
    ),
    
    # DIAGNOSTICS
    diagnosticsUI("mlr_diag", mode = "reg"),
    
    # PARITY
    parityUI("mlr_par"),
    
    # IMPORTANCE
    importanceUI("mlr_imp", mode = "mlr"),
    
    # PREDICTION
    predictionUI("mlr_pred", type = "reg")
    
  )
)

# =========================
# SERVER
# =========================

appMLRServer <- function(input, output, session, df_shared) {
  mlrmod  <- reactiveVal(NULL)
  mlrcv  <- reactiveVal(NULL)
  
  #   MODEL
  modelServer(
    "mlr_model",
    model_fun       = mod_mlr,
    df_reactive     = df_shared,
    model_reactive  = mlrmod,
    mode            = "reg",
    engine          = "lm"
  )
  
  # DIAGNOSTICS
  diagnosticsServer("mlr_diag", model_reactive = mlrmod, mode = "reg")
  
  # PARITY
  parityServer("mlr_par", model_reactive = mlrmod)
  
  # IMPORTANCE
  importanceServer("mlr_imp", model_reactive = mlrmod, mode = "mlr")
  
  # PREDICTION
  predictionServer(
    "mlr_pred",
    model_reactive = mlrmod,
    cv_reactive    = mlrcv,
    model_setter   = mlrmod,
    pred_fun       = pred_mlr,
    type           = "reg",
    output_fun     = make_reg_pred_output
  )
  
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.