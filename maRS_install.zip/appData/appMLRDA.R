# =========================
# UI
# =========================

appMLRDAUI <- div(
  id = "mlrda_module",
  
  compactNavbarStyle("mlrda_module"),
  
  navbarPage(
    "MLR-DA",
    
    # MODEL
    modelUI(
      "mlrda_model",
      engine = "lm",
      mode = "cla",
      title = "MLR-DA settings"
    ),
    
    # DIAGNOSTICS
    diagnosticsUI("mlrda_diag", mode = "da"),
    
    # METRICS
    metricsUI("mlrda_met"),
    
    # IMPORTANCE
    importanceUI("mlrda_imp", mode = "mlrda"),
    
    # PREDICTION
    predictionUI("mlrda_pred", type = "cla")
    
  )
)

# =========================
# SERVER
# =========================
appMLRDAServer <- function(input, output, session, df_shared) {
  mlrdamod  <- reactiveVal(NULL)
  mlrdacv  <- reactiveVal(NULL)
  
  # MODEL
  modelServer(
    "mlrda_model",
    model_fun       = mod_mlrda,
    df_reactive     = df_shared,
    model_reactive  = mlrdamod,
    mode            = "cla",
    engine          = "lm"
  )
  
  # DIAGNOSTICS
  diagnosticsServer("mlrda_diag", model_reactive = mlrdamod, mode = "da")
  
  # METRICS
  metricsServer("mlrda_met", model_reactive = mlrdamod)

  # IMPORTANCE
  importanceServer("mlrda_imp", mlrdamod, mode = "mlrda")
  
  # PREDICTION
  predictionServer(
    "mlrda_pred",
    model_reactive = mlrdamod,
    cv_reactive    = mlrdacv,
    model_setter   = mlrdamod,
    pred_fun       = pred_mlrda,
    type           = "cla",
    output_fun     = make_da_pred_output
  )
  
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.