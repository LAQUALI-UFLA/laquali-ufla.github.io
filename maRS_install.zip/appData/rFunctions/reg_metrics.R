reg_metrics <- function(res) {
  if (length(res) == 2) {
    # get y vectors
    y <- res$y_actual
    yhat <- res$y_hat
    
    # RMSE
    rmse <- sqrt(mean((y - yhat)^2))
    
    # R2 (with intercept)
    r2 <- cor(yhat, y)^2
    
    # r0^2 (y vs yhat, zero intercept)
    mod_0 <- lm(y ~ yhat + 0)
    
    ss_res <- sum(residuals(mod_0)^2)
    ss_tot <- sum((y - mean(y))^2)
    
    r02 <- 1 - ss_res / ss_tot
    
    # rm^2
    rm2 <- r2 * (1 - sqrt(r2 - r02))
    
    # RSD (%)
    rsd <- rmse / mean(y) * 100
    
    # RPD
    rpd <- sd(y) / rmse
    
    c(
      R2 = r2,
      R02 = r02,
      Rm2 = rm2,
      RMSE = rmse,
      RSD = rsd,
      RPD = rpd
    )
  }
  else{
    # get y vectors
    y <- res$y_actual
    yhatcal <- res$y_hat_cal
    
    # identify yr vectors
    yr_names <- grep("^yr", names(res), value = TRUE)
    
    # container for metrics
    mets <- matrix(NA, nrow = length(yr_names), ncol = 6)
    colnames(mets) <- c("R2", "r02", "rm2", "RMSE", "RSD", "RPD")
    
    # loop over yr
    for (i in seq_along(yr_names)) {
      yhat <- res[[yr_names[i]]]
      
      # RMSE
      rmse <- sqrt(mean((y - yhat)^2))
      
      # R2
      r2 <- cor(yhat, y)^2
      
      # r0^2 (zero intercept)
      mod_0 <- lm(y ~ yhat + 0)
      ss_res <- sum(residuals(mod_0)^2)
      ss_tot <- sum((y - mean(y))^2)
      r02 <- 1 - ss_res / ss_tot
      
      # rm^2
      rm2 <- r2 * (1 - sqrt(r2 - r02))
      
      # RSD (%)
      rsd <- rmse / mean(y) * 100
      
      # RPD
      rpd <- sd(y) / rmse
      
      mets[i, ] <- c(r2, r02, rm2, rmse, rsd, rpd)
    }
    
    # mean y-randomization metrics
    met_mean <- colMeans(mets, na.rm = TRUE)
    
    # r2 (calibration)
    r2cal <- cor(yhatcal, y)^2
    
    # r2p
    r2p <- sqrt(r2cal) * (sqrt(r2cal - met_mean["R2"]))
    
    c(
      R2   = unname(met_mean["R2"]),
      R02  = unname(met_mean["r02"]),
      Rm2  = unname(met_mean["rm2"]),
      RMSE = unname(met_mean["RMSE"]),
      RSD  = unname(met_mean["RSD"]),
      RPD  = unname(met_mean["RPD"]),
      cR2p  = unname(r2p)
    )
    
  }
  
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.