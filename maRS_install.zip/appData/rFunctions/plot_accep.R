plot_accep <- function(mod,
                       res = NULL,
                       norm_scale = TRUE,
                       log_scale = TRUE,
                       marker = TRUE,
                       labels = TRUE,
                       group = FALSE,
                       colPa = "Hue",
                       val_cex = 0.7) {
  # --- data ---
  if (!is.null(res)) {
    h <- as.vector(res$T2)
    Q <- as.vector(res$Q)
    
    if (!is.null(res$row_names)) {
      row_names <- res$row_names
    } else if (!is.null(res$groups)) {
      row_names <- res$groups
    } else {
      row_names <- seq_along(h)
    }
    
  } else {
    h <- as.vector(mod$T2)
    Q <- as.vector(mod$Q)
    
    if (!is.null(mod$row_names)) {
      row_names <- mod$row_names
    } else if (!is.null(mod$groups)) {
      row_names <- mod$groups
    } else {
      row_names <- seq_along(h)
    }
  }

  # --- limits ---
  lim_reg <- list(hlim = mod$T2lim[1, mod$ncomp], Qlim = mod$Qlim[1, mod$ncomp])
  
  lim_ext <- list(hlim = mod$T2lim[2, mod$ncomp], Qlim = mod$Qlim[2, mod$ncomp])
  
  lim_med <- list(hlim = mod$T2lim[3, mod$ncomp], Qlim = mod$Qlim[3, mod$ncomp])
  
  # --- normalization ---
  if (norm_scale) {
    h <- h / lim_med$hlim
    Q <- Q / lim_med$Qlim
    hlim_reg <- lim_reg$hlim / lim_med$hlim
    Qlim_reg <- lim_reg$Qlim / lim_med$Qlim
    hlim_ext <- lim_ext$hlim / lim_med$hlim
    Qlim_ext <- lim_ext$Qlim / lim_med$Qlim
  } else {
    hlim_reg <- lim_reg$hlim
    Qlim_reg <- lim_reg$Qlim
    hlim_ext <- lim_ext$hlim
    Qlim_ext <- lim_ext$Qlim
  }
  
  # --- log transformation ---
  if (log_scale) {
    xh <- log1p(h)
    yq <- log1p(Q)
    xlim <- log1p(c(0, max(hlim_ext, max(h))))
    ylim <- log1p(c(0, max(Qlim_ext, max(Q))))
  } else {
    xh <- h
    yq <- Q
    xlim <- c(0, max(hlim_ext, max(h)))
    ylim <- c(0, max(Qlim_ext, max(Q)))
  }
  
  #----------------------plot---------------------
  # Color setup based on groups / class_ref
  
  if (is.null(res)) {
    col <- rep(make_palette(1, colPa), length(h))
    
  } else {
    if (group && !is.null(res$groups)) {
      colfac <- factor(res$groups, levels = unique(res$groups))
      pal <- make_palette(length(levels(colfac)), colPa)
      col <- pal[colfac]
      
    } else if (!group && !is.null(res$class_ref)) {
      colfac <- factor(res$class_ref, levels = c("in", "out"))
      pal <- make_palette(2, colPa)
      col <- pal[colfac]
      
    } else {
      col <- rep(make_palette(1, colPa), length(h))
      
    }
  }
  
  
  # Allow drawing outside plot region
  op <- par(xpd = TRUE)
  on.exit(par(op))
  
  # --- plot base ---
  plot(
    xh,
    yq,
    las = 1,
    pch = if (marker)
      21
    else
      NA,
    col = col,
    bg  = mix_with_white(col, alpha = 0.2),
    cex = val_cex,
    xlab = if (log_scale)
      "log(1 + h / h0)"
    else
      "h / h0",
    ylab = if (log_scale)
      "log(1 + q / q0)"
    else
      "q / q0",
    lwd = 1.5,
    cex.axis = val_cex,
    cex.lab = val_cex,
    xlim = xlim,
    ylim = ylim
  )
  
  # Labels for active scores
  if (labels) {
    if (marker) {
      text(
        xh,
        yq,
        labels = row_names,
        pos = 3,
        cex = val_cex,
        offset = 0.3
      )
    } else {
      text(xh, yq, labels = row_names, cex = val_cex)
    }
  }
  
  # --- DETECT LIMIT TYPE ---
  lim_type <- mod$method
  
  # --- DRAW THE LIMITS ACCORDING TO THE TYPE ---
  if (lim_type == "smcla") {
    lim_data <- draw_rectangular_limits(hlim_reg, Qlim_reg, log_scale, lty = 2)
    
    if (is.null(res))
      lim_data_ext <- draw_rectangular_limits(hlim_ext, Qlim_ext, log_scale, lty = 2)
    
  } else if (lim_type %in% c("ddcla", "ddrob")) {
    lim_data <- draw_triangular_curve(hlim_reg, Qlim_reg, log_scale, lty = 2)
    
    if (is.null(res))
      lim_data_ext <- draw_triangular_curve(hlim_ext, Qlim_ext, log_scale, lty = 2)
  }
  
  # --- legend ---
  show_legend <- !is.null(res) &&
    exists("colfac") &&
    exists("pal")
  
  if (show_legend) {
    levels(colfac)[levels(colfac) == "in"] <- mod$targetclass
    leg_levels <- levels(colfac)
    leg_cols   <- pal
    
    legend(
      "top",
      inset = -0.1,
      legend = leg_levels,
      col    = leg_cols,
      pch = 21,
      pt.bg = mix_with_white(leg_cols, alpha = 0.2),
      pt.lwd = 1.5,
      pt.cex = 1,
      cex = val_cex,
      horiz = TRUE,
      bty = "n"
    )
  }
  
  plot_data <- list(
    xh = xh,
    yq = yq,
    line_h_lim = lim_data$line_h_lim,
    line_q_lim = lim_data$line_q_lim
  )
  
  invisible(plot_data)
}

# ----------------------------------------------------------------------------
# --- PLOTTING FUNCTIONS ---
# ----------------------------------------------------------------------------
# Function for triangular curve
draw_triangular_curve <- function(hlim,
                                  Qlim,
                                  log_scale,
                                  lty = 2,
                                  col = "black",
                                  lwd = 1) {
  hseq <- seq(0, hlim, length.out = 200)
  Qseq <- Qlim * (1 - hseq / hlim)
  
  if (log_scale) {
    x <- log1p(hseq)
    y <- log1p(Qseq)
    lines(x,
          y,
          lty = lty,
          col = col,
          lwd = lwd)
  } else {
    x <- hseq
    y <- Qseq
    lines(x,
          y,
          lty = lty,
          col = col,
          lwd = lwd)
  }
  
  return(list(line_h_lim = x, line_q_lim = y))
}

# Function for rectangular limits
draw_rectangular_limits <- function(hlim,
                                    Qlim,
                                    log_scale,
                                    lty = 2,
                                    col = "black",
                                    lwd = 1) {
  if (log_scale) {
    xh <- c(0, log1p(hlim))
    yq <- rep(log1p(Qlim), 2)
    
    xv <- rep(log1p(hlim), 2)
    yv <- c(0, log1p(Qlim))
    
  } else {
    xh <- c(0, hlim)
    yq <- rep(Qlim, 2)
    
    xv <- rep(hlim, 2)
    yv <- c(0, Qlim)
  }
  
  lines(xv,
        yv,
        lty = lty,
        col = col,
        lwd = lwd)
  lines(xh,
        yq,
        lty = lty,
        col = col,
        lwd = lwd)
  
  return(list(line_h_lim = c(xh, xh[2]), line_q_lim = c(yq, 0)));
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.
# This code is inspired by and partially based on implementations from the mdatools project developed by Sergey Kucheryavskiy.
# Original source: https://github.com/svkucheryavski/mdatools