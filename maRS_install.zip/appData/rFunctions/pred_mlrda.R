pred_mlrda <- function(mlrdamod, df, prepro = FALSE)
{
  lev <- mlrdamod$classes
  
  # Apply preprocessing using the parameters from the training model
  if (prepro){
    df <- pre_pro(df,
                  ppmet = mlrdamod$ppmet,
                  sgstp = mlrdamod$sgstp,
                  mx = mlrdamod$mx)
  }
  
  Xnew <- as.matrix(df$xdat)
  
  # ==========================
  # Apply centering / scaling
  # ==========================
  
  if (!is.null(mlrdamod$Xmeans))
    Xnew <- sweep(Xnew, 2, mlrdamod$Xmeans, "-")
  
  if (!is.null(mlrdamod$scale))
    Xnew <- sweep(Xnew, 2, mlrdamod$scale, "/")
  
  # ==========================
  # Prediction (MLR-DA)
  # ==========================
  
  B0 <- mlrdamod$b0
  BX <- mlrdamod$coefficients
  
  Yhat <- cbind(1, Xnew) %*% rbind(B0, BX)
  
  # ==========================
  # Class decision
  # ==========================
  
  idx <- max.col(Yhat, ties.method = "first")
  class_hat <- factor(lev[idx], levels = lev)
  
  # =================================================
  # If reference exists → return confusion matrix
  # =================================================
  
  if (!is.null(df$groups)) {
    class_ref <- factor(df$groups, levels = lev)
    
    if (length(class_hat) != length(class_ref))
      stop("Prediction did not return a row per sample.")
    
    cm <- table(Reference = class_ref, Predicted = class_hat)
    
    out <- list(class_hat = class_hat,
                class_ref = class_ref,
                cm        = cm)
    
  } else {
    out <- list(class_hat = class_hat)
  }
  
  return(out)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.