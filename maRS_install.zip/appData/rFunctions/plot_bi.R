plot_bi <- function(mvmod,
                    x = 1,
                    y = 2,
                    z = 0,
                    vrot = 25,
                    hrot = 40,
                    scormarker = TRUE,
                    scorlabels = TRUE,
                    group = FALSE,
                    elips = FALSE,
                    fillelip = FALSE,
                    mrksiz = FALSE,
                    mrkcol = FALSE,
                    colPa = "Hue",
                    vectors = FALSE,
                    loadmarker = TRUE,
                    loadlabels = TRUE,
                    adsupscor = FALSE,
                    adsupload = FALSE,
                    val_cex = 0.7,
                    grids = FALSE,
                    orlines = FALSE) {
  # Original scores and loadings
  scores <- if (!is.null(mvmod$scores))
    mvmod$scores
  else
    mvmod$x
  loadings_orig <- if (!is.null(mvmod$loadings))
    mvmod$loadings
  else
    mvmod$rotation
  
  # Check supplementary scores
  has_sups <- FALSE
  if (adsupscor) {
    if (!is.null(mvmod$suprows) && !is.null(mvmod$supscor)) {
      if (nrow(mvmod$supscor) > 0 &&
          ncol(mvmod$supscor) >= max(x, y, z)) {
        has_sups <- TRUE
        supscor <- mvmod$supscor
      } else {
        warning("Supplementary scores are not available or have insufficient dimensions")
      }
    }
  }
  
  # Check supplementary loadings
  has_supl <- FALSE
  if (adsupload) {
    if (!is.null(mvmod$supcols) && !is.null(mvmod$supload)) {
      if (nrow(mvmod$supload) > 0 &&
          ncol(mvmod$supload) >= max(x, y, z)) {
        has_supl <- TRUE
        supload_orig <- mvmod$supload
      } else {
        warning("Supplementary loadings are not available or have insufficient dimensions")
      }
    }
  }
  
  oldpar <- par(no.readonly = TRUE)
  
  # layout if colorbar
  use_cbar <- mrkcol && !group && !is.null(mvmod$scalecol)
  
  if (use_cbar) {
    on.exit({
      layout(1)
      par(oldpar)
    }, add = TRUE)
    
    layout(matrix(c(2, 1), nrow = 2), heights = c(1, 8))
    mar <- par("mar")
    mar[3] <- 1.82
    par(mar = mar)
  }
  else
    on.exit(par(oldpar), add = TRUE)
  
  # Plot scores
  pscor <- plot_scor(
    mvmod,
    x = x,
    y = y,
    z = z,
    vrot = vrot,
    hrot = hrot,
    marker = scormarker,
    labels = scorlabels,
    group = group,
    elips = elips,
    fillelip = fillelip,
    mrksiz = mrksiz,
    mrkcol = mrkcol,
    colPa = colPa,
    adsupscor = adsupscor,
    biplot = TRUE,
    grids = grids,
    val_cex = val_cex,
    orlines = orlines
  )
  
  # Score limits (asymmetric)
  x_min <- min(c(scores[, x], if (has_sups)
    supscor[, x]), na.rm = TRUE)
  x_max <- max(c(scores[, x], if (has_sups)
    supscor[, x]), na.rm = TRUE)
  y_min <- min(c(scores[, y], if (has_sups)
    supscor[, y]), na.rm = TRUE)
  y_max <- max(c(scores[, y], if (has_sups)
    supscor[, y]), na.rm = TRUE)
  
  if (z > 0) {
    z_min <- min(c(scores[, z], if (has_sups)
      supscor[, z]), na.rm = TRUE)
    z_max <- max(c(scores[, z], if (has_sups)
      supscor[, z]), na.rm = TRUE)
  }
  
  # Compute safe scaling factors
  calc_scale <- function(vals, v_min, v_max) {
    scale_fac <- Inf
    for (val in vals) {
      if (val > 0)
        scale_fac <- min(scale_fac, v_max / val, na.rm = TRUE)
      if (val < 0)
        scale_fac <- min(scale_fac, v_min / val, na.rm = TRUE)
    }
    return(if (is.finite(scale_fac))
      scale_fac * 0.9
      else
        1)
  }
  
  # Scaling factors for regular loadings
  scale_x <- calc_scale(loadings_orig[, x], x_min, x_max)
  scale_y <- calc_scale(loadings_orig[, y], y_min, y_max)
  if (z > 0)
    scale_z <- calc_scale(loadings_orig[, z], z_min, z_max)
  
  # Adjust scaling if supplementary loadings exist
  if (has_supl) {
    scale_x <- min(scale_x, calc_scale(supload_orig[, x], x_min, x_max), na.rm = TRUE)
    scale_y <- min(scale_y, calc_scale(supload_orig[, y], y_min, y_max), na.rm = TRUE)
    if (z > 0)
      scale_z <- min(scale_z, calc_scale(supload_orig[, z], z_min, z_max), na.rm = TRUE)
  }
  
  # Create scaled copies of loadings
  loadings_scaled <- loadings_orig
  loadings_scaled[, x] <- loadings_orig[, x] * scale_x
  loadings_scaled[, y] <- loadings_orig[, y] * scale_y
  if (z > 0)
    loadings_scaled[, z] <- loadings_orig[, z] * scale_z
  
  if (has_supl) {
    supload_scaled <- supload_orig
    supload_scaled[, x] <- supload_orig[, x] * scale_x
    supload_scaled[, y] <- supload_orig[, y] * scale_y
    if (z > 0)
      supload_scaled[, z] <- supload_orig[, z] * scale_z
  }
  
  # Overlay loadings on the existing plot
  par(xpd = NA)  # Avoid graphical clipping
  
  var_names <- mvmod$col_names
  
  # 3D case
  if (z > 0) {
    
    # Safe offset function for 3D labels
    safe_offset_3d <- function(pos, offset_frac, limits) {
      offset <- sign(pos) * offset_frac * diff(limits)
      new_pos <- pos + offset
      margin <- 0.02 * diff(limits)
      pmax(pmin(new_pos, limits[2] - margin), limits[1] + margin)
    }
    
    # Compute ranges for offset calculations
    if (has_supl) {
      x_rng <- range(c(loadings_scaled[, x], supload_scaled[, x]), na.rm = TRUE)
      y_rng <- range(c(loadings_scaled[, y], supload_scaled[, y]), na.rm = TRUE)
      z_rng <- range(c(loadings_scaled[, z], supload_scaled[, z]), na.rm = TRUE)
    } else {
      x_rng <- range(loadings_scaled[, x], na.rm = TRUE)
      y_rng <- range(loadings_scaled[, y], na.rm = TRUE)
      z_rng <- range(loadings_scaled[, z], na.rm = TRUE)
    }
    
    # Plot scaled loadings as vectors or markers
    if (vectors) {
      plot3D::arrows3D(
        x0 = rep(0, nrow(loadings_scaled)),
        y0 = rep(0, nrow(loadings_scaled)),
        z0 = rep(0, nrow(loadings_scaled)),
        x1 = loadings_scaled[, x],
        y1 = loadings_scaled[, y],
        z1 = loadings_scaled[, z],
        col = "black",
        lwd = 1,
        length = 0.2,
        angle = 20,
        add = TRUE
      )
    } else {
      plot3D::points3D(
        loadings_scaled[, x],
        loadings_scaled[, y],
        loadings_scaled[, z],
        pch = if (loadmarker)
          22
        else
          NA,
        col = "black",
        bg = if (loadmarker)
          mix_with_white("black", alpha = 0.2)
        else
          NA,
        add = TRUE
      )
    }
    
    # Plot supplementary loadings in 3D
    if (has_supl) {
      if (vectors) {
        plot3D::arrows3D(
          x0 = rep(0, nrow(supload_scaled)),
          y0 = rep(0, nrow(supload_scaled)),
          z0 = rep(0, nrow(supload_scaled)),
          x1 = supload_scaled[, x],
          y1 = supload_scaled[, y],
          z1 = supload_scaled[, z],
          col = "#e41a1c",
          lwd = 1,
          add = TRUE,
          length = 0.2,
          angle = 20
        )
      } else {
        plot3D::points3D(
          supload_scaled[, x],
          supload_scaled[, y],
          supload_scaled[, z],
          pch = if (loadmarker)
            22
          else
            NA,
          col = "#e41a1c",
          bg = if (loadmarker)
            mix_with_white("#e41a1c", alpha = 0.2)
          else
            NA,
          add = TRUE
        )
      }
    }
    
    # Add main loading labels
    if (loadlabels) {
      if (loadmarker && !vectors) {
        z_pos <- safe_offset_3d(loadings_scaled[, z], 0.06, z_rng)
        plot3D::text3D(
          x = loadings_scaled[, x],
          y = loadings_scaled[, y],
          z = z_pos,
          labels = var_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "black"
        )
      } else if (vectors) {
        x_pos <- safe_offset_3d(loadings_scaled[, x], 0.035, x_rng)
        y_pos <- safe_offset_3d(loadings_scaled[, y], 0.035, y_rng)
        z_pos <- safe_offset_3d(loadings_scaled[, z], 0.035, z_rng)
        plot3D::text3D(
          x = x_pos,
          y = y_pos,
          z = z_pos,
          labels = var_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "black"
        )
      } else {
        plot3D::text3D(
          x = loadings_scaled[, x],
          y = loadings_scaled[, y],
          z = loadings_scaled[, z],
          labels = var_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "black"
        )
      }
    }
    
    # Add supplementary loading labels in 3D
    if (has_supl && loadlabels) {
      if (loadmarker && !vectors) {
        z_pos <- safe_offset_3d(supload_scaled[, z], 0.06, z_rng)
        plot3D::text3D(
          x = supload_scaled[, x],
          y = supload_scaled[, y],
          z = z_pos,
          labels = mvmod$sup_col_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "#e41a1c"
        )
      } else if (vectors) {
        x_pos <- safe_offset_3d(supload_scaled[, x], 0.035, x_rng)
        y_pos <- safe_offset_3d(supload_scaled[, y], 0.035, y_rng)
        z_pos <- safe_offset_3d(supload_scaled[, z], 0.035, z_rng)
        plot3D::text3D(
          x = x_pos,
          y = y_pos,
          z = z_pos,
          labels = mvmod$sup_col_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "#e41a1c"
        )
      } else {
        plot3D::text3D(
          x = supload_scaled[, x],
          y = supload_scaled[, y],
          z = supload_scaled[, z],
          labels = mvmod$sup_col_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "#e41a1c"
        )
      }
    }
    
  } else {
    # 2D case
    
    # Compute ranges for offset calculations
    if (has_supl) {
      x_rng <- range(c(loadings_scaled[, x], supload_scaled[, x]), na.rm = TRUE)
      y_rng <- range(c(loadings_scaled[, y], supload_scaled[, y]), na.rm = TRUE)
    } else {
      x_rng <- range(loadings_scaled[, x], na.rm = TRUE)
      y_rng <- range(loadings_scaled[, y], na.rm = TRUE)
    }
    
    # Safe offset function for 2D labels
    safe_offset_2d <- function(pos, offset_frac, limits) {
      offset <- sign(pos) * offset_frac * diff(limits)
      new_pos <- pos + offset
      margin <- 0.02 * diff(limits)
      pmax(pmin(new_pos, limits[2] - margin), limits[1] + margin)
    }
    
    # Plot scaled loadings as markers
    points(
      loadings_scaled[, x],
      loadings_scaled[, y],
      pch = if (loadmarker && !vectors)
        22
      else
        NA,
      col = "black",
      bg = if (loadmarker &&
               !vectors)
        mix_with_white("black", alpha = 0.2)
      else
        NA
    )
    
    # Plot scaled loadings as vectors
    if (vectors) {
      arrows(
        0,
        0,
        loadings_scaled[, x],
        loadings_scaled[, y],
        col = "black",
        lwd = 1,
        length = 0.1,
        angle = 20
      )
    }
    
    # Plot supplementary loadings in 2D
    if (has_supl) {
      if (vectors) {
        arrows(
          0,
          0,
          supload_scaled[, x],
          supload_scaled[, y],
          col = "#e41a1c",
          lwd = 1,
          length = 0.1,
          angle = 20
        )
      } else {
        points(
          supload_scaled[, x],
          supload_scaled[, y],
          pch = if (loadmarker)
            22
          else
            NA,
          col = "#e41a1c",
          bg = if (loadmarker)
            mix_with_white("#e41a1c", alpha = 0.2)
          else
            NA
        )
      }
    }
    
    # Add main loading labels
    if (loadlabels) {
      if (loadmarker && !vectors) {
        text(
          loadings_scaled[, x],
          loadings_scaled[, y],
          labels = var_names,
          pos = 3,
          cex = val_cex,
          offset = 0.3
        )
      } else if (vectors) {
        x_pos <- safe_offset_2d(loadings_scaled[, x], 0.03, x_rng)
        y_pos <- safe_offset_2d(loadings_scaled[, y], 0.03, y_rng)
        text(x_pos, y_pos, labels = var_names, cex = val_cex)
      } else {
        text(loadings_scaled[, x],
             loadings_scaled[, y],
             labels = var_names,
             cex = val_cex)
      }
    }
    
    # Add supplementary loading labels in 2D
    if (has_supl && loadlabels) {
      if (loadmarker && !vectors) {
        text(
          supload_scaled[, x],
          supload_scaled[, y],
          labels = mvmod$sup_col_names,
          pos = 3,
          cex = val_cex,
          col = "#e41a1c",
          offset = 0.3
        )
      } else if (vectors) {
        x_pos <- safe_offset_2d(supload_scaled[, x], 0.03, x_rng)
        y_pos <- safe_offset_2d(supload_scaled[, y], 0.03, y_rng)
        text(
          x_pos,
          y_pos,
          labels = mvmod$sup_col_names,
          cex = val_cex,
          col = "#e41a1c"
        )
      } else {
        text(
          supload_scaled[, x],
          supload_scaled[, y],
          labels = mvmod$sup_col_names,
          cex = val_cex,
          col = "#e41a1c"
        )
      }
    }
    
  }
  
  # colorbar
  if (use_cbar) {
    par(mar = c(.1, 4, 0.5, 2))
    
    rng <- pscor$rng
    pal <- pscor$pal
    
    plot.new()
    plot.window(xlim = rng, ylim = c(0, 1))
    
    pal_cbar <- mix_with_white(colorRampPalette(pal)(20), alpha = 0.7)
    xs <- seq(rng[1], rng[2], length.out = length(pal_cbar) + 1)
    
    for (i in seq_along(pal_cbar)) {
      rect(xs[i], 0.35, xs[i + 1], 0.65, col = pal_cbar[i], border = NA)
    }
    
    ticks <- pretty(rng)
    ticks <- ticks[ticks >= rng[1] & ticks <= rng[2]]
    
    par(mgp = c(1.2, 0.2, 0))
    
    axis(
      1,
      at = ticks,
      labels = ticks,
      pos = 0.35,
      cex.axis = val_cex,
      tcl = -0.3,
      lwd = 0,
      lwd.ticks = 1
    )
    
    segments(rng[1], 0.35, rng[2], 0.35, lwd = 1)
    
    text(mean(rng), 0.9, mvmod$scalecol_name, cex = val_cex)
    
  }
  
  invisible()
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.