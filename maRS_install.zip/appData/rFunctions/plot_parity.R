plot_parity <- function(mvmod,
                        cal = TRUE,
                        cv = FALSE,
                        test = FALSE,
                        rnames = FALSE,
                        colPa = "Hue",
                        val_cex = 0.7) {
  if (length(mvmod) == 1) {
    mvcal <- NULL
    mvcv <- NULL
    mvtest <- mvmod
    mvtest$y_actual <- 1:length(mvtest$y_hat)
    no_actual <- TRUE
  }
  
  else if (length(mvmod) == 2) {
    mvcal <- NULL
    mvcv <- NULL
    mvtest <- mvmod
    no_actual <- FALSE
  }
  else{
    if (cal)
      mvcal <- mvmod$mvcal
    else
      mvcal <- NULL
    if (cv)
      mvcv <- mvmod$mvcv
    else
      mvcv <- NULL
    if (test)
      mvtest <- mvmod$mvtes
    else
      mvtest <- NULL
    no_actual <- FALSE
  }
  
  # Collect data
  dat_list <- list(cal = mvcal, cv = mvcv, tes = mvtest)
  dat_list <- dat_list[!sapply(dat_list, is.null)]
  
  if (length(dat_list) == 0)
    stop("At least one dataset must be provided.")
  
  # Global limits
  all_y <- unlist(lapply(dat_list, function(d)
    c(d$y_actual, d$y_hat)))
  
  expand <- 0.08
  lim <- range(all_y, na.rm = TRUE)
  
  if (diff(lim) == 0)
    lim <- lim + c(-1, 1)
  
  lim <- lim + c(-1, 1) * expand * diff(lim)
  
  # Plot frame
  plot(
    NA,
    xlim = if (!no_actual)
      lim
    else
      c(1, length(mvtest$y_hat)),
    ylim = lim,
    las = 1,
    xlab = if (!no_actual)
      "Actual"
    else
      "Objects",
    ylab = "Predicted",
    cex.lab = val_cex,
    cex.axis = val_cex
  )
  
  # 1:1 line
  if (!no_actual)
    abline(0, 1, col = "black", lwd = 1.5)
  
  # ---------- Palette ----------
  
  pal <- make_palette(length(dat_list), colPa)
  names(pal) <- names(dat_list)
  
  styles <- lapply(pal, function(cl) {
    list(col = cl, bg = mix_with_white(cl, alpha = 0.2))
  })
  
  # ---------- Add points ----------
  
  for (nm in names(dat_list)) {
    d <- dat_list[[nm]]
    
    points(
      d$y_actual,
      d$y_hat,
      pch = 21,
      col = styles[[nm]]$col,
      bg  = styles[[nm]]$bg,
      lwd = 1.5
    )
    
    # Add the names to the points if rnames is TRUE
    if (rnames) {
      # Define the origin of the names based on the dataset (cal/cv or tes)
      if (nm %in% c("cal", "cv")) {
        point_names <- mvmod$df_train$row_names
      } else if (nm == "tes") {
        point_names <- mvmod$df_test$row_names
      } else {
        point_names <- NULL
      }
      
      # Plot the text if the names exist
      if (!is.null(point_names)) {
        text(
          x = d$y_actual,
          y = d$y_hat,
          labels = point_names,
          pos = 3,
          offset = 0.3,
          cex = val_cex - 0.1
        )
      }
    }
  }
  
  # ---------- Legend ----------
  
  if (length(mvmod) > 2) {
    leg_names <- c(cal = "Calibration", cv  = "Cross-validation", tes = "Test")
    
    legend(
      "topleft",
      legend = leg_names[names(dat_list)],
      col = sapply(styles, `[[`, "col"),
      pt.bg = sapply(styles, `[[`, "bg"),
      pch = 21,
      pt.lwd = 1.5,
      pt.cex = 1,
      cex = val_cex * 0.9,
      bty = "n"
    )
  }
  
  invisible()
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.