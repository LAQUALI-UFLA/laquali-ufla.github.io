pred_plsda <- function(plsdamod,
                       df,
                       ncomp = NULL,
                       prepro = FALSE,
                       varsel = FALSE)
{
  lev <- plsdamod$classes
  
  # Apply preprocessing using the parameters from the training model
  
  if (prepro) {
    if (varsel && !is.null(plsdamod$bestVars$vars) &&
        sum(plsdamod$bestVars$vars) > 0) {
      mx <- plsdamod$mxFull
    } else{
      mx <- plsdamod$mx
    }
    
    df <- pre_pro(df,
                  ppmet = plsdamod$ppmet,
                  sgstp = plsdamod$sgstp,
                  mx = mx)
  }
  
  # Select variables (if iPLS-DA)
  if (varsel && !is.null(plsdamod$bestVars$vars) &&
      sum(plsdamod$bestVars$vars) > 0) {
    selVar <- plsdamod$bestVars$vars
    
    df$xdat <- df$xdat[, selVar, drop = FALSE]
    
    if (!is.null(df$val_col)) {
      df$val_col <- df$val_col[selVar]
    }
    
    if (!is.null(df$mx)) {
      df$mx <- df$mx[selVar]
    }
  }
  
  Xnew <- as.matrix(df$xdat)
  
  newdata <- data.frame(X = I(Xnew))
  
  if (is.null(ncomp))
    ncomp = plsdamod$ncomp_sel
  
  yp <- predict(plsdamod, newdata = newdata, ncomp = ncomp)
  # yp: n x nclass x 1
  
  yp <- yp[, , 1, drop = FALSE]
  
  idx <- max.col(yp[, , 1], ties.method = "first")
  class_hat <- factor(lev[idx], levels = lev)
  
  # =================================================
  # If reference exists → return confusion matrix
  # =================================================
  
  if (!is.null(df$groups)) {
    class_ref <- factor(df$groups, levels = lev)
    
    if (length(class_hat) != length(class_ref))
      stop("Prediction did not return a row per sample.")
    
    cm <- table(Reference = class_ref, Predicted = class_hat)
    
    out <- list(class_hat = class_hat,
                class_ref = class_ref,
                cm        = cm)
    
  } else {
    out <- list(class_hat = class_hat)
  }
  
  return(out)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.