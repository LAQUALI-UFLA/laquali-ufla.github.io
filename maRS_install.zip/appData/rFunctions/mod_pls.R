mod_pls <- function(plscv,
                    ncomp = 1,
                    yrand = FALSE,
                    nrep = 10,
                    q_lod = 1)
{
  # ------------------------------------------------------------------
  # Initialize model object
  # ------------------------------------------------------------------
  plsmod <- plscv
  plsmod$ncomp_sel <- ncomp
  
  plsmod$yrand     <- yrand
  plsmod$nrep      <- nrep
  plsmod$q_lod     <- q_lod
  
  
  # ------------------------------------------------------------------
  # Calibration, cross-validation, and test predictions
  # ------------------------------------------------------------------
  plsmod$mvcal <- list(y_hat    = as.numeric(plsmod$fitted.values[, 1, ncomp]),
                       y_actual = plsmod$model$y)
  
  plsmod$mvcv <- list(y_hat    = as.numeric(plsmod$validation$pred[, 1, ncomp]),
                      y_actual = plsmod$model$y)
  
  if (plscv$spl_type != "None")
    plsmod$mvtes <- pred_pls(plsmod, plsmod$df_test, ncomp = ncomp)
  else
    plsmod$mvtes <- NULL
  
  plsmod$coefs <- as.numeric(coef(plsmod, ncomp = ncomp, intercept = TRUE))
  names(plsmod$coefs) <- c("b0", plsmod$col_names)
  
  # ------------------------------------------------------------------
  # Multivariate diagnostics
  # ------------------------------------------------------------------
  plsmod$mdiag <- mv_diag_pls(plsmod, ncomp = ncomp)
  
  # ------------------------------------------------------------------
  # Regression metrics
  # ------------------------------------------------------------------
  plsmod$mvcal_met <- reg_metrics(plsmod$mvcal)

  plsmod$mvcal_met["LOD"] <- mv_lod(plsmod, q = q_lod)
  plsmod$mvcv_met  <- reg_metrics(plsmod$mvcv)
  
  if (plscv$spl_type != "None")
    plsmod$mvtes_met <- reg_metrics(plsmod$mvtes)
  else
    plsmod$mvtes_met <- NULL
  
  # ------------------------------------------------------------------
  # Y-randomization (optional)
  # ------------------------------------------------------------------
  if (yrand) {
    plsmod$mvyrand <- yrand_pls(plsmod,
                                plsmod$df_train,
                                ncomp = ncomp,
                                nrep = nrep)
    
    plsmod$mvyrand_met <- reg_metrics(plsmod$mvyrand)
  }
  
  # ------------------------------------------------------------------
  # Output
  # ------------------------------------------------------------------
  return(plsmod)
}

# ============================================================
# yrand_pls
# ============================================================

yrand_pls <- function(plsmod,
                      df,
                      ncomp = 1,
                      nrep = 10)
{
  # Build fixed X/Y dataset
  dat0 <- data.frame(y = df$resp[, 1], df$xdat)
  
  # Storage como lista
  yhat_rand_list <- list()
  
  # Add the first two elements (actual y and predicted y from calibration)
  yhat_rand_list[[1]] <- as.numeric(dat0$y)
  names(yhat_rand_list)[1] <- "y_actual"
  
  yhat_rand_list[[2]] <- as.numeric(plsmod$fitted.values[, 1, ncomp])
  names(yhat_rand_list)[2] <- "y_hat_cal"
  
  for (i in 1:nrep) {
    # Y randomization
    dat <- dat0
    dat$y <- sample(dat$y)
    
    # Fit random model
    mod_rand <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp,
      scale = plsmod$scale,
      validation = "none"
    )
    
    # Calibration predictions for fixed ncomp
    yhat_rand_list[[i + 2]] <- as.numeric(drop(mod_rand$fitted.values[, 1, ncomp]))
    names(yhat_rand_list)[i + 2] <- paste0("yr", i)
  }
  
  return(yhat_rand_list)
}

# ============================================================
# pred_pls
# ============================================================

pred_pls <- function(plsmod, df, ncomp = 1)
{
  # Initialize output object as a list
  plspred <- list()
  
  # Predict using the PLS model and drop extra dimensions
  x_pred <- data.frame(df$xdat)
  plspred$y_hat <- as.numeric(predict(plsmod, x_pred, ncomp = ncomp))
  
  # get actual y values
  if (!is.null(df$resp)) {
    plspred$y_actual <- drop(df$resp[, 1])
  }
  
  return(plspred)
}

# ============================================================
# mv_diag_pls
# ============================================================

mv_diag_pls <- function(mvmod, ncomp = 1) {
  # ---------- Leverages ----------
  
  # Scores
  T <- pls::scores(mvmod)[, 1:ncomp, drop = FALSE]
  n <- nrow(T)
  A <- ncomp
  
  # Leverage
  H <- T %*% MASS::ginv(t(T) %*% T) %*% t(T)
  leverage <- diag(H)
  
  # ---------- Y residuals ----------
  yhat <- drop(mvmod$fitted.values[, 1, ncomp])
  y <- drop(mvmod$model$y)
  res <- y - yhat
  
  # ---------- Studentized residuals ----------
  resy <- sqrt((1 / (n - 1)) * sum((res^2) / (1 - leverage)^2))
  r_student <- res / (resy * sqrt(1 - leverage))
  
  # ---------- Limits ----------
  
  # Leverage limit
  h_lim <- 2 * A / n
  
  # ---------- Output ----------
  out <- list(
    leverage = leverage,
    r_student = r_student,
    residuals = res,
    y_actual = y,
    y_hat = yhat,
    row_names = mvmod$row_names,
    limits = list(leverage = h_lim)
  )
  
  return(out)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.