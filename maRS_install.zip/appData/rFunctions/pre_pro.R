pre_pro <- function(df,
                    ppmet = NULL,
                    sgstp = NULL,
                    mx = NULL) {
  # Return original data if no preprocessing method is provided
  if (is.null(ppmet)) {
    return(df)
  }
  
  # Starting point: data to be processed
  x <- df$xdat
  
  # Loop through preprocessing methods in the order defined in ppmet
  for (m in ppmet) {
    if (m == "MSC") {
      # Multiplicative Scatter Correction
      if (is.null(mx)) {
        # Use column means as reference
        mx <- colMeans(x, na.rm = TRUE)
      }
      x <- msc(x, xref = mx)
      
    } else if (m == "L2-norm") {
      # L2 normalization by row
      x <- normaliz(x)
      
    } else if (m == "Savitzky-Golay") {
      # Savitzky–Golay smoothing/differentiation
      if (is.null(sgstp) || length(sgstp) != 3) {
        # Use default sgstp c(width, order, deriv)
        sgstp = c(3, 1, 1)
      }
      x <- savgol(x,
                  width = sgstp[1],
                  order = sgstp[2],
                  deriv = sgstp[3])
      
    } else if (m == "SNV") {
      # Standard Normal Variate
      x <- snv(x)
      
    } else {
      # Handle unknown preprocessing method
      stop(paste("Unknown method:", m))
    }
  }
  
  # Final output: list with processed data and metadata inherited from df
  list(
    xdat = as.data.frame(x),
    resp = df$resp,
    row_names = df$row_names,
    groups = df$groups,
    col_classes = df$col_classes,
    val_col = df$val_col,
    mx = mx,
    sgstp = sgstp,
    ppmet = ppmet,
    split_info = df$split_info
  )
}

################################################################################

# Function: msc

msc <- function(x, xref = NULL) {
  # If xref is not provided, compute column means of x
  if (is.null(xref)) {
    xref <- colMeans(x, na.rm = TRUE)
  }
  
  # Number of rows (samples) and columns (variables)
  m <- nrow(x)
  n <- ncol(x)
  
  # Convert x to matrix for matrix operations
  x_mat <- as.matrix(x)
  
  # Build reference matrix (column of ones + reference vector)
  mz <- cbind(rep(1, n), xref)
  
  # Matrix product to generate covariance-like matrix
  z <- t(mz) %*% mz
  
  # Singular value decomposition (SVD)
  tmp <- svd(z)
  u <- tmp$u
  sd <- tmp$d
  v <- tmp$v
  
  # Numerical stability adjustment
  cn <- 1e12
  ms <- sd[1] / sqrt(cn)
  cs <- pmax(sd, ms)
  
  # Reconstruct corrected matrix
  cz <- u %*% diag(cs) %*% t(v)
  zi <- solve(cz)
  
  # Estimate correction coefficients (m x 2)
  B <- t(zi %*% t(mz) %*% t(x_mat))
  
  # Additive correction: subtract first coefficient from all columns
  x_msc <- x_mat - tcrossprod(B[, 1], rep(1, n))
  
  # Multiplicative correction: divide by second coefficient
  x_msc <- x_msc / tcrossprod(B[, 2], rep(1, n))
  
  # Convert result to data.frame and restore names
  x_msc <- as.data.frame(x_msc)
  colnames(x_msc) <- colnames(x)
  rownames(x_msc) <- rownames(x)
  
  # Return corrected data
  return(x_msc)
}

################################################################################

# Function: snv

snv <- function(x) {
  # Transpose x so scale() operates on original rows
  # scale() centers and scales each column of the transposed matrix,
  # which is equivalent to applying SNV by row on x
  x_snv <- scale(t(x))
  
  # Transpose back and convert to data.frame
  # Ensures output has the same format as input
  as.data.frame(t(x_snv))
}

################################################################################

# Function: normaliz

normaliz <- function(x) {
  # L2 normalization by row
  # Convert input to matrix for numerical operations
  x_mat <- as.matrix(x)
  
  # Replace NA or NaN values with zero
  x_mat[is.na(x_mat) | is.nan(x_mat)] <- 0
  
  # Compute L2 norm of each row (square root of sum of squares)
  normas <- sqrt(rowSums(x_mat^2))
  
  # Identify rows with zero norm to avoid division by zero
  linhas_zero <- normas == 0
  if (any(linhas_zero)) {
    warning(sum(linhas_zero),
            " row(s) with zero norm. They will be kept as zeros.")
  }
  
  # Normalize each row (only rows with norm > 0)
  x_nrm <- x_mat
  linhas_ok <- !linhas_zero
  x_nrm[linhas_ok, ] <- x_mat[linhas_ok, ] / normas[linhas_ok]
  
  # Convert result to data.frame and restore names
  x_nrm <- as.data.frame(x_nrm)
  colnames(x_nrm) <- colnames(x)
  rownames(x_nrm) <- rownames(x)
  
  # Return normalized data
  return(x_nrm)
}

################################################################################

# Savitzky–Golay smoothing and differentiation

savgol <- function(x,
                   width = 3,
                   order = 1,
                   deriv = 1) {
  
  # Save whether input is a data.frame and store names
  is_dataframe <- is.data.frame(x)
  if (is_dataframe) {
    # Store column names
    col_names <- colnames(x)
    # Convert to matrix
    x_mat <- as.matrix(x)
  } else {
    x_mat <- as.matrix(x)
    col_names <- colnames(x_mat)
  }
  
  ## Insert spdiags function
  spdiags <- function(arg1, arg2, arg3, arg4) {
    B <- arg1
    if (is.matrix(arg2))
      d <- matrix(arg2, dim(arg2)[1] * dim(arg2)[2], 1)
    else
      d <- arg2
    p <- length(d)
    A <- Matrix::sparseMatrix(
      i = 1:arg3,
      j = 1:arg3,
      x = 0,
      dims = c(arg3, arg4)
    )
    m <- dim(A)[1]
    n <- dim(A)[2]
    len <- matrix(0, p + 1, 1)
    for (k in 1:p)
      len[k + 1] <- len[k] + length(max(1, 1 - d[k]):min(m, n - d[k]))
    a <- matrix(0, len[p + 1], 3)
    for (k in 1:p) {
      i <- t(max(1, 1 - d[k]):min(m, n - d[k]))
      a[(len[k] + 1):len[k + 1], ] <- c(i, i + d[k], B[(i + (m >= n) * d[k]), k])
    }
    res1 <- Matrix::sparseMatrix(
      i = a[, 1],
      j = a[, 2],
      x = a[, 3],
      dims = c(m, n)
    )
    return(res1)
  }
  ## End spdiags function
  
  # Matrix dimensions
  m <- nrow(x_mat)
  n <- ncol(x_mat)
  
  # Validate parameters
  if (n < width) {
    warning("Width is larger than the number of columns. Adjusting...")
    width <- min(width, n)
  }
  
  w <- max(3, 1 + 2 * round((width - 1) / 2))
  o <- min(c(max(0, round(order)), 5, w - 1))
  d <- min(max(0, round(deriv)), o)
  
  # Ensure width is odd and smaller than n
  if (w %% 2 == 0) {
    w <- w + 1
  }
  if (w > n) {
    w <- ifelse(n %% 2 == 0, n - 1, n)
    warning(paste("Width adjusted to", w, "due to the number of columns"))
  }
  
  # Build Savitzky–Golay convolution matrices
  p <- (w - 1) / 2
  xc <- ((-p:p) %*% matrix(1, 1, 1 + o))^(t(matrix(1, 1, w)) %*% (0:o))
  we <- qr.solve(xc, diag(w))
  
  options(warn = -1)
  b <- apply((
    matrix(1, d, 1) %*% matrix(1:(o + 1 - d), 1, (o + 1 - d)) +
      t(matrix(0:(d - 1), 1, (d))) %*% matrix(1, 1, o + 1 - d)
  ), 2, prod)
  gg <- matrix(1, n, 1) %*% we[(d + 1), ] * b[1]
  
  di <- spdiags(gg, p:(-p), n, n)
  options(warn = 0)
  
  w1 <- diag(b, nrow = length(b)) %*% we[(d + 1):(o + 1), ]
  
  # Adjust indices to avoid dimension errors
  if (w <= n && (p + 1) <= n) {
    di[1:w, 1:(p + 1)] <- t(xc[1:(p + 1), 1:(1 + o - d)] %*% w1)
  }
  
  if ((n - w + 1) > 0 && (n - p) > 0) {
    di[(n - w + 1):n, (n - p):n] <- t(xc[(p + 1):w, 1:(1 + o - d)] %*% w1)
  }
  
  # Compute result
  di_regular <- as.matrix(di)
  result_mat <- x_mat %*% di_regular
  
  # Convert output back to original format
  if (is_dataframe) {
    if (!is.matrix(result_mat)) {
      result_mat <- as.matrix(result_mat)
    }
    x_sg <- as.data.frame(result_mat)
    colnames(x_sg) <- col_names
  } else {
    x_sg <- result_mat
    if (!is.null(col_names)) {
      colnames(x_sg) <- col_names
    }
  }
  
  return(x_sg)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.