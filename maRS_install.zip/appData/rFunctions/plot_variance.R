plot_variance <- function(mvmod,
                     ncomp = NULL,
                     val_cex = 0.7,
                     grids = FALSE) {
  # If ncomp is not provided, use min(length(mvmod$sdev), 10)
  if (is.null(ncomp)) {
    ncomp <- min(length(mvmod$sdev), 10)
  }
  
  # PC explained variance
  prop_var <- mvmod$prop_var
  prop_var_cum <- mvmod$prop_var_cum
  
  # Restrict to the selected number of components
  prop_var_cum <- prop_var_cum[1:ncomp]
  prop_var <- prop_var[1:ncomp]
  
  # Initialize empty bar plot
  
  bp <- barplot(
    prop_var,
    xlab = "PC",
    ylab = "Variance (%)",
    las = 1,
    ylim = c(0, 105),
    cex.axis = val_cex,
    cex.lab = val_cex,
    col = NA,
    border = NA
  )
  
  # Add grid lines
  if (grids) {
    grid_col = "gray90"
    grid_lty = "solid"
    grid_lwd = .5
    
    # Horizontal grid lines
    y_grid <- seq(0, 100, by = 20)
    segments(
      x0 = bp[1] - (bp[2] - bp[1]) / 2,
      y0 = y_grid,
      x1 = bp[ncomp] + (bp[2] - bp[1]) / 2,
      y1 = y_grid,
      col = grid_col,
      lty = grid_lty,
      lwd = grid_lwd
    )
    
    # Vertical grid lines
    segments(
      x0 = bp,
      y0 = 0,
      x1 = bp,
      y1 = 100,
      col = grid_col,
      lty = grid_lty,
      lwd = grid_lwd
    )
  }
  
  # Redraw bars on top of the grid
  barplot(
    prop_var,
    names.arg = 1:ncomp,
    las = 1,
    col = "gray80",
    border = "black",
    add = TRUE,
    axes = FALSE,
    cex.names = val_cex
  )
  
  # Add cumulative variance line
  lines(
    bp,
    prop_var_cum,
    type = "o",
    pch = 19,
    col = "black",
    lwd = 1
  )
  
  invisible()
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.