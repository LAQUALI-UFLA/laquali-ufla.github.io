cv_ipls <- function(df,
                    ncomp = 1,
                    nint = 10,
                    sel_mode = "forward",
                    comb_full = TRUE,
                    scale = FALSE,
                    spl_type = "KS",
                    pro_test = 25,
                    cv = "LOO",
                    folds = 5)
{
  # ============================================================
  # Dataset split (external train/test)
  # ============================================================
  
  df_spt <- split_dataset(df, spl_type = spl_type, pro_test = pro_test)
  
  df_train <- df_spt$df_train
  
  # ============================================================
  # Build modeling data.frame
  # ============================================================
  
  X <- df_train$xdat
  y <- df_train$resp[, 1]
  
  dat <- data.frame(y = y, X)
  
  # Limit the maximum number of components
  ncomp <- min(ncomp, nrow(X) - 1, ncol(X))
  
  # ============================================================
  # iPLS
  # ============================================================
  
  # LV selection
  localMin <- function(press, ncomp) {
    r <- press[, 2:ncomp] - press[, 1:(ncomp - 1)]
    w <- which(r > 0)
    if (length(w) == 0)
      return(ncomp)
    return(w[1])
  }
  
  # Get metrics
  get_metrics <- function(Xm) {
    
    if (ncol(Xm) == 0) {
      return(list(lv = 1, rmse = Inf, r2 = 0))
    }
    
    datm <- data.frame(y = y, Xm)
    
    if (cv == "LOO") {
      train_size <- nrow(Xm) - 1
    } else {
          train_size <- nrow(Xm) - ceiling(nrow(Xm) / folds)
    }
    
    ncomp_safe <- min(ncomp, ncol(Xm), train_size - 1)
    ncomp_safe <- max(1, ncomp_safe)
    
    if (cv == "LOO") {
      mod <- pls::plsr(
        y ~ .,
        data = datm,
        ncomp = ncomp_safe,
        scale = scale,
        validation = "LOO"
      )
    } else if (cv == "VB") {
      mod <- pls::plsr(
        y ~ .,
        data = datm,
        ncomp = ncomp_safe,
        scale = scale,
        validation = "CV",
        segments = folds,
        segment.type = "interleaved"
      )
    } else {
      mod <- pls::plsr(
        y ~ .,
        data = datm,
        ncomp = ncomp_safe,
        scale = scale,
        validation = "CV",
        segments = folds,
        segment.type = "random"
      )
    }
    
    press <- mod$validation$PRESS
    rmsecv <- sqrt(press[1, 1:ncomp_safe] / nrow(Xm))
    
    lv <- detect_optimal_comp(rmsecv)
    rmse <- rmsecv[lv]
    
    tss <- sum((y - mean(y))^2)
    r2 <- 1 - press[1, lv] / tss
    
    return(list(lv = lv, rmse = rmse, r2 = r2))
  }
  
  # Define intrevals
  p <- ncol(X)
  int_size <- floor(p / nint)
  
  intervals <- lapply(1:nint, function(i) {
    start <- (i - 1) * int_size + 1
    end <- if (i == nint)
      p
    else
      i * int_size
    start:end
  })
  
  # Global metrics
  glob <- get_metrics(X)
  
  # Metrics for individual intervals (1st iteration)
  int1_lv   <- numeric(nint)
  int1_rmse <- numeric(nint)
  int1_r2   <- numeric(nint)
  
  int1_ini <- numeric(nint)
  int1_end <- numeric(nint)
  
  for (l in 1:nint) {
    vars <- intervals[[l]]
    
    Xm <- X[, vars, drop = FALSE]
    met <- get_metrics(Xm)
    
    int1_lv[l]   <- met$lv
    int1_rmse[l] <- met$rmse
    int1_r2[l]   <- met$r2
    
    int1_ini[l] <- min(vars)
    int1_end[l] <- max(vars)
  }
  
  # iPLS selection
  intMet <- list()
  
  if (sel_mode == "forward") {
    selected <- c()
    remaining <- 1:nint
    rmse_global <- Inf
    
    for (iter in 1:min(nint, 30)) {
      best_rmse <- Inf
      best_int <- NULL
      best_metrics <- NULL
      
      for (l in remaining) {
        vars <- c(unlist(intervals[selected]), intervals[[l]])
        Xm <- X[, vars, drop = FALSE]
        
        met <- get_metrics(Xm)
        
        if (met$rmse < best_rmse) {
          best_rmse <- met$rmse
          best_int <- l
          best_metrics <- met
        }
      }
      
      if (!comb_full && best_rmse > rmse_global)
        break
      
      rmse_global <- best_rmse
      selected <- c(selected, best_int)
      remaining <- setdiff(remaining, best_int)
      
      intMet[[length(selected)]] <- list(
        int = best_int,
        lv = best_metrics$lv,
        rmse = best_metrics$rmse,
        r2 = best_metrics$r2
      )
    }
    
    if (comb_full && length(intMet) > 0) {
      rmses <- sapply(intMet, function(x)
        x$rmse)
      best_iter <- which.min(rmses)
      selected <- selected[1:best_iter]
    }
    
    rmses <- sapply(intMet, function(x)
      x$rmse)
    best_iter <- which.min(rmses)
    best_ints <- sapply(intMet[1:best_iter], function(x)
      x$int)
    best_vars <- unlist(intervals[best_ints])
    
  } else if (sel_mode == "backward") {
    selected <- 1:nint
    rmse_global <- Inf
    
    for (iter in 1:min(nint, 30)) {
      
      if (length(selected) <= 1) {
        break
      }
      
      best_rmse <- Inf
      worst_int <- NULL
      best_metrics <- NULL
      
      for (l in selected) {
        keep <- setdiff(selected, l)
        vars <- unlist(intervals[keep])
        Xm <- X[, vars, drop = FALSE]
        
        met <- get_metrics(Xm)
        
        if (met$rmse < best_rmse) {
          best_rmse <- met$rmse
          worst_int <- l
          best_metrics <- met
        }
      }
      
      if (!comb_full && best_rmse > rmse_global)
        break
      
      rmse_global <- best_rmse
      selected <- setdiff(selected, worst_int)
      
      intMet[[length(intMet) + 1]] <- list(
        int = worst_int,
        lv = best_metrics$lv,
        rmse = best_metrics$rmse,
        r2 = best_metrics$r2
      )
    }
    
    if (comb_full && length(intMet) > 0) {
      rmses <- sapply(intMet, function(x)
        x$rmse)
      best_iter <- which.min(rmses)
      
      removed <- sapply(intMet[1:best_iter], function(x)
        x$int)
      selected <- setdiff(1:nint, removed)
    }
    
    rmses <- sapply(intMet, function(x)
      x$rmse)
    best_iter <- which.min(rmses)
    removed <- sapply(intMet[1:best_iter], function(x)
      x$int)
    best_ints <- setdiff(1:nint, removed)
    best_vars <- unlist(intervals[best_ints])
  }
  
  # Selected variables
  selVar <- sort(unlist(intervals[selected]))
  
  # New dat with selected variables
  dat <- data.frame(y = y, X[, selVar, drop = FALSE])
  
  # ============================================================
  # PLS CV with selected variables
  # ============================================================
  
  if (cv == "LOO") {
    train_size_final <- nrow(dat) - 1
  } else {
    train_size_final <- nrow(dat) - ceiling(nrow(dat) / folds)
  }
  
  ncomp_final <- min(ncomp, length(selVar), train_size_final - 1)
  ncomp_final <- max(1, ncomp_final)
  
  if (cv == "LOO") {
    iplscv <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp_final,
      scale = scale,
      validation = "LOO"
    )
    
  } else if (cv == "VB") {
    iplscv <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp_final,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "interleaved"
    )
    
  } else if (cv == "RND") {
    iplscv <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp_final,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "random"
    )
    
  } else {
    iplscv <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp_final,
      scale = scale,
      validation = "LOO"
    )
  }
  
  # Detect optimal ncomp
  press <- iplscv$validation$PRESS
  rmsecv <- sqrt(press[1, 1:ncomp_final] / nrow(dat))
  iplscv$opt_ncomp <- as.numeric(detect_optimal_comp(rmsecv))
  
  # ============================================================
  # Store metadata
  # ============================================================
  
  iplscv$xvals     <- df$val_col
  iplscv$Xmean     <- colMeans(df$xdat)
  iplscv$row_names <- df_train$row_names
  iplscv$groups    <- df_train$groups
  iplscv$val_col   <- df_train$val_col
  iplscv$y_name    <- colnames(df_train$resp)
  iplscv$col_names <- colnames(df_train$xdat)
  
  iplscv$sgstp <- df_train$sgstp
  iplscv$ppmet <- df_train$ppmet
  iplscv$mx    <- df_train$mx
  
  iplscv$prop_var <- pls::explvar(iplscv)
  
  iplscv$spl_type  <- spl_type
  iplscv$pro_test  <- pro_test
  iplscv$cv        <- cv
  iplscv$folds     <- folds
  iplscv$nint      <- nint
  iplscv$sel_mode  <- sel_mode
  iplscv$comb_full <- comb_full
  
  iplscv$df_train <- df_train
  iplscv$df_test  <- df_spt$df_test
  
  iplscv$model_type <- "iPLS"
  
  # iPLS information
  
  iplscv$intMet <- intMet
  
  iplscv$intMet_ind <- data.frame(
    int  = 1:nint,
    ini  = int1_ini,
    end  = int1_end,
    lv   = int1_lv,
    rmse = int1_rmse,
    r2   = int1_r2
  )
  
  iplscv$bestVars <- list(
    ints = sort(best_ints),
    vars = best_vars,
    lv   = as.numeric(intMet[[best_iter]]$lv),
    rmse = as.numeric(intMet[[best_iter]]$rmse),
    r2   = as.numeric(intMet[[best_iter]]$r2)
  )
  
  iplscv$globMet <- list(lv = glob$lv,
                         rmse = glob$rmse,
                         r2 = glob$r2)
  
  # Update columns
  iplscv$col_names <- colnames(df_train$xdat)[selVar]
  
  if (!is.null(iplscv$val_col)) {
    iplscv$val_col <- iplscv$val_col[selVar]
  }
  
  if (!is.null(iplscv$mx)) {
    iplscv$mxFull <- iplscv$mx
    iplscv$mx     <- iplscv$mx[selVar]
  }
  
  # Update df_train
  
  iplscv$df_train$xdat <- df_train$xdat[, selVar, drop = FALSE]
  
  if (!is.null(df_train$val_col)) {
    iplscv$df_train$val_col <- df_train$val_col[selVar]
  }
  
  if (!is.null(df_train$mx)) {
    iplscv$df_train$mx <- df_train$mx[selVar]
  }
  
  # Update df_test
  
  if (!is.null(df_spt$df_test)) {
    iplscv$df_test$xdat <- df_spt$df_test$xdat[, selVar, drop = FALSE]
    
    if (!is.null(df_spt$df_test$val_col)) {
      iplscv$df_test$val_col <- df_spt$df_test$val_col[selVar]
    }
    
    if (!is.null(df_spt$df_test$mx)) {
      iplscv$df_test$mx <- df_spt$df_test$mx[selVar]
    }
  }
  
  # ============================================================
  # Output
  # ============================================================
  
  return(iplscv)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.