mod_mlrda <- function(df,
                    center = FALSE,
                    scale = FALSE,
                    spl_type = "KS",
                    pro_test = 25,
                    cv = "LOO",
                    folds = 5,
                    yrand = FALSE,
                    nrep = 10,
                    q_lod = 0)
{
  # ============================================================
  # Dataset split (balanced per class)
  # ============================================================
  
  classes <- levels(factor(df$groups))
  
  train_list <- list()
  test_list  <- list()
  
  for (cl in classes) {
    idx <- which(df$groups == cl)
    
    df_cl <- df
    df_cl$xdat   <- df$xdat[idx, , drop = FALSE]
    df_cl$groups <- df$groups[idx]
    
    if (!is.null(df$row_names))
      df_cl$row_names <- df$row_names[idx]
    
    if (!is.null(df$split_info)) {
      df_cl$split_info <- df$split_info[idx]
    }
    
    df_spt_cl <- split_dataset(df_cl, spl_type  = spl_type, pro_test  = pro_test)
    
    train_list[[cl]] <- df_spt_cl$df_train
    test_list[[cl]]  <- df_spt_cl$df_test
  }
  
  df_train <- rbind_df(train_list)
  df_test  <- rbind_df(test_list)
  
  # ============================================================
  # Dummy
  # ============================================================
  
  df_train$groups <- factor(df_train$groups, levels = classes)
  
  Y_dummy <- model.matrix( ~ groups - 1, data = data.frame(groups = df_train$groups))
  
  colnames(Y_dummy) <- gsub("groups", "", colnames(Y_dummy))
  
  X <- as.matrix(df_train$xdat)
  Y <- as.matrix(Y_dummy)
  
  n <- nrow(X)
  p <- ncol(X)
  K <- ncol(Y)
  
  # ============================================================
  # Center / scale
  # ============================================================
  if (scale)
    center <- TRUE
  
  Xmeans <- rep(0, p)
  Xscale <- rep(1, p)
  
  if (center) {
    Xmeans <- colMeans(X)
    X <- sweep(X, 2, Xmeans, "-")
  }
  
  if (scale) {
    Xscale <- apply(X, 2, sd)
    Xscale[Xscale == 0] <- 1
    X <- sweep(X, 2, Xscale, "/")
  }
  
  # ============================================================
  # MLR-DA calibration
  # ============================================================
  
  Xd <- cbind(1, X)
  B <- MASS::ginv(t(Xd) %*% Xd) %*% t(Xd) %*% Y   # (p+1) x K
  
  B0 <- B[1, , drop = FALSE]
  BX <- B[-1, , drop = FALSE]
  
  Yhat <- Xd %*% B
  
  # ----- class prediction -----
  lev <- colnames(Y_dummy)
  
  idx <- max.col(Yhat)
  class_hat <- factor(lev[idx], levels = lev)
  
  # ============================================================
  # Cross-validation
  # ============================================================
  
  if (tolower(cv) != "none") {
    if (cv == "LOO") {
      segments <- pls::cvsegments(n, k = n)
    } else if (cv == "RND") {
      segments <- pls::cvsegments(n, k = folds, type = "random")
    }
    
    Yhat_cv <- matrix(NA, n, K)
    
    for (seg in segments) {
      tr <- setdiff(seq_len(n), seg)
      
      Xtr <- X[tr, , drop = FALSE]
      Ytr <- Y[tr, , drop = FALSE]
      Xte <- X[seg, , drop = FALSE]
      
      Xd_tr <- cbind(1, Xtr)
      B_tr <- MASS::ginv(t(Xd_tr) %*% Xd_tr) %*% t(Xd_tr) %*% Ytr
      
      Xd_te <- cbind(1, Xte)
      
      Yhat_cv[seg, ] <- Xd_te %*% B_tr
    }
    
    idx_cv <- max.col(Yhat_cv)
    class_cv <- factor(lev[idx_cv], levels = lev)
    
  } else {
    class_cv <- NULL
    Yhat_cv  <- NULL
  }
  
  # ============================================================
  # External test prediction
  # ============================================================
  
  if (!is.null(df_test) && nrow(df_test$xdat) > 0) {

    Xtest <- as.matrix(df_test$xdat)
    
    if (center)
      Xtest <- sweep(Xtest, 2, Xmeans, "-")
    
    if (scale)
      Xtest <- sweep(Xtest, 2, Xscale, "/")
    
    Ytest_hat <- cbind(1, Xtest) %*% B
    idx_test  <- max.col(Ytest_hat)
    
    class_test <- factor(lev[idx_test], levels = lev)
    class_ref_test <- factor(df_test$groups, levels = lev)
    
  } else {
    class_test <- NULL
    class_ref_test <- NULL
  }
  
  # ============================================================
  # Build output
  # ============================================================
  
  mlrdamod <- list()
  
  class(mlrdamod) <- "mlrdamod"
  
  mlrdamod$classes <- lev
  mlrdamod$model_type <- "MLR-DA"
  
  mlrdamod$coefficients <- BX
  mlrdamod$b0 <- B0
  
  mlrdamod$Xmeans <- if (center)
    Xmeans
  else
    NULL
  mlrdamod$scale  <- if (scale)
    Xscale
  else
    NULL
  
  mlrdamod$row_names <- df_train$row_names
  mlrdamod$groups <- df_train$groups
  mlrdamod$col_names <- colnames(df_train$xdat)
  
  # ============================================================
  # Calibration results
  # ============================================================
  
  cal_ref <- factor(df_train$groups, levels = lev)
  
  mlrdamod$mvcal <- list(class_hat = class_hat, class_ref = cal_ref)
  
  mlrdamod$cmCal <- table(Reference = cal_ref, Predicted = class_hat)
  
  mlrdamod$cal_metrics <- cla_metrics(mlrdamod$cmCal)
  
  # ============================================================
  # CV results
  # ============================================================
  
  if (!is.null(class_cv)) {
    mlrdamod$mvcv <- list(class_hat = class_cv, class_ref = cal_ref)
    
    mlrdamod$cmCV <- table(Reference = cal_ref, Predicted = class_cv)
    
    mlrdamod$cv_metrics <- cla_metrics(mlrdamod$cmCV)
    
  }
  
  # ============================================================
  # Y-randomization
  # ============================================================
  
  if (yrand) {
    # Obtain Y-randomization predictions
    yrand_list <- yrand_mlrda(mlrdamod, df_train, nrep = nrep)
    
    classes <- levels(df_train$groups)
    K <- length(classes)
    
    # Initialize accumulators
    per_class_acc <- matrix(0, nrow = K, ncol = 11)
    rownames(per_class_acc) <- classes
    colnames(per_class_acc) <- c("TP",
                                 "TN",
                                 "FP",
                                 "FN",
                                 "PRE",
                                 "SPE",
                                 "SEL",
                                 "ACU",
                                 "EFI",
                                 "F1S",
                                 "MCC")
    
    global_acc <- rep(0, 11)
    names(global_acc) <- c("TP",
                           "TN",
                           "FP",
                           "FN",
                           "PRE",
                           "SPE",
                           "SEL",
                           "ACU",
                           "EFI",
                           "F1S",
                           "MCC")
    
    cm_acc <- matrix(0, nrow = K, ncol = K)
    rownames(cm_acc) <- classes
    colnames(cm_acc) <- classes
    
    # Loop through all randomizations
    for (i in 3:(nrep + 2)) {
      yhat <- yrand_list[[i]]
      cm <- table(factor(df_train$groups, levels = classes),
                  factor(yhat, levels = classes))
      
      met <- cla_metrics(cm)
      
      per_class_acc <- per_class_acc + met$per_class
      global_acc    <- global_acc + met$global
      cm_acc        <- cm_acc + cm
    }
    
    # Average
    per_class_mean <- per_class_acc / nrep
    global_mean    <- global_acc / nrep
    cm_mean        <- cm_acc / nrep
    
    # Save to object
    mlrdamod$mvyrand <- yrand_list
    
    mlrdamod$cmYrand <- round(cm_mean)
    dimnames(mlrdamod$cmYrand) <- list(Reference = rownames(cm_mean),
                                     Predicted = colnames(cm_mean))
    
    mlrdamod$yrand_metrics <- list(per_class = per_class_mean,
                                 global    = global_mean,
                                 confusion = cm_mean)
    
  }
  
  # ============================================================
  # Test results
  # ============================================================
  
  if (!is.null(class_test)) {
    mlrdamod$mvtest <- list(class_hat = class_test, class_ref = class_ref_test)
    
    mlrdamod$cmTest <- table(Reference = class_ref_test, Predicted = class_test)
    
    mlrdamod$test_metrics <- cla_metrics(mlrdamod$cmTest)
  }
  
  # ============================================================
  # Diagnostics (leverage)
  # ============================================================
  
  Xd_full <- cbind(1, X)
  H <- Xd_full %*% MASS::ginv(t(Xd_full) %*% Xd_full) %*% t(Xd_full)
  
  mlrdamod$mdiag <- list(
    leverage = diag(H),
    limits   = list(leverage = 2 * (p + 1) / n),
    row_names = df_train$row_names
  )
  
  # ============================================================
  # Metadata
  # ============================================================
  mlrdamod$row_names <- df_train$row_names
  mlrdamod$groups    <- df_train$groups
  mlrdamod$val_col   <- df$val_col
  mlrdamod$y_name    <- df$col_classes
  mlrdamod$col_names <- colnames(df_train$xdat)
  mlrdamod$xvals     <- df$val_col
  
  mlrdamod$sgstp <- df_train$sgstp
  mlrdamod$ppmet <- df_train$ppmet
  mlrdamod$mx    <- df_train$mx
  
  mlrdamod$spl_type  <- spl_type
  mlrdamod$pro_test  <- pro_test
  mlrdamod$cv        <- cv
  mlrdamod$folds     <- folds
  mlrdamod$yrand     <- yrand
  mlrdamod$nrep      <- nrep
  
  mlrdamod$df_train <- df_train
  mlrdamod$df_test  <- df_test
  
  mlrdamod$model_type <- "MLR-DA"
  
  mlrdamod$coefs <- rbind(mlrdamod$b0, mlrdamod$coefficients)
  rownames(mlrdamod$coefs) <- c("b0", mlrdamod$col_names)
  
  return(mlrdamod)
}

# ============================================================
# y-randomization
# ============================================================

yrand_mlrda <- function(mlrdamod, df_train, nrep = 10) {
  stopifnot(!is.null(df_train$xdat), !is.null(df_train$groups))
  
  # ---------- X matrix ----------
  X <- as.matrix(df_train$xdat)
  n <- nrow(X)
  p <- ncol(X)
  
  # ---------- Centering / Scaling ----------
  if (!is.null(mlrdamod$Xmeans))
    X <- sweep(X, 2, mlrdamod$Xmeans, "-")
  if (!is.null(mlrdamod$scale))
    X <- sweep(X, 2, mlrdamod$scale, "/")
  
  # ---------- Dummy matrix original ----------
  Y_dummy <- model.matrix(~ groups - 1, data = data.frame(groups = df_train$groups))
  colnames(Y_dummy) <- gsub("groups", "", colnames(Y_dummy))
  K <- ncol(Y_dummy)
  
  # ---------- Design matrix ----------
  Xd <- cbind(1, X)  # n x (p+1)
  
  # ---------- List of results ----------
  yhat_rand_list <- vector("list", nrep + 2)
  
  # --- y real (original classes) ---
  yhat_rand_list[[1]] <- df_train$groups
  names(yhat_rand_list)[1] <- "y_actual"
  
  # --- and calibration of the true model ---
  B_full <- rbind(mlrdamod$b0, mlrdamod$coefficients) 
  Yhat_cal <- Xd %*% B_full
  idx_cal <- max.col(Yhat_cal)
  yhat_rand_list[[2]] <- factor(colnames(Y_dummy)[idx_cal], levels = colnames(Y_dummy))
  names(yhat_rand_list)[2] <- "y_hat_cal"
  
  # ---------- Y-randomization ----------
  for (i in seq_len(nrep)) {
    # Shuffle the rows of the dummy matrix
    Yrand <- Y_dummy[sample(n), , drop = FALSE]
    
    # Recalculates MLR-DA coefficients with shuffled Y
    B_rand <- MASS::ginv(t(Xd) %*% Xd) %*% t(Xd) %*% Yrand
    
    # Prediction
    Yhat_rand <- Xd %*% B_rand
    idx_rand <- max.col(Yhat_rand)
    
    yhat_rand_list[[i + 2]] <- factor(colnames(Y_dummy)[idx_rand], levels = colnames(Y_dummy))
    names(yhat_rand_list)[i + 2] <- paste0("yr", i)
  }
  
  return(yhat_rand_list)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.