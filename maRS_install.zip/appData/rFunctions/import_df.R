import_df <- function(df,
                      headers = TRUE,
                      col_names = NULL,
                      col_classes = NULL,
                      col_resp = NULL,
                      col_split = NULL) {
  # Assign default column names if headers are not provided
  if (!headers) {
    names(df) <- as.character(seq_len(ncol(df)))
  }
  
  # Extract row names from a specified column
  if (!is.null(col_names) && col_names %in% names(df)) {
    row_names <- as.character(df[[col_names]])
    df <- df[, setdiff(names(df), col_names), drop = FALSE]
  } else {
    row_names <- as.character(seq_len(nrow(df)))
  }
  
  # Extract group labels from a specified column
  if (!is.null(col_classes) && col_classes %in% names(df)) {
    groups <- as.character(df[[col_classes]])
    df <- df[, setdiff(names(df), col_classes), drop = FALSE]
  } else {
    groups <- NULL
  }
  
  # Extract split labels from a specified column
  if (!is.null(col_split) && col_split %in% names(df)) {
    split_info <- as.character(df[[col_split]])
    df <- df[, setdiff(names(df), col_split), drop = FALSE]
  } else {
    split_info <- NULL
  }
  
  # Extract response values from a specified column
  if (!is.null(col_resp) && col_resp %in% names(df)) {
    resp <- as.data.frame(as.numeric(df[[col_resp]]))
    colnames(resp) <- col_resp
    df <- df[, setdiff(names(df), col_resp), drop = FALSE]
  } else {
    resp <- NULL
  }
  
  # Generate numeric variable labels from column names
  suppressWarnings({
    val_col <- as.numeric(names(df))
  })
  if (any(is.na(val_col))) {
    val_col <- seq_len(ncol(df))
  }
  
  # Return standardized data structure
  list(
    xdat = as.data.frame(df),# x_train
    resp = resp,# y_train
    row_names = row_names,# row_names_train
    groups = groups,# groups_train
    col_classes = col_classes,
    val_col = val_col,
    mx = NULL,
    sgstp = NULL,
    ppmet = NULL,
    split_info = split_info
  )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.