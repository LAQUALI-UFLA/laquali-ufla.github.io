cv_iplsda <- function(df,
                      ncomp = 1,
                      nint = 10,
                      sel_mode = "forward",
                      comb_full = TRUE,
                      scale = FALSE,
                      spl_type = "KS",
                      pro_test = 25,
                      cv = "LOO",
                      folds = 5)
{
  # ============================================================
  # Dataset split (balanced per class)
  # ============================================================
  
  classes <- levels(factor(df$groups))
  
  train_list <- list()
  test_list  <- list()
  
  for (cl in classes) {
    idx <- which(df$groups == cl)
    
    df_cl <- df
    df_cl$xdat   <- df$xdat[idx, , drop = FALSE]
    df_cl$groups <- df$groups[idx]
    
    if (!is.null(df$row_names)) {
      df_cl$row_names <- df$row_names[idx]
    }
    
    if (!is.null(df$split_info)) {
      df_cl$split_info <- df$split_info[idx]
    }
    
    df_spt_cl <- split_dataset(df_cl, spl_type = spl_type, pro_test = pro_test)
    
    train_list[[cl]] <- df_spt_cl$df_train
    test_list[[cl]]  <- df_spt_cl$df_test
  }
  
  df_train <- rbind_df(train_list)
  df_test  <- rbind_df(test_list)
  
  # ============================================================
  # Dummy Y
  # ============================================================
  
  if (length(unique(df_train$groups)) < 2)
    stop("PLS-DA requires at least two classes.")
  
  df_train$groups <- factor(df_train$groups, levels = classes)
  Y_dummy <- model.matrix( ~ groups - 1, data = data.frame(groups = df_train$groups))
  colnames(Y_dummy) <- gsub("groups", "", colnames(Y_dummy))
  
  X <- as.matrix(df_train$xdat)
  Y <- as.matrix(Y_dummy)
  
  ncomp <- min(ncomp, nrow(X) - 1, ncol(X))
  
  # ============================================================
  # iPLS - evaluation function (ACU CV)
  # ============================================================
  
  get_acu <- function(Xm) {
    if (ncol(Xm) == 0) {
      return(list(lv = 1, acu = 0))
    }
    
    if (cv == "LOO") {
      train_size <- nrow(Xm) - 1
    } else {
      train_size <- nrow(Xm) - ceiling(nrow(Xm) / folds)
    }
    
    ncomp_safe <- min(ncomp, ncol(Xm), train_size - 1)
    ncomp_safe <- max(1, ncomp_safe)
    
    if (cv == "LOO") {
      mod <- pls::plsr(Y ~ Xm,
                       ncomp = ncomp_safe,
                       scale = scale,
                       validation = "LOO")
    } else if (cv == "RND") {
      mod <- pls::plsr(
        Y ~ Xm,
        ncomp = ncomp_safe,
        scale = scale,
        validation = "CV",
        segments = folds,
        segment.type = "random"
      )
    }
    
    pv <- mod$validation$pred
    lev <- colnames(Y_dummy)
    y_ref <- factor(df_train$groups, levels = lev)
    
    A <- dim(pv)[3]
    acu <- numeric(A)
    
    for (a in 1:A) {
      idx <- max.col(pv[, , a], ties.method = "first")
      y_hat <- factor(lev[idx], levels = lev)
      cm <- table(y_ref, y_hat)
      acu[a] <- cla_metrics(cm)$global["ACU"]
    }
    
    lv <- detect_optimal_comp(1 - acu + 1)
    
    list(lv = lv, acu = acu[lv])
  }
  
  # ============================================================
  # INTERVALS
  # ============================================================
  
  p <- ncol(X)
  int_size <- floor(p / nint)
  
  intervals <- lapply(1:nint, function(i) {
    ini <- (i - 1) * int_size + 1
    fim <- if (i == nint)
      p
    else
      i * int_size
    ini:fim
  })
  
  # --- Global metrics (all variables)
  glob <- get_acu(X)
  
  # --- Metrics by individual interval (1st iteration)
  int1_lv   <- numeric(nint)
  int1_acu  <- numeric(nint)
  int1_ini  <- numeric(nint)
  int1_end  <- numeric(nint)
  
  for (l in 1:nint) {
    vars <- intervals[[l]]
    
    met <- get_acu(X[, vars, drop = FALSE])
    
    int1_lv[l]  <- met$lv
    int1_acu[l] <- met$acu
    
    int1_ini[l] <- min(vars)
    int1_end[l] <- max(vars)
  }
  
  # ============================================================
  # iPLS selection
  # ============================================================
  
  intMet <- list()
  
  if (sel_mode == "forward") {
    selected <- c()
    remaining <- 1:nint
    best_global <- -Inf
    
    for (iter in 1:nint) {
      best_acu <- -Inf
      
      for (l in remaining) {
        vars <- c(unlist(intervals[selected]), intervals[[l]])
        met <- get_acu(X[, vars, drop = FALSE])
        
        if (met$acu > best_acu) {
          best_acu <- met$acu
          best_int <- l
          best_met <- met
        }
      }
      
      if (!comb_full && best_acu < best_global)
        break
      
      best_global <- best_acu
      selected <- c(selected, best_int)
      remaining <- setdiff(remaining, best_int)
      
      intMet[[length(selected)]] <- list(int = best_int,
                                         lv  = best_met$lv,
                                         acu = best_met$acu)
    }
    
    acus <- sapply(intMet, \(x) x$acu)
    best_iter <- which.max(acus)
    best_ints <- sapply(intMet[1:best_iter], \(x) x$int)
    
  } else {
    selected <- 1:nint
    best_global <- -Inf
    
    for (iter in 1:nint) {
      if (length(selected) <= 1) {
        break
      }
      
      best_acu <- -Inf
      
      for (l in selected) {
        keep <- setdiff(selected, l)
        vars <- unlist(intervals[keep])
        met <- get_acu(X[, vars, drop = FALSE])
        
        if (met$acu > best_acu) {
          best_acu <- met$acu
          worst_int <- l
          best_met <- met
        }
      }
      
      if (!comb_full && best_acu < best_global)
        break
      
      best_global <- best_acu
      selected <- setdiff(selected, worst_int)
      
      intMet[[length(intMet) + 1]] <- list(int = worst_int,
                                           lv  = best_met$lv,
                                           acu = best_met$acu)
    }
    
    acus <- sapply(intMet, \(x) x$acu)
    best_iter <- which.max(acus)
    removed <- sapply(intMet[1:best_iter], \(x) x$int)
    best_ints <- setdiff(1:nint, removed)
  }
  
  # Selected variables
  selVar <- sort(unlist(intervals[best_ints]))
  
  # ============================================================
  # Final model
  # ============================================================
  
  X <- X[, selVar, drop = FALSE]
  
  if (cv == "LOO") {
    train_size_final <- nrow(X) - 1
  } else {
    train_size_final <- nrow(X) - ceiling(nrow(X) / folds)
  }
  ncomp_final <- min(ncomp, length(selVar), train_size_final - 1)
  ncomp_final <- max(1, ncomp_final)
  
  if (cv == "LOO") {
    iplsdacv <- pls::plsr(Y ~ X,
                          ncomp = ncomp_final,
                          scale = scale,
                          validation = "LOO")
  } else if (cv == "RND") {
    iplsdacv <- pls::plsr(
      Y ~ X,
      ncomp = ncomp_final,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "random"
    )
  }
  
  # ============================================================
  # Storage
  # ============================================================
  
  fv <- iplsdacv$fitted.values
  n  <- dim(fv)[1]
  A  <- dim(fv)[3]
  lev <- colnames(Y_dummy)
  
  rn <- rownames(fv)
  if (is.null(rn))
    rn <- seq_len(n)
  
  class_hat <- array(NA, c(n, 1, A), dimnames = list(rn, "class", paste0("Comp_", 1:A)))
  
  for (a in 1:A) {
    idx <- max.col(fv[, , a], ties.method = "first")
    class_hat[, 1, a] <- lev[idx]
  }
  
  iplsdacv$class.fitted.values <- class_hat
  
  # CV
  pv <- iplsdacv$validation$pred
  class_cv <- array(NA, c(n, 1, A), dimnames = list(rn, "class", paste0("Comp_", 1:A)))
  
  for (a in 1:A) {
    idx <- max.col(pv[, , a], ties.method = "first")
    class_cv[, 1, a] <- lev[idx]
  }
  
  iplsdacv$validation$class.fitted.values <- class_cv
  
  # ============================================================
  # METRICS
  # ============================================================
  
  y_ref <- factor(df_train$groups, levels = lev)
  
  metrics <- c("PRE", "SPE", "SEN", "ACU", "EFI", "F1S", "MCC")
  
  cal_metrics <- lapply(metrics, \(x) numeric(A))
  cv_metrics  <- lapply(metrics, \(x) numeric(A))
  names(cal_metrics) <- names(cv_metrics) <- metrics
  
  for (a in 1:A) {
    cm_cal <- table(y_ref, factor(class_hat[, 1, a], levels = lev))
    cm_cv  <- table(y_ref, factor(class_cv[, 1, a], levels = lev))
    
    mc_cal <- cla_metrics(cm_cal)$global
    mc_cv  <- cla_metrics(cm_cv)$global
    
    for (m in metrics) {
      cal_metrics[[m]][a] <- mc_cal[m]
      cv_metrics[[m]][a]  <- mc_cv[m]
    }
  }
  
  iplsdacv$cal_metrics <- cal_metrics
  iplsdacv$cv_metrics  <- cv_metrics
  
  # Detect optimal ncomp
  acu <- iplsdacv$cv_metrics$ACU
  iplsdacv$opt_ncomp <- as.numeric(detect_optimal_comp(1 - acu + 1))
  
  # ============================================================
  # TEST
  # ============================================================
  
  if (pro_test > 0 && nrow(df_test$xdat) > 0) {
    X_test <- as.matrix(df_test$xdat[, selVar, drop = FALSE])
    pred_test <- predict(iplsdacv, X_test, ncomp = seq_len(ncomp_final))
    
    A <- ncomp_final
    lev <- colnames(Y_dummy)
    
    class_test <- array(NA, c(nrow(X_test), 1, A))
    
    for (a in 1:A) {
      idx <- max.col(pred_test[, , a], ties.method = "first")
      class_test[, 1, a] <- lev[idx]
    }
    
    y_test <- factor(df_test$groups, levels = lev)
    
    test_metrics <- lapply(metrics, \(x) numeric(A))
    names(test_metrics) <- metrics
    
    for (a in 1:A) {
      cm <- table(y_test, factor(class_test[, 1, a], levels = lev))
      mc <- cla_metrics(cm)$global
      
      for (m in metrics) {
        test_metrics[[m]][a] <- mc[m]
      }
    }
    
    iplsdacv$test_metrics <- test_metrics
  }
  
  # ============================================================
  # METADATA
  # ============================================================
  
  iplsdacv$xvals     <- df$val_col
  iplsdacv$Xmean     <- colMeans(df$xdat)
  iplsdacv$row_names <- df_train$row_names
  iplsdacv$groups    <- df_train$groups
  iplsdacv$val_col   <- df$val_col
  iplsdacv$y_name    <- df$col_classes
  iplsdacv$col_names <- colnames(df_train$xdat)
  
  iplsdacv$sgstp <- df_train$sgstp
  iplsdacv$ppmet <- df_train$ppmet
  iplsdacv$mx    <- df_train$mx
  
  iplsdacv$prop_var <- pls::explvar(iplsdacv)
  
  iplsdacv$spl_type  <- spl_type
  iplsdacv$pro_test  <- pro_test
  iplsdacv$cv        <- cv
  iplsdacv$folds     <- folds
  iplsdacv$nint      <- nint
  iplsdacv$sel_mode  <- sel_mode
  iplsdacv$comb_full <- comb_full
  
  iplsdacv$df_train <- df_train
  iplsdacv$df_test  <- df_test
  
  iplsdacv$model_type <- "iPLS-DA"
  iplsdacv$classes    <- lev
  
  # ============================================================
  # Storage
  # ============================================================
  
  iplsdacv$intMet <- intMet
  
  iplsdacv$intMet_ind <- data.frame(
    int = 1:nint,
    ini = int1_ini,
    end = int1_end,
    lv  = int1_lv,
    acu = int1_acu
  )
  
  iplsdacv$bestVars <- list(
    ints = sort(best_ints),
    vars = selVar,
    lv   = as.numeric(intMet[[best_iter]]$lv),
    acu  = as.numeric(intMet[[best_iter]]$acu)
  )
  
  iplsdacv$globMet <- list(lv  = glob$lv, acu = glob$acu)
  
  # ============================================================
  # Update columns
  # ============================================================
  
  iplsdacv$col_names <- colnames(df_train$xdat)[selVar]
  
  if (!is.null(iplsdacv$val_col)) {
    iplsdacv$val_col <- iplsdacv$val_col[selVar]
  }
  
  if (!is.null(iplsdacv$mx)) {
    iplsdacv$mxFull <- iplsdacv$mx
    iplsdacv$mx     <- iplsdacv$mx[selVar]
  }
  
  # ============================================================
  # Update df_train
  # ============================================================
  
  iplsdacv$df_train$xdat <- df_train$xdat[, selVar, drop = FALSE]
  
  if (!is.null(df_train$val_col)) {
    iplsdacv$df_train$val_col <- df_train$val_col[selVar]
  }
  
  if (!is.null(df_train$mx)) {
    iplsdacv$df_train$mx <- df_train$mx[selVar]
  }
  
  # ============================================================
  # Update df_test
  # ============================================================
  
  if (!is.null(df_test)) {
    iplsdacv$df_test$xdat <- df_test$xdat[, selVar, drop = FALSE]
    
    if (!is.null(df_test$val_col)) {
      iplsdacv$df_test$val_col <- df_test$val_col[selVar]
    }
    
    if (!is.null(df_test$mx)) {
      iplsdacv$df_test$mx <- df_test$mx[selVar]
    }
  }
  
  return(iplsdacv)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.