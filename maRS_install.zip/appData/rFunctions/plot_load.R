plot_load <- function(mvmod,
                      x = 1,
                      y = 2,
                      z = 0,
                      mlines = FALSE,
                      vectors = FALSE,
                      vrot = 25,
                      hrot = 40,
                      marker = TRUE,
                      labels = TRUE,
                      var_lab = NULL,
                      adsupload = FALSE,
                      val_cex = 0.7,
                      grids = FALSE,
                      orlines = FALSE) {
  loadings <- if (!is.null(mvmod$loadings))
    mvmod$loadings
  else
    mvmod$rotation
  var_names <- mvmod$col_names
  expand = 0.05
  
  # Check supplementary loadings
  has_supl <- FALSE
  if (adsupload) {
    if (!is.null(mvmod$supcols) && !is.null(mvmod$supload)) {
      if (nrow(mvmod$supload) > 0 &&
          ncol(mvmod$supload) >= max(x, y, z)) {
        has_supl <- TRUE
      } else {
        warning("Supplementary loadings are not available or have insufficient dimensions")
      }
    }
  }
  
  # 1D case
  if (mlines) {
    pcs <- c(x, y, z)
    pcs <- pcs[pcs != 0]
    
    if (length(pcs) == 0) {
      warning("No valid PC selected for 1D plot")
      return(invisible())
    }
    
    # Check if PCs exist
    if (any(pcs > ncol(loadings))) {
      stop(sprintf(
        "PC(s) %s do not exist (maximum: %d)",
        paste(pcs[pcs > ncol(loadings)], collapse = ", "),
        ncol(loadings)
      ))
    }
    
    # X-axis limits
    xlim <- range(mvmod$val_col, na.rm = TRUE)
    xlim <- xlim + c(-expand, expand) * diff(xlim)
    
    # Y-axis limits (symmetric)
    y_data <- as.vector(loadings[, pcs, drop = FALSE])
    y_max <- max(abs(y_data), na.rm = TRUE) * (1 + expand)
    ylim <- c(-y_max, y_max)
    
    # Initialize empty plot
    plot(
      mvmod$val_col,
      loadings[, pcs[1]],
      type = "n",
      xlab = if (!is.null(var_lab))
        var_lab
      else
        "Variables",
      ylab = if (length(pcs) == 1) {
        if (!is.null(mvmod$call[[1]]) && mvmod$call[[1]] == "plsr") {
          sprintf("LV%d (%.1f%%)", pcs, mvmod$prop_var[pcs])
        }
        else if (length(pcs) > 1) {
          sprintf("PC%d (%.1f%%)", pcs, mvmod$prop_var[pcs])
        }
      } else {
        "Loadings"
      },
      las = 1,
      xlim = xlim,
      ylim = ylim,
      cex.lab = val_cex,
      cex.axis = val_cex
    )

    # Plot loading lines for each PC
    line_cols <- c("#619CFF", "#e41a1c", "#4daf4a")[seq_along(pcs)]
    for (i in seq_along(pcs)) {
      lines(mvmod$val_col,
            loadings[, pcs[i]],
            col = line_cols[i],
            lwd = 1.5)
    }
    
    # Add legend if multiple PCs are shown
    if (length(pcs) > 1) {
      op_legend <- par(xpd = TRUE)
      legend(
        "top",
        inset = -0.1,
        legend = if (!is.null(mvmod$call[[1]]) && mvmod$call[[1]] == "plsr")
          sprintf("LV%d (%.1f%%)", pcs, mvmod$prop_var[pcs])
        else
          sprintf("PC%d (%.1f%%)", pcs, mvmod$prop_var[pcs]),
        col = line_cols,
        lty = 1,
        lwd = 1.5,
        bty = "n",
        cex = val_cex * 0.9,
        horiz = TRUE
      )
      par(op_legend)
    }
    
    # Add horizontal reference line at zero
    if (orlines) {
      abline(
        h = 0,
        col = "gray60",
        lty = "solid",
        lwd = 1
      )
    }
    
    # Add grid lines
    if (grids) {
      par(xpd = FALSE)
      abline(
        h = pretty(ylim),
        v = pretty(xlim),
        col = "gray90",
        lty = "solid",
        lwd = .5
      )
    }
    
  } else if (z > 0) {
    # 3D case
    
    # Check dimensions
    if (z > ncol(loadings)) {
      stop(sprintf("Dim%d does not exist (maximum: %d)", z, ncol(loadings)))
    }
    
    if (!is.null(mvmod$call[[1]]) && mvmod$call[[1]] == "plsr") {
      xlab_txt <- sprintf("LV%d (%.1f%%)", x, mvmod$prop_var[x])
      ylab_txt <- sprintf("LV%d (%.1f%%)", y, mvmod$prop_var[y])
      zlab_txt <- sprintf("LV%d (%.1f%%)", z, mvmod$prop_var[z])
    }
    else{
      xlab_txt <- sprintf("PC%d (%.1f%%)", x, mvmod$prop_var[x])
      ylab_txt <- sprintf("PC%d (%.1f%%)", y, mvmod$prop_var[y])
      zlab_txt <- sprintf("PC%d (%.1f%%)", z, mvmod$prop_var[z])
    }
    
    # Compute symmetric limits
    if (has_supl) {
      x_vals <- c(loadings[, x], mvmod$supload[, x])
      y_vals <- c(loadings[, y], mvmod$supload[, y])
      z_vals <- c(loadings[, z], mvmod$supload[, z])
    } else {
      x_vals <- loadings[, x]
      y_vals <- loadings[, y]
      z_vals <- loadings[, z]
    }
    
    x_max <- max(abs(x_vals), na.rm = TRUE) * (1 + expand)
    y_max <- max(abs(y_vals), na.rm = TRUE) * (1 + expand)
    z_max <- max(abs(z_vals), na.rm = TRUE) * (1 + expand)
    
    xlim <- c(-x_max, x_max)
    ylim <- c(-y_max, y_max)
    zlim <- c(-z_max, z_max)
    
    # Safe offset function for labels
    safe_offset <- function(pos, offset_frac, limits) {
      offset <- sign(pos) * offset_frac * diff(limits)
      new_pos <- pos + offset
      margin <- 0.01 * diff(limits)
      pmax(pmin(new_pos, limits[2] - margin), limits[1] + margin)
    }
    
    # Plot main loadings as vectors or markers
    if (vectors) {
      plot3D::arrows3D(
        x0 = rep(0, nrow(loadings)),
        y0 = rep(0, nrow(loadings)),
        z0 = rep(0, nrow(loadings)),
        x1 = loadings[, x],
        y1 = loadings[, y],
        z1 = loadings[, z],
        col = "black",
        lwd = 1,
        add = FALSE,
        xlab = paste("\n", xlab_txt),
        ylab = paste("\n", ylab_txt),
        zlab = paste("\n", zlab_txt),
        cex = 1,
        cex.axis = val_cex,
        cex.lab = val_cex,
        length = 0.2,
        angle = 20,
        theta = hrot,
        phi = vrot,
        bty = if (grids)
          "u"
        else
          "b",
        col.grid = "gray90",
        lwd.grid = 1,
        ticktype = "detailed",
        xlim = xlim,
        ylim = ylim,
        zlim = zlim
      )
    } else {
      plot3D::scatter3D(
        x = loadings[, x],
        y = loadings[, y],
        z = loadings[, z],
        pch = if (marker)
          22
        else
          NA,
        col = "black",
        bg = if (marker)
          mix_with_white("black", alpha = 0.2)
        else
          NA,
        colvar = NULL,
        theta = hrot,
        phi = vrot,
        cex = 1,
        cex.axis = val_cex,
        cex.lab = val_cex,
        grid = FALSE,
        bty = if (grids)
          "u"
        else
          "b",
        col.grid = "gray90",
        lwd.grid = 1,
        xlab = paste("\n", xlab_txt),
        ylab = paste("\n", ylab_txt),
        zlab = paste("\n", zlab_txt),
        ticktype = "detailed",
        xlim = xlim,
        ylim = ylim,
        zlim = zlim
      )
    }
    
    # Plot supplementary loadings
    if (has_supl) {
      if (vectors) {
        plot3D::arrows3D(
          x0 = rep(0, nrow(mvmod$supload)),
          y0 = rep(0, nrow(mvmod$supload)),
          z0 = rep(0, nrow(mvmod$supload)),
          x1 = mvmod$supload[, x],
          y1 = mvmod$supload[, y],
          z1 = mvmod$supload[, z],
          col = "#e41a1c",
          lwd = 1,
          add = TRUE,
          length = 0.2,
          angle = 20
        )
      } else {
        plot3D::scatter3D(
          x = mvmod$supload[, x],
          y = mvmod$supload[, y],
          z = mvmod$supload[, z],
          add = TRUE,
          pch = if (marker)
            22
          else
            NA,
          col = "#e41a1c",
          bg = if (marker)
            mix_with_white("#e41a1c", alpha = 0.2)
          else
            NA,
          colvar = NULL,
          cex = 1
        )
      }
    }
    
    # Add main loading labels
    if (labels) {
      if (marker && !vectors) {
        z_pos <- safe_offset(loadings[, z], 0.06, zlim)
        plot3D::text3D(
          x = loadings[, x],
          y = loadings[, y],
          z = z_pos,
          labels = var_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "black"
        )
      } else if (vectors) {
        x_pos <- safe_offset(loadings[, x], 0.035, xlim)
        y_pos <- safe_offset(loadings[, y], 0.035, ylim)
        z_pos <- safe_offset(loadings[, z], 0.035, zlim)
        plot3D::text3D(
          x = x_pos,
          y = y_pos,
          z = z_pos,
          labels = var_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "black"
        )
      } else {
        plot3D::text3D(
          x = loadings[, x],
          y = loadings[, y],
          z = loadings[, z],
          labels = var_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "black"
        )
      }
    }
    
    # Add supplementary loading labels
    if (has_supl && labels) {
      if (marker && !vectors) {
        z_pos <- safe_offset(mvmod$supload[, z], 0.06, zlim)
        plot3D::text3D(
          x = mvmod$supload[, x],
          y = mvmod$supload[, y],
          z = z_pos,
          labels = mvmod$sup_col_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "#e41a1c"
        )
      } else if (vectors) {
        x_pos <- safe_offset(mvmod$supload[, x], 0.035, xlim)
        y_pos <- safe_offset(mvmod$supload[, y], 0.035, ylim)
        z_pos <- safe_offset(mvmod$supload[, z], 0.035, zlim)
        plot3D::text3D(
          x = x_pos,
          y = y_pos,
          z = z_pos,
          labels = mvmod$sup_col_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "#e41a1c"
        )
      } else {
        plot3D::text3D(
          x = mvmod$supload[, x],
          y = mvmod$supload[, y],
          z = mvmod$supload[, z],
          labels = mvmod$sup_col_names,
          add = TRUE,
          cex = val_cex,
          adj = 0.5,
          col = "#e41a1c"
        )
      }
    }
    
  } else {
    # 2D case
    
    # Compute symmetric limits
    if (has_supl) {
      x_vals <- c(loadings[, x], mvmod$supload[, x])
      y_vals <- c(loadings[, y], mvmod$supload[, y])
    } else {
      x_vals <- loadings[, x]
      y_vals <- loadings[, y]
    }
    
    x_max <- max(abs(x_vals), na.rm = TRUE) * (1 + expand)
    y_max <- max(abs(y_vals), na.rm = TRUE) * (1 + expand)
    
    xlim <- c(-x_max, x_max)
    ylim <- c(-y_max, y_max)
    
    # Plot main loadings
    plot(
      loadings[, x],
      loadings[, y],
      xlab = if (!is.null(mvmod$call[[1]]) && mvmod$call[[1]] == "plsr")
        sprintf("LV%d (%.1f%%)", x, mvmod$prop_var[x])
      else
        sprintf("PC%d (%.1f%%)", x, mvmod$prop_var[x]),
      ylab = if (!is.null(mvmod$call[[1]]) && mvmod$call[[1]] == "plsr")
        sprintf("LV%d (%.1f%%)", y, mvmod$prop_var[y])
      else
        sprintf("PC%d (%.1f%%)", y, mvmod$prop_var[y]),
      pch = if (marker && !vectors)
        22
      else
        NA,
      col = "black",
      bg = if (marker &&
               !vectors)
        mix_with_white("black", alpha = 0.2)
      else
        NA,
      lwd = 1.5,
      las = 1,
      cex.lab = val_cex,
      cex.axis = val_cex,
      xlim = xlim,
      ylim = ylim
    )
    
    # Plot loadings as vectors
    if (vectors) {
      arrows(
        0,
        0,
        loadings[, x],
        loadings[, y],
        col = "black",
        lwd = 1,
        length = 0.07,
        angle = 20
      )
    }
    
    # Plot supplementary loadings
    if (has_supl) {
      if (vectors) {
        arrows(
          0,
          0,
          mvmod$supload[, x],
          mvmod$supload[, y],
          col = "#e41a1c",
          lwd = 1,
          length = 0.1,
          angle = 20
        )
      } else {
        points(
          mvmod$supload[, x],
          mvmod$supload[, y],
          pch = if (marker)
            22
          else
            NA,
          col = "#e41a1c",
          bg = if (marker)
            mix_with_white("#e41a1c", alpha = 0.2)
          else
            NA,
          lwd = 1.5
        )
      }
    }
    
    # Add loading labels
    if (labels) {
      safe_offset_2d <- function(pos, offset_frac, limits) {
        offset <- sign(pos) * offset_frac * diff(limits)
        new_pos <- pos + offset
        margin <- 0.02 * diff(limits)
        pmax(pmin(new_pos, limits[2] - margin), limits[1] + margin)
      }
      
      if (marker && !vectors) {
        text(
          loadings[, x],
          loadings[, y],
          labels = var_names,
          pos = 3,
          cex = val_cex,
          offset = 0.3
        )
      } else if (vectors) {
        x_pos <- safe_offset_2d(loadings[, x], 0.03, xlim)
        y_pos <- safe_offset_2d(loadings[, y], 0.03, ylim)
        text(x_pos, y_pos, labels = var_names, cex = val_cex)
      } else {
        text(loadings[, x],
             loadings[, y],
             labels = var_names,
             cex = val_cex)
      }
    }
    
    # Add supplementary loading labels
    if (has_supl && labels) {
      if (marker && !vectors) {
        text(
          mvmod$supload[, x],
          mvmod$supload[, y],
          labels = mvmod$sup_col_names,
          pos = 3,
          cex = val_cex,
          col = "#e41a1c",
          offset = 0.3
        )
      } else if (vectors) {
        x_pos <- safe_offset_2d(mvmod$supload[, x], 0.03, xlim)
        y_pos <- safe_offset_2d(mvmod$supload[, y], 0.03, ylim)
        text(
          x_pos,
          y_pos,
          labels = mvmod$sup_col_names,
          cex = val_cex,
          col = "#e41a1c"
        )
      } else {
        text(
          mvmod$supload[, x],
          mvmod$supload[, y],
          labels = mvmod$sup_col_names,
          cex = val_cex,
          col = "#e41a1c"
        )
      }
    }
    
    # Add reference lines at origin
    if (orlines) {
      usr <- par("usr")
      segments(
        0,
        usr[3],
        0,
        usr[4],
        col = "gray60",
        lty = "solid",
        lwd = 1
      )
      segments(
        usr[1],
        0,
        usr[2],
        0,
        col = "gray60",
        lty = "solid",
        lwd = 1
      )
    }
    
    # Add grid lines
    if (grids) {
      par(xpd = FALSE)
      abline(
        h = pretty(ylim),
        v = pretty(xlim),
        col = "gray90",
        lty = "solid",
        lwd = .5
      )
    }
  }
  
  invisible()
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.