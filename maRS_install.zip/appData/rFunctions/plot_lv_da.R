plot_lv_da <- function(mvcv,
                       plot_cal = TRUE,
                       plot_cv = TRUE,
                       plot_test = FALSE,
                       plot_type = "SEN",
                       val_cex = 0.7)
{
  
  if (mvcv$spl_type=='None')
    plot_test <- FALSE
  
  plot_type <- toupper(plot_type)
  
  allowed <- c("PRE", "SPE", "SEN", "ACU", "EFI", "F1S")
  if (!plot_type %in% allowed)
    stop("plot_type must be one of: ", paste(allowed, collapse = ", "))
  
  c_cal  <- "#377eb8"
  c_cv   <- "#e41a1c"
  c_test <- "#4daf4a"
  
  col_set <- c(c_cal, c_cv, c_test)
  bg_set  <- c(
    mix_with_white(c_cal, alpha = 0.2),
    mix_with_white(c_cv, alpha = 0.2),
    mix_with_white(c_test, alpha = 0.2)
  )
  
  LV <- seq_len(mvcv$ncomp)
  if (plot_cal)
    cal_metrics <- mvcv$cal_metrics[[plot_type]]
  if (plot_cv)
    cv_metrics <- mvcv$cv_metrics[[plot_type]]
  if (plot_test)
    test_metrics <- mvcv$test_metrics[[plot_type]]
  
  # ============================================================
  # Plot
  # ============================================================
  plot(
    LV,
    LV,
    type = "n",
    cex.axis = val_cex,
    cex.lab  = val_cex,
    xaxp = c(min(LV), max(LV), max(LV) - min(LV)),
    xlab = if (class(mvcv) == "mvr")
      "LV"
    else if (class(mvcv) == "simcacv")
      "PC",
    ylab = plot_type,
    ylim = c(0, 1)
  )
  
  if (plot_cal) {
    lines(
      LV,
      cal_metrics,
      type = "b",
      pch = 21,
      col = col_set[1],
      bg  = bg_set[1],
      lwd = 1.5
    )
  }
  
  if (plot_cv) {
    lines(
      LV,
      cv_metrics,
      type = "b",
      pch = 21,
      col = col_set[2],
      bg  = bg_set[2],
      lwd = 1.5
    )
  }
  
  if (plot_test) {
    lines(
      LV,
      test_metrics,
      type = "b",
      pch = 21,
      col = col_set[3],
      bg  = bg_set[3],
      lwd = 1.5
    )
  }
  
  # Allow drawing outside plot region
  par(xpd = TRUE)
  
  leg_idx    <- c(plot_cal, plot_cv, plot_test)
  leg_labels <- c("Calibration  ", "CV", "Test")[leg_idx]
  leg_cols   <- col_set[leg_idx]
  leg_bgs    <- bg_set[leg_idx]
  
  legend(
    "top",
    inset = -0.1,
    horiz = TRUE,
    legend = leg_labels,
    pch = 21,
    pt.bg = leg_bgs,
    col = leg_cols,
    lwd = 1.5,
    bty = "n",
    cex = val_cex
  )
  
  par(xpd = FALSE)
  invisible()
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.