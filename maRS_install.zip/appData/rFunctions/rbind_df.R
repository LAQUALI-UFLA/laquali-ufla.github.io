rbind_df <- function(lst) {
  out <- lst[[1]]
  
  if (length(lst) == 1)
    return(out)
  
  for (i in 2:length(lst)) {
    out$xdat   <- rbind(out$xdat, lst[[i]]$xdat)
    out$groups <- c(out$groups, lst[[i]]$groups)
    
    if (!is.null(out$row_names) && !is.null(lst[[i]]$row_names)) {
      out$row_names <- c(out$row_names, lst[[i]]$row_names)
    }
    
  }
  
  return(out)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.