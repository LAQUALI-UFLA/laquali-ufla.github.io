# =========================
# UI
# =========================

appPCAUI <- div(
  id = "pca_module",
  # lockInput
  tags$script(
    HTML(
      "
        Shiny.addCustomMessageHandler('lockInput', function(x) {
          var ids = Array.isArray(x.id) ? x.id : [x.id];

          ids.forEach(function(id) {
            var el = document.getElementById(id);
            if (el) el.closest('.shiny-input-container').style.pointerEvents = 'none';
          });
        });
        "
    )
  ),
  
  tags$script(
    HTML(
      "
    Shiny.addCustomMessageHandler('unlockInput', function(x) {
      var ids = Array.isArray(x.id) ? x.id : [x.id];

      ids.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.closest('.shiny-input-container').style.pointerEvents = 'auto';
      });
    });
    "
    )
  ),
  
  compactNavbarStyle("pca_module"),
  
  navbarPage(
    "PCA",
    
    # TAB MODEL
    tabPanel("Model", fluidRow(
      column(
        width = 3,
        wellPanel(
          style = "padding-top:0px;",
          h3("PCA settings"),
          
          numericInput("pca_ncomp", "Max. n of PCs:", 1, min = 1, step =
                         1),
          checkboxInput("pca_scale", "Scale", FALSE),
          
          selectInput("pca_suprows", "Supplementary rows:", choices = "None"),
          
          selectInput(
            "pca_supcols",
            "Supplementary columns:",
            choices = "None",
            multiple = TRUE
          ),
          
          selectInput("pca_scalecol", "Scores visual scale:", choices =
                        "None"),
          
          br(),
          
          fluidRow(column(
            width = 12,
            
            # Line 1 — Run and Reset
            div(
              style = "display:flex; gap:10px;",
              actionButton(
                "run_pca_btn",
                "Run",
                icon = icon("play"),
                class = "btn-primary",
                style = "flex:1;"
              ),
              actionButton(
                "reset",
                "Reset",
                icon = icon("chart-line"),
                class = "btn-primary",
                style = "flex:1;"
              )
            ),
            
            br(),
            
            # Line 2 — Save
            div(
              style = "display:flex; gap:10px;",
              uiOutput("save_pca_results", style = "flex:1;"),
              uiOutput("save_pca_model", style = "flex:1;")
            ),
            
            br(),
          )),
          hr(),
          # Line 3 — Load
          fluidRow(column(
            width = 12,
            fileInput(
              "pca_load_model_file",
              "Load model (.rds)",
              accept = ".rds",
              width = "100%"
            )
          )),
          
        )
      ), column(width = 9, fluidRow(
        column(9, uiOutput("pca_model_plot_container")), column(
          3,
          wellPanel(
            style = "padding-top:0px;",
            h3("Export graph"),
            numericInput(
              "pca_fontsize",
              "Font factor:",
              value = 0.7,
              min = 0.3,
              max = 2,
              step = 0.1
            ),
            exportPlotUI("pca_model_export")
          )
        )
      ))
    )),
    
    # TAB SCORES
    tabPanel("Scores", fluidRow(
      column(
        width = 3,
        wellPanel(
          style = "padding-top:0px;",
          
          numericInput("scor_x", "PC on x:", 1, min = 1, step = 1),
          numericInput("scor_y", "PC on y:", 2, min = 1, step = 1),
          numericInput("scor_z", "PC on z:", 0, min = 0, step = 1),
          
          numericInput(
            "scor_vrot",
            "Vertical rotation:",
            25,
            min = 1,
            max = 360
          ),
          numericInput(
            "scor_hrot",
            "Horizontal rotation:",
            40,
            min = 1,
            max = 360
          ),
          
          checkboxInput("scor_marker", "Markers", TRUE),
          checkboxInput("scor_labels", "Labels", TRUE),
          checkboxInput("scor_group", "Groups", FALSE),
          checkboxInput("scor_elips", "Ellipse", FALSE),
          checkboxInput("scor_fillelip", "Fill ellipse", FALSE),
          checkboxInput("scor_mrksiz", "Scale marker size", FALSE),
          checkboxInput("scor_mrkcol", "Scale marker color", FALSE),
          checkboxInput("scor_adsupscor", "Add supplementary", FALSE),
          
          selectInput(
            "scor_palette",
            "Colors:",
            c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
          ),
          
          checkboxInput("scor_orlines", "Origin lines", FALSE)
        )
      ), column(width = 9, fluidRow(
        column(9, uiOutput("pca_scores_plot_container")), column(
          3,
          wellPanel(
            style = "padding-top:0px;",
            h3("Export graph"),
            numericInput(
              "scor_fontsize",
              "Font factor:",
              value = 0.7,
              min = 0.3,
              max = 2,
              step = 0.1
            ),
            exportPlotUI("pca_scores_export")
          )
        )
      ))
    )),
    
    # TAB LOADINGS
    tabPanel("Loadings", fluidRow(
      column(
        width = 3,
        wellPanel(
          style = "padding-top:0px;",
          
          numericInput("load_x", "PC on x:", 1, min = 1, step = 1),
          numericInput("load_y", "PC on y:", 2, min = 1, step = 1),
          numericInput("load_z", "PC on z:", 0, min = 0, step = 1),
          
          checkboxInput("load_mlines", "Multiple", FALSE),
          checkboxInput("load_vectors", "Vectors", FALSE),
          
          numericInput(
            "load_vrot",
            "Vertical rotation:",
            25,
            min = 1,
            max = 360
          ),
          numericInput(
            "load_hrot",
            "Horizontal rotation:",
            40,
            min = 1,
            max = 360
          ),
          
          checkboxInput("load_marker", "Markers", TRUE),
          checkboxInput("load_labels", "Labels", TRUE),
          
          textInput("load_var_lab", "X label:", "Variables"),
          
          checkboxInput("load_adsupload", "Add supplementary", FALSE),
          
          checkboxInput("load_orlines", "Origin lines", FALSE)
        )
      ), column(width = 9, fluidRow(
        column(9, uiOutput("pca_load_plot_container")), column(
          3,
          wellPanel(
            style = "padding-top:0px;",
            h3("Export graph"),
            numericInput(
              "load_fontsize",
              "Font factor:",
              value = 0.7,
              min = 0.3,
              max = 2,
              step = 0.1
            ),
            exportPlotUI("pca_load_export")
          )
        )
      ))
    )),
    
    # TAB BIPLOT
    tabPanel("Biplot", fluidRow(
      column(
        width = 3,
        wellPanel(
          style = "padding-top:0px;",
          
          numericInput("bi_x", "PC on x:", 1, min = 1, step = 1),
          numericInput("bi_y", "PC on y:", 2, min = 1, step = 1),
          numericInput("bi_z", "PC on z:", 0, min = 0, step = 1),
          
          numericInput(
            "bi_vrot",
            "Vertical rotation:",
            25,
            min = 1,
            max = 360
          ),
          numericInput(
            "bi_hrot",
            "Horizontal rotation:",
            40,
            min = 1,
            max = 360
          ),
          
          selectInput(
            "bi_palette",
            "Colors:",
            c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
          ),
          
          checkboxInput("bi_orlines", "Origin lines", FALSE),
          
          h4("Scores"),
          checkboxInput("bi_scormarker", "Markers", TRUE),
          checkboxInput("bi_scorlabels", "Labels", TRUE),
          checkboxInput("bi_group", "Groups", FALSE),
          checkboxInput("bi_elips", "Ellipse", FALSE),
          checkboxInput("bi_fillelip", "Fill ellipse", FALSE),
          checkboxInput("bi_mrksiz", "Scale marker size", FALSE),
          checkboxInput("bi_mrkcol", "Scale marker color", FALSE),
          checkboxInput("bi_adsupscor", "Add supplementary", FALSE),
          
          h4("Loadings"),
          checkboxInput("bi_loadlabels", "Labels", TRUE),
          checkboxInput("bi_loadmarker", "Markers", TRUE),
          checkboxInput("bi_vectors", "Vectors", FALSE),
          checkboxInput("bi_adsupload", "Add supplementary", FALSE)
        )
      ), column(width = 9, fluidRow(
        column(9, uiOutput("pca_bi_plot_container")), column(
          3,
          wellPanel(
            style = "padding-top:0px;",
            h3("Export graph"),
            numericInput(
              "bi_fontsize",
              "Font factor:",
              value = 0.7,
              min = 0.3,
              max = 2,
              step = 0.1
            ),
            exportPlotUI("pca_bi_export")
          )
        )
      ))
    ))
  )
)

# =========================
# SERVER
# =========================

appPCAServer <- function(input, output, session, df_shared) {
  pca_ran <- reactiveVal(FALSE)
  pcamod  <- reactiveVal(NULL)
  
  # Update limits
  observe({
    req(df_shared())
    maxpc <- min(nrow(df_shared()$xdat) - 1, ncol(df_shared()$xdat))
    
    updateNumericInput(session,
                       "pca_ncomp",
                       value = min(10, maxpc),
                       max   = maxpc)
    updateNumericInput(session, "scor_x", max = maxpc)
    updateNumericInput(session, "scor_y", max = maxpc)
    updateNumericInput(session, "load_x", max = maxpc)
    updateNumericInput(session, "load_y", max = maxpc)
    updateNumericInput(session, "bi_x", max = maxpc)
    updateNumericInput(session, "bi_y", max = maxpc)
    
    updateSelectInput(session, "pca_suprows", choices = c("None", unique(df_shared()$groups)))
    
    updateSelectInput(session, "pca_supcols", choices = c("None", colnames(df_shared()$xdat)))
    
    updateSelectInput(session, "pca_scalecol", choices = c("None", colnames(df_shared()$xdat)))
  })
  
  # Run PCA
  observeEvent(input$run_pca_btn, {
    req(df_shared())
    
    suprows <- if ("None" %in% input$pca_suprows)
      NULL
    else
      input$pca_suprows
    supcols <- if ("None" %in% input$pca_supcols)
      NULL
    else
      input$pca_supcols
    scalecol <- if (input$pca_scalecol == "None")
      NULL
    else
      input$pca_scalecol
    
    pcamod(
      mod_pca(
        df       = df_shared(),
        ncomp    = input$pca_ncomp,
        scale    = input$pca_scale,
        suprows  = suprows,
        supcols  = supcols,
        scalecol = scalecol
      )
    )
    
    pca_ran(TRUE)
    
  })
  
  # Reset
  observeEvent(input$reset, {
    req(pcamod())
    
    session$sendCustomMessage("unlockInput", list(id = session$ns(
      c(
        "pca_ncomp",
        "pca_scale",
        "pca_suprows",
        "pca_supcols",
        "pca_scalecol"
      )
    )))
    
    updateNumericInput(session, "pca_ncomp", value = 1)
    updateCheckboxInput(session, "pca_scale", value = FALSE)
    updateSelectInput(session, "pca_suprows", choices = "None")
    updateSelectInput(session, "pca_supcols", choices  =  "None")
    updateSelectInput(session, "pca_scalecol", choices  =  "None")
    
    pcamod(NULL)
    pca_ran(FALSE)
  })
  
  # MODEL PLOT
  make_model_plot <- function() {
    plot_variance(pcamod(), val_cex = input$pca_fontsize)
  }
  
  output$main_pca_model_plot <- renderPlot({
    req(pca_ran())
    make_model_plot()
  })
  
  exp_model <- exportPlotServer("pca_model_export", plot_fun = make_model_plot)
  
  output$pca_model_plot_container <- renderUI({
    plotOutput(
      "main_pca_model_plot",
      width = paste0(exp_model$width(), "px"),
      height = paste0(exp_model$height(), "px")
    )
  })
  
  # SCORES PLOT
  make_scores_plot <- function() {
    plot_scor(
      pcamod(),
      x = input$scor_x,
      y = input$scor_y,
      z = input$scor_z,
      vrot = input$scor_vrot,
      hrot = input$scor_hrot,
      marker = input$scor_marker,
      labels = input$scor_labels,
      group = input$scor_group,
      elips = input$scor_elips,
      fillelip = input$scor_fillelip,
      mrksiz = input$scor_mrksiz,
      mrkcol = input$scor_mrkcol,
      adsupscor = input$scor_adsupscor,
      colPa = input$scor_palette,
      val_cex = input$scor_fontsize,
      orlines = input$scor_orlines
    )
  }
  
  output$main_pca_scores_plot <- renderPlot({
    req(pca_ran())
    make_scores_plot()
  })
  
  exp_scores <- exportPlotServer("pca_scores_export", plot_fun = make_scores_plot)
  
  output$pca_scores_plot_container <- renderUI({
    plotOutput(
      "main_pca_scores_plot",
      width = paste0(exp_scores$width(), "px"),
      height = paste0(exp_scores$height(), "px")
    )
  })
  
  # LOADINGS PLOT
  make_load_plot <- function() {
    plot_load(
      pcamod(),
      x = input$load_x,
      y = input$load_y,
      z = input$load_z,
      mlines = input$load_mlines,
      vectors = input$load_vectors,
      vrot = input$load_vrot,
      hrot = input$load_hrot,
      marker = input$load_marker,
      labels = input$load_labels,
      var_lab = input$load_var_lab,
      adsupload = input$load_adsupload,
      val_cex = input$load_fontsize,
      orlines = input$load_orlines
    )
  }
  
  output$main_pca_load_plot <- renderPlot({
    req(pca_ran())
    make_load_plot()
  })
  
  exp_load <- exportPlotServer("pca_load_export", plot_fun = make_load_plot)
  
  output$pca_load_plot_container <- renderUI({
    plotOutput(
      "main_pca_load_plot",
      width = paste0(exp_load$width(), "px"),
      height = paste0(exp_load$height(), "px")
    )
  })
  
  # BIPLOT
  make_bi_plot <- function() {
    plot_bi(
      pcamod(),
      x = input$bi_x,
      y = input$bi_y,
      z = input$bi_z,
      vrot = input$bi_vrot,
      hrot = input$bi_hrot,
      scormarker = input$bi_scormarker,
      scorlabels = input$bi_scorlabels,
      group = input$bi_group,
      elips = input$bi_elips,
      fillelip = input$bi_fillelip,
      mrksiz = input$bi_mrksiz,
      mrkcol = input$bi_mrkcol,
      colPa = input$bi_palette,
      vectors = input$bi_vectors,
      loadmarker = input$bi_loadmarker,
      loadlabels = input$bi_loadlabels,
      adsupscor = input$bi_adsupscor,
      adsupload = input$bi_adsupload,
      val_cex = input$bi_fontsize,
      orlines = input$bi_orlines
    )
  }
  
  output$main_pca_bi_plot <- renderPlot({
    req(pca_ran())
    make_bi_plot()
  })
  
  exp_bi <- exportPlotServer("pca_bi_export", plot_fun = make_bi_plot)
  
  output$pca_bi_plot_container <- renderUI({
    plotOutput(
      "main_pca_bi_plot",
      width = paste0(exp_bi$width(), "px"),
      height = paste0(exp_bi$height(), "px")
    )
  })
  
  # SAVE MODEL
  output$save_pca_model <- renderUI({
    if (!pca_ran())
      downloadLink(
        "save_pca_model_btn",
        "Save model",
        class = "btn btn-success",
        onclick = "return false;",
        style = "width:100%;"
      )
    else
      downloadLink("save_pca_model_btn",
                   "Save model",
                   class = "btn btn-success",
                   style = "width:100%;")
  })
  
  output$save_pca_model_btn <- downloadHandler(
    filename = function() {
      paste0("PCA_model_", Sys.Date(), ".rds")
    },
    
    content = function(file) {
      req(pcamod())
      saveRDS(pcamod(), file)
    }
  )
  
  # Save PCA
  output$save_pca_results <- renderUI({
    if (!pca_ran()) {
      downloadLink(
        "save_pca_mod",
        "Save results",
        icon = icon("save"),
        class = "btn btn-success",
        onclick = "return false;",
        style = "width:100%;"
      )
      
    } else {
      downloadLink(
        "save_pca_mod",
        "Save results",
        icon = icon("save"),
        class = "btn btn-success",
        style = "width:100%;"
      )
      
    }
  })
  
  # Save results
  output$save_pca_mod <- downloadHandler(
    filename = function() {
      paste0("PCA_model_", Sys.Date(), ".xlsx")
    },
    
    content = function(file) {
      req(pcamod())
      
      mod <- pcamod()
      
      names(mod$prop_var) <- paste0("PC", 1:length(mod$prop_var))
      names(mod$prop_var_cum) <- paste0("PC", 1:length(mod$prop_var_cum))
      
      var_df     <- as.data.frame(t(mod$prop_var))
      cumvar_df  <- as.data.frame(t(mod$prop_var_cum))
      
      sheets <- list(
        "scores"   = cbind(Object = mod$row_names, as.data.frame(mod$x)),
        "loadings" = cbind(Variable = mod$col_names, as.data.frame(mod$rotation)),
        "var"      = var_df,
        "cumVar"   = cumvar_df
      )
      
      if (!is.null(mod$supscor)) {
        sheets[["supScor"]] <- cbind(Object = mod$sup_row_names, as.data.frame(mod$supscor))
      }
      
      if (!is.null(mod$supload)) {
        sheets[["supLoad"]] <- cbind(Variable = mod$sup_col_names, as.data.frame(mod$supload))
      }
      
      writexl::write_xlsx(sheets, file)
    }
  )
  
  # LOAD MODEL
  observeEvent(input$pca_load_model_file, {
    mod_loaded <- readRDS(input$pca_load_model_file$datapath)
    
    pcamod(mod_loaded)
    pca_ran(TRUE)
    
    mod <- pcamod()
    
    # pca_ncomp
    if (!is.null(mod$sdev)) {
      updateNumericInput(session, "pca_ncomp", value = length(mod$sdev))
    }
    
    # pca_scale
    if (!is.null(mod$scale)) {
      updateCheckboxInput(session, "pca_scale", value = mod$scale)
    }
    
    # pca_suprows
    if (!is.null(mod$sup_row_names)) {
      updateSelectInput(
        session,
        "pca_suprows",
        choices  = mod$sup_row_names,
        selected = mod$sup_row_names
      )
    }
    
    # pca_supcols
    if (!is.null(mod$sup_col_names)) {
      updateSelectInput(
        session,
        "pca_supcols",
        choices  = mod$sup_col_names,
        selected = mod$sup_col_names
      )
    }
    
    # pca_scalecol
    if (!is.null(mod$scalecol_name)) {
      updateSelectInput(
        session,
        "pca_scalecol",
        choices  = mod$scalecol_name,
        selected = mod$scalecol_name
      )
    }
    
    # Lock
    session$sendCustomMessage("lockInput", list(id = session$ns(
      c(
        "pca_ncomp",
        "pca_scale",
        "pca_suprows",
        "pca_supcols",
        "pca_scalecol"
      )
    )))
  })
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.