run_designers <- function() {
  start_script <- system.file("app", "start.R", package = "designers")
  
  if (start_script == "") {
    stop("The start.R file was not found in the app folder. Try reinstalling the designers package.", call. = FALSE)
  }
  
  suppressMessages(source(start_script, chdir = TRUE))
}

rundesigners <- run_designers
designers_gui <- run_designers
designersgui <- run_designers

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.