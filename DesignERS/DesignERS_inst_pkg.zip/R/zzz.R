create_shortcuts <- function() {
  app_dir <- system.file("app", package = "DesignERS")
  if (app_dir == "") return(FALSE)
  
  os <- Sys.info()["sysname"]
  
  if (os == "Windows") {
    ps_script <- normalizePath(
      file.path(app_dir, "DesignERS.ps1"),
      winslash = "\\",
      mustWork = TRUE
    )
    
    icon_path <- normalizePath(
      file.path(app_dir, "www", "logo_DesignERS.ico"),
      winslash = "\\",
      mustWork = TRUE
    )
    
    app_dir_win <- normalizePath(
      app_dir,
      winslash = "\\",
      mustWork = TRUE
    )
    
    ps_code <- sprintf("
      $Wscript = New-Object -ComObject WScript.Shell;
      $StartMenu = Join-Path $env:APPDATA 'Microsoft\\Windows\\Start Menu\\Programs\\DesignERS';
      $Desktop = [Environment]::GetFolderPath('Desktop');

      if (-not (Test-Path $StartMenu)) {
        New-Item -Path $StartMenu -ItemType Directory -Force | Out-Null
      }

      $s1 = $Wscript.CreateShortcut((Join-Path $StartMenu 'DesignERS.lnk'));
      $s1.TargetPath = 'powershell.exe';
      $s1.Arguments = '-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File \"%s\"';
      $s1.WorkingDirectory = '%s';
      $s1.IconLocation = '%s';
      $s1.WindowStyle = 7;
      $s1.Save();

      $s2 = $Wscript.CreateShortcut((Join-Path $Desktop 'DesignERS.lnk'));
      $s2.TargetPath = 'powershell.exe';
      $s2.Arguments = '-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File \"%s\"';
      $s2.WorkingDirectory = '%s';
      $s2.IconLocation = '%s';
      $s2.WindowStyle = 7;
      $s2.Save();
    ",
                       ps_script,
                       app_dir_win,
                       icon_path,
                       ps_script,
                       app_dir_win,
                       icon_path
    )
    
    result <- system2(
      "powershell",
      args = c(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-Command", ps_code
      ),
      stdout = FALSE,
      stderr = FALSE
    )
    
    return(result == 0)
    
  } else if (os == "Linux") {
    sh_script <- file.path(app_dir, "DesignERS.sh")
    icon_path <- file.path(app_dir, "www", "logo_DesignERS.png")
    desktop_dir <- file.path(
      Sys.getenv("HOME"),
      ".local",
      "share",
      "applications"
    )
    desktop_file <- file.path(desktop_dir, "DesignERS.desktop")
    
    if (!file.exists(sh_script) || !file.exists(icon_path)) {
      return(FALSE)
    }
    
    dir.create(
      desktop_dir,
      recursive = TRUE,
      showWarnings = FALSE
    )
    
    if (!dir.exists(desktop_dir)) {
      return(FALSE)
    }
    
    Sys.chmod(sh_script, "0755")
    
    content <- c(
      "[Desktop Entry]",
      "Version=1.0",
      "Type=Application",
      "Name=DesignERS",
      sprintf("Exec=bash \"%s\"", sh_script),
      sprintf("Icon=%s", icon_path),
      sprintf("Path=%s", app_dir),
      "Terminal=false",
      "Categories=Science;Education;"
    )
    
    writeLines(content, desktop_file)
    
    if (!file.exists(desktop_file)) {
      return(FALSE)
    }
    
    Sys.chmod(desktop_file, "0755")
    
    if (nzchar(Sys.which("update-desktop-database"))) {
      system2(
        "update-desktop-database",
        args = shQuote(desktop_dir),
        stdout = FALSE,
        stderr = FALSE
      )
    }
    
    return(TRUE)
    
  } else if (os == "Darwin") {
    sh_script <- file.path(app_dir, "DesignERS.sh")
    app_dir_mac <- file.path(Sys.getenv("HOME"), "Applications")
    app_bundle <- file.path(app_dir_mac, "DesignERS.app")
    
    if (!file.exists(sh_script)) {
      return(FALSE)
    }
    
    dir.create(
      app_dir_mac,
      recursive = TRUE,
      showWarnings = FALSE
    )
    
    if (!dir.exists(app_dir_mac)) {
      return(FALSE)
    }
    
    Sys.chmod(sh_script, "0755")
    
    if (!nzchar(Sys.which("osacompile"))) {
      return(FALSE)
    }
    
    script <- sprintf(
      'do shell script "bash \\"%s\\" > /dev/null 2>&1 &"',
      sh_script
    )
    
    result <- system2(
      "osacompile",
      args = c(
        "-o", shQuote(app_bundle),
        "-e", shQuote(script)
      ),
      stdout = FALSE,
      stderr = FALSE
    )
    
    return(result == 0 && dir.exists(app_bundle))
  }
  
  FALSE
}

remove_shortcuts <- function() {
  os <- Sys.info()["sysname"]
  
  if (os == "Windows") {
    cmd <- 'powershell -NoProfile -ExecutionPolicy Bypass -Command "
      $Desktop = [Environment]::GetFolderPath(\'Desktop\');
      $StartMenu = Join-Path $env:APPDATA \'Microsoft\\Windows\\Start Menu\\Programs\\DesignERS\';
      Remove-Item \"$Desktop\\DesignERS.lnk\" -Force -ErrorAction SilentlyContinue;
      Remove-Item $StartMenu -Recurse -Force -ErrorAction SilentlyContinue;
    "'
    system(cmd, show.output.on.console = FALSE)
  } else if (os == "Linux") {
    unlink(file.path(Sys.getenv("HOME"), ".local", "share", "applications", "DesignERS.desktop"))
  } else if (os == "Darwin") {
    unlink(file.path(Sys.getenv("HOME"), "Applications", "DesignERS.app"), recursive = TRUE)
  }
  
  message("DesignERS shortcuts removed from the system.")
}

uninstall_designers <- function() {
  remove_shortcuts()
  if ("DesignERS" %in% loadedNamespaces()) {
    unloadNamespace("DesignERS")
  }
  remove.packages("DesignERS")
  message("DesignERS and its shortcuts have been successfully uninstalled!")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("DesignERS ready for use.")
}

.onUnload <- function(libpath) {
  calls <- sys.calls()
  call_names <- unlist(lapply(calls, function(x) {
    tryCatch(deparse(x[[1]])[1], error = function(e) "")
  }))
  
  if (any(c("remove.packages", "utils::remove.packages") %in% call_names)) {
    remove_shortcuts()
  }
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.