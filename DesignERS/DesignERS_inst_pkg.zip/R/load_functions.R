.onLoad <- function(libname, pkgname) {
  folders <- c("rFunctions")
  
  for (folder in folders) {
    path <- system.file("app", folder, package = pkgname)
    
    if (dir.exists(path)) {
      files <- sort(list.files(path, pattern = "\\.R$", full.names = TRUE))
      
      for (file in files) {
        sys.source(file, envir = asNamespace(pkgname))
      }
    }
  }
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.