#!/usr/bin/env bash

# Gets the current directory path (appData) where this script and start.R reside
APP_DATA_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
R_FILE="$APP_DATA_PATH/start.R"

# 1. Try to find Rscript in the system PATH
RSCRIPT_PATH=$(command -v Rscript 2>/dev/null)

# Verify if the found command is actually executable
if [ -n "$RSCRIPT_PATH" ] && [ ! -x "$RSCRIPT_PATH" ]; then
    RSCRIPT_PATH=""
fi

# 2. If it is not in the PATH, search in known macOS and Linux directories
if [ -z "$RSCRIPT_PATH" ]; then
    SEARCH_PATHS=(
        "/usr/bin/Rscript"
        "/usr/local/bin/Rscript"
        "/opt/homebrew/bin/Rscript"
        "/Library/Frameworks/R.framework/Resources/bin/Rscript"
        "/Library/Frameworks/R.framework/Versions/Current/Resources/bin/Rscript"
    )
    for path in "${SEARCH_PATHS[@]}"; do
        if [ -x "$path" ]; then
            RSCRIPT_PATH="$path"
            break
        fi
    done
fi

# 3. Runs the app or displays an error box
if [ -n "$RSCRIPT_PATH" ]; then
    cd "$APP_DATA_PATH" || exit 1
    nohup "$RSCRIPT_PATH" "$R_FILE" >/dev/null 2>&1 &
else
    # Displays native GUI error dialogs depending on the OS
    MSG="R was not found on this computer. Please install R to continue."
    TITLE="Dependency Error"

    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS native popup
        osascript -e "display dialog \"$MSG\" with title \"$TITLE\" buttons {\"OK\"} default button \"OK\" with icon stop" 2>/dev/null

    # 1. KDE Plasma native dialog (kdialog)
    elif command -v kdialog >/dev/null 2>&1; then
        kdialog --error "$MSG" --title "$TITLE" 2>/dev/null

    # 2. GNOME / GTK native dialog (zenity)
    elif command -v zenity >/dev/null 2>&1; then
        zenity --error --title="$TITLE" --text="$MSG" 2>/dev/null

    # 3. X11 universal fallback
    elif command -v xmessage >/dev/null 2>&1; then
        xmessage -center -title "$TITLE" "$MSG" 2>/dev/null

    # 4. Critical notification popup (KDE System Tray fallback)
    elif command -v notify-send >/dev/null 2>&1; then
        notify-send -u critical -i dialog-error "$TITLE" "$MSG" 2>/dev/null

    # 5. Konsole / Terminal window fallback for KDE
    else
        TERM_CMD="echo '[$TITLE]'; echo '$MSG'; echo ''; read -p 'Press Enter to close...' key"
        if command -v konsole >/dev/null 2>&1; then
            konsole -e bash -c "$TERM_CMD"
        elif command -v x-terminal-emulator >/dev/null 2>&1; then
            x-terminal-emulator -e bash -c "$TERM_CMD"
        elif command -v gnome-terminal >/dev/null 2>&1; then
            gnome-terminal -- bash -c "$TERM_CMD"
        elif command -v xterm >/dev/null 2>&1; then
            xterm -e bash -c "$TERM_CMD"
        fi
    fi
fi