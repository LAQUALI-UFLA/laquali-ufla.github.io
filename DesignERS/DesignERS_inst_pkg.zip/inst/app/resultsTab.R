# =========================
# UI
# =========================

appResultsUI <- tabPanel("Results", fluidRow(
  # -------------------------
  # LEFTY
  # -------------------------
  column(width = 3, wellPanel(
    style = "padding-top:0px;",
    h3("No analyzable design."),
    uiOutput("res_left_panel")
  )),
  
  # -------------------------
  # CENTER
  # -------------------------
  column(
    width = 7,
    uiOutput("res_plot_container"),
    br(),
    uiOutput("res_tables"),
    br(),
    br()
  ),
  
  # -------------------------
  # RIGHT
  # -------------------------
  column(
    width = 2,
    wellPanel(
      style = "padding-top:0px;",
      h3("Plot settings"),
      numericInput(
        "val_cex",
        "Font factor:",
        value = 0.7,
        min = 0.3,
        max = 2,
        step = 0.1
      ),
      exportPlotUI("res_plot_export")
    )
  )
))

# =========================
# SERVER
# =========================

appResultsServer <- function(input, output, session, doe_mod_reactive) {
  # Auxiliary reactive to verify that responses are valid
  is_valid_resp <- reactive({
    mod <- doe_mod_reactive()
    req(mod)
    if (is.null(mod$resp) || ncol(mod$resp) == 0)
      return(FALSE)
    has_empty <- any(is.na(mod$resp)) ||
      any(mod$resp == "", na.rm = TRUE)
    return(!has_empty)
  })
  
  # ==========================================
  # 1. DYNAMIC LEFT-SIDE UI
  # ==========================================
  output$res_left_panel <- renderUI({
    req(is_valid_resp())
    mod <- doe_mod_reactive()
    plan_typ <- mod$plan_typ
    n_rep <- ncol(mod$resp)
    
    cent_pts <- sum(apply(mod$cod_plan, 1, function(x)
      all(x == 0)))
    n_factors <- ncol(mod$cod_plan)
    vars <- colnames(mod$exp_plan)
    
    ui_list <- list()
    
    if (plan_typ %in% c("PBD", "FFD", "FrFD")) {
      if (plan_typ == "PBD" && n_rep == 1 && cent_pts == 0) {
        ui_list$err_typ <- selectInput("err_typ", "Error type:", c("Dummy Variables" =
                                                                     "DM"))
      } else {
        ui_list$err_typ <- selectInput(
          "err_typ",
          "Error type:",
          c(
            "Pure Error" = "PE",
            "Residual Sum of Squares" = "SSR"
          )
        )
      }
      if (plan_typ != "PBD") {
        ui_list$two_w_eff <- checkboxInput("two_w_eff", "Two-Way Effects", TRUE)
      }
      if (!(plan_typ %in% c("PBD", "FrFD")) && n_factors > 2) {
        ui_list$three_w_eff <- checkboxInput("three_w_eff", "Three-Way Effects", TRUE)
      }
      if (cent_pts > 1) {
        ui_list$curv_ck <- checkboxInput("curv_ck", "Curvature check", TRUE)
      }
      ui_list$n_sig <- numericInput("n_sig", "Significance (%):", 5, 0.1, 100, 0.1)
      ui_list$graph_typ <- selectInput("graph_typ", "Plot type:", c("Pareto", "Contrast"))
      
      ui_list$contrast_opts <- conditionalPanel(
        condition = "input.graph_typ == 'Contrast'",
        selectInput("x_vals", "x:", vars, selected = vars[1]),
        selectInput(
          "contr_vals",
          "Contrast:",
          vars,
          selected = ifelse(length(vars) > 1, vars[2], vars[1])
        ),
        checkboxInput("pt_mean", "Means", TRUE),
        if (cent_pts > 1)
          checkboxInput("cent_pt", "Center point", TRUE)
        else
          NULL
      )
      
    } else if (plan_typ %in% c("CCD", "CFD")) {
      ui_list$err_typ <- selectInput("err_typ",
                                     "Error type:",
                                     c(
                                       "Pure Error" = "PE",
                                       "Residual Sum of Squares" = "SSR"
                                     ))
      ui_list$n_sig <- numericInput("n_sig", "Significance (%):", 5, 0.1, 100, 0.1)
      ui_list$graph_typ <- selectInput("graph_typ",
                                       "Plot type:",
                                       c("Pareto", "Parity", "Residuals", "Surface"))
      
      ui_list$surf_opts <- conditionalPanel(
        condition = "input.graph_typ == 'Surface'",
        selectInput("x_ax", "x:", vars, selected = vars[1]),
        selectInput("y_ax", "y:", vars, selected = ifelse(length(vars) >
                                                            1, vars[2], vars[1])),
        selectInput("plot_typ", "Surface type:", c("2D" = "cont", "3D" =
                                                     "surf")),
        conditionalPanel(
          condition = "input.plot_typ == 'surf'",
          numericInput(
            "phi",
            "Vertical rotation:",
            40,
            min = 1,
            max = 360
          ),
          numericInput(
            "theta",
            "Horizontal rotation:",
            40,
            min = 1,
            max = 360
          )
        ),
        selectInput(
          "colPa",
          "Colors:",
          c("FullSpec", "DarkSpec", "RightSpec", "LeftSpec", "Gray")
        ),
        if (n_factors > 2)
          rHandsontableOutput("fix_x_hot")
        else
          NULL
      )
      
    } else if (plan_typ %in% c("LAT3", "LAT6", "LAT10", "CEN7", "MIX")) {
      mod_opts <- c(
        "Linear" = "lin",
        "Quadratic" = "qua",
        "Special Cubic" = "scub",
        "Full Cubic" = "fcub"
      )
      if (plan_typ == "LAT3")
        mod_opts <- mod_opts[1]
      else if (plan_typ == "LAT6")
        mod_opts <- mod_opts[1:2]
      else if (plan_typ == "CEN7")
        mod_opts <- mod_opts[1:3]
      
      ui_list$mod_typ <- selectInput("mod_typ", "Model type:", mod_opts)
      ui_list$n_sig <- numericInput("n_sig", "Significance (%):", 5, 0.1, 100, 0.1)
      ui_list$graph_typ <- selectInput("graph_typ",
                                       "Plot type:",
                                       c("Parity", "Residuals", "Surface"))
      
      ui_list$surf_opts <- conditionalPanel(condition = "input.graph_typ == 'Surface'", selectInput(
        "colPa",
        "Colors:",
        c("FullSpec", "DarkSpec", "RightSpec", "LeftSpec", "Gray")
      ))
    }
    
    do.call(tagList, ui_list)
  })
  
  # ==========================================
  # 2. TABLE FOR FIX_X (TRANSPOSED)
  # ==========================================
  output$fix_x_hot <- renderRHandsontable({
    mod <- doe_mod_reactive()
    req(mod)
    
    # Calculate the averages
    means <- colMeans(as.matrix(mod$exp_plan), na.rm = TRUE)
    
    # Create a dataframe with factors in the ROWS
    fix_df <- data.frame(
      Factor = names(means),
      Value = as.numeric(means),
      stringsAsFactors = FALSE
    )
    
    rw <- max(nchar(rownames(fix_df))) * 8  # ~8 px per character
    
    rhandsontable(
      fix_df,
      contextMenu = FALSE,
      rowHeaderWidth = rw,
      rowHeaders = FALSE
    ) %>%
      hot_col("Factor", readOnly = TRUE) %>% # Name of the protected factor
      hot_col("Value", type = "numeric") %>% # Only the value is editable
      add_cop_head()
  })
  
  # ==========================================
  # 3. MODEL LOGIC (MOD_PROCESSED AND IGN_COEFS)
  # ==========================================
  
  ign_coefs_vec <- reactive({
    if (is.null(input$coef_checks_hot))
      return(NULL)
    df <- hot_to_r(input$coef_checks_hot)
    
    mod <- doe_mod_reactive()
    req(mod)
    is_mix <- mod$plan_typ %in% c("LAT3", "LAT6", "LAT10", "CEN7", "MIX")
    
    if ("Include" %in% colnames(df)) {
      if (is_mix) {
        # For mixtures, there is no intercept. Returns the actual values.
        return(df$Include)
      } else {
        # For other models, inject the intercept's TRUE value into the first position.
        return(c(TRUE, df$Include))
      }
    }
    return(NULL)
  })
  
  mod_processed <- reactive({
    req(is_valid_resp())
    mod <- doe_mod_reactive()
    plan_typ <- mod$plan_typ
    
    req(input$n_sig)
    
    # Retrieves the current interface settings
    ign <- ign_coefs_vec()
    
    if (plan_typ %in% c("PBD", "FFD", "FrFD")) {
      req(input$err_typ)
      mod <- doe_eff(
        mod,
        err_typ = input$err_typ,
        two_w_eff = isTRUE(input$two_w_eff),
        three_w_eff = isTRUE(input$three_w_eff),
        curv_ck = isTRUE(input$curv_ck),
        n_sig = input$n_sig
      )
      
    } else if (plan_typ %in% c("CCD", "CFD")) {
      req(input$err_typ)
      
      # Safety check: Calculates the base to verify the correct size
      mod_base <- doe_coefs(
        mod,
        err_typ = input$err_typ,
        ign_coefs = NULL,
        n_sig = input$n_sig
      )
      if (!is.null(ign) && length(ign) != nrow(mod_base$coef_res)) {
        ign <- NULL # If the size doesn't match (UI transition), reset to avoid the error
      }
      
      mod <- doe_coefs(
        mod,
        err_typ = input$err_typ,
        ign_coefs = ign,
        n_sig = input$n_sig
      )
      
    } else if (plan_typ %in% c("LAT3", "LAT6", "LAT10", "CEN7", "MIX")) {
      req(input$mod_typ)
      
      # Safety check: Calculates the base to verify the correct size
      mod_base <- doe_coefs(
        mod,
        mod_typ = input$mod_typ,
        ign_coefs = NULL,
        n_sig = input$n_sig
      )
      if (!is.null(ign) && length(ign) != nrow(mod_base$coef_res)) {
        ign <- NULL # If the size doesn't match (UI transition), reset to avoid the error
      }
      
      mod <- doe_coefs(
        mod,
        mod_typ = input$mod_typ,
        ign_coefs = ign,
        n_sig = input$n_sig
      )
    }
    
    return(mod)
  })
  
  # ==========================================
  # 4. TABLE DISPLAY
  # ==========================================
  output$res_tables <- renderUI({
    req(is_valid_resp())
    mod <- doe_mod_reactive()
    plan_typ <- mod$plan_typ
    
    if (plan_typ %in% c("PBD", "FFD", "FrFD")) {
      tagList(h4("Effects"), rHandsontableOutput("eff_res_hot"))
    } else {
      # Placing the Checks and Results Side by Side
      tagList(
        h4("Model coefficients"),
        fluidRow(
          column(3, rHandsontableOutput("coef_checks_hot")),
          column(9, rHandsontableOutput("coef_res_hot"))
        ),
        br(),
        h4("ANOVA"),
        rHandsontableOutput("anova_hot")
      )
    }
  })
  
  output$eff_res_hot <- renderRHandsontable({
    mod <- mod_processed()
    req(mod$eff_res)
    
    # colnames(mod$eff_res) <- c("Effect", "Error", "t", "p", "Significant")
    rw <- max(nchar(rownames(mod$eff_res))) * 8  # ~8 px per character
    
    rhandsontable(
      mod$eff_res,
      contextMenu = FALSE,
      rowHeaderWidth = rw,
      readOnly = TRUE
    ) %>%
      add_cop_head()
  })
  
  output$anova_hot <- renderRHandsontable({
    mod <- mod_processed()
    req(mod$anova)
    
    rw <- max(nchar(rownames(mod$anova))) * 8  # ~8 px per character
    
    rhandsontable(
      mod$anova,
      contextMenu = FALSE,
      readOnly = TRUE,
      rowHeaderWidth = rw,
      na = ""
    ) %>%
      hot_col(2, format = "0") %>%
      add_cop_head()
  })
  
  # New table specifically for checkboxes
  output$coef_checks_hot <- renderRHandsontable({
    mod <- doe_mod_reactive()
    is_mix <- mod$plan_typ %in% c("LAT3", "LAT6", "LAT10", "CEN7", "MIX")
    
    if (is_mix) {
      req(input$mod_typ)
      mod_base <- doe_coefs(
        mod,
        mod_typ = input$mod_typ,
        ign_coefs = NULL,
        n_sig = input$n_sig
      )
    } else {
      req(input$err_typ)
      mod_base <- doe_coefs(
        mod,
        err_typ = input$err_typ,
        ign_coefs = NULL,
        n_sig = input$n_sig
      )
    }
    
    req(mod_base$coef_res)
    
    # Get all the coefficient names
    todos_termos <- rownames(mod_base$coef_res)
    
    # Removes the first term only if it is NOT a mixture model
    if (is_mix) {
      termos_tabela <- todos_termos
    } else {
      termos_tabela <- todos_termos[-1]
    }
    
    # Create a dataframe containing only the “Include” column for the visible terms
    df <- data.frame(Include = rep(TRUE, length(termos_tabela)), row.names = termos_tabela)
    
    # Keeps the current state if it has already been modified
    current_ign <- isolate(ign_coefs_vec())
    
    if (!is.null(current_ign) &&
        length(current_ign) == length(todos_termos)) {
      if (is_mix) {
        df$Include <- current_ign
      } else {
        df$Include <- current_ign[-1]
      }
    }
    
    rw <- max(nchar(rownames(df))) * 8  # ~8 px per character
    
    rhandsontable(df, contextMenu = FALSE, rowHeaderWidth = rw) %>%
      hot_col(col = "Include",
              type = "checkbox",
              halign = "center") %>%
      add_cop_head()
  })
  
  # Table specifically for displaying the calculated results
  output$coef_res_hot <- renderRHandsontable({
    mod <- mod_processed()
    req(mod$coef_res)
    
    # Render the results dataframe showing the rownames (rowHeaders = TRUE by default)
    
    # colnames(mod$coef_res) <- c("Coefficient", "Error", "t", "p", "Significant")
    
    rw <- max(nchar(rownames(mod$coef_res))) * 8  # ~8 px per character
    
    rhandsontable(
      mod$coef_res,
      contextMenu = FALSE,
      readOnly = TRUE,
      rowHeaderWidth = rw
    ) %>%
      add_cop_head()
  })
  
  # ==========================================
  # 5. PLOT GENERATOR
  # ==========================================
  make_plot <- function() {
    mod <- mod_processed()
    req(input$graph_typ, input$val_cex)
    g_typ <- input$graph_typ
    plan_typ <- mod$plan_typ
    
    if (g_typ == "Pareto") {
      plot_pareto(mod, val_cex = input$val_cex)
    } else if (g_typ == "Contrast") {
      req(input$x_vals, input$contr_vals)
      plot_contrast(
        mod,
        x_vals = input$x_vals,
        contr_vals = input$contr_vals,
        pt_mean = isTRUE(input$pt_mean),
        cent_pt = isTRUE(input$cent_pt),
        val_cex = input$val_cex
      )
    } else if (g_typ == "Parity") {
      plot_parity(mod, val_cex = input$val_cex)
    } else if (g_typ == "Residuals") {
      plot_residuals(mod, val_cex = input$val_cex)
    } else if (g_typ == "Surface" &&
               plan_typ %in% c("CCD", "CFD")) {
      req(input$x_ax, input$y_ax, input$plot_typ, input$colPa)
      fix_x_vec <- NULL
      if (ncol(mod$cod_plan) > 2 && !is.null(input$fix_x_hot)) {
        fix_df <- hot_to_r(input$fix_x_hot)
        # Extracts the values from the “Value” column and assigns the names from the “Factor” column
        fix_x_vec <- fix_df$Value
        names(fix_x_vec) <- fix_df$Factor
      }
      plot_surf(
        mod,
        x = input$x_ax,
        y = input$y_ax,
        fix_x = fix_x_vec,
        colPa = input$colPa,
        plot_typ = input$plot_typ,
        theta = input$theta,
        phi = input$phi,
        val_cex = input$val_cex
      )
    } else if (g_typ == "Surface" &&
               plan_typ %in% c("LAT3", "LAT6", "LAT10", "CEN7", "MIX")) {
      req(input$colPa)
      plot_ternsurf(mod,
                    colPa = input$colPa,
                    val_cex = input$val_cex)
    }
  }
  
  # ==========================================
  # 6. EXPORTING THE PLOT
  # ==========================================
  output$main_plot <- renderPlot({
    req(is_valid_resp())
    make_plot()
  })
  
  export_controls <- exportPlotServer("res_plot_export", plot_fun = make_plot)
  
  output$res_plot_container <- renderUI({
    plotOutput(
      "main_plot",
      width  = paste0(export_controls$width(), "px"),
      height = paste0(export_controls$height(), "px")
    )
  })
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.