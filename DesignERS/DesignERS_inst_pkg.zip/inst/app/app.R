library(rhandsontable)
library(htmlwidgets)

# Graphic resolution
renderPlot96 <- function(expr, ..., res = 96) {
  expr <- substitute(expr)
  env  <- parent.frame()
  shiny::renderPlot(expr = eval(expr, env), ..., res = res)
}
assign("renderPlot", renderPlot96, envir = .GlobalEnv)

#========================
# Load functions e tabs
#========================
if ("rFunctions" %in% search())
  detach("rFunctions")
.fun <- new.env()
files <- sort(list.files("rFunctions", pattern = "\\.R$", full.names = TRUE))
invisible(lapply(files, source, local = .fun))
attach(.fun, name = "rFunctions")

source("resultsTab.R")
source("designTab.R")

#========================
# UI
#========================

ui <- fluidPage(
  tags$head(
    # Tell translators that this page must not be translated
    tags$meta(name = "google", content = "notranslate"),
    
    tags$script(
      HTML(
        "
        function disableTranslation() {
          document.documentElement.setAttribute('translate', 'no');
          document.documentElement.classList.add('notranslate');

          if (document.body) {
            document.body.setAttribute('translate', 'no');
            document.body.classList.add('notranslate');
          }
        }

        disableTranslation();

        document.addEventListener('DOMContentLoaded', function() {

          disableTranslation();

          const observer = new MutationObserver(function() {
            disableTranslation();
          });

          observer.observe(document.body, {
            childList: true,
            subtree: true
          });

        });
        "
      )
    ),
    
    tags$title("DesignERS"),
    tags$style(
      HTML(
        "
      body { font-size:12px; }
      h3 { font-size:16px; }
      label { font-size:12px; }
      .form-group { margin-bottom:4px !important; }

      /* Estilo base para os botões da navbar */
      .nav-btn {
        border: none !important;
        background: transparent;
        font-weight: normal;
        padding: 8px 15px;
        height: 100%;
        border-radius: 0px;
        transition: all 0.2s;
      }
      .nav-btn:focus, .nav-btn:active { outline: none !important; box-shadow: none !important; }
    "
      )
    )
  ),
  
  # Custom navigation bar
  fluidRow(
    style = "background-color: #f5f5f5;
           border-bottom: 1px solid #ccc;
           display: flex;
           align-items: stretch; /* Crucial para o botão encostar no topo/fundo */
           padding: 0px 0px 0px 15px; /* Padding apenas na esquerda do título */
           margin-bottom: 15px;
           height: 38px;",
    
    # Title in different colors
    div(
      style = "display: flex; align-items: center; margin-right: 20px; font-size: 18px; font-weight: bold;",
      span(style = "color: #0070C0;", "DesignE"),
      span(style = "color: #00B050;", "R"),
      span(style = "color: #FFC000;", "S")
    ),
    
    # Buttons
    uiOutput("navbar_buttons", style = "display: flex; align-items: stretch;"),
    
    div(style = "flex-grow: 1;"),
    
    # help & About
    div(
      style = "margin-left: auto; padding-right: 15px; height: 100%; display: flex; align-items: center; gap: 15px;",
      tags$a(
        "Help",
        href = "userGuide.pdf",
        target = "_blank",
        style = "font-size: 12px; color: #333; text-decoration: none; cursor: pointer;"
      ),
      actionLink("btn_about", "About", style = "font-size: 12px; color: #333;")
    )
  ),
  
  # Hidden tab panel
  tabsetPanel(id = "main_tabs", type = "hidden", appDOEUI, appResultsUI)
)

#========================
# SERVER
#========================

server <- function(input, output, session) {
  # 1. Variable to control the active tab
  current_tab <- reactiveVal("Design")
  
  # 2. Tab servers
  doe_mod <- reactiveVal(NULL)
  appDOEServer(input, output, session, doe_mod)
  appResultsServer(input, output, session, doe_mod)
  
  # 3. Dynamic rendering of Navbar buttons
  output$navbar_buttons <- renderUI({
    tagList(
      actionButton(
        "btn_tab_design",
        "Design",
        class = "nav-btn",
        style = if (current_tab() == "Design")
          "background-color: #337ab7 !important; color: white !important;"
        else
          "color: #333;"
      ),
      actionButton(
        "btn_tab_results",
        "Results",
        class = "nav-btn",
        style = if (current_tab() == "Results")
          "background-color: #337ab7 !important; color: white !important;"
        else
          "color: #333;"
      )
    )
  })
  
  # 4. Click to switch tabs
  observeEvent(input$btn_tab_design, {
    current_tab("Design")
    updateTabsetPanel(session, "main_tabs", selected = "Design")
  })
  
  observeEvent(input$btn_tab_results, {
    current_tab("Results")
    updateTabsetPanel(session, "main_tabs", selected = "Results")
  })
  
  # 5. About pop-up
  observeEvent(input$btn_about, {
    showModal(
      modalDialog(
        title = "About",
        tagList(
          # PNG no topo
          tags$div(
            style = "text-align:center; margin-bottom:10px;",
            tags$img(
              src = "logo_DesignERS.png",
              height = "48px",
              width = "48px"
            )
          ),
          HTML(
            "<div style='text-align: center; font-size: 14px;'>
          <b>
            <b><span style='color:#0070C0;'>DesignE</span><span style='color:#00B050;'>R</span><span style='color:#FFC000;'>S</span></b>
          </b><br>

          <span style='font-weight:bold; color:#0070C0;'>Design</span> of
          <span style='font-weight:bold; color:#0070C0;'>E</span>xperiments in
          <span style='font-weight:bold; color:#00B050;'>R</span> and
          <span style='font-weight:bold; color:#FFC000;'>S</span>hiny<br>

          Version 0.1 beta<br>
          <br>
          Cleiton A. Nunes<br>
          Federal University of Lavras<br>
          Brazil<br>
          2026<br>
          <br>
          <span style='font-size: 11px;'>
      This software is provided &quot;as is&quot;, without warranty of any kind, and is distributed under the terms of the GNU General Public License v3.0 (GPL-3.0).
    </span>
        </div>"
          )
        ),
        easyClose = TRUE,
        footer = modalButton("Close"),
        size = "s"
      )
    )
  })
}

shinyApp(ui, server)

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.