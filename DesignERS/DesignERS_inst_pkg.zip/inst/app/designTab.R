#========================
# UI
#========================

appDOEUI <- tabPanel("Design", fluidRow(
  # LEFT
  column(
    3,
    
    wellPanel(
      style = "padding-top:0px;",
      
      h3("Design setup"),
      
      selectInput(
        "plan_typ",
        "Design:",
        c(
          "Full" = "FFD",
          "Fractional" = "FrFD",
          "Plackett-Burman" = "PBD",
          "Center-Faced" = "CFD",
          "Central Composite" = "CCD",
          "3-factor Mixture" = "MIX"
        )
      ),
      
      uiOutput("ui_simp_typ"),
      uiOutput("ui_n_fac"),
      uiOutput("ui_cent_pts"),
      uiOutput("ui_frac_siz"),
      numericInput("n_rep", "N of replications:", 2, 1, 20, 1),
      numericInput("n_resp", "N of responses:", 1, 1, 10, 1),
      uiOutput("ui_resp_name"),
      uiOutput("ui_exp_lev"),
      br(),
      actionButton("run_design", "Design", class = "btn-primary"),
      br(),
      br(),
      downloadButton("save_doe", "Save DoE", class = "btn-success"),
      br(),
      br(),
      fileInput("load_doe", "Load DoE (.rds)", accept = ".rds")
    )
  ),
  
  # CENTER
  column(
    9,
    verbatimTextOutput("design_info"),
    br(),
    h4("Experimental factors"),
    rHandsontableOutput("plan_data"),
    br(),
    uiOutput("des_setup_ui"),
    br(),
    uiOutput("design_table_ui")
  )
))

#========================
# SERVER
#========================

appDOEServer <- function(input, output, session, doe_mod) {
  plan_data <- reactiveVal(NULL)
  des_setup <- reactiveVal(NULL)
  
  #====================
  # Design Info
  #====================
  output$design_info <- renderText({
    req(input$plan_typ)
    
    # Design types
    plan_name <- switch(
      input$plan_typ,
      "FFD" = "Full Factorial",
      "FrFD" = "Fractional Factorial",
      "PBD" = "Plackett-Burman",
      "CFD" = "Center-Faced",
      "CCD" = "Central Composite",
      "MIX" = "3-factor Mixture",
      input$plan_typ
    )
    
    # Create the base string
    base_text <- paste(plan_name, "Design")
    
    # Add the specific logic for the fractional model
    if (input$plan_typ == "FrFD") {
      req(input$n_fac, input$frac_siz)
      genrel_text <- doe_genrel(input$n_fac, as.numeric(input$frac_siz))
      return(paste0(base_text, "\n", genrel_text))
      
    } else {
      # Returns only the base text for the other designs
      return(base_text)
    }
  })
  
  #====================
  # Helper Function
  #====================
  update_desirability <- function(mod, ds) {
    has_empty <- any(is.na(mod$des_resp)) ||
      any(mod$des_resp == "", na.rm = TRUE)
    
    if (!has_empty) {
      y_dat <- as.data.frame(lapply(mod$des_resp, function(x)
        as.numeric(as.character(x))))
      opt_typ_vec <- unname(sapply(ds$Goal, function(g) {
        switch(
          as.character(g),
          "Maximize" = "LTB",
          "Minimize" = "STB",
          "Target" = "NTB",
          "LTB"
        )
      }))
      
      des_fun <- doe_des(
        y_dat   = y_dat,
        opt_typ = opt_typ_vec,
        lim_low = as.numeric(ds$`Lower limit`),
        lim_upp = as.numeric(ds$`Upper limit`),
        trg_val = as.numeric(ds$`Target`),
        s_val   = as.numeric(ds$s),
        s1_val   = as.numeric(ds$s1),
        s2_val   = as.numeric(ds$s2)
      )
      
      mod$resp <- as.data.frame(des_fun$glob_des)
      mod$des_fun <- des_fun
      colnames(mod$resp) <- paste("Desirability", 1:ncol(mod$resp), sep = ".")
      mod$des_setup <- ds
    }
    return(mod)
  }
  
  #====================
  # Dynamic inputs
  #====================
  
  output$ui_simp_typ <- renderUI({
    if (input$plan_typ == "MIX") {
      selectInput(
        "simp_typ",
        "Simplex type",
        c(
          "Lattice - 3 points" = "LAT3",
          "Lattice - 6 points" = "LAT6",
          "Lattice - 10 points" = "LAT10",
          "Centroid - 7 points" = "CEN7"
        )
      )
    }
  })
  
  output$ui_n_fac <- renderUI({
    if (input$plan_typ == "MIX")
      return(NULL)
    if (input$plan_typ == "FrFD")
      numericInput("n_fac", "N of factors:", 3, 3, 10, 1)
    else if (input$plan_typ == "PBD")
      numericInput("n_fac", "N of factors:", 2, 2, 20, 1)
    else
      numericInput("n_fac", "N of factors:", 2, 2, 10, 1)
  })
  
  output$ui_cent_pts <- renderUI({
    if (input$plan_typ == "MIX")
      return(NULL)
    
    # The CCD requires at least one central point to avoid quadratic collinearity
    min_cp <- if (input$plan_typ %in% c("CCD", "CFD"))
      1
    else
      0
    def_cp <- if (input$plan_typ %in% c("CCD", "CFD"))
      2
    else
      0
    
    numericInput("cent_pts", "N of center points:", def_cp, min_cp, 20, 1)
  })
  
  output$ui_frac_siz <- renderUI({
    req(input$plan_typ)
    if (input$plan_typ != "FrFD")
      return(NULL)
    vals <- switch(
      as.character(input$n_fac),
      "3" = c(-1),
      "4" = c(-1),
      "5" = c(-1, -2),
      "6" = c(-1, -2, -3),
      "7" = c(-1, -2, -3),
      "8" = c(-1, -2, -3, -4),
      "9" = c(-1, -2, -3, -4, -5),
      "10" = c(-1, -2, -3, -4, -5, -6)
    )
    selectInput("frac_siz", "Fraction size:", vals)
  })
  
  output$ui_resp_name <- renderUI({
    if (input$n_resp == 1)
      textInput("resp_name", "Response label:", "Y")
  })
  
  observe({
    if (input$plan_typ == "MIX")
      updateNumericInput(session,
                         "n_rep",
                         min = 2,
                         value = max(input$n_rep, 2))
    else
      updateNumericInput(session, "n_rep", min = 1)
  })
  
  observeEvent(c(input$n_rep, input$plan_typ), {
    req(!is.null(input$n_rep),
        !is.null(input$cent_pts),
        input$plan_typ)
    if (input$plan_typ == "MIX")
      return()
    
    min_cp <- if (input$plan_typ %in% c("CCD", "CFD"))
      1
    else
      0
    
    if (input$n_rep == 1) {
      # Without repetitions, at least 2 points are needed to generate degrees of freedom (Pure Error)
      updateNumericInput(session,
                         "cent_pts",
                         value = max(2, input$cent_pts),
                         min = 2)
    } else {
      # When using repetitions, the minimum limit for the design type is observed
      updateNumericInput(
        session,
        "cent_pts",
        value = max(min_cp, input$cent_pts),
        min = min_cp
      )
    }
  })
  
  output$ui_exp_lev <- renderUI({
    if (input$plan_typ != "MIX") {
      checkboxInput("exp_lev", "Experimental levels", value = FALSE)
    }
  })
  
  #====================
  # Editable factor table
  #====================
  
  observe({
    req(input$plan_typ)
    if (input$plan_typ != "MIX") {
      req(input$n_fac)
    }
    
    nfac <- if (input$plan_typ == "MIX")
      3
    else
      input$n_fac
    
    if (input$plan_typ == "CCD") {
      alpha <- round((2^nfac)^(1 / 4), 3)
      df <- data.frame(
        Factors = paste0("X", 1:nfac),
        rep(-alpha, nfac),
        rep(alpha, nfac),
        check.names = FALSE
      )
      colnames(df) <- c("Factors",
                        paste0("(-", round(alpha, 2), ")"),
                        paste0("(+", round(alpha, 2), ")"))
    } else if (input$plan_typ == "MIX") {
      df <- data.frame(
        Factors = paste0("X", 1:nfac),
        `(min.)` = rep(0, nfac),
        `(max.)` = rep(1, nfac),
        check.names = FALSE
      )
    } else {
      df <- data.frame(
        Factors = paste0("X", 1:nfac),
        `(-1)` = if (input$cent_pts == 0)
          rep("-1", nfac)
        else
          rep(-1, nfac),
        `(+1)` = if (input$cent_pts == 0)
          rep("1", nfac)
        else
          rep(1, nfac),
        check.names = FALSE
      )
    }
    rownames(df) <- paste0("X", 1:nfac)
    plan_data(df)
  })
  
  output$plan_data <- renderRHandsontable({
    req(plan_data())
    rhandsontable(plan_data(),
                  contextMenu = FALSE,
                  rowHeaders = TRUE) %>%
      add_cop_head()
  })
  observeEvent(input$plan_data, {
    plan_data(hot_to_r(input$plan_data))
  })
  
  #====================
  # Create design
  #====================
  
  observeEvent(input$run_design, {
    pd <- plan_data()
    
    # 1. Creating the Model Object
    if (input$plan_typ != "MIX") {
      mod <- doe_facplan(
        plan_typ = input$plan_typ,
        n_fac = input$n_fac,
        cent_pts = input$cent_pts,
        frac_siz = as.numeric(input$frac_siz)
      )
      mod <- doe_explan(
        mod,
        fac_names = pd[, 1],
        resp_name = input$resp_name,
        fac_min = pd[, 2],
        fac_max = pd[, 3]
      )
    } else {
      mod <- doe_mixplan(
        plan_typ = input$simp_typ,
        exp_var = pd[, 1],
        resp_name = input$resp_name,
        range_A = as.numeric(pd[1, 2:3]),
        range_B = as.numeric(pd[2, 2:3]),
        range_C = as.numeric(pd[3, 2:3])
      )
    }
    
    # 2. Initializing the Response Matrices
    if (input$n_resp == 1) {
      mod$resp <- as.data.frame(matrix("", nrow(mod$cod_plan), input$n_rep))
      colnames(mod$resp) <- paste(input$resp_name, 1:input$n_rep, sep = ".")
      mod$des_resp <- NULL
      des_setup(NULL) # Hide the desirability table if there is only one response
    } else {
      # Multiple responses: Prepare the raw data matrix and the desirability matrix
      mod$des_resp <- as.data.frame(matrix("", nrow(mod$cod_plan), input$n_rep * input$n_resp))
      colnames(mod$des_resp) <- paste(rep(paste0("Y", 1:input$n_resp), each = input$n_rep), 1:input$n_rep, sep = ".")
      
      mod$resp <- as.data.frame(matrix("", nrow(mod$cod_plan), input$n_rep))
      colnames(mod$resp) <- paste("Desirability", 1:input$n_rep, sep = ".")
      
      # 3. CREATING THE DES_SETUP TABLE (new plan = clean table)
      df_ds <- as.data.frame(matrix("", nrow = input$n_resp, ncol = 8))
      colnames(df_ds) <- c("Label",
                           "Goal",
                           "Lower limit",
                           "Upper limit",
                           "Target",
                           "s",
                           "s1",
                           "s2")
      df_ds$Label <- paste0("Y", 1:input$n_resp)
      df_ds$Goal <- "Maximize"
      df_ds$s <- 1
      df_ds$s1 <- 1
      df_ds$s2 <- 1
      
      mod$des_setup <- df_ds
      des_setup(df_ds)
    }
    
    #====================
    # Save UI state inside mod
    #====================
    
    mod$des_setup$ui <- list(
      plan_typ = input$plan_typ,
      simp_typ = input$simp_typ,
      n_fac = input$n_fac,
      cent_pts = input$cent_pts,
      frac_siz = input$frac_siz,
      n_rep = input$n_rep,
      n_resp = input$n_resp,
      resp_name = input$resp_name,
      exp_lev = input$exp_lev,
      
      # tables
      plan_data = plan_data(),
      des_setup = des_setup(),
      design_table = if (!is.null(input$design_table))
        hot_to_r(input$design_table)
      else
        NULL
    )
    
    doe_mod(mod)
  })
  
  #====================
  # des_setup table
  #====================
  
  output$des_setup_ui <- renderUI({
    if (is.null(des_setup()))
      return(NULL)
    tagList(h4("Response desirability"),
            rHandsontableOutput("des_setup"))
  })
  
  output$des_setup <- renderRHandsontable({
    req(des_setup())
    ds <- des_setup()
    
    rt <- rhandsontable(
      ds,
      contextMenu = FALSE,
      rowHeaders = FALSE,
      overflow = "visible"
    ) %>%
      hot_col("Lower limit", width = 80) %>%
      hot_col("Upper limit", width = 80) %>%
      hot_col(
        "Goal",
        type = "dropdown",
        source = c("Maximize", "Minimize", "Target"),
        strict = TRUE
      ) %>%
      add_cop_head()
    
    for (i in seq_len(nrow(ds))) {
      if (ds$Goal[i] %in% c("Maximize", "Minimize")) {
        rt <- rt %>%
          hot_cell(row = i,
                   col = "Target",
                   readOnly = TRUE) %>%
          hot_cell(row = i,
                   col = "s1",
                   readOnly = TRUE) %>%
          hot_cell(row = i,
                   col = "s2",
                   readOnly = TRUE)
      } else if (ds$Goal[i] == "Target") {
        rt <- rt %>%
          hot_cell(row = i,
                   col = "s",
                   readOnly = TRUE)
      }
    }
    return(rt)
  })
  
  observeEvent(input$des_setup, {
    ds <- hot_to_r(input$des_setup)
    mod <- doe_mod()
    ds_mod <- ds
    changed <- FALSE
    
    for (i in seq_len(nrow(ds_mod))) {
      # CASE: MAXIMIZE OR MINIMIZE
      if (ds_mod$Goal[i] %in% c("Maximize", "Minimize")) {
        if (!is.na(ds_mod$Target[i])) {
          ds_mod$Target[i] <- NA
          changed <- TRUE
        }
        if (!is.na(ds_mod$s1[i])) {
          ds_mod$s1[i] <- NA
          changed <- TRUE
        }
        if (!is.na(ds_mod$s2[i])) {
          ds_mod$s2[i] <- NA
          changed <- TRUE
        }
        if (is.na(ds_mod$s[i])) {
          ds_mod$s[i] <- 1
          changed <- TRUE
        }
        
        # CASE: TARGET
      } else if (ds_mod$Goal[i] == "Target") {
        if (!is.na(ds_mod$s[i])) {
          ds_mod$s[i] <- NA
          changed <- TRUE
        }
        if (is.na(ds_mod$s1[i])) {
          ds_mod$s1[i] <- 1
          changed <- TRUE
        }
        if (is.na(ds_mod$s2[i])) {
          ds_mod$s2[i] <- 1
          changed <- TRUE
        }
        
        # If Target is empty, calculate the average
        if (is.na(ds_mod$Target[i]) || ds_mod$Target[i] == "") {
          if (!is.null(mod) && !is.null(mod$des_resp)) {
            # Find the columns that belong to this answer
            resp_pattern <- paste0("^", ds_mod$Label[i], "\\.")
            cols <- grep(resp_pattern, colnames(mod$des_resp))
            vals <- as.numeric(as.matrix(mod$des_resp[, cols]))
            
            # If data is available, calculate the average; otherwise, leave it blank
            if (length(vals) > 0 && !all(is.na(vals))) {
              ds_mod$Target[i] <- round(mean(vals, na.rm = TRUE), 4)
              changed <- TRUE
            }
          }
        }
      }
    }
    
    if (changed) {
      des_setup(ds_mod)
      return()
    }
    
    # Updating names and calculating desirability
    if (!is.null(mod) && !is.null(mod$des_resp)) {
      n_resp <- nrow(ds)
      n_rep <- ncol(mod$des_resp) / n_resp
      new_names <- paste(rep(ds$Label, each = n_rep), 1:n_rep, sep = ".")
      
      if (!identical(colnames(mod$des_resp), new_names)) {
        colnames(mod$des_resp) <- new_names
        mod$des_setup <- ds
        doe_mod(mod)
      }
      
      has_empty <- any(is.na(mod$des_resp)) ||
        any(mod$des_resp == "", na.rm = TRUE)
      if (!has_empty) {
        new_mod <- update_desirability(mod, ds)
        if (!isTRUE(all.equal(mod$resp, new_mod$resp, check.attributes = FALSE))) {
          doe_mod(new_mod)
        }
      }
    }
  })
  
  #====================
  # design table
  #====================
  
  output$design_table_ui <- renderUI({
    req(doe_mod())
    tagList(h4("Experimental design"),
            rHandsontableOutput("design_table"))
  })
  
  output$design_table <- renderRHandsontable({
    req(doe_mod())
    mod <- doe_mod()
    
    # 1. Load the original data frame (with duplicate names)
    if (input$plan_typ == "MIX") {
      df <- if (!is.null(mod$des_resp))
        cbind(mod$exp_plan, mod$des_resp, mod$resp)
      else
        cbind(mod$exp_plan, mod$resp)
      
    } else {
      # Choose between experimental or coded levels
      des_lev <- if (isTRUE(input$exp_lev))
        mod$exp_plan
      else
        mod$cod_plan
      
      df <- if (!is.null(mod$des_resp))
        cbind(des_lev, mod$des_resp, mod$resp)
      else
        cbind(des_lev, mod$resp)
    }
    
    rownames(df) <- seq_len(nrow(df))
    
    # 2. Keep the original names
    orig_names <- colnames(df)
    
    # 3. Enforce unique names internally so the JSON doesn't break
    colnames(df) <- make.unique(orig_names)
    
    # 4. Runs `df` but instructs the table to use the `orig_names` in the view
    rt <- rhandsontable(
      df,
      contextMenu = FALSE,
      rowHeaders = TRUE,
      colHeaders = orig_names
    ) %>%
      hot_cols(readOnly = TRUE) %>%
      add_cop_head()
    
    cols_resp <- if (!is.null(mod$des_resp))
      colnames(mod$des_resp)
    else
      colnames(mod$resp)
    
    for (col in cols_resp) {
      rt <- rt %>% hot_col(col = col, readOnly = FALSE)
    }
    
    return(rt)
  })
  
  observeEvent(input$design_table, {
    req(doe_mod())
    mod <- doe_mod()
    df <- hot_to_r(input$design_table)
    
    if (!is.null(mod$des_resp)) {
      new_des_resp <- df[, colnames(mod$des_resp), drop = FALSE]
      
      # Stop if the response is identical
      if (isTRUE(all.equal(mod$des_resp, new_des_resp, check.attributes = FALSE))) {
        return()
      }
      
      mod$des_resp <- new_des_resp
      mod$resp <- df[, colnames(mod$resp), drop = FALSE]
      
      has_empty <- any(is.na(mod$des_resp)) ||
        any(mod$des_resp == "", na.rm = TRUE)
      
      if (!has_empty) {
        # Retrieves data from the setup table directly from the visual, if it exists
        ds <- if (!is.null(input$des_setup))
          hot_to_r(input$des_setup)
        else
          des_setup()
        
        if (!is.null(ds)) {
          limits_updated <- FALSE
          for (i in seq_len(nrow(ds))) {
            resp_pattern <- paste0("^", ds$Label[i], "\\.")
            cols <- grep(resp_pattern, colnames(mod$des_resp))
            vals <- as.numeric(as.matrix(mod$des_resp[, cols]))
            
            # Only fill in the limits automatically if the cell is blank
            if (is.na(ds$`Lower limit`[i]) ||
                ds$`Lower limit`[i] == "") {
              ds$`Lower limit`[i] <- round(min(vals, na.rm = TRUE), 4)
              limits_updated <- TRUE
            }
            if (is.na(ds$`Upper limit`[i]) ||
                ds$`Upper limit`[i] == "") {
              ds$`Upper limit`[i] <- round(max(vals, na.rm = TRUE), 4)
              limits_updated <- TRUE
            }
            if (is.na(ds$`Target`[i]) || ds$`Target`[i] == "") {
              ds$`Target`[i] <- round(mean(vals, na.rm = TRUE), 4)
              limits_updated <- TRUE
            }
          }
          
          if (limits_updated)
            des_setup(ds)
          mod <- update_desirability(mod, ds)
        }
        doe_mod(mod)
      }
      
    } else {
      # Handling when there is only one response
      new_resp <- df[, colnames(mod$resp), drop = FALSE]
      if (isTRUE(all.equal(mod$resp, new_resp, check.attributes = FALSE)))
        return()
      
      mod$resp <- as.data.frame(lapply(new_resp, function(x)
        as.numeric(as.character(x))))
      has_empty <- any(is.na(mod$resp)) ||
        any(mod$resp == "", na.rm = TRUE)
      if (!has_empty)
        doe_mod(mod)
    }
  })
  
  #====================
  # Save / Load
  #====================
  
  output$save_doe <- downloadHandler(
    filename = function() {
      paste0("DoE_", Sys.Date(), ".rds")
    },
    content = function(file) {
      req(doe_mod())
      mod <- doe_mod()
      
      # Saves partial UI inputs that haven't yet triggered a full re-render
      if (!is.null(input$design_table)) {
        df <- hot_to_r(input$design_table)
        if (!is.null(mod$des_resp)) {
          mod$des_resp <- df[, colnames(mod$des_resp), drop = FALSE]
        } else {
          mod$resp <- df[, colnames(mod$resp), drop = FALSE]
        }
      }
      if (!is.null(input$des_setup)) {
        mod$des_setup <- hot_to_r(input$des_setup)
      }
      
      # Update the UI's final state before saving
      mod$des_setup$ui <- list(
        plan_typ = input$plan_typ,
        simp_typ = input$simp_typ,
        n_fac = input$n_fac,
        cent_pts = input$cent_pts,
        frac_siz = input$frac_siz,
        n_rep = input$n_rep,
        n_resp = input$n_resp,
        resp_name = input$resp_name,
        exp_lev = input$exp_lev,
        
        plan_data = plan_data(),
        des_setup = des_setup(),
        design_table = if (!is.null(input$design_table))
          hot_to_r(input$design_table)
        else
          NULL
      )
      
      saveRDS(mod, file)
    }
  )
  
  observeEvent(input$load_doe, {
    mod <- readRDS(input$load_doe$datapath)
    
    ui <- mod$des_setup$ui
    
    if (!is.null(ui)) {
      updateSelectInput(session, "plan_typ", selected = ui$plan_typ)
      
      if (!is.null(ui$simp_typ))
        updateSelectInput(session, "simp_typ", selected = ui$simp_typ)
      
      if (!is.null(ui$n_fac))
        updateNumericInput(session, "n_fac", value = ui$n_fac)
      
      if (!is.null(ui$cent_pts))
        updateNumericInput(session, "cent_pts", value = ui$cent_pts)
      
      if (!is.null(ui$frac_siz))
        updateSelectInput(session, "frac_siz", selected = ui$frac_siz)
      
      if (!is.null(ui$n_rep))
        updateNumericInput(session, "n_rep", value = ui$n_rep)
      
      if (!is.null(ui$n_resp))
        updateNumericInput(session, "n_resp", value = ui$n_resp)
      
      if (!is.null(ui$resp_name))
        updateTextInput(session, "resp_name", value = ui$resp_name)
      
      if (!is.null(ui$exp_lev))
        updateCheckboxInput(session, "exp_lev", value = ui$exp_lev)
      
      if (!is.null(ui$plan_data))
        plan_data(ui$plan_data)
      
      if (!is.null(ui$des_setup))
        des_setup(ui$des_setup)
    }
    
    doe_mod(mod)
  })
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.