doe_explan <- function(doe_mod,
                       fac_names = NULL,
                       resp_name = NULL,
                       fac_min = NULL,
                       fac_max = NULL) {
  fac_plan <- doe_mod$cod_plan
  fac_plan <- as.matrix(fac_plan)
  n_fac <- ncol(fac_plan)
  
  # ---------------------------
  # Update resp_name
  # ---------------------------
  if (!is.null(resp_name))
    doe_mod$resp_name <- resp_name
  else
    print("resp_name não atualizado")
  
  # ---------------------------
  # checks
  # ---------------------------
  if ((!is.null(fac_min) && length(fac_min) != n_fac) ||
      (!is.null(fac_max) && length(fac_max) != n_fac)) {
    stop("fac_min and fac_max must have a size equal to the number of factors.")
  }
  
  # ---------------------------
  # detect data type
  # ---------------------------
  if (!is.null(fac_min) && !is.null(fac_max)) {
    is_text <- is.character(fac_min) || is.character(fac_max)
    
    # detect if it's only -1 and +1
    only_pm1 <- all(fac_plan %in% c(-1, 1))
    
    explan <- matrix(NA, nrow = nrow(fac_plan), ncol = n_fac)
    
    # ---------------------------
    # CASE 1: TEXT + only -1/+1
    # ---------------------------
    if (is_text && only_pm1) {
      for (j in 1:n_fac) {
        explan[, j] <- ifelse(fac_plan[, j] == -1, fac_min[j], fac_max[j])
      }
      
      explan <- as.data.frame(explan, stringsAsFactors = FALSE)
    }
    
    # ---------------------------
    # CASE 2: NUMERICAL (general)
    # ---------------------------
    else {
      fac_min <- as.numeric(fac_min)
      fac_max <- as.numeric(fac_max)
      
      # detect alpha
      max_abs <- apply(abs(fac_plan), 2, max)
      alpha <- ifelse(max_abs > 1, max_abs, 1)
      
      for (j in 1:n_fac) {
        x <- fac_plan[, j]
        
        center <- (fac_max[j] + fac_min[j]) / 2
        delta  <- (fac_max[j] - fac_min[j]) / (2 * alpha[j])
        
        explan[, j] <- center + x * delta
      }
      
      explan <- as.data.frame(explan)
    }
    
    doe_mod$exp_plan <- explan
  }
  
  # Update fac_names
  if (!is.null(fac_names) && length(fac_names) == n_fac)
    colnames(doe_mod$exp_plan) <- fac_names
  else
    colnames(doe_mod$exp_plan) <- colnames(doe_mod$cod_plan)
  
  
  return(doe_mod)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.