plot_contrast <- function(doe_mod,
                          x_vals = "X1",
                          contr_vals = "X2",
                          pt_mean = TRUE,
                          cent_pt = FALSE,
                          val_cex = 0.7) {
  # 1. Extracting data from the DOE object
  exp_plan <- doe_mod$exp_plan
  
  # check if the factors are present in the plan
  if (!(x_vals %in% colnames(exp_plan)) |
      !(contr_vals %in% colnames(exp_plan))) {
    stop("Variables x_vals or contr_vals not found in doe_mod$exp_plan.")
  }
  
  x_data <- exp_plan[[x_vals]]
  c_data <- exp_plan[[contr_vals]]
  
  # combine all response columns (duplicates)
  y_name <- doe_mod$resp_name
  
  n_rep <- ncol(doe_mod$resp)
  
  # vector containing all the answers
  y <- as.vector(as.matrix(doe_mod$resp))
  
  # Repeat the experimental procedure for each replicate
  exp_plan <- exp_plan[rep(seq_len(nrow(exp_plan)), n_rep), ]
  
  # Update factors
  x_data <- exp_plan[[x_vals]]
  c_data <- exp_plan[[contr_vals]]
  
  # 2. Identifying high and low levels
  x_low <- min(x_data, na.rm = TRUE)
  x_high <- max(x_data, na.rm = TRUE)
  c_low <- min(c_data, na.rm = TRUE)
  c_high <- max(c_data, na.rm = TRUE)
  
  # Helper function to filter the ‘y’ response by levels
  get_y <- function(xv, cv) {
    y[x_data == xv & c_data == cv]
  }
  
  # Data for the 4 vertices of the contrast
  y_ll <- get_y(x_low, c_low)
  y_hl <- get_y(x_high, c_low)
  y_lh <- get_y(x_low, c_high)
  y_hh <- get_y(x_high, c_high)
  
  # Calculating averages
  m_ll <- mean(y_ll)
  sd_ll <- sd(y_ll)
  m_hl <- mean(y_hl)
  sd_hl <- sd(y_hl)
  m_lh <- mean(y_lh)
  sd_lh <- sd(y_lh)
  m_hh <- mean(y_hh)
  sd_hh <- sd(y_hh)
  
  #3. Treatment of the Central Point (if applicable and requested)
  y_cent <- c()
  x_cent_val <- NA
  if (cent_pt) {
    # Filter out points that are not extreme to isolate the central point
    idx_cent <- x_data != x_low &
      x_data != x_high & c_data != c_low & c_data != c_high
    y_cent <- y[idx_cent]
    if (length(y_cent) > 0) {
      x_cent_val <- mean(x_data[idx_cent]) # Position x from the center
    } else {
      warning("cent_pt=TRUE, but no center points were found in exp_plan.")
      cent_pt <- FALSE
    }
  }
  
  # 4. Adjust the Y-axis limits (to accommodate error bars if necessary)
  y_min <- min(y, na.rm = TRUE)
  y_max <- max(y, na.rm = TRUE) * 1
  
  if (pt_mean) {
    calc_bounds <- function(vals) {
      if (length(vals) == 0)
        return(c(NA, NA))
      m <- mean(vals)
      s <- sd(vals)
      if (is.na(s))
        s <- 0
      c(m - s, m + s)
    }
    bounds <- c(calc_bounds(y_ll),
                calc_bounds(y_hl),
                calc_bounds(y_lh),
                calc_bounds(y_hh))
    if (cent_pt)
      bounds <- c(bounds, calc_bounds(y_cent))
    
    y_min <- min(c(y_min, bounds), na.rm = TRUE)
    y_max <- max(c(y_max, bounds), na.rm = TRUE) * 1
  }
  
  # 5. Basic Plot Configuration
  
  # Colors and lines
  pal <- c("#619CFF", "#F8766D", "#00BA38")
  l_wd = 1.5
  pt_cont = "black"
  
  plot(
    NULL,
    xlim = c(x_low - 0.1 * (x_high - x_low), x_high + 0.1 * (x_high - x_low)),
    ylim = c(y_min, y_max),
    xlab = x_vals,
    ylab = y_name,
    xaxt = "n",
    cex.lab = val_cex,
    cex.axis = val_cex,
    las = 1
  )
  
  # Custom X-axis (Top, Bottom, and Center)
  eixo_x_ats <- c(x_low, x_high)
  if (cent_pt)
    eixo_x_ats <- c(x_low, x_cent_val, x_high)
  axis(1,
       at = eixo_x_ats,
       labels = eixo_x_ats,
       cex.axis = val_cex)
  
  # 6. Connecting lines (always connect the averages)
  lines(c(x_low, x_high),
        c(m_ll, m_hl),
        col = pal[1],
        lwd = l_wd) # Low Level
  lines(c(x_low, x_high),
        c(m_lh, m_hh),
        col = pal[2],
        lwd = l_wd)  # Upper Level
  
  # Helper function for drawing the error bar
  draw_error_bar <- function(x, m, s, cor) {
    if (!is.na(s) && s > 0) {
      arrows(
        x,
        m - s,
        x,
        m + s,
        length = 0.05,
        angle = 90,
        code = 3,
        col = cor,
        lwd = l_wd
      )
    }
  }
  
  # 7. Plotting Points (Means with error bars OR Raw data points)
  
  if (pt_mean) {
    # Low Level of contr_vals (Blue)
    draw_error_bar(x_low, m_ll, sd_ll, pal[1])
    draw_error_bar(x_high, m_hl, sd_hl, pal[1])
    points(
      c(x_low, x_high),
      c(m_ll, m_hl),
      pch = 21,
      col = pt_cont,
      bg = pal[1],
      cex = 1.2
    )
    
    # High level of contr_vals (Red)
    draw_error_bar(x_low, m_lh, sd_lh, pal[2])
    draw_error_bar(x_high, m_hh, sd_hh, pal[2])
    points(
      c(x_low, x_high),
      c(m_lh, m_hh),
      pch = 21,
      col = pt_cont,
      bg = pal[2],
      cex = 1.2
    )
    
  } else {
    # All individual points without error bars
    points(
      rep(x_low, length(y_ll)),
      y_ll,
      pch = 21,
      col = pt_cont,
      bg = pal[1]
    )
    points(
      rep(x_high, length(y_hl)),
      y_hl,
      pch = 21,
      col = pt_cont,
      bg = pal[1]
    )
    points(
      rep(x_low, length(y_lh)),
      y_lh,
      pch = 21,
      col = pt_cont,
      bg = pal[2]
    )
    points(
      rep(x_high, length(y_hh)),
      y_hh,
      pch = 21,
      col = pt_cont,
      bg = pal[2]
    )
  }
  
  # 8. Plotting the Center Point
  if (cent_pt) {
    if (pt_mean) {
      m_cent <- mean(y_cent)
      sd_cent <- sd(y_cent)
      draw_error_bar(x_cent_val, m_cent, sd_cent, pal[3])
      points(
        x_cent_val,
        m_cent,
        pch = 21,
        col = pt_cont,
        bg = pal[3],
        cex = 1.2
      )
    } else {
      points(
        rep(x_cent_val, length(y_cent)),
        y_cent,
        pch = 21,
        col = pt_cont,
        bg = pal[3]
      )
    }
  }
  
  #9. Legend
  usr <- par("usr")
  oldpar <- par(no.readonly = TRUE)
  par(xpd = NA)
  
  legend(
    x = mean(usr[1:2]),
    y = usr[4] * 1.15,
    xjust = 0.5,
    
    legend = if (cent_pt)
      c(
        paste(contr_vals, "(", c_low, ")", sep = ""),
        paste(contr_vals, "(", c_high, ")", sep = ""),
        "center point"
      )
    else
      c(
        paste(contr_vals, "(", c_low, ")", sep = ""),
        paste(contr_vals, "(", c_high, ")", sep = "")
      ),
    col = pt_cont,
    pch = 21,
    pt.cex = 1.2,
    pt.bg = if (cent_pt)
      c(pal[1], pal[2], pal[3])
    else
      c(pal[1], pal[2]),
    bty = "n",
    cex = val_cex,
    horiz = TRUE
  )
  
  # Restore margins
  par(oldpar)
  
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.