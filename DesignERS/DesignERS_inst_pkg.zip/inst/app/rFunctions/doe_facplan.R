doe_facplan <- function(plan_typ = "FFD",
                        # "PBD", "FFD", "FrFD", "CCD", "CFD"
                        n_fac = 2,
                        cent_pts = 3,
                        frac_siz = -1) {
  # ---------------------------
  # FULL FACTORIAL
  # ---------------------------
  if (plan_typ == "FFD") {
    ff <- as.matrix(expand.grid(rep(list(c(
      -1, 1
    )), n_fac)))[, n_fac:1]
  }
  
  # ---------------------------
  # FRACTIONAL FACTORIAL
  # ---------------------------
  else if (plan_typ == "FrFD") {
    if (n_fac < 2)
      stop("FrFD requires n_fac >= 2")
    frac_siz = abs(frac_siz)
    k_base <- n_fac - frac_siz
    base <- as.matrix(expand.grid(rep(list(c(
      -1, 1
    )), k_base)))[, k_base:1]
    
    ff <- base
    
    # generates additional factors such as product
    for (i in 1:frac_siz) {
      new_col <- apply(base, 1, prod)
      ff <- cbind(ff, new_col)
    }
    
    ff <- ff[, 1:n_fac, drop = FALSE]
  }
  
  # ---------------------------
  # CENTRAL COMPOSITE/CENTER-FACED DESIGN
  # ---------------------------
  else if (plan_typ == "CCD" || plan_typ == "CFD") {
    ff <- as.matrix(expand.grid(rep(list(c(
      -1, 1
    )), n_fac)))[, n_fac:1]
    
    alpha <- if (plan_typ == "CCD")
      (2^n_fac)^(1 / 4)
    else if (plan_typ == "CFD")
      1
    
    star <- matrix(0, nrow = 2 * n_fac, ncol = n_fac)
    for (i in 1:n_fac) {
      star[2 * i - 1, i] <- -alpha
      star[2 * i, i]   <-  alpha
    }
    
    ff <- rbind(ff, star)
  }
  
  # ---------------------------
  # PLACKETT-BURMAN
  # ---------------------------
  else if (plan_typ == "PBD") {
    # classical bases (N-1)
    pb_list <- list(
      "8"  = c(1, 1, 1, -1, 1, -1, -1),
      "12" = c(1, 1, -1, 1, 1, 1, -1, -1, -1, 1, -1),
      "16" = c(1, 1, 1, 1, -1, 1, -1, 1, 1, -1, -1, 1, -1, -1, -1),
      "20" = c(1, 1, -1, -1, 1, 1, 1, 1, -1, 1, -1, 1, -1, -1, -1, -1, 1, 1, -1)
    )
    
    sizes <- as.numeric(names(pb_list))
    
    # choose the smallest N such that N-1 >= n_fac
    N <- sizes[which(sizes - 1 >= n_fac)][1]
    
    if (is.na(N)) {
      stop("The number of factors is too large for PBD (max = 19)")
    }
    
    base <- pb_list[[as.character(N)]]
    
    # generate matrix
    ff <- matrix(NA, nrow = length(base), ncol = length(base))
    ff[, 1] <- base
    
    for (i in 2:ncol(ff)) {
      ff[, i] <- c(ff[nrow(ff), i - 1], ff[1:(nrow(ff) - 1), i - 1])
    }
    
    # adds final line of -1
    ff <- rbind(ff, rep(-1, ncol(ff)))
    
    # get dummy factors
    dmf <- ff[, (n_fac + 1):ncol(ff), drop = FALSE]
    colnames(dmf) <- paste0("X", (n_fac + 1):ncol(ff))
    
    # keep only the necessary number of factors
    ff <- ff[, 1:n_fac, drop = FALSE]
  }
  
  else {
    stop("Invalid type")
  }
  
  # ---------------------------
  # ADD CENTRAL POINTS (global)
  # ---------------------------
  if (cent_pts > 0) {
    center <- matrix(0, nrow = cent_pts, ncol = ncol(ff))
    ff <- rbind(ff, center)
  }
  
  colnames(ff) <- paste0("X", 1:ncol(ff))
  
  doe_mod <- list()
  doe_mod$plan_typ <- plan_typ
  doe_mod$cod_plan <- as.data.frame(ff)
  if (plan_typ == "PBD")
    doe_mod$cod_dum <- as.data.frame(dmf)
  
  doe_mod$exp_plan <- doe_mod$cod_plan
  doe_mod$resp_name <- "Y"
  
  return(doe_mod)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.