plot_pareto <- function(doe_mod, val_cex = 0.7) {
  # 1. Identify the type of plan and extract data
  if (doe_mod$plan_typ %in% c("CCD", "CFD")) {
    raw_vals <- doe_mod$coef_res$t
    raw_nomes <- rownames(doe_mod$coef_res)
    xlab_str <- "Standardized Effect (t value)"
    
  } else if (doe_mod$plan_typ %in% c("PBD", "FFD", "FrFD")) {
    # raw_vals <- doe_mod$eff_res$Effect
    raw_vals <- doe_mod$eff_res$t
    raw_nomes <- rownames(doe_mod$eff_res)
    # xlab_str <- "Effect (absolute value)"
    xlab_str <- "Standardized Effect (t value)"
    
  } else {
    stop("Planning type (plan_typ) not supported.")
  }
  
  # 2. Obtain absolute values and sort them into a Pareto chart
  abs_vals <- abs(raw_vals)
  ordem <- order(abs_vals, decreasing = FALSE)
  
  plot_vals <- abs_vals[ordem]
  plot_nomes <- raw_nomes[ordem]
  
  # 3. Set margins so that the names fit on the left (and wrap to the next line at the end)
  old_par <- par(no.readonly = TRUE)
  on.exit(par(old_par))
  
  # Estimates the space needed for the left margin based on the longest name
  max_nchar <- max(nchar(plot_nomes))
  par(mar = c(5, max(4, max_nchar * val_cex * 0.7), 4, 2) + 0.1)
  
  # 4. Create the bar chart
  max_x <- max(c(plot_vals, doe_mod$crit_pareto), na.rm = TRUE)
  
  bp <- barplot(
    plot_vals,
    names.arg = plot_nomes,
    horiz = TRUE,
    col = "lightgray",
    border = "black",
    xlab = xlab_str,
    las = 1,
    xlim = c(0, max_x * 1.2),
    cex.names = val_cex,
    cex.axis = val_cex,
    cex.lab = val_cex
  )
  
  # 5. Add labels with values to the right ends of the bars
  labels_str <- formatC(raw_vals[ordem], format = "f", digits = 3)
  text(
    x = plot_vals,
    y = bp,
    labels = labels_str,
    pos = 4,
    cex = val_cex
  )
  
  # 6. Add the red dotted critical line
  crit_pareto <- doe_mod$crit_pareto
  abline(
    v = crit_pareto,
    col = "red",
    lty = 3,
    lwd = 1
  )
  
  # 7. Add the text ‘p = alpha’ at the top of the line
  alpha <- doe_mod$n_sig / 100
  texto_alpha <- paste0("p = ", alpha)
  
  usr <- par("usr")
  text(
    x = crit_pareto,
    y = usr[4],
    labels = texto_alpha,
    col = "red",
    pos = 3,
    xpd = TRUE,
    cex = val_cex
  )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.