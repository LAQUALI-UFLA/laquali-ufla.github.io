plot_residuals <- function(doe_mod, val_cex = 0.7) {
  # 1. Data extraction and conversion
  medidos <- as.vector(as.matrix(doe_mod$resp))
  preditos <- as.vector(as.matrix(doe_mod$y_pred))
  residuals <- medidos - preditos
  
  # 2. Calculating the symmetric limits for the Y-axis
  max_res <- max(abs(residuals), na.rm = TRUE)
  
  # Add a margin so that the point isn't right up against the edge of the chart
  lim_y <- max_res * 1.05
  
  # 3. Base plot
  plot(
    x = preditos,
    y = residuals,
    ylim = c(-lim_y, lim_y),
    xlab = "Predicted",
    ylab = "Residuals",
    pch = 21,
    bg = "#619CFF",
    col = "black",
    cex.axis = val_cex,
    cex.lab = val_cex,
    las = 1
  )
  
  # 4. Zero reference line
  abline(
    h = 0,
    col = "black",
    lty = 2,
    lwd = 1.5
  )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.