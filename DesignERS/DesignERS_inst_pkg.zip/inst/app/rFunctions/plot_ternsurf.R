plot_ternsurf <- function(doe_mod,
                          colPa = "FullSpec",
                          val_cex = 0.7) {
  # =========================================================
  # Extract experimental design
  # =========================================================
  
  cod_plan <- doe_mod$cod_plan
  
  if (ncol(cod_plan) != 3) {
    stop("plot_ternsurf() requires exactly 3 mixture variables.")
  }
  
  comp_names <- colnames(doe_mod$exp_plan)
  
  # =========================================================
  # Generation of the ternary mesh
  # =========================================================
  n_grid = 500
  
  u <- seq(0, 1, length.out = n_grid)
  v <- seq(0, sqrt(3) / 2, length.out = n_grid)
  
  U <- matrix(rep(u, times = n_grid), nrow = n_grid, byrow = FALSE)
  
  V <- matrix(rep(v, times = n_grid), nrow = n_grid, byrow = TRUE)
  
  # ---------------------------------------------------------
  # Cartesian to Barycentric Transformation
  # ---------------------------------------------------------
  
  Y <- V / (sqrt(3) / 2)
  X <- U - Y / 2
  Z <- 1 - X - Y
  
  # =========================================================
  # Defines points outside the triangle
  # =========================================================
  
  fora_tri <- X < 0 | Y < 0 | Z < 0 |
    X > 1 | Y > 1 | Z > 1
  
  # =========================================================
  # Dataframe for prediction
  # =========================================================
  
  df_pred <- data.frame(matrix(nrow = length(as.vector(X)), ncol = ncol(cod_plan)))
  
  colnames(df_pred) <- colnames(cod_plan)
  
  df_pred[[1]] <- as.vector(Y)
  df_pred[[2]] <- as.vector(Z)
  df_pred[[3]] <- as.vector(X)
  
  # =========================================================
  # Reconstruction of the model matrix
  # =========================================================
  
  raw_names <- names(coef(doe_mod$mod_lm))
  clean_names <- gsub("^mod_matrix_exp", "", raw_names)
  
  terms <- clean_names[clean_names != "(Intercept)"]
  
  if (length(terms) > 0) {
    form_str <- paste("~ 0 +", paste(terms, collapse = " + "))
    
    X_pred <- model.matrix(as.formula(form_str), data = df_pred)
    
  } else {
    X_pred <- matrix(0, nrow = nrow(df_pred), ncol = 0)
  }
  
  # ---------------------------------------------------------
  # Intercept
  # ---------------------------------------------------------
  
  if ("(Intercept)" %in% clean_names) {
    X_pred <- cbind(`(Intercept)` = 1, X_pred)
  }
  
  # ---------------------------------------------------------
  # Sort columns
  # ---------------------------------------------------------
  
  X_pred <- X_pred[, clean_names, drop = FALSE]
  
  # =========================================================
  # Prediction
  # =========================================================
  
  coefs <- unname(coef(doe_mod$mod_lm))
  
  valid_idx <- !is.na(coefs)
  
  z_vec <- as.numeric(X_pred[, valid_idx, drop = FALSE] %*%
                        coefs[valid_idx])
  
  # =========================================================
  # Convert to an array
  # =========================================================
  
  z_mat <- matrix(z_vec,
                  nrow = n_grid,
                  ncol = n_grid,
                  byrow = FALSE)
  
  z_mat[fora_tri] <- NA
  
  # =========================================================
  # Actual component limits
  # =========================================================
  
  lims <- apply(doe_mod$exp_plan, 2, range, na.rm = TRUE)
  
  # right component
  c1 <- Y
  
  # left component
  c2 <- Z
  
  # bottom component
  c3 <- X
  
  # =========================================================
  # Visual restriction mask
  # =========================================================
  
  fora_limites <-
    c1 < lims[1, 1] | c1 > lims[2, 1] |
    c2 < lims[1, 2] | c2 > lims[2, 2] |
    c3 < lims[1, 3] | c3 > lims[2, 3]
  
  # =========================================================
  # Visual auxiliary matrix
  # =========================================================
  
  z_gray <- z_mat
  
  z_cont <- z_mat
  z_cont[fora_limites] <- NA
  
  z_gray[fora_limites & !fora_tri] <- min(z_mat, na.rm = TRUE) - 1
  
  # =========================================================
  # Color palettes
  # =========================================================
  
  if (colPa == "RightSpec") {
    pal <- colorRampPalette(
      # c("#00FF00", "#FFFF00", "#FF0000")
      c(
        "#05A04B",
        "#64AA46",
        "#D7B42D",
        "#E19B37",
        "#E16E41",
        "#E6323C"
      )
    )
  } else if (colPa == "LeftSpec") {
    pal <- colorRampPalette(c(
      "#4655F5",
      "#2D8CF0",
      "#2DC3A5",
      "#82C855",
      "#FFC837",
      "#F5E628"
    ))
  } else if (colPa == "FullSpec") {
    pal <- colorRampPalette(
      c("#23AAE1", "#0AA050", "#FFDC37", "#F5962D", "#F0413C")
      # c(
      #   "#3300FF",
      #   "#0038FF",
      #   "#00A3FF",
      #   "#00FFF0",
      #   "#00FF85",
      #   "#00FF19" ,
      #   "#52FF00" ,
      #   "#BDFF00",
      #   "#FFD600",
      #   "#FF6B00",
      #   "#FF0000"
      # )
    )
  } else if (colPa == "DarkSpec") {
    pal <- colorRampPalette(
      c(
        "#5A4BA0",
        "#00A0B4",
        "#69D7AF",
        "#E6FAB4",
        "#FAD77D",
        "#F0911E",
        "#C8413C",
        "#A51E4B"
      )
    )
  } else if (colPa == "Gray") {
    pal <- colorRampPalette(c("white", "gray90", "gray70", "gray50", "gray30", "gray10"))
  } else {
    pal <- colorRampPalette(c("blue", "white", "red"))
  }
  
  # =========================================================
  # Plotting
  # =========================================================
  
  oldpar <- par(no.readonly = TRUE)
  
  par(mar = c(3, 2, 4, 3), xpd = NA)
  
  # =========================================================
  # Configuring Breaks and Limits
  # =========================================================
  
  z_min_real <- min(z_mat, na.rm = TRUE)
  z_max_real <- max(z_mat, na.rm = TRUE)
  
  # Creates a sequence of breaks for the color palette
  # 1. The first break isolates the ‘gray’ value (min - 1)
  # 2. The remaining breaks divide the actual data range perfectly
  n_cores <- 200
  quebras_dados <- seq(z_min_real, z_max_real, length.out = n_cores + 1)
  todas_quebras <- c(z_min_real - 1.1, z_min_real - 0.5, quebras_dados)
  
  # Set the colors: Gray for the first break, white for the transition, and the palette
  cores_finais <- c("gray80", "white", pal(n_cores))
  
  # =========================================================
  # Scale and Mask Adjustment
  # =========================================================
  
  z_min <- min(z_mat, na.rm = TRUE)
  z_max <- max(z_mat, na.rm = TRUE)
  
  # Calculates the exact amount of 1 color from the palette (1/200th of the total)
  passo <- (z_max - z_min) / 200
  
  # Gray step
  z_gray[fora_limites & !fora_tri] <- z_min - passo
  
  # Defines breaks for the legend based solely on the actual data
  ticks_leg <- pretty(c(z_min, z_max))
  ticks_leg <- ticks_leg[ticks_leg >= z_min & ticks_leg <= z_max]
  
  # =========================================================
  # Plotting
  # =========================================================
  
  oldpar <- par(no.readonly = TRUE)
  par(mar = c(3, 2, 5, 3), xpd = NA)
  
  plot3D::image2D(
    z = z_gray,
    x = u,
    y = v,
    zlim = c(z_min - passo, z_max),
    col = c("gray80", pal(200)),
    NAcol = "white",
    rasterImage = TRUE,
    axes = FALSE,
    xlab = "",
    ylab = "",
    frame.plot = FALSE,
    contour = FALSE,
    clab = doe_mod$resp_name,
    colkey = list(
      at = ticks_leg,
      labels = ticks_leg,
      width = 0.7,
      dist = 0.05,
      tcl = -0.3,
      mgp = c(3, 0.5, 0),
      cex.axis = val_cex,
      cex.clab = val_cex,
      line.clab = 1.5,
      side.clab = 4,
      font.clab = 1
    )
  )
  
  contour(
    x = u,
    y = v,
    z = z_cont,
    add = TRUE,
    drawlabels = FALSE,
    col = "black",
    lwd = 0.5
  )
  
  # =========================================================
  # Edges of the triangle
  # =========================================================
  
  polygon(x = c(0, 1, 0.5),
          y = c(0, 0, sqrt(3) / 2),
          lwd = 2)
  
  # =========================================================
  # Vertex labels
  # =========================================================
  
  text(0.9, 0.5, comp_names[1], cex = val_cex)
  text(0.1, 0.5, comp_names[2], cex = val_cex)
  text(0.5, -0.1, comp_names[3], cex = val_cex)
  
  # =========================================================
  # Ticks
  # =========================================================
  
  ticks <- seq(0, 1, by = 0.2)
  ticksize <- 0.015
  
  # ---------------------------------------------------------
  # Lower axis
  # ---------------------------------------------------------
  
  for (i in ticks) {
    x0 <- i
    y0 <- 0
    
    segments(x0, y0, x0, y0 - ticksize)
    
    text(x0, y0 - 0.04, labels = sprintf("%.1f", i), cex = val_cex)
  }
  
  # ---------------------------------------------------------
  # Left axis
  # ---------------------------------------------------------
  
  for (i in ticks) {
    x0 <- 0.5 * i
    y0 <- (sqrt(3) / 2) * i
    
    dx <- ticksize * cos(pi / 6)
    dy <- ticksize * sin(pi / 6)
    
    segments(x0, y0, x0 - dx, y0 + dy)
    
    text(x0 - 0.05,
         y0 + 0.015,
         labels = sprintf("%.1f", 1 - i),
         cex = val_cex)
  }
  
  # ---------------------------------------------------------
  # Right axis
  # ---------------------------------------------------------
  
  for (i in ticks) {
    x0 <- 1 - 0.5 * i
    y0 <- (sqrt(3) / 2) * i
    
    dx <- ticksize * cos(pi / 6)
    dy <- ticksize * sin(pi / 6)
    
    segments(x0, y0, x0 + dx, y0 + dy)
    
    text(x0 + 0.05,
         y0 + 0.015,
         labels = sprintf("%.1f", i),
         cex = val_cex)
  }
  
  # =========================================================
  # Restore par()
  # =========================================================
  
  par(oldpar)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.