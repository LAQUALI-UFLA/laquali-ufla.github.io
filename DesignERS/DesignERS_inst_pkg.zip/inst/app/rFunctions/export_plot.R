exportPlotUI <- function(id) {
  ns <- NS(id)
  
  wellPanel(
    style = "padding-top:0px;",
    h3("Export graph"),
    
    numericInput(ns("width"), "Width (px):", 400, min = 100),
    numericInput(ns("height"), "Height (px):", 400, min = 100),
    
    selectInput(
      ns("format"),
      "Format:",
      c("PNG", "JPEG", "TIFF", "BMP", "SVG", "EPS", "PPTX")
    ),
    
    br(),
    
    downloadButton(ns("save"), "Save"),
    
    # br(),
    # br(),
    #
    # actionButton(ns("copy_bitmap"), "Copy as Bitmap"),
    # actionButton(ns("copy_vector"), "Copy as Vector")
  )
}

exportPlotServer <- function(id, plot_fun) {
  moduleServer(id, function(input, output, session) {
    output$save <- downloadHandler(
      # filename = function() {
      #   paste0("plot.", tolower(input$format))
      # },
      
      filename = function() {
        if (input$format == "PPTX") {
          "plot.pptx"
        } else {
          paste0("plot.", tolower(input$format))
        }
      },
      
      content = function(file) {
        width  <- input$width
        height <- input$height
        fmt    <- input$format
        
        # if (fmt == "PPTX") {
        #   plot_fun()
        #
        #   export::graph2ppt(file = file,
        #                     width = width / 96,
        #                     height = height / 96)
        #
        # }
        
        if (fmt == "PPTX") {
          slide_w <- 10
          slide_h <- 7.5
          
          w_in <- width / 96
          h_in <- height / 96
          
          left <- (slide_w - w_in) / 2
          top  <- (slide_h - h_in) / 2
          
          doc <- officer::read_pptx()
          
          doc <- officer::add_slide(doc, layout = "Title and Content", master = "Office Theme")
          
          doc <- officer::ph_with(
            doc,
            rvg::dml(code = {
              plot_fun()
            }),
            location = officer::ph_location(
              left = left,
              top = top,
              width = w_in,
              height = h_in
            )
          )
          
          print(doc, target = file)
          
        }
        
        
        else {
          switch(
            fmt,
            "PNG"  = png(
              file,
              width = width,
              height = height,
              units = "px"
            ),
            "JPEG" = jpeg(
              file,
              width = width,
              height = height,
              units = "px"
            ),
            "TIFF" = tiff(
              file,
              width = width,
              height = height,
              units = "px"
            ),
            "BMP"  = bmp(
              file,
              width = width,
              height = height,
              units = "px"
            ),
            "SVG"  = svg(file, width = width / 96, height = height / 96),
            "EPS" = cairo_ps(
              file,
              onefile = FALSE,
              width = width / 96,
              height = height / 96,
              fallback_resolution = 600
            )
          )
          
          plot_fun()
          dev.off()
        }
      }
    )
    
    return(list(
      width  = reactive(input$width),
      height = reactive(input$height)
    ))
  })
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.