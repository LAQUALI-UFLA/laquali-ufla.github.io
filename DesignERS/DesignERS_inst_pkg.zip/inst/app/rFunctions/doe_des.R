doe_des <- function(y_dat,
                    opt_typ = NULL,
                    lim_low = NULL,
                    lim_upp = NULL,
                    trg_val = NULL,
                    s_val = NULL,
                    s1_val = NULL,
                    s2_val = NULL) {
  # https://cran.r-project.org/web/packages/desirability/vignettes/desirability.pdf
  #--------------------------------------------------
  # checks
  #--------------------------------------------------
  y_dat <- as.data.frame(y_dat)
  
  if (is.null(colnames(y_dat)))
    stop("y_dat must have column names.")
  
  # detect responses
  resp_names <- sub("\\.[0-9]+$", "", colnames(y_dat))
  resp_names <- unique(resp_names)
  
  n_resp <- length(resp_names)
  
  # detect repetitions from suffix (.1, .2, ...)
  rep_lab <- sub("^.*\\.([0-9]+)$", "\\1", colnames(y_dat))
  rep_lab <- as.numeric(rep_lab)
  
  if (any(is.na(rep_lab)))
    stop("Column names must end with repetition labels like '.1', '.2', '.3'.")
  
  n_rep <- length(unique(rep_lab))
  
  # numeric matrix
  y_num <- as.matrix(y_dat)
  storage.mode(y_num) <- "numeric"
  
  n_obs <- nrow(y_num)
  
  # parameter lengths
  if (length(opt_typ) != n_resp)
    stop("opt_typ must have one value per response.")
  
  if (length(lim_low) != n_resp)
    stop("lim_low must have one value per response.")
  
  if (length(lim_upp) != n_resp)
    stop("lim_upp must have one value per response.")
  
  if (any(opt_typ == "NTB") && length(trg_val) != n_resp)
    stop("trg_val must have one value per response.")
  
  if (length(s1_val) != n_resp)
    stop("s1_val must have one value per response.")
  
  if (length(s_val) != n_resp)
    stop("s_val must have one value per response.")
  
  if (length(s2_val) != n_resp)
    stop("s2_val must have one value per response.")
  
  #--------------------------------------------------
  # individual desirabilities
  #--------------------------------------------------
  d_ind <- matrix(NA, nrow = n_obs, ncol = n_resp * n_rep)
  
  colnames(d_ind) <- colnames(y_num)
  
  for (i in seq_len(n_resp)) {
    cols <- which(sub("\\.[0-9]+$", "", colnames(y_num)) == resp_names[i])
    
    y <- y_num[, cols, drop = FALSE]
    
    L <- lim_low[i]
    U <- lim_upp[i]
    T <- trg_val[i]
    
    opt <- toupper(opt_typ[i])
    
    d <- matrix(0, nrow(y), ncol(y))
    
    #-----------------------------------
    # LTB
    #-----------------------------------
    if (opt == "LTB") {
      idx <- y >= L & y <= U
      
      d[idx] <- ((y[idx] - L) / (U - L))^s_val[i]
    }
    
    #-----------------------------------
    # NTB
    #-----------------------------------
    else if (opt == "NTB") {
      idx1 <- y >= L & y <= T
      idx2 <- y > T & y <= U
      
      d[idx1] <- ((y[idx1] - L) / (T - L))^s1_val[i]
      d[idx2] <- ((y[idx2] - U) / (T - U))^s2_val[i]
    }
    
    #-----------------------------------
    # STB
    #-----------------------------------
    else if (opt == "STB") {
      idx <- y >= L & y <= U
      
      d[idx] <- ((y[idx] - U) / (L - U))^s_val[i]
    }
    
    else {
      stop(paste0("Unknown opt_typ: ", opt, ". Use 'LTB', 'NTB', or 'STB'."))
    }
    
    d_ind[, cols] <- d
  }
  
  #--------------------------------------------------
  # global desirability
  # geometric mean across responses
  # for each repetition
  #--------------------------------------------------
  D <- matrix(NA, nrow = n_obs, ncol = n_rep)
  
  colnames(D) <- paste0("D", seq_len(n_rep))
  
  for (j in seq_len(n_rep)) {
    geo_cols <- seq(j, n_resp * n_rep, by = n_rep)
    
    D[, j] <- apply(d_ind[, geo_cols, drop = FALSE], 1, function(x)
      prod(x)^(1 / length(x)))
  }
  
  #--------------------------------------------------
  # output
  #--------------------------------------------------
  return(
    list(
      ind_des = as.data.frame(d_ind),
      glob_des = as.data.frame(D),
      n_resp = n_resp,
      n_rep = n_rep
    )
  )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.