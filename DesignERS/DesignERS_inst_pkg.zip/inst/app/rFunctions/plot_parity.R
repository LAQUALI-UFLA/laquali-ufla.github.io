plot_parity <- function(doe_mod, val_cex = 0.7) {
  # 1. Data extraction and conversion
  medidos <- as.vector(as.matrix(doe_mod$resp))
  preditos <- as.vector(as.matrix(doe_mod$y_pred))
  
  # 2. Setting the boundaries so that the graph is square and includes the origin
  max_val <- max(c(medidos, preditos), na.rm = TRUE)
  
  # Get the minimum value, ensuring that zero is visible on the graph
  min_val <- min(c(0, medidos, preditos), na.rm = TRUE)
  
  # Add a small margin at the top so the dots don't touch the edge
  lim_max <- max_val * 1.05
  
  # 3. Base plot
  plot(
    x = medidos,
    y = preditos,
    xlim = c(min_val, lim_max),
    ylim = c(min_val, lim_max),
    xlab = "Measured",
    ylab = "Predicted",
    pch = 21,
    bg = "#00BA38",
    col = "black",
    cex.axis = val_cex,
    cex.lab = val_cex,
    las = 1
  )
  
  #4. Parity line
  lines(
    x = c(0, lim_max),
    y = c(0, lim_max),
    col = "#F8766D",
    lwd = 1.5
  )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.