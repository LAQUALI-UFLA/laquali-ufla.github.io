doe_coefs <- function(doe_mod,
                      err_typ = "PE",
                      mod_typ = "lin",
                      ign_coefs = NULL,
                      n_sig = 5) {
  # ---------------------------
  # 1. Plan Type Validation
  # ---------------------------
  if (doe_mod$plan_typ %in% c("PBD", "FFD", "FrFD")) {
    message("Plan_typ é '",
            doe_mod$plan_typ,
            "'. Função não calcula nada para este tipo.")
    return(doe_mod)
  }
  
  # Determines whether it is a mixture model and forces the SSR
  is_mixture <- doe_mod$plan_typ %in% c("LAT3", "LAT6", "LAT10", "CEN7")
  if (is_mixture) {
    err_typ <- "SSR"
  }
  # --------------------------
  
  # ---------------------------
  # 2. Data Preparation
  # ---------------------------
  alpha <- n_sig / 100
  
  # Define x
  x <- as.matrix(doe_mod$cod_plan)
  
  # Define y_raw and calculate dimensions
  y_raw <- as.matrix(doe_mod$resp)
  n_reps <- ncol(y_raw)
  N <- nrow(y_raw)
  
  # ---------------------------
  # 3. Building the Model Matrix (Complete)
  # ---------------------------
  df_temp <- as.data.frame(x)
  x_names <- colnames(x)
  
  if (is_mixture) {
    # Scheffé formulas (without intercept: “0 +”) for 3 components
    if (mod_typ == "lin") {
      formula_str <- "~ 0 + ."
    } else if (mod_typ == "qua") {
      formula_str <- "~ 0 + .^2"
    } else if (mod_typ == "scub") {
      # Linear + pairwise interactions + three-way interaction
      formula_str <- paste0("~ 0 + .^2 + ", x_names[1], ":", x_names[2], ":", x_names[3])
    } else if (mod_typ == "fcub") {
      # Cubic asymmetry and triple interaction
      scub_term <- paste0(x_names[1], ":", x_names[2], ":", x_names[3])
      term12 <- paste0("I(",
                       x_names[1],
                       "*",
                       x_names[2],
                       "*(",
                       x_names[1],
                       "-",
                       x_names[2],
                       "))")
      term13 <- paste0("I(",
                       x_names[1],
                       "*",
                       x_names[3],
                       "*(",
                       x_names[1],
                       "-",
                       x_names[3],
                       "))")
      term23 <- paste0("I(",
                       x_names[2],
                       "*",
                       x_names[3],
                       "*(",
                       x_names[2],
                       "-",
                       x_names[3],
                       "))")
      
      formula_str <- paste("~ 0 + .^2 +", scub_term, "+", term12, "+", term13, "+", term23)
    } else {
      stop("mod_typ inválido para misturas. Use 'lin', 'qua', 'scub' ou 'fcub'.")
    }
  } else {
    # Original equation for conventional DoEs: intercept, linear terms, two-way interactions, and quadratic terms
    quad_terms <- paste0("I(", x_names, "^2)")
    formula_str <- paste("~ .^2 +", paste(quad_terms, collapse = " + "))
  }
  
  # Create the model matrix
  mod_matrix <- model.matrix(as.formula(formula_str), data = df_temp)
  
  # ---------------------------
  #4. Filter for Ignored Coefficients
  # ---------------------------
  if (!is.null(ign_coefs)) {
    if (length(ign_coefs) != ncol(mod_matrix)) {
      stop(
        paste(
          "The size of ign_coefs (",
          length(ign_coefs),
          ") must be equal to the number of terms in the model (",
          ncol(mod_matrix),
          ").",
          sep = ""
        )
      )
    }
    # Keeps only the columns where ign_coefs is 1
    mod_matrix <- mod_matrix[, as.logical(ign_coefs), drop = FALSE]
  }
  
  # ---------------------------
  #5. Data Expansion for Calculation
  # ---------------------------
  # Expand X and Y to easily handle repetitions and OLS (Ordinary Least Squares)
  mod_matrix_exp <- mod_matrix[rep(1:nrow(mod_matrix), n_reps), , drop = FALSE]
  y_expanded <- as.vector(y_raw)
  
  # Fits a linear model. The intercept is already in mod_matrix, so we use “0 +”
  mod_lm <- lm(y_expanded ~ 0 + mod_matrix_exp)
  coefs <- unname(coef(mod_lm))
  
  # Calculation of Experimental Coefficients
  df_exp_real <- as.data.frame(doe_mod$exp_plan)
  colnames(df_exp_real) <- colnames(doe_mod$cod_plan)
  # Generate the model matrix using the actual values (same formula)
  mod_matrix_real <- model.matrix(as.formula(formula_str), data = df_exp_real)
  
  # Applies the `ign_coefs` filter to maintain consistency with the encoded model
  if (!is.null(ign_coefs)) {
    mod_matrix_real <- mod_matrix_real[, as.logical(ign_coefs), drop = FALSE]
  }
  
  # Expand to include repetitions and adjust the actual model
  mod_matrix_real_full <- mod_matrix_real[rep(1:nrow(mod_matrix_real), n_reps), , drop = FALSE]
  mod_lm_exp <- lm(y_expanded ~ 0 + mod_matrix_real_full)
  
  # Save only the coefficients in the output object
  # doe_mod$coefs_exp <- unname(coef(mod_lm_exp))
  # -------------------------------------------------------------
  
  # ---------------------------
  # 6. Error Calculation (MSE and DF)
  # ---------------------------
  ms_error <- 0
  df_error <- 0
  
  if (err_typ == "PE") {
    # Uses a coded plan to identify exact groups/repetitions, just like in doe_eff
    x_cod <- as.matrix(doe_mod$cod_plan)
    groups <- apply(x_cod, 1, paste, collapse = "_")
    unique_groups <- unique(groups)
    ss_pe <- 0
    df_pe <- 0
    
    for (g in unique_groups) {
      idx <- which(groups == g)
      group_y <- as.vector(y_raw[idx, ])
      n_i <- length(group_y)
      
      if (n_i > 1) {
        ss_pe <- ss_pe + sum((group_y - mean(group_y))^2)
        df_pe <- df_pe + (n_i - 1)
      }
    }
    
    if (df_pe == 0) {
      warning("There are no degrees of freedom for Pure Error (PE). Consider using err_typ = ‘SSR’.")
      ms_error <- NA
      df_error <- NA
    } else {
      ms_error <- ss_pe / df_pe
      df_error <- df_pe
    }
    
  } else if (err_typ == "SSR") {
    # Sum of the squares of the residuals from the fitted model
    ss_res <- sum(mod_lm$residuals^2)
    df_error <- mod_lm$df.residual
    
    if (df_error == 0) {
      warning("There are no degrees of freedom for the residual error (SSR).")
      ms_error <- NA
    } else {
      ms_error <- ss_res / df_error
    }
  }
  
  # ---------------------------
  # 7. t-test and p-values
  # ---------------------------
  sum_mod <- summary(mod_lm)
  cov_unscaled <- sum_mod$cov.unscaled  # Unstrapped covariance matrix (X'X)^-1
  
  if (!is.na(ms_error)) {
    # Standard error of the coefficients = sqrt(diagonal of the cov_unscaled matrix * ms_error)
    se_coef <- sqrt(diag(cov_unscaled) * ms_error)
    t_val <- coefs / se_coef
    p_val <- 2 * (1 - pt(abs(t_val), df = df_error))
    sig <- ifelse(p_val < alpha, "*", "")
  } else {
    se_coef <- rep(NA, length(coefs))
    t_val <- rep(NA, length(coefs))
    p_val <- rep(NA, length(coefs))
    sig <- rep("", length(coefs))
  }
  
  # ---------------------------
  # 8. Naming
  # ---------------------------
  # Retrieve the original names from the model matrix
  all_names <- colnames(mod_matrix)
  
  # 1. Simplify the quadratic terms: from I(X1^2) to X1^2
  all_names <- gsub("I\\((.*)\\)", "\\1", all_names)
  all_names <- gsub("\\^2", "²", all_names)
  all_names <- gsub("\\:", ".", all_names)
  
  # 2. Apply aliases if exp_plan exists
  if (!is.null(doe_mod$exp_plan)) {
    coded_names <- colnames(doe_mod$cod_plan)
    real_names <- colnames(doe_mod$exp_plan)
    main_aliases <- paste0(coded_names, "(", real_names, ")")
    
    # Replaces only the main linear and quadratic effects
    for (i in 1:length(coded_names)) {
      # Replace linear term
      all_names[all_names == coded_names[i]] <- main_aliases[i]
    }
  }
  
  if (!is_mixture)
    all_names[1] <- "Intercept"
  
  # Creating the final dataframe with the processed names
  coef_res <- data.frame(
    Coefficient = coefs,
    Error = se_coef,
    t = t_val,
    p = p_val,
    Significant = sig,
    row.names = all_names
  )
  
  if (!isTRUE(all.equal(round(unname(doe_mod$cod_plan), 2), round(unname(doe_mod$exp_plan), 2)))) {
    coef_res$Experimental <- unname(coef(mod_lm_exp))
  }
  
  # ---------------------------
  # 9. ANOVA
  # ---------------------------
  # SS Total e SS Residual
  y_mean_global <- mean(y_expanded)
  ss_total <- sum((y_expanded - y_mean_global)^2)
  df_total <- length(y_expanded) - 1
  
  ss_resid <- sum(mod_lm$residuals^2)
  df_resid <- mod_lm$df.residual
  ms_resid <- ifelse(df_resid > 0, ss_resid / df_resid, NA)
  
  # SS Regression
  ss_reg <- ss_total - ss_resid
  # Checks if there is an intercept in the model to subtract 1 DF
  has_int <- "(Intercept)" %in% colnames(mod_matrix_exp)
  df_reg <- if (has_int || is_mixture)
    ncol(mod_matrix_exp) - 1
  else
    ncol(mod_matrix_exp)
  ms_reg <- ifelse(df_reg > 0, ss_reg / df_reg, NA)
  
  # F e p-value Regression
  f_reg <- ifelse(!is.na(ms_reg) &&
                    !is.na(ms_resid) && ms_resid > 0,
                  ms_reg / ms_resid,
                  NA)
  p_reg <- ifelse(!is.na(f_reg),
                  pf(f_reg, df_reg, df_resid, lower.tail = FALSE),
                  NA)
  
  # R² e Adjusted R²
  r_sq <- ifelse(ss_total > 0, ss_reg / ss_total, NA)
  adj_r_sq <- ifelse(!is.na(r_sq) &&
                       df_resid > 0, 1 - ((1 - r_sq) * (df_total / df_resid)), NA)
  
  # Recalculate Pure Error (PE) for the ANOVA (regardless of err_typ)
  x_cod_anova <- as.matrix(doe_mod$cod_plan)
  groups_anova <- apply(x_cod_anova, 1, paste, collapse = "_")
  unique_groups_anova <- unique(groups_anova)
  
  ss_pe_anova <- 0
  df_pe_anova <- 0
  
  for (g in unique_groups_anova) {
    idx <- which(groups_anova == g)
    group_y <- as.vector(y_raw[idx, ])
    n_i <- length(group_y)
    if (n_i > 1) {
      ss_pe_anova <- ss_pe_anova + sum((group_y - mean(group_y))^2)
      df_pe_anova <- df_pe_anova + (n_i - 1)
    }
  }
  
  # Lack-of-fit
  df_lof <- df_resid - df_pe_anova
  ss_lof <- ss_resid - ss_pe_anova
  
  # Construction of the ANOVA table based on the presence of lack-of-fit and pure error
  if (df_pe_anova > 0 && df_lof > 0) {
    # Scenario with sufficient repetitions and degrees of freedom
    ms_lof <- ss_lof / df_lof
    ms_pe <- ifelse(df_pe_anova > 0, ss_pe_anova / df_pe_anova, NA)
    
    f_lof <- ifelse(!is.na(ms_pe) && ms_pe > 0, ms_lof / ms_pe, NA)
    p_lof <- ifelse(!is.na(f_lof),
                    pf(f_lof, df_lof, df_pe_anova, lower.tail = FALSE),
                    NA)
    
    anova_tab <- data.frame(
      SS = c(
        ss_reg,
        ss_resid,
        ss_lof,
        ss_pe_anova,
        ss_total,
        r_sq,
        adj_r_sq
      ),
      DF = c(df_reg, df_resid, df_lof, df_pe_anova, df_total, NA, NA),
      MS = c(ms_reg, ms_resid, ms_lof, ms_pe, NA, NA, NA),
      F  = c(f_reg, NA, f_lof, NA, NA, NA, NA),
      p  = c(p_reg, NA, p_lof, NA, NA, NA, NA),
      row.names = c(
        "Regression",
        "Residual",
        "Lack-of-fit",
        "Pure error",
        "Total",
        "R²",
        "Adjusted R²"
      ),
      stringsAsFactors = FALSE
    )
    
    df_crit <- if (err_typ == "PE")
      df_pe_anova
    else if (err_typ == "SSR")
      df_resid
    
  } else {
    # Scenario with no pure error or no degrees of freedom for lack of fit
    anova_tab <- data.frame(
      SS = c(ss_reg, ss_resid, ss_total, r_sq, adj_r_sq),
      DF = c(df_reg, df_resid, df_total, NA, NA),
      MS = c(ms_reg, ms_resid, NA, NA, NA),
      F  = c(f_reg, NA, NA, NA, NA),
      p  = c(p_reg, NA, NA, NA, NA),
      row.names = c("Regression", "Residual", "Total", "R²", "Adjusted R²"),
      stringsAsFactors = FALSE
    )
    
    df_crit <- df_resid
  }
  
  # Clears the NAs to display empty cells
  # anova_tab[is.na(anova_tab)] <- ""
  
  # Appends the results to the original object
  doe_mod$coef_res <- coef_res
  doe_mod$anova <- anova_tab
  
  # ---------------------------
  #10. Predicted Values
  # ---------------------------
  # Extracts the adjusted values
  y_pred_mat <- matrix(fitted(mod_lm), nrow = N, ncol = n_reps)
  colnames(y_pred_mat) <- paste0("Pred_", colnames(doe_mod$resp))
  doe_mod$y_pred <- as.data.frame(y_pred_mat)
  
  # critical t
  doe_mod$crit_pareto <- qt(((1 - alpha + 1) / 2), df_crit)
  doe_mod$n_sig <- n_sig
  
  # save model
  doe_mod$mod_lm <- mod_lm
  doe_mod$mod_lm_exp <- mod_lm_exp
  
  return(doe_mod)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.