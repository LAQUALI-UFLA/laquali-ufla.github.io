add_cop_head <- function(tabela_hot) {
  tabela_hot %>%
    onRender(
      "
      function(el, x) {
        // SAFETY LOCK: Checks if the table has already received the copy rule
        if (el.copied_rule_added) {
          return; // If already received, stop here to avoid duplicates!
        }

        var hot = this.hot;

        hot.addHook('beforeCopy', function(data, coords) {
          var startRow = Math.min(coords[0].startRow, coords[0].endRow);
          var startCol = Math.min(coords[0].startCol, coords[0].endCol);
          var endCol = Math.max(coords[0].startCol, coords[0].endCol);

          for (var i = 0; i < data.length; i++) {
            var actualRowIndex = startRow + i;
            var rowHeader = hot.getRowHeader(actualRowIndex);
            data[i].unshift(rowHeader);
          }

          var colHeaders = [];
          colHeaders.push(''); // Empty space to align the top-left corner

          for (var j = startCol; j <= endCol; j++) {
            colHeaders.push(hot.getColHeader(j));
          }

          data.unshift(colHeaders);
        });

        // Mark this table as having already been configured so it won't run again
        el.copied_rule_added = true;
      }
    "
    )
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.