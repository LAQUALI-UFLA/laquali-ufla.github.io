plot_surf <- function(doe_mod,
                      x = "X1",
                      y = "X2",
                      fix_x = NULL,
                      colPa = "FullSpec",
                      plot_typ = "cont",
                      theta = 40,
                      phi = 40,
                      val_cex = 0.7) {
  # Index of factor names
  idx_x <- which(colnames(doe_mod$exp_plan) == x)
  idx_y <- which(colnames(doe_mod$exp_plan) == y)
  
  cod_x <- colnames(doe_mod$cod_plan)[idx_x]
  cod_y <- colnames(doe_mod$cod_plan)[idx_y]
  
  exp_plan <- doe_mod$exp_plan
  
  # 1. Validation of Factors X and Y
  if (!(x %in% colnames(exp_plan)) | !(y %in% colnames(exp_plan))) {
    stop("The variables ‘x’ or ‘y’ were not found in doe_mod$exp_plan.")
  }
  
  # 2. Handling fixed variables (fix_x)
  n_vars <- ncol(exp_plan)
  if (is.null(fix_x)) {
    # If `fix_x` is not provided, we center each column
    fix_x <- colMeans(exp_plan, na.rm = TRUE)
  } else {
    if (length(fix_x) != n_vars) {
      stop(
        paste(
          "The vector `fix_x` must have a length",
          n_vars,
          "(the same number of columns as in the exp_plan)."
        )
      )
    }
  }
  
  # 3. Generation of the grid for surface prediction
  n_grid <- 20
  x_seq <- seq(min(exp_plan[[x]], na.rm = TRUE),
               max(exp_plan[[x]], na.rm = TRUE),
               length.out = n_grid)
  y_seq <- seq(min(exp_plan[[y]], na.rm = TRUE),
               max(exp_plan[[y]], na.rm = TRUE),
               length.out = n_grid)
  
  # Create an empty dataframe with the same structure as the plan
  df_pred <- data.frame(matrix(nrow = n_grid * n_grid, ncol = n_vars))
  colnames(df_pred) <- colnames(doe_mod$cod_plan)
  
  # Fills columns with fixed values (the actual values from `fix_x`)
  for (i in 1:n_vars) {
    df_pred[, i] <- fix_x[i]
  }
  
  # Replace with the grid values using the mapped encoded names
  grid_xy <- expand.grid(X = x_seq, Y = y_seq)
  df_pred[[cod_x]] <- grid_xy$X  # cod_x was already defined at the beginning by idx_x
  df_pred[[cod_y]] <- grid_xy$Y  # cod_y has already been defined at the beginning by idx_y
  
  # 4. Calculating Z (Reconstructing the Model Matrix)
  # Extracts the coefficient names and removes the ‘mod_matrix_real_full’ prefix
  raw_names <- names(coef(doe_mod$mod_lm_exp))
  
  # Removes the prefix that R adds when using matrices in lm()
  clean_names <- gsub("^mod_matrix_real_full", "", raw_names)
  
  # Isolates the terms (X1, X2, X1:X2, I(X1^2), etc.)
  terms <- clean_names[clean_names != "(Intercept)"]
  
  # Generate the prediction matrix (now df_pred contains X1, X2...)
  if (length(terms) > 0) {
    # Protects terms such as X1:X2 or I(X1^2) using the model names
    form_str <- paste("~ 0 +", paste(terms, collapse = " + "))
    X_pred <- model.matrix(as.formula(form_str), data = df_pred)
  } else {
    X_pred <- matrix(0, nrow = nrow(df_pred), ncol = 0)
  }
  
  # Manually add the intercept column if the original model has one
  if ("(Intercept)" %in% clean_names) {
    X_pred <- cbind(`(Intercept)` = 1, X_pred)
  }
  
  # Ensures that the columns of the new matrix are in the exact order of the coefficients
  X_pred <- X_pred[, clean_names, drop = FALSE]
  
  # Isolates the pure coefficients
  coefs <- unname(coef(doe_mod$mod_lm_exp))
  
  # Robust matrix multiplication (ignores missing values if some coefficients have not been estimated)
  valid_idx <- !is.na(coefs)
  z_vec <- as.numeric(X_pred[, valid_idx, drop = FALSE] %*% coefs[valid_idx])
  
  # Convert the prediction vector into a matrix for the graph
  z_mat <- matrix(z_vec, nrow = n_grid, ncol = n_grid)
  
  #5. Defining the Color Palette
  if (colPa == "RightSpec") {
    pal <- colorRampPalette(
      # c("#00FF00", "#FFFF00", "#FF0000")
      c(
        "#05A04B",
        "#64AA46",
        "#D7B42D",
        "#E19B37",
        "#E16E41",
        "#E6323C"
      )
    )
  } else if (colPa == "LeftSpec") {
    pal <- colorRampPalette(c(
      "#4655F5",
      "#2D8CF0",
      "#2DC3A5",
      "#82C855",
      "#FFC837",
      "#F5E628"
    ))
  } else if (colPa == "FullSpec") {
    pal <- colorRampPalette(
      c("#23AAE1", "#0AA050", "#FFDC37", "#F5962D", "#F0413C")
      # c(
      #   "#3300FF",
      #   "#0038FF",
      #   "#00A3FF",
      #   "#00FFF0",
      #   "#00FF85",
      #   "#00FF19" ,
      #   "#52FF00" ,
      #   "#BDFF00",
      #   "#FFD600",
      #   "#FF6B00",
      #   "#FF0000"
      # )
    )
  } else if (colPa == "DarkSpec") {
    pal <- colorRampPalette(
      c(
        "#5A4BA0",
        "#00A0B4",
        "#69D7AF",
        "#E6FAB4",
        "#FAD77D",
        "#F0911E",
        "#C8413C",
        "#A51E4B"
      )
    )
  } else if (colPa == "Gray") {
    pal <- colorRampPalette(c("white", "gray90", "gray70", "gray50", "gray30", "gray10"))
  } else {
    pal <- colorRampPalette(c("blue", "white", "red"))
  }
  
  #6. Plotting
  
  if (plot_typ == "cont") {
    plot3D::image2D(
      z = z_mat,
      x = x_seq,
      y = y_seq,
      clab = doe_mod$resp_name,
      col = pal(100),
      contour = list(
        drawlabels = FALSE,
        col = "black",
        lwd = 0.5
      ),
      rasterImage = TRUE,
      xlab = x,
      ylab = y,
      cex.axis = val_cex,
      cex.lab = val_cex,
      tcl = -0.3,
      mgp = c(2, 0.5, 0),
      colkey = list(
        width = 0.7,
        tcl = -0.3,
        mgp = c(3, 0.5, 0),
        cex.axis = val_cex,
        cex.clab = val_cex,
        line.clab = 1.5,
        side.clab = 4,
        font.clab = 1
      )
    )
    
  } else if (plot_typ == "surf") {
    oldpar <- par(no.readonly = TRUE)
    par(mar = c(2, 2, 2, 2), xpd = NA)
    
    x_mat <- matrix(rep(x_seq, each = n_grid), nrow = n_grid)
    y_mat <- matrix(rep(y_seq, times = n_grid), nrow = n_grid)
    
    plot3D::persp3D(
      x = y_mat,
      y = x_mat,
      z = z_mat,
      border = "black",
      colvar = z_mat,
      col = pal(n_grid),
      theta = theta,
      phi = phi,
      xlab = paste("\n", x),
      ylab = paste("\n", y),
      zlab = paste("\n", doe_mod$resp_name),
      ticktype = "detailed",
      cex.axis = val_cex,
      cex.lab = val_cex,
      colkey = FALSE
    )
    
    # Restore margins
    par(oldpar)
  }
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.