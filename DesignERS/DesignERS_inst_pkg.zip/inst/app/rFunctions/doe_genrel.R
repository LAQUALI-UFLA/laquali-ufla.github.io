doe_genrel <- function(n_fac, frac_siz) {
  p <- abs(frac_siz)
  
  if (p != round(p))
    stop("frac_siz must be an integer >= 0")
  
  if (p == 0)
    return(paste0("2^", n_fac, " (full factorial), Resolution: Inf"))
  
  n_base <- n_fac - p
  
  if (n_base < 2)
    stop("Insufficient number of factors.")
  
  fac <- LETTERS[1:n_fac]
  
  basic <- fac[1:n_base]
  gen   <- fac[(n_base + 1):n_fac]
  
  rel <- character(p)
  
  for (i in seq_len(p)) {
    idx <- ((seq_len(n_base) + i - 2) %% n_base) + 1
    
    rel[i] <- paste0(gen[i], " = ", paste(basic[idx], collapse = ""))
  }
  
  # Resolution
  res <- n_fac - p + 1
  
  paste0("Generator: ",
         paste(rel, collapse = ", "),
         " | Resolution: ",
         as.roman(res))
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.