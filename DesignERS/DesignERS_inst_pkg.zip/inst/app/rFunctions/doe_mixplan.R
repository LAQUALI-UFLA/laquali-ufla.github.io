doe_mixplan <- function(plan_typ = "LAT3",
                        # "LAT3", "LAT6", "LAT10", "CEN7"
                        exp_var = c("X1", "X2", "X3"),
                        resp_name = "Y",
                        range_A = c(0, 1),
                        range_B = c(0, 1),
                        range_C = c(0, 1)) {
  am <- range_A[1]
  aM <- range_A[2]
  bm <- range_B[1]
  bM <- range_B[2]
  cm <- range_C[1]
  cM <- range_C[2]
  
  # ---------------------------
  # initial vertices
  # ---------------------------
  ffex <- rbind(c(1 - bm - cm, bm, cm), c(am, 1 - am - cm, cm), c(am, bm, 1 - am - bm))
  
  # ---------------------------
  # adjust vertex A
  # ---------------------------
  if (aM < 1 && aM < ffex[1, 1]) {
    iM <- which.max(ffex[1, ])
    iO <- setdiff(1:3, iM)
    
    np1 <- matrix(NA, 2, 3)
    
    np1[1, iM]    <- aM
    np1[1, iO[1]] <- bm
    np1[1, iO[2]] <- 1 - aM - bm
    
    np1[2, iM]    <- aM
    np1[2, iO[2]] <- cm
    np1[2, iO[1]] <- 1 - aM - cm
    
    if (all(np1[1, ] == np1[2, ]))
      np1 <- np1[1, , drop = FALSE]
  } else {
    np1 <- ffex[1, , drop = FALSE]
  }
  
  # ---------------------------
  # adjust vertex B
  # ---------------------------
  if (bM < 1 && bM < ffex[2, 2]) {
    iM <- which.max(ffex[2, ])
    iO <- setdiff(1:3, iM)
    
    np2 <- matrix(NA, nrow = 2, ncol = 3)
    
    np2[1, iM]     <- bM
    np2[1, iO[1]]  <- am
    np2[1, iO[2]]  <- 1 - bM - am
    
    np2[2, iM]     <- bM
    np2[2, iO[2]]  <- cm
    np2[2, iO[1]]  <- 1 - bM - cm
    
    if (all(np2[1, ] == np2[2, ]))
      np2 <- np2[1, , drop = FALSE]
  } else {
    np2 <- ffex[2, , drop = FALSE]
  }
  
  # ---------------------------
  # adjust vertex C
  # ---------------------------
  if (cM < 1 && cM < ffex[3, 3]) {
    iM <- which.max(ffex[3, ])
    iO <- setdiff(1:3, iM)
    
    np3 <- matrix(NA, 2, 3)
    
    np3[1, iM]    <- cM
    np3[1, iO[1]] <- am
    np3[1, iO[2]] <- 1 - cM - am
    
    np3[2, iM]    <- cM
    np3[2, iO[2]] <- bm
    np3[2, iO[1]] <- 1 - cM - bm
    
    if (all(np3[1, ] == np3[2, ]))
      np3 <- np3[1, , drop = FALSE]
  } else {
    np3 <- ffex[3, , drop = FALSE]
  }
  
  # adjusted base
  ffex <- rbind(np1, np2, np3)
  
  # ---------------------------
  # auxiliary calculations
  # ---------------------------
  lab <- np2[1, 2] - max(np1[, 2])
  lac <- np3[1, 3] - max(np1[, 3])
  lbc <- np3[1, 3] - max(np2[, 3])
  
  # ---------------------------
  # expansion according to type
  # ---------------------------
  if (plan_typ == "LAT3") {
    ff <- ffex
  }
  
  else if (plan_typ == "LAT6") {
    ff <- rbind(
      ffex,
      c(max(np2[, 1]) + 0.5 * lab, 1 - (max(np2[, 1]) + 0.5 * lab) - min(np2[, 3]), min(np2[, 3])),
      c(max(np3[, 1]) + 0.5 * lac, min(np3[, 2]), 1 - (max(np3[, 1]) + 0.5 *
                                                         lac) - min(np3[, 2])),
      c(min(np2[, 1]), 1 - min(np2[, 1]) - (max(np2[, 3]) + 0.5 * lbc), max(np2[, 3]) + 0.5 *
          lbc)
    )
  }
  
  else if (plan_typ == "LAT10") {
    ff <- rbind(
      ffex,
      c(max(np2[, 1]) + 1 / 3 * lab, 1 - (max(np2[, 1]) + 1 / 3 * lab) - min(np2[, 3]), min(np2[, 3])),
      c(max(np2[, 1]) + 2 / 3 * lab, 1 - (max(np2[, 1]) + 2 / 3 * lab) - min(np2[, 3]), min(np2[, 3])),
      c(max(np3[, 1]) + 1 / 3 * lac, min(np3[, 2]), 1 - (max(np3[, 1]) + 1 /
                                                           3 * lac) - min(np3[, 2])),
      c(max(np3[, 1]) + 2 / 3 * lac, min(np3[, 2]), 1 - (max(np3[, 1]) + 2 /
                                                           3 * lac) - min(np3[, 2])),
      c(min(np2[, 1]), 1 - min(np2[, 1]) - (max(np2[, 3]) + 1 / 3 * lbc), max(np2[, 3]) + 1 /
          3 * lbc),
      c(min(np2[, 1]), 1 - min(np2[, 1]) - (max(np2[, 3]) + 2 / 3 * lbc), max(np2[, 3]) + 2 /
          3 * lbc),
      colMeans(ffex)
    )
  }
  
  else if (plan_typ == "CEN7") {
    ff <- rbind(
      ffex,
      c(max(np2[, 1]) + 0.5 * lab, 1 - (max(np2[, 1]) + 0.5 * lab) - min(np2[, 3]), min(np2[, 3])),
      c(max(np3[, 1]) + 0.5 * lac, min(np3[, 2]), 1 - (max(np3[, 1]) + 0.5 *
                                                         lac) - min(np3[, 2])),
      c(min(np2[, 1]), 1 - min(np2[, 1]) - (max(np2[, 3]) + 0.5 * lbc), max(np2[, 3]) + 0.5 *
          lbc),
      colMeans(ffex)
    )
  }
  
  else {
    stop("Invalid type")
  }
  
  colnames(ff) <- c("X1", "X2", "X3")
  
  doe_mod <- list()
  doe_mod$plan_typ <- plan_typ
  doe_mod$cod_plan <- as.data.frame(ff)
  doe_mod$exp_plan <- doe_mod$cod_plan
  colnames(doe_mod$exp_plan) <- exp_var
  
  if (!is.null(resp_name)) {
    doe_mod$resp_name <- resp_name
  }
  
  return(doe_mod)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.