cv_pls <- function(df,
                   ncomp = 1,
                   scale = FALSE,
                   spl_type = "KS",
                   pro_test = 25,
                   cv = "LOO",
                   folds = 5)
{
  # ============================================================
  # Dataset split (external train/test)
  # ============================================================
  
  df_spt <- split_dataset(df, spl_type = spl_type, pro_test = pro_test)
  
  df_train <- df_spt$df_train

  # ============================================================
  # Build modeling data.frame
  # ============================================================
  
  # Extract predictor (X) and response (Y)
  dat <- data.frame(y = df_train$resp[, 1], df_train$xdat)
  
  # Limit the maximum number of components
  # ncomp <- min(ncomp, nrow(df_train$xdat) - 1, ncol(df_train$xdat))
  n_train <- nrow(df_train$xdat)
  n_cal <- if (cv == "LOO") {
    n_train - 1
  } else {
    # Para K-fold (VB ou RND)
    n_train - ceiling(n_train / folds)
  }
  ncomp <- min(ncomp, n_cal - 1, ncol(df_train$xdat))
  
  # ============================================================
  # PLS with internal cross-validation (pls::plsr)
  # ============================================================
  
  # Leave-One-Out cross-validation
  if (cv == "LOO") {
    plscv <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp,
      scale = scale,
      validation = "LOO"
    )
    
    # k-fold cross-validation using Venetian blinds
  } else if (cv == "VB") {
    plscv <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "interleaved"
    )
    
    # k-fold cross-validation using randomized segments
  } else if (cv == "RND") {
    plscv <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "random"
    )
    
    # Default: Leave-One-Out cross-validation
  } else {
    plscv <- pls::plsr(
      y ~ .,
      data = dat,
      ncomp = ncomp,
      scale = scale,
      validation = "LOO"
    )
  }
  
  # Detect optimal ncomp
  press <- plscv$validation$PRESS
  rmsecv <- sqrt(press[1, 1:ncomp] / nrow(dat))
  plscv$opt_ncomp <- as.numeric(detect_optimal_comp(rmsecv))

  # ============================================================
  # Store metadata and additional outputs
  # ============================================================
  
  plscv$row_names <- df_train$row_names
  plscv$groups    <- df_train$groups
  plscv$val_col   <- df_train$val_col
  plscv$xvals     <- df$val_col
  plscv$y_name    <- colnames(df_train$resp)
  plscv$col_names <- colnames(df_train$xdat)
  
  plscv$sgstp <- df_train$sgstp
  plscv$ppmet <- df_train$ppmet
  plscv$mx    <- df_train$mx
  
  plscv$prop_var <- pls::explvar(plscv)
  
  plscv$spl_type  <- spl_type
  plscv$pro_test  <- pro_test
  plscv$cv        <- cv
  plscv$folds     <- folds
  
  plscv$df_train <- df_train
  plscv$df_test  <- df_spt$df_test
  
  plscv$model_type <- "PLS"
  
  # ============================================================
  # Output
  # ============================================================
  
  return(plscv)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.