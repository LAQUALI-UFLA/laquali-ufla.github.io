cv_bvepls <- function(df,
                      ncomp = 1,
                      vip_lim = 1,
                      scale = FALSE,
                      spl_type = "KS",
                      pro_test = 25,
                      cv = "LOO",
                      folds = 5)
{
  # ============================================================
  # Dataset split (external train/test)
  # ============================================================
  
  df_spt <- split_dataset(df, spl_type = spl_type, pro_test = pro_test)
  df_train <- df_spt$df_train
  
  # ============================================================
  # Build modeling data.frame
  # ============================================================
  
  X <- df_train$xdat
  y <- df_train$resp[, 1]
  
  dat <- data.frame(y = y, X)
  
  # Limit the maximum number of components
  # ncomp <- min(ncomp, nrow(X) - 1, ncol(X))
  n_train <- nrow(X)
  n_cal <- if (cv == "LOO") {
    n_train - 1
  } else {
    n_train - ceiling(n_train / folds)
  }
  ncomp <- min(ncomp, n_cal - 1, ncol(X))
  
  # ============================================================
  # Functions
  # ============================================================
  
  get_metrics <- function(Xm) {
    datm <- data.frame(y = y, Xm)
    
    if (cv == "LOO") {
      mod <- pls::plsr(
        y ~ ., data = datm,
        ncomp = ncomp,
        scale = scale,
        validation = "LOO"
      )
    } else if (cv == "VB") {
      mod <- pls::plsr(
        y ~ ., data = datm,
        ncomp = ncomp,
        scale = scale,
        validation = "CV",
        segments = folds,
        segment.type = "interleaved"
      )
    } else {
      mod <- pls::plsr(
        y ~ ., data = datm,
        ncomp = ncomp,
        scale = scale,
        validation = "CV",
        segments = folds,
        segment.type = "random"
      )
    }
    
    press <- mod$validation$PRESS
    rmsecv <- sqrt(press[1, 1:ncomp] / nrow(Xm))
    
    lv <- detect_optimal_comp(rmsecv)
    rmse <- rmsecv[lv]
    
    tss <- sum((y - mean(y))^2)
    r2 <- 1 - press[1, lv] / tss
    
    return(list(lv = lv, rmse = rmse, r2 = r2, mod = mod))
  }
  
  # ============================================================
  # Global metrics
  # ============================================================
  
  glob <- get_metrics(X)
  
  # ============================================================
  # BVE loop
  # ============================================================
  
  varMet <- list()
  current_vars <- 1:ncol(X)
  
  for (iter in 1:ncol(X)) {
    
    Xm <- X[, current_vars, drop = FALSE]
    met <- get_metrics(Xm)
    
    varMet[[iter]] <- list(
      vars = current_vars,
      lv   = met$lv,
      rmse = met$rmse,
      r2   = met$r2
    )
    
    # Stop condition
    if (length(current_vars) <= (ncomp + 1)) break
    
    # VIP
    vip <- calc_vip(met$mod, opt.comp = met$lv)
    vip <- as.vector(vip)
    
    rem_idx <- which(vip < vip_lim)
    
    # fallback
    if (length(rem_idx) == 0) {
      rem_idx <- order(vip)[1]
    }
    
    # prevent collapse
    if ((length(current_vars) - length(rem_idx)) < (ncomp + 1)) {
      rem_idx <- order(vip)[1:(length(current_vars) - (ncomp + 1))]
    }
    
    current_vars <- current_vars[-rem_idx]
  }
  
  # ============================================================
  # Choosing the best iteration
  # ============================================================
  
  rmses <- sapply(varMet, function(x) x$rmse)
  
  best_iter <- which.min(rmses)
  
  best_vars <- varMet[[best_iter]]$vars
  
  # ============================================================
  # Final model
  # ============================================================
  
  dat <- data.frame(y = y, X[, best_vars, drop = FALSE])
  
  if (cv == "LOO") {
    bveplscv <- pls::plsr(
      y ~ ., data = dat,
      ncomp = ncomp,
      scale = scale,
      validation = "LOO"
    )
    
  } else if (cv == "VB") {
    bveplscv <- pls::plsr(
      y ~ ., data = dat,
      ncomp = ncomp,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "interleaved"
    )
    
  } else {
    bveplscv <- pls::plsr(
      y ~ ., data = dat,
      ncomp = ncomp,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "random"
    )
  }
  
  # ============================================================
  # Detect optimal ncomp
  # ============================================================
  
  press <- bveplscv$validation$PRESS
  rmsecv <- sqrt(press[1, 1:ncomp] / nrow(dat))
  bveplscv$opt_ncomp <- as.numeric(detect_optimal_comp(rmsecv))
  
  # ============================================================
  # Metadata
  # ============================================================
  
  bveplscv$xvals    <- df$val_col
  bveplscv$Xmean    <- colMeans(df$xdat)
  bveplscv$ncol     <- ncol(df$xdat)
  bveplscv$row_names <- df_train$row_names
  bveplscv$groups    <- df_train$groups
  bveplscv$val_col   <- df_train$val_col
  bveplscv$y_name    <- colnames(df_train$resp)
  bveplscv$col_names <- colnames(df_train$xdat)
  
  bveplscv$sgstp <- df_train$sgstp
  bveplscv$ppmet <- df_train$ppmet
  bveplscv$mx    <- df_train$mx
  
  bveplscv$prop_var <- pls::explvar(bveplscv)
  
  bveplscv$spl_type <- spl_type
  bveplscv$pro_test <- pro_test
  bveplscv$cv       <- cv
  bveplscv$folds    <- folds
  bveplscv$vip_lim  <- vip_lim

  bveplscv$df_train <- df_train
  bveplscv$df_test  <- df_spt$df_test
  
  bveplscv$model_type <- "BVE/PLS"
  
  # ============================================================
  # BVE info
  # ============================================================
  
  bveplscv$varMet <- varMet
  
  bveplscv$bestVars <- list(
    vars = best_vars,
    lv   = varMet[[best_iter]]$lv,
    rmse = varMet[[best_iter]]$rmse,
    r2   = varMet[[best_iter]]$r2
  )
  
  bveplscv$globMet <- list(
    lv   = glob$lv,
    rmse = glob$rmse,
    r2   = glob$r2
  )
  
  # ============================================================
  # Update columns
  # ============================================================
  
  bveplscv$col_names <- colnames(df_train$xdat)[best_vars]
  
  if (!is.null(bveplscv$val_col)) {
    bveplscv$val_col <- bveplscv$val_col[best_vars]
  }
  
  if (!is.null(bveplscv$mx)) {
    bveplscv$mxFull <- bveplscv$mx
    bveplscv$mx     <- bveplscv$mx[best_vars]
  }
  
  bveplscv$df_train$xdat <- df_train$xdat[, best_vars, drop = FALSE]
  
  if (!is.null(df_spt$df_test)) {
    bveplscv$df_test$xdat <- df_spt$df_test$xdat[, best_vars, drop = FALSE]
    
    if (!is.null(df_spt$df_test$val_col)) {
      bveplscv$df_test$val_col <- df_spt$df_test$val_col[best_vars]
    }
    
    if (!is.null(df_spt$df_test$mx)) {
      bveplscv$df_test$mx <- df_spt$df_test$mx[best_vars]
    }
  }
  
  return(bveplscv)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.