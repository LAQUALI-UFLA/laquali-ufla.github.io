create_shortcuts <- function() {
  app_dir <- system.file("app", package = "maRS")
  if (app_dir == "")
    return(FALSE)
  
  os <- Sys.info()["sysname"]
  
  if (os == "Windows") {
    ps_script <- normalizePath(file.path(app_dir, "maRS.ps1"),
                               winslash = "\\",
                               mustWork = FALSE)
    icon_path <- normalizePath(
      file.path(app_dir, "www", "logo_maRS.ico"),
      winslash = "\\",
      mustWork = FALSE
    )
    app_dir_win <- normalizePath(app_dir, winslash = "\\", mustWork = FALSE)
    
    ps_code <- sprintf(
      "
      $Wscript = New-Object -ComObject WScript.Shell;
      $StartMenu = Join-Path $env:APPDATA 'Microsoft\\Windows\\Start Menu\\Programs\\maRS';
      $Desktop = [Environment]::GetFolderPath('Desktop');

      if (-not (Test-Path $StartMenu)) { New-Item -Path $StartMenu -ItemType Directory -Force | Out-Null }

      $s1 = $Wscript.CreateShortcut((Join-Path $StartMenu 'maRS.lnk'));
      $s1.TargetPath = 'powershell.exe';
      $s1.Arguments = '-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File \"\"%s\"\"';
      $s1.WorkingDirectory = '%s';
      $s1.IconLocation = '%s';
      $s1.WindowStyle = 7;
      $s1.Save();

      $s2 = $Wscript.CreateShortcut((Join-Path $Desktop 'maRS.lnk'));
      $s2.TargetPath = 'powershell.exe';
      $s2.Arguments = '-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File \"\"%s\"\"';
      $s2.WorkingDirectory = '%s';
      $s2.IconLocation = '%s';
      $s2.WindowStyle = 7;
      $s2.Save();
    ",
      ps_script,
      app_dir_win,
      icon_path,
      ps_script,
      app_dir_win,
      icon_path
    )
    
    system2(
      "powershell",
      args = c(
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        shQuote(ps_code)
      ),
      stdout = FALSE,
      stderr = FALSE
    )
    
  } else if (os == "Linux") {
    sh_script <- file.path(app_dir, "maRS.sh")
    icon_path <- file.path(app_dir, "www", "logo_maRS.ico")
    desktop_dir <- file.path(Sys.getenv("HOME"), ".local", "share", "applications")
    desktop_file <- file.path(desktop_dir, "maRS.desktop")
    
    dir.create(desktop_dir,
               recursive = TRUE,
               showWarnings = FALSE)
    Sys.chmod(sh_script, "0755")
    
    content <- c(
      "[Desktop Entry]",
      "Version=1.0",
      "Type=Application",
      "Name=maRS",
      sprintf("Exec=bash \"%s\"", sh_script),
      sprintf("Icon=%s", icon_path),
      sprintf("Path=%s", app_dir),
      "Terminal=false",
      "Categories=Science;Education;"
    )
    writeLines(content, desktop_file)
    Sys.chmod(desktop_file, "0755")
    system("update-desktop-database ~/.local/share/applications 2>/dev/null",
           wait = FALSE)
    
  } else if (os == "Darwin") {
    sh_script <- file.path(app_dir, "maRS.sh")
    app_dir_mac <- file.path(Sys.getenv("HOME"), "Applications")
    app_bundle <- file.path(app_dir_mac, "maRS.app")
    
    Sys.chmod(sh_script, "0755")
    dir.create(app_dir_mac,
               recursive = TRUE,
               showWarnings = FALSE)
    
    cmd <- sprintf(
      'osacompile -o "%s" -e \'do shell script "bash \\"%s\\" > /dev/null 2>&1 &"\'',
      app_bundle,
      sh_script
    )
    system(cmd, ignore.stdout = TRUE, ignore.stderr = TRUE)
  }
  
  return(TRUE)
}


remove_shortcuts <- function() {
  os <- Sys.info()["sysname"]
  
  if (os == "Windows") {
    cmd <- 'powershell -NoProfile -ExecutionPolicy Bypass -Command "
      $Desktop = [Environment]::GetFolderPath(\'Desktop\');
      $StartMenu = Join-Path $env:APPDATA \'Microsoft\\Windows\\Start Menu\\Programs\\maRS\';
      Remove-Item \"$Desktop\\maRS.lnk\" -Force -ErrorAction SilentlyContinue;
      Remove-Item $StartMenu -Recurse -Force -ErrorAction SilentlyContinue;
    "'
    system(cmd, show.output.on.console = FALSE)
  } else if (os == "Linux") {
    unlink(file.path(
      Sys.getenv("HOME"),
      ".local",
      "share",
      "applications",
      "maRS.desktop"
    ))
  } else if (os == "Darwin") {
    unlink(file.path(Sys.getenv("HOME"), "Applications", "maRS.app"),
           recursive = TRUE)
  }
  
  message("maRS shortcuts removed from the system.")
}


uninstall_mars <- function() {
  remove_shortcuts()
  if ("maRS" %in% loadedNamespaces()) {
    unloadNamespace("maRS")
  }
  remove.packages("maRS")
  message("maRS and its shortcuts have been successfully uninstalled!")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("maRS ready for use.")
}

.onUnload <- function(libpath) {
  calls <- sys.calls()
  call_names <- unlist(lapply(calls, function(x) {
    tryCatch(
      deparse(x[[1]])[1],
      error = function(e)
        ""
    )
  }))
  
  if (any(c("remove.packages", "utils::remove.packages") %in% call_names)) {
    remove_shortcuts()
  }
}