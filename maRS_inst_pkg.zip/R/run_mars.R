# Main function exported to the user
run_mars <- function() {
  # Finds the app directory within the package installation
  appDir <- system.file("app", package = "maRS")
  
  if (appDir == "") {
    stop("App directory not found. Try reinstalling the `maRS` package.", call. = FALSE)
  }
  
  # Run the application
  shiny::runApp(appDir, display.mode = "normal")
}

runmars  <- run_mars