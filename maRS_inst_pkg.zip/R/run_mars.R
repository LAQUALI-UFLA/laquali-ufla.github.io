run_mars <- function() {
  start_script <- system.file("app", "start.R", package = "maRS")
  
  if (start_script == "") {
    stop("The start.R file was not found in the app folder. Try reinstalling the maRS package.", call. = FALSE)
  }
  
  source(start_script, chdir = TRUE)
}

runmars <- run_mars


