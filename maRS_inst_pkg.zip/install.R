options(repos = c(CRAN = "https://cloud.r-project.org"))

if ("maRS" %in% loadedNamespaces()) unloadNamespace("maRS")

if (!require("remotes", quietly = TRUE)) install.packages("remotes")

remotes::install_url("https://laquali-ufla.github.io/maRS_inst_pkg.zip", force = TRUE, upgrade = "always")

if ("maRS" %in% loadedNamespaces()) unloadNamespace("maRS")
library(maRS)

maRS::create_shortcuts(force = TRUE)