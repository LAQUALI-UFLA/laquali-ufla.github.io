pred_pls <- function(plsmod,
                     df,
                     ncomp = NULL,
                     prepro = FALSE,
                     varsel = FALSE)
{
  
  # Initialize output object as a list
  plspred <- list()
  
  # Apply preprocessing using the parameters from the training model
  
  if (prepro) {
    if (varsel && !is.null(plsmod$bestVars$vars) &&
        sum(plsmod$bestVars$vars) > 0) {
      mx <- plsmod$mxFull
    } else{
      mx <- plsmod$mx
    }
    
    df <- pre_pro(df,
                  ppmet = plsmod$ppmet,
                  sgstp = plsmod$sgstp,
                  mx = mx)
  }
  
  # Select variables (if iPLS)
  if (varsel && !is.null(plsmod$bestVars$vars) &&
      sum(plsmod$bestVars$vars) > 0) {
    selVar <- plsmod$bestVars$vars
    
    df$xdat <- df$xdat[, selVar, drop = FALSE]
    
    if (!is.null(df$val_col)) {
      df$val_col <- df$val_col[selVar]
    }
    
    if (!is.null(df$mx)) {
      df$mx <- df$mx[selVar]
    }
  }
  
  # Predict using the PLS model
  if (is.null(ncomp))
    ncomp <- plsmod$ncomp_sel
  
  x_pred <- data.frame(df$xdat)
  plspred$y_hat <- as.numeric(predict(plsmod, x_pred, ncomp = ncomp))
  
  # get actual y values
  if (!is.null(df$resp)) {
    plspred$y_actual <- drop(df$resp[, 1])
  }
  
  return(plspred)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.