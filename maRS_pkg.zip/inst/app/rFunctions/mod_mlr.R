mod_mlr <- function(df,
                    center = FALSE,
                    scale = FALSE,
                    spl_type = "KS",
                    pro_test = 25,
                    cv = "LOO",
                    folds = 5,
                    yrand = FALSE,
                    nrep = 10,
                    q_lod = 1)
{
  # ============================================================
  # Basic checks
  # ============================================================
  
  stopifnot(is.data.frame(df$xdat),
            is.data.frame(df$resp),
            ncol(df$resp) == 1)
  
  # ============================================================
  # Train/test split (raw data)
  # ============================================================
  
  df_spt <- split_dataset(df, spl_type = spl_type, pro_test = pro_test)
  
  df_train <- df_spt$df_train
  
  X <- as.matrix(df_train$xdat)
  y <- as.numeric(df_train$resp[, 1])
  n <- nrow(X)
  p <- ncol(X)
  
  # ============================================================
  # Object initialization
  # ============================================================
  
  mlrmod <- list()
  class(mlrmod) <- "mlrmod"
  mlrmod$xdat <- df_train$xdat
  mlrmod$q_lod <- q_lod
  
  # ============================================================
  # Centering and scaling (training set only)
  # ============================================================
  if (scale)
    center <- TRUE
  
  Xmeans <- rep(0, p)
  Xscale <- rep(1, p)
  
  if (center) {
    Xmeans <- colMeans(X)
    X <- sweep(X, 2, Xmeans, "-")
  }
  
  if (scale) {
    Xscale <- apply(X, 2, sd)
    Xscale[Xscale == 0] <- 1
    X <- sweep(X, 2, Xscale, "/")
  }
  
  mlrmod$Xmeans <- if (center)
    Xmeans
  else
    NULL
  mlrmod$scale  <- if (scale)
    Xscale
  else
    NULL
  
  dat <- data.frame(y = y, X)
  
  # ============================================================
  # MLR calibration
  # ============================================================
  
  mlr_fit <- lm(y ~ ., data = dat)
  
  coef <- coef(mlr_fit)
  b0 <- coef[1]
  coef_x <- coef[-1]
  coef_x[is.na(coef_x)] <- 0
  coef_3d <- array(coef_x, dim = c(length(coef_x), 1, 1))
  
  mlrmod$model <- list(y = y)
  mlrmod$b0 <- b0
  mlrmod$coefficients <- coef_3d
  
  # ============================================================
  # Fitted values (calibration)
  # ============================================================
  
  yhat_cal <- as.numeric(b0 + X %*% coef_x)
  mlrmod$fitted.values <- array(yhat_cal, dim = c(n, 1, 1))
  
  mlrmod$mvcal <- list(y_hat = as.numeric(mlrmod$fitted.values),
                       y_actual = mlrmod$model$y)
  
  # ============================================================
  # Calibration metrics
  # ============================================================
  
  mlrmod$mvcal_met <- reg_metrics(mlrmod$mvcal)
  mlrmod$mvcal_met["LOD"] <- mv_lod(mlrmod, q = q_lod)
  
  # ============================================================
  # Cross-validation (plsr-like: fold-wise centering/scaling)
  # ============================================================
  
  if (tolower(cv) != "none") {
    # --- CV segments (same logic as pls::plsr) ---
    if (cv == "LOO") {
      segments <- pls::cvsegments(n, k = n)
    } else if (cv == "VB") {
      segments <- pls::cvsegments(n, k = folds, type = "interleaved")
    } else if (cv == "RND") {
      segments <- pls::cvsegments(n, k = folds, type = "random")
    } else {
      segments <- pls::cvsegments(n, k = n)
    }
    
    yhat_cv <- rep(NA, n)
    
    # --- Globally preprocessed training data (like plsr) ---
    Xg <- as.matrix(df_train$xdat)
    yg <- as.numeric(df_train$resp[, 1])
    
    for (i in seq_along(segments)) {
      test_idx  <- segments[[i]]
      train_idx <- setdiff(seq_len(n), test_idx)
      
      Xtr <- Xg[train_idx, , drop = FALSE]
      ytr <- yg[train_idx]
      
      Xte <- Xg[test_idx, , drop = FALSE]
      
      # --- Centering (fold-wise, like plsr) ---
      if (center) {
        mu <- colMeans(Xtr)
        Xtr <- sweep(Xtr, 2, mu, "-")
        Xte <- sweep(Xte, 2, mu, "-")
      }
      
      # --- Scaling (fold-wise, like plsr) ---
      if (scale) {
        sdv <- apply(Xtr, 2, sd)
        sdv[sdv == 0] <- 1
        Xtr <- sweep(Xtr, 2, sdv, "/")
        Xte <- sweep(Xte, 2, sdv, "/")
      }
      
      # --- MLR fit ---
      dat_tr <- data.frame(y = ytr, Xtr)
      mlr_tr <- lm(y ~ ., data = dat_tr)
      
      coef_tr <- coef(mlr_tr)
      b0_tr <- coef_tr[1]
      bx_tr <- coef_tr[-1]
      bx_tr[is.na(bx_tr)] <- 0
      
      # --- Prediction ---
      yhat_cv[test_idx] <- as.numeric(b0_tr + Xte %*% bx_tr)
    }
    
    mlrmod$validation <- list(pred = array(yhat_cv, dim = c(n, 1, 1)), segments = segments)
    
    mlrmod$mvcv <- list(y_hat = as.numeric(mlrmod$validation$pred),
                        y_actual = yg)
    
    mlrmod$mvcv_met <- reg_metrics(mlrmod$mvcv)
    
  } else {
    mlrmod$validation <- list(pred = array(NA, dim = c(n, 1, 1)))
  }
  
  # ============================================================
  # Y-randomization
  # ============================================================
  
  if (yrand) {
    mlrmod$mvyrand <- yrand_mlr(mlrmod, df_train, nrep = nrep)
    mlrmod$mvyrand_met <- reg_metrics(mlrmod$mvyrand)
  }
  
  # ============================================================
  # Model structure and metadata
  # ============================================================
  
  mlrmod$row_names <- df_train$row_names
  mlrmod$groups    <- df_train$groups
  mlrmod$val_col   <- df$val_col
  mlrmod$y_name    <- colnames(df$resp)
  mlrmod$col_names <- colnames(df$xdat)
  mlrmod$xvals     <- df$val_col
  mlrmod$sgstp     <- df_train$sgstp
  mlrmod$ppmet     <- df_train$ppmet
  mlrmod$mx        <- df_train$mx
  mlrmod$spl_type  <- spl_type
  mlrmod$pro_test  <- pro_test
  mlrmod$cv        <- cv
  mlrmod$folds     <- folds
  mlrmod$yrand     <- yrand
  mlrmod$nrep      <- nrep
  
  mlrmod$df_train  <- df_train
  mlrmod$df_test   <- df_spt$df_test
  
  mlrmod$model_type <- "MLR"
  
  mlrmod$coefs <- c(mlrmod$b0, mlrmod$coefficients)
  names(mlrmod$coefs) <- c("b0", mlrmod$col_names)
  
  # ============================================================
  # External test set prediction
  # ============================================================
  
  if (nrow(df_spt$df_test$xdat) > 0) {
    mlrmod$mvtes <- pred_mlr(mlrmod, df_spt$df_test)
    mlrmod$mvtes_met <- reg_metrics(mlrmod$mvtes)
    
  } else {
    mlrmod$mvtes <- NULL
    mlrmod$mvtes_met <- NULL
    
  }
  
  # ============================================================
  # Diagnostics
  # ============================================================
  
  mlrmod$mdiag <- mv_diag_mlr(mlrmod)
  
  return(mlrmod)
}

# ============================================================
# pred_mlr
# ============================================================

pred_mlr <- function(mlrmod, df)
{
  stopifnot(inherits(mlrmod, "mlrmod"), is.data.frame(df$xdat))
  
  mlrpred <- list()
  
  # ---------- X matrix ----------
  X <- as.matrix(df$xdat)
  
  # ---------- Centering ----------
  if (!is.null(mlrmod$Xmeans)) {
    X <- sweep(X, 2, mlrmod$Xmeans, "-")
  }
  
  # ---------- Scaling ----------
  if (!is.null(mlrmod$scale)) {
    X <- sweep(X, 2, mlrmod$scale, "/")
  }
  
  # ---------- Coefficients ----------
  b0 <- mlrmod$b0
  B  <- mlrmod$coefficients[, 1, 1, drop = FALSE]  # p x 1
  
  # ---------- Prediction ----------
  y_hat <- drop(b0 + X %*% B)
  mlrpred$y_hat <- as.numeric(y_hat)
  
  # ---------- If reference y exists ----------
  if (!is.null(df$resp)) {
    mlrpred$y_actual <- drop(df$resp[, 1])
  }
  
  return(mlrpred)
}

# ============================================================
# mv_diag_mlr
# ============================================================

mv_diag_mlr <- function(mvmod, ncomp = 1) {
  # ---------- leverage ----------
  if (inherits(mvmod, "mlrmod")) {
    X <- as.matrix(mvmod$xdat)
    
    if (!is.null(mvmod$Xmeans))
      X <- sweep(X, 2, mvmod$Xmeans, "-")
    
    if (!is.null(mvmod$scale))
      X <- sweep(X, 2, mvmod$scale, "/")
    
    Xd <- cbind(1, X)
    
    n <- nrow(X)
    A <- ncol(X)
    
    H <- Xd %*% MASS::ginv(t(Xd) %*% Xd) %*% t(Xd)
    leverage <- diag(H)
  }
  
  # ---------- Y residuals ----------
  yhat <- drop(mvmod$fitted.values[, 1, ncomp])
  y <- drop(mvmod$model$y)
  res <- y - yhat
  
  # ---------- Studentized residuals ----------
  resy <- sqrt((1 / (n - 1)) * sum((res^2) / (1 - leverage)^2))
  r_student <- res / (resy * sqrt(1 - leverage))
  
  # ---------- Limits ----------
  
  # Leverage limit
  if (inherits(mvmod, "mvr")) {
    h_lim <- 2 * A / n
  }
  
  if (inherits(mvmod, "mlrmod")) {
    h_lim <- 2 * (A + 1) / n
  }
  
  # ---------- Output ----------
  out <- list(
    leverage = leverage,
    r_student = r_student,
    residuals = res,
    y_actual = y,
    y_hat = yhat,
    row_names = mvmod$row_names,
    limits = list(leverage = h_lim)
  )
  
  return(out)
}

# ============================================================
# yrand_mlr
# ============================================================

yrand_mlr <- function(mlrmod, df, nrep = 10)
{
  stopifnot(is.data.frame(df$xdat), !is.null(df$resp))
  
  # ---------- X matrix ----------
  X <- as.matrix(df$xdat)
  y0 <- as.numeric(df$resp[, 1])
  n <- nrow(X)
  p <- ncol(X)
  
  # ---------- Centering ----------
  if (!is.null(mlrmod$Xmeans)) {
    X <- sweep(X, 2, mlrmod$Xmeans, "-")
  }
  
  # ---------- Scaling ----------
  if (!is.null(mlrmod$scale)) {
    X <- sweep(X, 2, mlrmod$scale, "/")
  }
  
  # ---------- Fixed dataset ----------
  dat0 <- data.frame(y = y0, X)
  
  # ---------- Storage ----------
  yhat_rand_list <- vector("list", nrep + 2)
  
  # y real
  yhat_rand_list[[1]] <- y0
  names(yhat_rand_list)[1] <- "y_actual"
  
  # and calibration of the true model
  yhat_rand_list[[2]] <- drop(mlrmod$fitted.values[, 1, 1])
  names(yhat_rand_list)[2] <- "y_hat_cal"
  
  # ---------- Y-randomization ----------
  for (i in seq_len(nrep)) {
    dat <- dat0
    dat$y <- sample(dat$y)
    
    mod_rand <- lm(y ~ ., data = dat)
    
    coefr <- coef(mod_rand)
    b0r <- coefr[1]
    br  <- coefr[-1]
    br[is.na(br)] <- 0
    
    yhat_rand_list[[i + 2]] <- as.numeric(b0r + X %*% br)
    names(yhat_rand_list)[i + 2] <- paste0("yr", i)
  }
  
  return(yhat_rand_list)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.