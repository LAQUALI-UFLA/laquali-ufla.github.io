run_hca <- function(df,
                    center = TRUE,
                    scale = FALSE,
                    distance  = 'euclidean',
                    linkage   = 'average',
                    ngroups   = 1,
                    horiz     = TRUE,
                    colPa     = "Hue",
                    val_cex = 0.7) {
  
  # data
  row_names <- df$row_name
  groups <- df$groups
  x <- df$xdat
  
  # Preprocessing
  if (center == TRUE) {
    # Mean centering
    x = scale(x, center = TRUE, scale = FALSE)
  }
  if (scale == TRUE) {
    # Autoscaling (mean centering + scaling)
    x = scale(x, center = TRUE, scale = TRUE)
  }
  
  # Sample labels
  if (is.null(row_names)) {
    row_names <- as.character(seq_len(nrow(x)))
  }
  
  # Distance calculation and hierarchical clustering
  d  <- dist(x, method = distance)
  hc <- hclust(d, method = linkage)
  dend <- as.dendrogram(hc)
  
  # Reorder labels according to dendrogram order
  dend_order <- order.dendrogram(dend)
  dendextend::labels(dend) <- row_names[dend_order]
  
  # Color labels by groups
  if (!is.null(groups)) {
    class_levels <- unique(groups)
    cores_labels <- make_palette(length(class_levels), colPa)
    class_colors <- setNames(cores_labels, class_levels)
    dendextend::labels_colors(dend) <- class_colors[groups][dend_order]
  }
  
  # Color dendrogram branches
  if (ngroups == 1) {
    dend <- dendextend::color_branches(dend, k = 1, col = "black")
  } else {
    cores_branches <- make_palette(ngroups, colPa)
    dend <- dendextend::color_branches(dend, k = ngroups, col = cores_branches)
  }
  
  # Set label size for dendrogram leaves
  dend <- dendextend::assign_values_to_leaves_nodePar(dend, val_cex, "lab.cex")
  
  # Plot dendrogram
  if (horiz) {
    plot(
      dend,
      xlab = paste(distance, "distance"),
      horiz = TRUE,
      las = 2,
      cex.axis = val_cex,
      cex.lab  = val_cex
    )
  } else {
    plot(
      dend,
      ylab = paste(distance, "distance"),
      horiz = FALSE,
      las = 2,
      cex.axis = val_cex,
      cex.lab  = val_cex
    )
  }
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.