mod_plsda <- function(plsdacv,
                      ncomp = 1,
                      yrand = FALSE,
                      nrep = 10,
                      q_lod = 0)
{
  plsdamod <- plsdacv
  plsdamod$ncomp_sel <- ncomp
  
  plsdamod$yrand     <- yrand
  plsdamod$nrep      <- nrep
  
  lev <- plsdamod$classes
  
  # ============================================================
  # Calibration predictions
  # ============================================================
  
  cal_hat <- plsdamod$class.fitted.values[, 1, ncomp]
  cal_hat <- factor(as.character(cal_hat), levels = lev)
  names(cal_hat) <- NULL
  
  cal_ref <- factor(plsdamod$groups, levels = lev)
  names(cal_ref) <- NULL
  
  plsdamod$mvcal <- list(class_hat = cal_hat, class_ref = cal_ref)
  
  plsdamod$cmCal <- table(Reference = cal_ref, Predicted = cal_hat)
  
  plsdamod$cal_metrics <- cla_metrics(plsdamod$cmCal)
  
  plsdamod$coefs <- coef(plsdamod, ncomp = ncomp, intercept = TRUE)
  plsdamod$coefs <- plsdamod$coefs[, , 1]
  rownames(plsdamod$coefs) <- c("b0", plsdamod$col_names)
  
  # ============================================================
  # Cross-validation predictions
  # ============================================================
  
  if (!is.null(plsdamod$validation$pred)) {
    fv <- plsdamod$validation$pred   # n x nclass x ncomp
    n  <- dim(fv)[1]
    
    class_cv <- rep(NA, n)
    
    tmp <- fv[, , ncomp, drop = FALSE]
    idx <- max.col(tmp[, , 1], ties.method = "first")
    class_cv <- factor(lev[idx], levels = lev)
    
    plsdamod$mvcv <- list(class_hat = class_cv, class_ref = cal_ref)
    
    plsdamod$cmCV <- table(Reference = cal_ref, Predicted = class_cv)
    
    plsdamod$cv_metrics <- cla_metrics(plsdamod$cmCV)
    
  } else {
    plsdamod$mvcv <- NULL
    plsdamod$cmCV <- NULL
    plsdamod$cv_metrics <- NULL
  }
  
  # ============================================================
  # External test predictions
  # ============================================================
  
  if (nrow(plsdamod$df_test$xdat)>0) {
    df_test <- plsdamod$df_test

    Xtest <- as.matrix(df_test$xdat)
    
    Yhat <- predict(plsdamod, Xtest, ncomp = ncomp)
    
    tmp <- Yhat[, , 1]
    idx <- max.col(tmp, ties.method = "first")
    class_test <- factor(lev[idx], levels = lev)
    
    test_ref <- factor(df_test$groups, levels = lev)
    
    plsdamod$mvtes <- list(class_hat = class_test, class_ref = test_ref)
    
    plsdamod$cmTest <- table(Reference = test_ref, Predicted = class_test)
    
    plsdamod$test_metrics <- cla_metrics(plsdamod$cmTest)
    
  } else {
    plsdamod$mvtes <- NULL
    plsdamod$cmTest <- NULL
    plsdamod$test_metrics <- NULL
  }
  
  # ============================================================
  # Multivariate diagnostics (leverage only)
  # ============================================================
  
  plsdamod$mdiag <- mv_diag_plsda(plsdamod, ncomp = ncomp)
  
  # ============================================================
  # Y-randomization
  # ============================================================
  
  if (yrand) {
    yr <- yrand_plsda(plsdamod,
                      df    = plsdamod$df_train,
                      ncomp = ncomp,
                      nrep  = nrep)
    
    lev <- plsdamod$classes
    df_train <- plsdamod$df_train
    
    # ============================================================
    # mvyrand
    # ============================================================
    
    mvyrand <- vector("list", nrep + 2)
    
    # y real
    mvyrand[[1]] <- factor(df_train$groups, levels = lev)
    names(mvyrand)[1] <- "y_actual"
    
    # and calibration (actual model)
    mvyrand[[2]] <- plsdamod$mvcal$class_hat
    names(mvyrand)[2] <- "y_hat_cal"
    
    # yr1...yrN
    for (i in seq_len(nrep)) {
      mvyrand[[i + 2]] <- yr[[paste0("yr", i)]]$predicted
      names(mvyrand)[i + 2] <- paste0("yr", i)
    }
    
    plsdamod$mvyrand <- mvyrand
    
    
    # Average
    
    classes <- lev
    K <- length(classes)
    
    # accumulators
    per_class_acc <- NULL
    global_acc    <- NULL
    cm_acc        <- matrix(
      0,
      nrow = K,
      ncol = K,
      dimnames = list(classes, classes)
    )
    
    for (i in seq_len(nrep)) {
      cm <- yr[[paste0("yr", i)]]$confusion
      met <- yr[[paste0("yr", i)]]$metrics
      
      if (is.null(per_class_acc)) {
        per_class_acc <- met$per_class * 0
        global_acc    <- met$global * 0
      }
      
      per_class_acc <- per_class_acc + met$per_class
      global_acc    <- global_acc + met$global
      cm_acc        <- cm_acc + cm
    }
    
    # average
    per_class_mean <- per_class_acc / nrep
    global_mean    <- global_acc / nrep
    cm_mean        <- cm_acc / nrep
    
    # save
    plsdamod$yrand_metrics <- list(per_class = per_class_mean,
                                   global    = global_mean,
                                   confusion = cm_mean)
    
  }
  
  plsdamod$model_type <- "PLS-DA"
  
  return(plsdamod)
}



# ------------------------------------------------------------------
# mv_diag_plsda (only leverage)
# ------------------------------------------------------------------

mv_diag_plsda <- function(plsdamod, ncomp = 1)
{
  T <- pls::scores(plsdamod)[, 1:ncomp, drop = FALSE]
  
  n <- nrow(T)
  A <- ncomp
  
  H <- T %*% MASS::ginv(t(T) %*% T) %*% t(T)
  lev <- diag(H)
  
  h_lim <- 2 * A / n
  
  out <- list(
    leverage = lev,
    limits   = list(leverage = h_lim),
    row_names = plsdamod$row_names
  )
  
  return(out)
}

# ------------------------------------------------------------------
# yrand_plsda
# ------------------------------------------------------------------
yrand_plsda <- function(plsdamod,
                        df,
                        ncomp = 1,
                        nrep = 10)
{
  lev <- plsdamod$classes
  
  X <- as.matrix(df$xdat)
  Y <- model.matrix( ~ df$groups - 1)
  colnames(Y) <- lev
  
  res <- list()
  res$y_ref <- df$groups
  
  for (i in 1:nrep) {
    yr <- sample(df$groups)
    Yr <- model.matrix( ~ yr - 1)
    colnames(Yr) <- lev
    
    mod <- pls::plsr(
      Yr ~ X,
      ncomp = ncomp,
      scale = plsdamod$scale,
      validation = "none"
    )
    
    fv <- mod$fitted.values[, , ncomp]
    idx <- max.col(fv)
    yhat <- factor(lev[idx], levels = lev)
    
    cm <- table(Reference = df$groups, Predicted = yhat)
    
    res[[paste0("yr", i)]] <- list(predicted = yhat,
                                   confusion = cm,
                                   metrics   = cla_metrics(cm))
    
  }
  
  return(res)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.