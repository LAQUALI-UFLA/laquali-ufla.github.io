cv_simca <- function(df,
                     ncomp = 1,
                     center = TRUE,
                     scale = FALSE,
                     spl_type = "KS",
                     pro_test = 25,
                     cv = "LOO",
                     folds = 5,
                     targetclass = NULL,
                     method = "smcla",
                     alpha = 0.05,
                     gamma = 0.01)
{
  if (scale)
    center <- TRUE
  
  if (is.null(targetclass))
    stop("SIMCA requires targetclass.")
  if (!cv %in% c("LOO", "RND"))
    stop("cv must be 'LOO' or 'RND'")
  
  # ============================================================
  # Target / non-target split
  # ============================================================
  
  idx_tar <- df$groups %in% targetclass
  idx_non <- !idx_tar
  
  if (sum(idx_tar) < 3)
    stop("Not enough target class samples.")
  
  df_tar <- df
  df_tar$xdat      <- df$xdat[idx_tar, , drop = FALSE]
  df_tar$row_names <- df$row_names[idx_tar]
  df_tar$groups    <- df$groups[idx_tar]
  
  if (!is.null(df$split_info)) {
    df_tar$split_info <- df$split_info[idx_tar]
  }
  
  df_non <- df
  df_non$xdat      <- df$xdat[idx_non, , drop = FALSE]
  df_non$row_names <- df$row_names[idx_non]
  df_non$groups    <- df$groups[idx_non]
  
  if (!is.null(df$split_info)) {
    df_non$split_info <- df$split_info[idx_non]
  }
  
  # ============================================================
  # Split only target
  # ============================================================
  
  spl <- split_dataset(df_tar, spl_type, pro_test)
  df_train <- spl$df_train
  df_test  <- if (sum(idx_non) > 0)
    rbind_df(list(spl$df_test, df_non))
  else
    spl$df_test
  
  # ============================================================
  # Internal CV
  # ============================================================
  
  X <- as.matrix(df_train$xdat)
  n <- nrow(X)
  ncomp <- min(ncomp, n - 1, ncol(X))
  
  folds_id <- if (cv == "LOO")
    as.list(seq_len(n))
  else {
    # set.seed(123)
    split(sample(seq_len(n)), rep(seq_len(folds), length.out = n))
  }
  
  inout_cv <- matrix(NA, n, ncomp, dimnames = list(df_train$row_names, paste0("Comp_", seq_len(ncomp))))
  
  # Creates matrices directly
  T2_cv    <- matrix(NA, n, ncomp, dimnames = list(df_train$row_names, paste0("Comp_", seq_len(ncomp))))
  Q_cv     <- matrix(NA, n, ncomp, dimnames = list(df_train$row_names, paste0("Comp_", seq_len(ncomp))))
  T2lim_cv <- matrix(NA, 4, ncomp, dimnames = list(
    c("Extremes", "Outliers", "Mean", "DoF"),
    paste0("Comp_", seq_len(ncomp))
  ))
  Qlim_cv  <- matrix(NA, 4, ncomp, dimnames = list(
    c("Extremes", "Outliers", "Mean", "DoF"),
    paste0("Comp_", seq_len(ncomp))
  ))
  
  for (k in seq_along(folds_id)) {
    idx_val <- folds_id[[k]]
    idx_cal <- setdiff(seq_len(n), idx_val)
    
    df_cal <- df_train
    df_cal$xdat      <- df_train$xdat[idx_cal, , drop = FALSE]
    df_cal$row_names <- df_train$row_names[idx_cal]
    df_cal$groups    <- df_train$groups[idx_cal]
    
    simcamod <- mod_simca(df_cal,
                          targetclass,
                          ncomp,
                          center,
                          scale,
                          method,
                          alpha,
                          gamma)
    
    df_val <- df_train
    df_val$xdat      <- df_train$xdat[idx_val, , drop = FALSE]
    df_val$row_names <- df_train$row_names[idx_val]
    df_val$groups    <- NULL
    
    for (a in seq_len(ncomp)) {
      pred <- pred_simca(simcamod, df_val, ncomp = a)
      inout_cv[idx_val, a] <- ifelse(pred$class_hat == "in", 1, 0)
      
      T2_cv[idx_val, a] <- pred$T2
      Q_cv[idx_val, a]  <- pred$Q
      
      if (k == 1) {
        T2lim_cv[, a] <- simcamod$T2lim[, a]
        Qlim_cv[, a]  <- simcamod$Qlim[, a]
      }
      
    }
  }
  
  cv_metrics <- get_SEN(inout_cv, ncomp)
  
  # Detect optimal ncomp
  sen <- cv_metrics$SEN
  # opt_ncomp <- as.numeric(detect_optimal_comp(1 - sen + 1))
  opt_ncomp <- which.max(sen) 
  # ============================================================
  # Calibration metrics
  # ============================================================
  
  simca_final <- mod_simca(df_train,
                           targetclass,
                           ncomp,
                           center,
                           scale,
                           method,
                           alpha,
                           gamma)
  
  df_pred <- df_train
  df_pred$groups <- NULL
  
  inout_cal <- matrix(NA, nrow(df_train$xdat), ncomp)
  
  T2_cal    <- matrix(NA, n, ncomp, dimnames = list(df_train$row_names, paste0("Comp_", seq_len(ncomp))))
  Q_cal     <- matrix(NA, n, ncomp, dimnames = list(df_train$row_names, paste0("Comp_", seq_len(ncomp))))
  T2lim_cal <- matrix(NA, 4, ncomp, dimnames = list(
    c("Extremes", "Outliers", "Mean", "DoF"),
    paste0("Comp_", seq_len(ncomp))
  ))
  Qlim_cal  <- matrix(NA, 4, ncomp, dimnames = list(
    c("Extremes", "Outliers", "Mean", "DoF"),
    paste0("Comp_", seq_len(ncomp))
  ))
  
  for (a in seq_len(ncomp)) {
    pred_cal <- pred_simca(simca_final, df_pred, ncomp = a)
    inout_cal[, a] <- ifelse(pred_cal$class_hat == "in", 1, 0)
    
    T2_cal[, a] <- pred_cal$T2
    Q_cal[, a]  <- pred_cal$Q
    
    T2lim_cal[, a] <- simca_final$T2lim[, a]
    Qlim_cal[, a]  <- simca_final$Qlim[, a]
  }
  
  cal_metrics <- get_SEN(inout_cal, ncomp)
  
  # ============================================================
  # Test set prediction (if pro_test > 0)
  # ============================================================
  
  if (pro_test > 0 && nrow(df_test$xdat) > 0) {
    df_test_pred <- df_test
    df_test_pred$groups <- NULL
    
    nt <- nrow(df_test$xdat)
    
    inout_test <- matrix(NA, nt, ncomp, dimnames = list(df_test$row_names, paste0("Comp_", seq_len(ncomp))))
    
    T2_test <- matrix(NA, nt, ncomp, dimnames = list(df_test$row_names, paste0("Comp_", seq_len(ncomp))))
    Q_test  <- matrix(NA, nt, ncomp, dimnames = list(df_test$row_names, paste0("Comp_", seq_len(ncomp))))
    
    T2lim_test <- matrix(NA, 4, ncomp, dimnames = list(
      c("Extremes", "Outliers", "Mean", "DoF"),
      paste0("Comp_", seq_len(ncomp))
    ))
    
    Qlim_test <- matrix(NA, 4, ncomp, dimnames = list(
      c("Extremes", "Outliers", "Mean", "DoF"),
      paste0("Comp_", seq_len(ncomp))
    ))
    
    for (a in seq_len(ncomp)) {
      pred_test <- pred_simca(simca_final, df_test_pred, ncomp = a)
      
      inout_test[, a] <- ifelse(pred_test$class_hat == "in", 1, 0)
      
      T2_test[, a] <- pred_test$T2
      Q_test[, a]  <- pred_test$Q
      
      T2lim_test[, a] <- simca_final$T2lim[, a]
      Qlim_test[, a]  <- simca_final$Qlim[, a]
    }
    
    is_target_test <- df_test$groups %in% targetclass
    
    test_metrics <- get_SEN(inout_test[is_target_test, , drop = FALSE], ncomp)

  }
  
  out <- list(
    inout_cv     = inout_cv,
    cal_metrics      = cal_metrics,
    cv_metrics       = cv_metrics,
    test_metrics = if (exists("test_metrics"))
      test_metrics
    else
      NULL,
    opt_ncomp    = opt_ncomp,
    scale        = scale,
    ncomp        = ncomp,
    cv           = cv,
    spl_type     = spl_type,
    folds        = folds,
    pro_test     = pro_test,
    y_name       = df$col_classes,
    targetclass  = targetclass,
    method       = method,
    alpha        = alpha,
    gamma        = gamma,
    df_train     = df_train,
    df_test      = df_test,
    xvals        = df$val_col,
    row_names    = df_train$row_names,
    groups       =df_train$groups,
    model_type   = switch(method,
                         "smcla" = "Classic",
                         "ddcla" = "DD-classic",
                         "ddrob" = "DD-robust"
    ),
    prop_var     = simca_final$prop_var,
    prop_var_cum = simca_final$prop_var_cum,
    sdev         = simca_final$sdev,
    
    calMet = list(
      T2    = T2_cal,
      Q     = Q_cal,
      T2lim = T2lim_cal,
      Qlim  = Qlim_cal,
      eigenvals = (simca_final$sdev^2)
    ),
    
    cvMet = list(
      T2    = T2_cv,
      Q     = Q_cv,
      T2lim = T2lim_cv,
      Qlim  = Qlim_cv
    ),
    
    testMet = if (exists("T2_test"))
      list(
        T2    = T2_test,
        Q     = Q_test,
        T2lim = T2lim_test,
        Qlim  = Qlim_test
      )
    else
      NULL,
    
    model_type   = "SIMCA"
  )
  
  class(out) <- "simcacv"
  out
}

# ============================================================
# Metrics helper
# ============================================================

get_SEN <- function(inout, ncomp) {
  SEN <- rep(NA_real_, ncomp)
  
  for (a in seq_len(ncomp)) {
    y_hat <- ifelse(inout[, a] == 1, "in", "out")
    
    TP <- sum(y_hat == "in", na.rm = TRUE)
    FN <- sum(y_hat == "out", na.rm = TRUE)
    
    SEN[a] <- if ((TP + FN) > 0)
      TP / (TP + FN)
    else
      NA_real_
  }
  
  out <- list(SEN = SEN)
  return(out)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.
# This code is inspired by and partially based on implementations from the mdatools project developed by Sergey Kucheryavskiy.
# Original source: https://github.com/svkucheryavski/mdatools