plot_ipls <- function(iplscv,
                      xlabel = "Variables",
                      val_cex = 0.7) {
  
  # =========================
  # Data
  # =========================
  
  int_ind <- iplscv$intMet_ind
  
  ini <- int_ind$ini
  end <- int_ind$end
  lv  <- int_ind$lv
  
  if (!is.null(int_ind$rmse))
    plsmode <- "reg"
  else if (!is.null(int_ind$acu))
    plsmode <- "cla"
  
  if (plsmode == "reg") {
    metric <- int_ind$rmse
    ylab   <- "RMSECV"
    glob   <- iplscv$globMet$rmse
  } else {
    metric <- int_ind$acu
    ylab   <- "ACU"
    glob   <- iplscv$globMet$acu
  }
  
  selected <- rep(FALSE, length(ini))
  selected[iplscv$bestVars$ints] <- TRUE
  
  xvals <- iplscv$xvals
  Xmean <- iplscv$Xmean
  
  # =========================
  # Scale Adjustment
  # =========================
  
  if (plsmode == "reg") {
    ylim <- c(0, max(metric) * 1.1)
  } else {
    ylim <- c(0, max(1, max(metric) * 1.05))
  }
  
  dx <- diff(range(xvals)) * 0.03
  xlim <- c(min(xvals) - dx, max(xvals))
  
  # normalize spectrum
  Xmean_scaled <- (Xmean - min(Xmean)) / (max(Xmean) - min(Xmean))
  Xmean_scaled <- Xmean_scaled * (ylim[2] - ylim[1])
  
  # =========================
  # Base plot
  # =========================
  
  plot(
    0, 0,
    type = "n",
    xlim = xlim,
    ylim = ylim,
    xlab = xlabel,
    ylab = ylab,
    cex.lab = val_cex,
    cex.axis = val_cex
  )
  
  # =========================
  # Bar of the intervals
  # =========================
  
  for (i in seq_along(ini)) {
    
    xleft  <- xvals[ini[i]]
    xright <- xvals[end[i]]
    
    rect(
      xleft,
      0,
      xright,
      metric[i],
      col = ifelse(selected[i],
                   rgb(0.65, 1.0, 0.75),
                   rgb(0.85, 0.95, 1)),
      border = "gray70"
    )
    
    # LV
    text(
      x = (xleft + xright) / 2,
      y = 0.05 * ylim[2],
      labels = lv[i],
      cex = val_cex,
      col = "gray30"
    )
  }
  
  # =========================
  # Average spectrum
  # =========================
  
  lines(xvals, Xmean_scaled, col = "red")
  
  # =========================
  # Global line
  # =========================
  
  abline(h = glob,
         lty = 2,
         col = "gray40")
  
  # Global LV
  text(
    x = min(xvals) - dx,
    y = glob,
    labels = iplscv$globMet$lv,
    pos = 3,
    col = "gray20",
    cex = val_cex
  )
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.