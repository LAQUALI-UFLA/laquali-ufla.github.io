pred_simca <- function(simcamod, df, ncomp = NULL, prepro = FALSE) {
 
  # Apply preprocessing using the parameters from the training model
  if (prepro){
    df <- pre_pro(df,
                  ppmet = simcamod$ppmet,
                  sgstp = simcamod$sgstp,
                  mx = simcamod$mx)
  }
  
  X <- as.matrix(df$xdat)
  
  if (is.null(ncomp))
    ncomp <- simcamod$ncomp
  
  ## ---------------------------
  ## Projection
  ## ---------------------------
  Xproc <- X
  if (!is.null(simcamod$center))
    Xproc <- scale(Xproc, center = simcamod$center, scale = FALSE)
  if (!is.null(simcamod$scale))
    Xproc <- scale(Xproc, center = FALSE, scale = simcamod$scale)
  
  scores <- Xproc %*%
    simcamod$rotation[, 1:ncomp, drop = FALSE]
  
  ## ---------------------------
  ## T2
  ## ---------------------------
  lambda <- simcamod$sdev^2
  
  T2 <- rowSums(sweep(scores^2, 2, lambda[1:ncomp], "/"))
  
  ## ---------------------------
  ## Q residuals
  ## ---------------------------
  Xhat <- scores %*%
    t(simcamod$rotation[, 1:ncomp, drop = FALSE])
  
  E <- Xproc - Xhat
  Q <- rowSums(E^2)
  
  ## ---------------------------
  ## Classification
  ## ---------------------------
  limits <- "Extremes"
  T2lim <- simcamod$T2lim[limits, ncomp]
  Qlim  <- simcamod$Qlim[limits, ncomp]
  
  if (simcamod$method %in% c("ddcla", "ddrob")) {
    class_hat <- ifelse((T2 / T2lim + Q / Qlim) <= 1, "in", "out")
  } else {
    class_hat <- ifelse(T2 <= T2lim & Q <= Qlim, "in", "out")
  }
  
  class_hat <- factor(class_hat, levels = c("out", "in"))
  
  ## ---------------------------
  ## Output
  ## ---------------------------
  if (!is.null(df$groups)) {
    if (!is.null(simcamod$targetclass)) {
      class_ref <- ifelse(df$groups %in% simcamod$targetclass, "in", "out")
    } else {
      # Pure one-class model - everything is “in” by definition
      class_ref <- rep("in", length(df$groups))
    }
    
    class_ref <- factor(class_ref, levels = c("out", "in"))
    
    cm <- table(Reference = class_ref, Predicted = class_hat)
    
    simcapred <- list(
      T2 = T2,
      Q  = Q,
      class_hat = class_hat,
      class_ref = class_ref,
      groups = df$groups,
      row_names = df$row_names,
      cm = cm
    )
    
  } else {
    simcapred <- list(
      T2 = T2,
      Q  = Q,
      class_hat = class_hat,
      row_names = df$row_names
    )
  }
  
  class(simcapred) <- "pred_simca"
  return(simcapred)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.
# This code is inspired by and partially based on implementations from the mdatools project developed by Sergey Kucheryavskiy.
# Original source: https://github.com/svkucheryavski/mdatools