plot_diag <- function(mvmod,
                      x = "leverage",
                      y = "r_student",
                      marker = TRUE,
                      labels = TRUE,
                      orlines = F,
                      val_cex = 0.7) {
  diag <- mvmod$mdiag
  
  if (is.null(diag$y_hat)){
    diag$y_hat <- 1:length(diag$leverage)
    no_actual <- TRUE
  }
  else{
    no_actual <- FALSE
  }
  
  # -------- Checks --------
  stopifnot(is.list(diag))
  
  if (!x %in% names(diag))
    stop("'", x, "' não existe em diag.")
  if (!y %in% names(diag))
    stop("'", y, "' não existe em diag.")
  
  vx <- diag[[x]]
  vy <- diag[[y]]
  
  if (!is.numeric(vx) || !is.numeric(vy))
    stop("x e y devem ser vetores numéricos.")
  
  if (length(vx) != length(vy))
    stop("x e y devem ter o mesmo comprimento.")
  
  # -------- Labels --------
  xylabs <- c(
    leverage   = "Leverage",
    r_student  = "Studentized residual",
    residuals  = "Residuals",
    y_actual   = "Actual",
    y_hat   = if(!no_actual)
      "Predicted"
    else
      "Objects"
  )
  
  xlab <- if (x %in% names(xylabs))
    xylabs[[x]]
  else
    x
  ylab <- if (y %in% names(xylabs))
    xylabs[[y]]
  else
    y
  
  labs <- names(vx)
  if (is.null(labs))
    labs <- seq_along(vx)
  
  # -------- Axis limits --------
  expand <- 0.08
  
  xlim <- range(vx, na.rm = TRUE)
  ylim <- range(vy, na.rm = TRUE)
  
  if (diff(xlim) == 0)
    xlim <- xlim + c(-1, 1)
  if (diff(ylim) == 0)
    ylim <- ylim + c(-1, 1)
  
  xlim <- xlim + c(-1, 1) * expand * diff(xlim)
  ylim <- ylim + c(-1, 1) * expand * diff(ylim)
  
  # -------- Plot --------
  plot(
    vx,
    vy,
    type = "n",
    las = 1,
    xlab = xlab,
    ylab = ylab,
    xlim = xlim,
    ylim = ylim,
    cex.lab = val_cex,
    cex.axis = val_cex
  )
  
  # -------- Origin line --------
  if (orlines) {
    abline(h = 0,
           col = "gray60",
           lwd = 1)
  }
  
  if (marker) {
    points(
      vx,
      vy,
      pch = 21,
      col = "#619CFF",
      bg  = mix_with_white("#619CFF", alpha = 0.2)
    )
  }
  
  if (labels) {
    text(
      vx,
      vy,
      labels = diag$row_names,
      pos = if (marker)
        3
      else
        NULL,
      offset = if (marker)
        0.3
      else
        0,
      cex = val_cex - 0.1
    )
  }
  
  
  # -------- Reference limits --------
  
  # X
  if (x == "r_student") {
    abline(
      v = c(-3, -2.5, -2, 2, 2.5, 3),
      col = c("red", "orange", "#FFD700", "#FFD700", "orange", "red"),
      lty = 2,
      lwd = 1.1
    )
    
  } else if (!is.null(diag$limits) && x %in% names(diag$limits)) {
    abline(
      v = diag$limits[[x]],
      col = "red",
      lty = 2,
      lwd = 1.2
    )
  }
  
  # Y
  if (y == "r_student") {
    abline(
      h = c(-3, -2.5, -2, 2, 2.5, 3),
      col = c("red", "orange", "#FFD700", "#FFD700", "orange", "red"),
      lty = 2,
      lwd = 1.1
    )
    
  } else if (!is.null(diag$limits) && y %in% names(diag$limits)) {
    abline(
      h = diag$limits[[y]],
      col = "red",
      lty = 2,
      lwd = 1.2
    )
  }
  
  invisible(list(x = vx, y = vy))
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.