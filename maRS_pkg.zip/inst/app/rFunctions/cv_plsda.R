cv_plsda <- function(df,
                     ncomp = 1,
                     scale = FALSE,
                     spl_type = "KS",
                     pro_test = 25,
                     cv = "LOO",
                     folds = 5)
{
  # ============================================================
  # Dataset split (external train/test) - BALANCED PER CLASS
  # ============================================================
  
  classes <- levels(factor(df$groups))
  
  train_list <- list()
  test_list  <- list()
  
  for (cl in classes) {
    idx <- which(df$groups == cl)
    
    df_cl <- df
    df_cl$xdat   <- df$xdat[idx, , drop = FALSE]
    df_cl$groups <- df$groups[idx]
    
    if (!is.null(df$row_names)) {
      df_cl$row_names <- df$row_names[idx]
    }
    
    if (!is.null(df$split_info)) {
      df_cl$split_info <- df$split_info[idx]
    }
    
    df_spt_cl <- split_dataset(df_cl, spl_type  = spl_type, pro_test  = pro_test)
    
    train_list[[cl]] <- df_spt_cl$df_train
    test_list[[cl]]  <- df_spt_cl$df_test
  }
  
  df_train <- rbind_df(train_list)
  df_test  <- rbind_df(test_list)
  
  # ============================================================
  # Build modeling data.frame (dummy Y)
  # ============================================================
  
  if (length(unique(df_train$groups)) < 2)
    stop("PLS-DA requires at least two classes in training set.")
  
  df_train$groups <- factor(df_train$groups, levels = classes)
  Y_dummy <- model.matrix( ~ groups - 1, data = data.frame(groups = df_train$groups))
  
  colnames(Y_dummy) <- gsub("groups", "", colnames(Y_dummy))
  
  
  # Limit ncomp
  ncomp <- min(ncomp, nrow(df_train$xdat) - 1, ncol(df_train$xdat))
  
  # ============================================================
  # PLS with internal cross-validation
  # ============================================================
  
  X <- as.matrix(df_train$xdat)
  Y <- as.matrix(Y_dummy)
  
  if (cv == "LOO") {
    plsdacv <- pls::plsr(Y ~ X,
                         ncomp = ncomp,
                         scale = scale,
                         validation = "LOO")
    
  } else if (cv == "RND") {
    plsdacv <- pls::plsr(
      Y ~ X,
      ncomp = ncomp,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "random"
    )
    
  }
  
  # ============================================================
  # Convert fitted values to class predictions (argmax)
  # ============================================================
  
  fv <- plsdacv$fitted.values     # n x nclass x ncomp
  n  <- dim(fv)[1]
  A  <- dim(fv)[3]
  lev <- colnames(Y_dummy)
  
  rn <- rownames(fv)
  if (is.null(rn))
    rn <- seq_len(dim(fv)[1])
  
  class_hat <- array(NA,
                     dim = c(n, 1, A),
                     dimnames = list(rn, "class", paste0("Comp_", 1:A)))
  
  for (a in 1:A) {
    tmp <- fv[, , a, drop = FALSE]
    idx_max <- max.col(tmp[, , 1], ties.method = "first")
    if (length(idx_max) != n)
      stop("argmax failed in component ", a)
    class_hat[, 1, a] <- lev[idx_max]
  }
  
  plsdacv$class.fitted.values <- class_hat
  
  # ============================================================
  # Convert CV predicted values to class predictions (argmax)
  # ============================================================
  
  if (!is.null(plsdacv$validation$pred)) {
    pv <- plsdacv$validation$pred   # n x nclass x ncomp
    n  <- dim(pv)[1]
    A  <- dim(pv)[3]
    
    rn_cv <- rownames(pv)
    if (is.null(rn_cv))
      rn_cv <- rn
    
    class_cv <- array(NA,
                      dim = c(n, 1, A),
                      dimnames = list(rn_cv, "class", paste0("Comp_", 1:A)))
    
    for (a in 1:A) {
      tmp <- pv[, , a, drop = FALSE]
      idx_max <- max.col(tmp[, , 1], ties.method = "first")
      if (length(idx_max) != n)
        stop("CV argmax failed in component ", a)
      class_cv[, 1, a] <- lev[idx_max]
    }
    
    plsdacv$validation$class.fitted.values <- class_cv
  }
  
  # ============================================================
  # Store metadata
  # ============================================================
  
  plsdacv$row_names <- df_train$row_names
  plsdacv$groups    <- df_train$groups
  plsdacv$val_col   <- df$val_col
  plsdacv$xvals     <- df$val_col
  plsdacv$y_name    <- df$col_classes
  plsdacv$col_names <- colnames(df_train$xdat)
  
  plsdacv$sgstp <- df_train$sgstp
  plsdacv$ppmet <- df_train$ppmet
  plsdacv$mx    <- df_train$mx
  
  plsdacv$prop_var <- pls::explvar(plsdacv)
  
  plsdacv$spl_type  <- spl_type
  plsdacv$pro_test  <- pro_test
  plsdacv$cv        <- cv
  plsdacv$folds     <- folds
  
  plsdacv$df_train <- df_train
  plsdacv$df_test  <- df_test
  
  plsdacv$model_type <- "PLS-DA"
  plsdacv$classes    <- lev
  
  # ============================================================
  # CV metrics (calibration + CV) — plot_lv_da compatible
  # ============================================================
  
  y_ref <- factor(plsdacv$groups, levels = plsdacv$classes)
  
  fv_cal <- plsdacv$class.fitted.values
  fv_cv  <- plsdacv$validation$class.fitted.values
  
  A   <- dim(fv_cal)[3]
  lev <- plsdacv$classes
  
  metrics <- c("PRE", "SPE", "SEN", "ACU", "EFI", "F1S", "MCC")
  
  cal_metrics <- lapply(metrics, function(x)
    numeric(A))
  cv_metrics  <- lapply(metrics, function(x)
    numeric(A))
  
  names(cal_metrics) <- names(cv_metrics) <- metrics
  
  for (a in seq_len(A)) {
    # ---------- Calibration ----------
    cal_hat <- factor(fv_cal[, 1, a], levels = lev)
    cm_cal  <- table(Reference = y_ref, Predicted = cal_hat)
    
    mc_cal  <- cla_metrics(cm_cal)$global
    
    # ---------- Cross-validation ----------
    cv_hat <- factor(fv_cv[, 1, a], levels = lev)
    cm_cv  <- table(Reference = y_ref, Predicted = cv_hat)
    mc_cv  <- cla_metrics(cm_cv)$global
    
    for (m in metrics) {
      cal_metrics[[m]][a] <- mc_cal[m]
      cv_metrics[[m]][a]  <- mc_cv[m]
    }
  }
  
  plsdacv$cal_metrics <- cal_metrics
  plsdacv$cv_metrics  <- cv_metrics
  
  # Detect optimal ncomp
  acu <- plsdacv$cv_metrics$ACU
  plsdacv$opt_ncomp <- as.numeric(detect_optimal_comp(1 - acu + 1))
  
  # ============================================================
  # External test prediction + metrics
  # ============================================================
  
  if (pro_test > 0 && nrow(df_test$xdat) > 0) {
    # --- Prepare X_test
    X_test <- as.matrix(df_test$xdat)
    
    # --- Predict Y (array: ntest x nclass x ncomp)
    pred_test <- predict(plsdacv, newdata = X_test, ncomp = seq_len(ncomp))
    
    ntest <- dim(pred_test)[1]
    A <- ncomp
    
    rn_test <- df_test$row_names
    if (is.null(rn_test))
      rn_test <- seq_len(ntest)
    
    # --- Convert to class predictions (argmax)
    class_test <- array(NA,
                        dim = c(ntest, 1, A),
                        dimnames = list(rn_test, "class", paste0("Comp_", seq_len(A))))
    
    for (a in seq_len(A)) {
      tmp <- pred_test[, , a, drop = FALSE]
      idx_max <- max.col(tmp[, , 1], ties.method = "first")
      class_test[, 1, a] <- lev[idx_max]
    }
    
    # ============================================================
    # Test metrics (same structure as cal / cv)
    # ============================================================
    
    y_test <- factor(df_test$groups, levels = lev)
    
    metrics <- c("PRE", "SPE", "SEN", "ACU", "EFI", "F1S", "MCC")
    
    test_metrics <- lapply(metrics, function(x)
      numeric(A))
    names(test_metrics) <- metrics
    
    for (a in seq_len(A)) {
      test_hat <- factor(class_test[, 1, a], levels = lev)
      cm_test  <- table(Reference = y_test, Predicted = test_hat)
      mc_test  <- cla_metrics(cm_test)$global
      
      for (m in metrics) {
        test_metrics[[m]][a] <- mc_test[m]
      }
    }
    
    plsdacv$test_metrics <- test_metrics
  }
  
  # ============================================================
  # Output
  # ============================================================
  
  return(plsdacv)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.