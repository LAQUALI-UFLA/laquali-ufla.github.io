mv_lod <- function(mvmodel, q = 1) {
  # Get ncomp
  if (is.null(mvmodel$ncomp_sel))
    ncomp <- 1
  else
    ncomp <- mvmodel$ncomp_sel
  
  # Get y vectors from model
  yhat <- as.numeric(mvmodel$fitted.values[, 1, ncomp])
  ycal <- mvmodel$model$y
  
  # Pseudounivariate regression
  p <- lm(yhat ~ ycal)
  b <- coef(p)[2]  # slope
  
  # Residuals and residual error
  yfit <- fitted(p)
  resid <- yhat - yfit
  syx <- sqrt(sum(resid^2) / (length(ycal) - 2))  # standard error of residuals
  
  # w0 calculation
  N <- length(ycal)
  c_mean <- mean(ycal)
  w0 <- sqrt(1 / q + 1 / N + (c_mean^2) / sum((ycal - c_mean)^2))
  
  # Delta value (alpha = beta = 0.05)
  # Delta <- 3.3
  Delta <- qt(1 - 0.05, df = N - 2) * 2
  
  # LOD calculation
  LOD_PU <- unname((Delta * w0 * syx) / b)
  
  return(LOD_PU)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.