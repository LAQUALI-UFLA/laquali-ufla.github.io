synt_oversamp <- function(df, method = "SMOTE", k = 5) {
  x <- df$xdat
  y <- as.factor(df$groups)
  
  if (method == "SMOTE")
    sdf <- SMOTEWB::SMOTE(x, y, k = k, ovRate = 1)
  else if (method == "ADASYN")
    sdf <- SMOTEWB::ADASYN(x, y, k = k, ovRate = 1)
  
  row_names <- c(df$row_names, paste0("syn", 1:length(sdf$y_syn)))
  groups <- c(df$groups, as.character(sdf$y_syn))
  
  synt_df <- cbind(obj = row_names, classes = groups , sdf$x_new)
  
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.