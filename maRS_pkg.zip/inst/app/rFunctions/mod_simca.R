mod_simca <- function(simcacv,
                      targetclass = NULL,
                      ncomp = NULL,
                      center = TRUE,
                      scale = FALSE,
                      method = "smcla",
                      alpha = 0.05,
                      gamma = 0.01) {
  if (scale)
    center <- TRUE
  
  ## ---------------------------
  ## Dataset
  ## ---------------------------
  
  if (is.null(simcacv$df_train))
    df = simcacv
  else
    df <- simcacv$df_train
  
  if (!is.null(targetclass)) {
    # Use only target class samples
    row_keep <- df$groups %in% targetclass
    
    df$xdat <- df$xdat[row_keep, , drop = FALSE]
    df$row_names <- df$row_names[row_keep]
    df$groups    <- df$groups[row_keep]
  }
  
  X <- as.matrix(df$xdat)
  n <- nrow(X)
  p <- ncol(X)
  
  ## ---------------------------
  ## PCA
  ## ---------------------------
  pcamod <- mod_pca(df,
                    ncomp = ncomp,
                    center = center,
                    scale = scale)
  
  scores   <- pcamod$x[, 1:ncomp, drop = FALSE]
  loadings <- pcamod$rotation[, 1:ncomp, drop = FALSE]
  lambda   <- pcamod$sdev^2
  
  ## ---------------------------
  ## Hotelling T2
  ## ---------------------------
  h_all <- matrix(0, nrow = n, ncol = ncomp)
  for (a in 1:ncomp) {
    h_all[, a] <- rowSums(sweep(scores[, 1:a, drop = FALSE]^2, 2, lambda[1:a], "/"))
  }
  
  ## ---------------------------
  ## Q statistic
  ## ---------------------------
  Xproc <- X
  if (center)
    Xproc <- scale(Xproc, center = pcamod$center, scale = FALSE)
  if (scale)
    Xproc <- scale(Xproc, center = FALSE, scale = pcamod$scale)
  
  Q_all <- matrix(0, nrow = n, ncol = ncomp)
  for (a in 1:ncomp) {
    Xhat <- scores[, 1:a, drop = FALSE] %*%
      t(loadings[, 1:a, drop = FALSE])
    E <- Xproc - Xhat
    Q_all[, a] <- rowSums(E^2)
  }
  
  ## ---------------------------
  ## Parameter estimation
  ## ---------------------------
  
  # DD-moments parameter estimation
  param_ddcla <- function(U) {
    if (is.null(dim(U)))
      dim(U) <- c(length(U), 1)
    
    u0 <- apply(U, 2, mean)
    su <- apply(U, 2, sd)
    Nu <- 2 * (u0 / su)^2
    
    list(u0 = u0,
         Nu = Nu,
         nobj = nrow(U))
  }
  
  # Robust DD parameter estimation
  param_ddrob <- function(U) {
    if (is.null(dim(U)))
      dim(U) <- c(length(U), 1)
    
    Mu <- apply(U, 2, median)
    Su <- apply(U, 2, IQR)
    
    Mu[abs(Mu) < .Machine$double.eps] <- .Machine$double.eps
    RM <- Su / Mu
    
    Nu <- round(exp((1.380948 * log(2.68631 / RM))^1.185785))
    Nu[RM > 2.685592117] <- 1
    Nu[RM < 0.194565995] <- 100
    
    u0 <- 0.5 * Nu * (Mu / qchisq(0.50, Nu) +
                        Su / (qchisq(0.75, Nu) - qchisq(0.25, Nu)))
    
    list(u0 = u0,
         Nu = Nu,
         nobj = nrow(U))
  }
  
  # Data-driven (DD) chi-square control limits combining Q and T² statistics
  crit_dd <- function(paramQ,
                      paramT2,
                      alpha = 0.05,
                      gamma = 0.01) {
    nobj <- paramQ$nobj
    
    Nq <- pmin(pmax(round(paramQ$Nu), 1), 250)
    Nh <- pmin(pmax(round(paramT2$Nu), 1), 250)
    
    rbind(qchisq(1 - alpha, Nq + Nh), qchisq((1 - gamma)^(1 / nobj), Nq + Nh))
  }
  
  ## ---------------------------
  ## T2 limits
  ## ---------------------------
  T2lim <- matrix(NA, 4, ncomp, dimnames = list(
    c("Extremes", "Outliers", "Mean", "DoF"),
    paste("Comp", 1:ncomp)
  ))
  
  Xhat_full <- scores %*% t(loadings)
  residuals_full <- Xproc - Xhat_full
  
  for (a in 1:ncomp) {
    T2lim[3, a] <- mean(h_all[, a])
    
    if (method == "smcla") {
      lims1 <- (a * (n - 1) / (n - a)) * qf(1 - alpha, a, n - a)
      lims2 <- (a * (n - 1) / (n - a)) * qf((1 - gamma)^(1 / n), a, n - a)
      
      T2lim[1, a] <- lims1
      T2lim[2, a] <- lims2
      T2lim[4, a] <- n
      
    } else if (method == "ddcla") {
      paramQ  <- param_ddcla(Q_all[, a, drop = FALSE])
      paramT2 <- param_ddcla(h_all[, a, drop = FALSE])
      
      lims <- crit_dd(paramQ, paramT2, alpha, gamma)
      DoF <- pmin(pmax(round(paramT2$Nu), 1), 250)
      
      T2lim[1:2, a] <- lims[, 1] * paramT2$u0 / DoF
      T2lim[4, a] <- DoF
      
    } else if (method == "ddrob") {
      paramQ  <- param_ddrob(Q_all[, a, drop = FALSE])
      paramT2 <- param_ddrob(h_all[, a, drop = FALSE])
      
      T2lim[3, a] <- paramT2$u0
      
      lims <- crit_dd(paramQ, paramT2, alpha, gamma)
      DoF <- pmin(pmax(round(paramT2$Nu), 1), 250)
      
      T2lim[1:2, a] <- lims[, 1] * paramT2$u0 / DoF
      T2lim[4, a] <- DoF
    }
  }
  
  ## ---------------------------
  ## Q limits
  ## ---------------------------
  
  Qlim <- matrix(NA, 4, ncomp, dimnames = list(
    c("Extremes", "Outliers", "Mean", "DoF"),
    paste("Comp", 1:ncomp)
  ))
  
  ## ---- smcla pre-calculation ----
  if (method == "smcla") {
    nobj <- nrow(residuals_full)
    max_ncomp <- min(nrow(residuals_full) - 1, ncol(residuals_full))
    
    eigenvals <- lambda
    
    if (length(eigenvals) < max_ncomp) {
      eigenvals <- c(eigenvals, svd(residuals_full)$d[seq_len(max_ncomp - length(lambda))]^2 / (nobj - 1))
    }
    
    eigenvals <- eigenvals[-1]
    
    t1 <- rev(cumsum(rev(eigenvals)))[seq_len(ncomp)]
    t2 <- rev(cumsum(rev(eigenvals)^2))[seq_len(ncomp)]
    t3 <- rev(cumsum(rev(eigenvals)^3))[seq_len(ncomp)]
    
    h0 <- 1 - 2 * t1 * t3 / (3 * t2^2)
    h0[h0 < 0.001] <- 0.001
    
    gcl <- 1 - (1 - gamma)^(1 / nobj)
    
    ca1 <- qnorm(1 - alpha)
    ca2 <- qnorm(1 - gcl)
    
    h1a <- ca1 * sqrt(2 * t2 * h0^2) / t1
    h1g <- ca2 * sqrt(2 * t2 * h0^2) / t1
    h2  <- t2 * h0 * (h0 - 1) / (t1^2)
    
    lims_smcla <- rbind(t1 * (1 + h1a + h2)^(1 / h0), t1 * (1 + h1g + h2)^(1 / h0))
    
    if (ncomp == max_ncomp) {
      lims_smcla[, max_ncomp] <- 0
    }
    
    attr(lims_smcla, "eigenvals") <- eigenvals
  }
  
  ## ---- main loop ----
  for (a in 1:ncomp) {
    if (method == "smcla") {
      Qlim[3, a] <- mean(Q_all[, a])
      Qlim[1:2, a] <- lims_smcla[, a]
      Qlim[4, a] <- n
      
      if (a == ncomp)
        attr(Qlim, "eigenvals") <- attr(lims_smcla, "eigenvals")
      
    } else if (method == "ddcla") {
      paramQ  <- param_ddcla(Q_all[, a, drop = FALSE])
      paramT2 <- param_ddcla(h_all[, a, drop = FALSE])
      
      lims <- crit_dd(paramQ, paramT2, alpha, gamma)
      DoF <- pmin(pmax(round(paramQ$Nu), 1), 250)
      
      Qlim[3, a] <- mean(Q_all[, a])
      Qlim[1:2, a] <- lims[, 1] * paramQ$u0 / DoF
      Qlim[4, a] <- DoF
      
    } else if (method == "ddrob") {
      paramQ  <- param_ddrob(Q_all[, a, drop = FALSE])
      paramT2 <- param_ddrob(h_all[, a, drop = FALSE])
      
      lims <- crit_dd(paramQ, paramT2, alpha, gamma)
      DoF <- pmin(pmax(round(paramQ$Nu), 1), 250)
      
      Qlim[3, a] <- paramQ$u0
      Qlim[1:2, a] <- lims[, 1] * paramQ$u0 / DoF
      Qlim[4, a] <- DoF
    }
  }
  ## ---------------------------
  ## Output
  ## ---------------------------
  simcamod <- pcamod
  
  simcamod$sgstp <- df$sgstp
  simcamod$ppmet <- df$ppmet
  simcamod$mx    <- df$mx
  
  simcamod$y_name <-simcacv$y_name
  
  simcamod$xvals <- df$val_col
  
  simcamod$T2          <- h_all[, ncomp]
  simcamod$Q           <- Q_all[, ncomp]
  simcamod$T2lim       <- T2lim
  simcamod$Qlim        <- Qlim
  simcamod$ncomp_sel   <- ncomp
  simcamod$method      <- method
  simcamod$alpha       <- alpha
  simcamod$gamma       <- gamma
  simcamod$targetclass <- targetclass
  
  if (!is.null(simcacv$cal_metrics))
    simcamod$cal_metrics <- simcacv$cal_metrics
  
  if (!is.null(simcacv$cv_metrics))
    simcamod$cv_metrics <- simcacv$cv_metrics
  
  if (!is.null(simcacv$test_metrics))
    simcamod$test_metrics <- simcacv$test_metrics
  
  if (!is.null(simcacv$df_train))
    simcamod$df_train <- simcacv$df_train
  
  if (!is.null(simcacv$df_test))
    simcamod$df_test <- simcacv$df_test
  
  return(simcamod)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.
# This code is inspired by and partially based on implementations from the mdatools project developed by Sergey Kucheryavskiy.
# Original source: https://github.com/svkucheryavski/mdatools