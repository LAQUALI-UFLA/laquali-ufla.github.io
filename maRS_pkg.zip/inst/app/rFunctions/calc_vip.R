calc_vip <- function(mvmod, opt.comp = NULL)
{
  # If not specified, it uses all components of the model
  if (is.null(opt.comp)) {
    opt.comp <- mvmod$ncomp
  }
  
  # Scores, weights and loadings
  T <- pls::scores(mvmod)[, 1:opt.comp, drop = FALSE]
  W <- mvmod$loading.weights[, 1:opt.comp, drop = FALSE]
  Q <- mvmod$Yloadings[, 1:opt.comp, drop = FALSE]
  
  p <- nrow(W)
  
  # Variance explained by component
  TT <- colSums(T^2)
  QQ <- colSums(Q^2)
  s  <- TT * QQ
  
  # Weight norm
  wnorm <- apply(W, 2, function(x) sqrt(sum(x^2)))
  
  # Avoid division by zero
  wnorm[wnorm == 0] <- 1
  
  vip <- numeric(p)
  
  for (i in 1:p) {
    wnorm2 <- (W[i, ] / wnorm)^2
    vip[i] <- sqrt(p * sum(s * wnorm2) / sum(s))
  }
  
  # Name
  names(vip) <- rownames(W)
  
  return(vip)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.