plot_lv_reg <- function(plsmod,
                        plot_cal = TRUE,
                        plot_cv  = TRUE,
                        plot_test = FALSE,
                        plot_type = "RMSE",
                        val_cex = 0.7) {
  
  if (plsmod$spl_type=='None')
    plot_test <- FALSE
  
  
  c_cal  <- "#377eb8"
  c_cv   <- "#e41a1c"
  c_test <- "#4daf4a"
  
  col_set <- c(c_cal, c_cv, c_test)
  bg_set  <- c(
    mix_with_white(c_cal, alpha = 0.2),
    mix_with_white(c_cv, alpha = 0.2),
    mix_with_white(c_test, alpha = 0.2)
  )
  # -------------------------
  # y actual
  # -------------------------
  y <- drop(plsmod$model$y)
  y_mean <- mean(y, na.rm = TRUE)
  SST <- sum((y - y_mean)^2, na.rm = TRUE)
  
  # -------------------------
  # y predicted
  # -------------------------
  yhat_cal <- plsmod$fitted.values        # n x 1 x A
  yhat_cv  <- plsmod$validation$pred      # n x 1 x A
  
  A <- dim(yhat_cal)[3]
  LV <- seq_len(A)
  
  rmse_cal <- rmse_cv <- r2_cal <- r2_cv <- numeric(A)
  
  rmse_test <- r2_test <- rep(NA, A)
  
  for (a in LV) {
    yc_hat <- drop(yhat_cal[, , a])
    yv_hat <- drop(yhat_cv[, , a])
    
    # --- RMSE ---
    rmse_cal[a] <- sqrt(mean((y - yc_hat)^2, na.rm = TRUE))
    rmse_cv[a]  <- sqrt(mean((y - yv_hat)^2, na.rm = TRUE))
    
    # --- R2 ---
    SSE_cal <- sum((y - yc_hat)^2, na.rm = TRUE)
    SSE_cv  <- sum((y - yv_hat)^2, na.rm = TRUE)
    
    r2_cal[a] <- 1 - SSE_cal / SST
    r2_cv[a]  <- 1 - SSE_cv  / SST
    
    # ---------- Test ----------
    if (plot_test &&
        plsmod$pro_test > 0 && !is.null(plsmod$df_test)) {
      plspred <- pred_pls(plsmod, plsmod$df_test, ncomp = a)
      
      if (!is.null(plspred$y_actual)) {
        yt <- plspred$y_actual
        yt_hat <- plspred$y_hat
        
        # RMSE
        rmse_test[a] <- sqrt(mean((yt - yt_hat)^2, na.rm = TRUE))
        
        # R2
        SST_t <- sum((yt - mean(yt, na.rm = TRUE))^2, na.rm = TRUE)
        SSE_t <- sum((yt - yt_hat)^2, na.rm = TRUE)
        r2_test[a] <- 1 - SSE_t / SST_t
      }
    }
  }

  # -------------------------
  # Plot RMSE
  # -------------------------
  if (toupper(plot_type) == "RMSE") {
    plot(
      LV,
      LV,
      type = "n",
      cex.axis = val_cex,
      cex.lab  = val_cex,
      xaxp = c(min(LV), max(LV), max(LV) - min(LV)),
      xlab = "LV",
      ylab = "RMSE",
      ylim = range(c(rmse_cal, rmse_cv, rmse_test), na.rm = TRUE)
    )
    
    if (plot_cal) {
      lines(
        LV,
        rmse_cal,
        type = "b",
        pch = 21,
        col = col_set[1],
        bg  = bg_set[1],
        lwd = 1.5
      )
    }

    if (plot_cv) {
      lines(
        LV,
        rmse_cv,
        type = "b",
        pch = 21,
        col = col_set[2],
        bg  = bg_set[2],
        lwd = 1.5
      )
    }
    
    if (plot_test) {
      lines(
        LV,
        rmse_test,
        type = "b",
        pch = 21,
        col = col_set[3],
        bg  = bg_set[3],
        lwd = 1.5
      )
    }
    
  }
  
  # -------------------------
  # Plot R2
  # -------------------------
  else if (toupper(plot_type) == "R2") {
    plot(
      LV,
      LV,
      type = "n",
      cex.axis = val_cex,
      cex.lab  = val_cex,
      xaxp = c(min(LV), max(LV), max(LV) - min(LV)),
      xlab = "LV",
      ylab = expression(R^2),
      ylim = c(0, 1)
    )
    
    if (plot_cal) {
      lines(
        LV,
        r2_cal,
        type = "b",
        pch = 21,
        col = col_set[1],
        bg  = bg_set[1],
        lwd = 1.5
      )
    }
    
    if (plot_cv) {
      lines(
        LV,
        r2_cv,
        type = "b",
        pch = 21,
        col = col_set[2],
        bg  = bg_set[2],
        lwd = 1.5
      )
    }
    
    if (plot_test) {
      lines(
        LV,
        r2_test,
        type = "b",
        pch = 21,
        col = col_set[3],
        bg  = bg_set[3],
        lwd = 1.5
      )
    }
  }
  
  # -------------------------
  # Legend
  # -------------------------
  # Allow drawing outside plot region
  par(xpd = TRUE)
  
  leg_idx    <- c(plot_cal, plot_cv, plot_test)
  leg_labels <- c("Calibration   ", "CV", "Test")[leg_idx]
  leg_cols   <- col_set[leg_idx]
  leg_bgs    <- bg_set[leg_idx]
  
  legend(
    "top",
    inset = -0.1,
    horiz = TRUE,
    legend = leg_labels,
    pch = 21,
    pt.bg = leg_bgs,
    col = leg_cols,
    lwd = 1.5,
    bty = "n",
    cex = val_cex
  )
  
  par(xpd = FALSE)
  invisible()
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.