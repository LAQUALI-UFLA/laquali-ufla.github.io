plot_lines <- function(df,
                       center = FALSE,
                       scale = FALSE,
                       xlabel = "Variables",
                       ylabel = "Values",
                       gtitle = NULL,
                       col_groups = FALSE,
                       colPa = "Hue",
                       val_cex = 0.7,
                       grids = FALSE,
                       orlines = FALSE) {
  x_val <- df$val_col
  groups <- df$groups
  df_data <- df$xdat
  
  # Preprocessing
  if (scale == TRUE) {
    # Autoscale (already includes center = TRUE)
    df_data = scale(df_data, center = TRUE, scale = TRUE)
  } else if (center == TRUE) {
    # Mean centering only
    df_data = scale(df_data, center = TRUE, scale = FALSE)
  }
  
  df_data <- as.matrix(df_data)
  n_series <- nrow(df_data)
  
  # Color handling by groups (optional)
  if (isTRUE(col_groups) && !is.null(groups)) {
    # Check group length consistency
    if (length(groups) != n_series) {
      stop("Length of 'groups' must match the number of rows (series) in df.")
    }
    grupos_unicos <- unique(groups)
    ngroups <- length(grupos_unicos)
    
    cores <- make_palette(ngroups, colPa)
    grupo_cores <- setNames(cores, grupos_unicos)
    cores_plot <- grupo_cores[as.character(groups)]
  } else {
    # Default color when no grouping is used
    cores_plot <- rep("#619CFF", n_series)
    grupos_unicos <- NULL
    cores <- NULL
  }
  
  # Y-axis limits with upper margin
  ymin <- min(df_data, na.rm = TRUE)
  ymax <- max(df_data, na.rm = TRUE)
  
  y_range <- ymax - ymin
  ylim <- c(ymin, ymax + 0.2 * abs(y_range))
  
  # Create empty plot

    plt_ln <- plot(
    NA,
    type = "n",
    xlim = range(x_val),
    ylim = ylim,
    xlab = xlabel,
    ylab = ylabel,
    main = gtitle,
    las = 1,
    cex.lab = val_cex,
    cex.axis = val_cex
  )
  
  # Add grid
  if (grids) {
    xlim <- range(x_val, na.rm = TRUE)
    ylim_current <- par("usr")[3:4]
    
    # Horizontal grid
    abline(
      h = pretty(ylim_current),
      col = "gray90",
      lty = "solid",
      lwd = 0.5
    )
    
    # Vertical grid
    abline(
      v = pretty(xlim),
      col = "gray90",
      lty = "solid",
      lwd = 0.5
    )
  }
  
  # Plot data lines
  matplot(
    x_val,
    t(df_data),
    type = "l",
    lty = 1,
    col = cores_plot,
    add = TRUE
  )
  
  # Draw y = 0 reference line if data were centered
  if (orlines) {
    if (center || scale) {
      abline(h = 0,
             col = "gray60",
             lwd = 1)
    }
  }
  
  # Legend (if groups are used)
  if (isTRUE(col_groups) && !is.null(groups)) {
    # Place legend inside the plot area at the top
    legend(
      "top",
      inset = -0.01,
      legend = grupos_unicos,
      col = "black",
      pt.bg = cores,
      pch = 22,
      pt.cex = 1.2,
      pt.lwd = 1.5,
      cex = val_cex * 0.9,
      horiz = TRUE,
      bty = "n",
      x.intersp = 1.2
    )
  }
  
  invisible()
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.