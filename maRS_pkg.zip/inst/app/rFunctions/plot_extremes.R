plot_extremes <- function(simcacv,
                          ncomp = 1,
                          val_cex = 0.7) {
  # ============================
  # Extract data
  # ============================
  T2 <- simcacv$calMet$T2[, ncomp, drop = FALSE]
  Q  <- simcacv$calMet$Q[, ncomp, drop = FALSE]
  
  nobj <- nrow(T2)
  expected <- seq_len(nobj)
  i <- expected
  alpha <- i / nobj
  
  # ============================
  # Calculation of the Observed
  # ============================
  alpha_mat <- matrix(alpha,
                      nrow = nobj,
                      ncol = nobj,
                      byrow = TRUE)
  
  p <- get_prob(
    simcacv = simcacv,
    ncomp   = ncomp,
    q       = Q[, 1],
    h       = T2[, 1]
  )
  
  p <- sort(p, decreasing = FALSE)
  p_mat <- matrix(1 - p, nrow = nobj, ncol = nobj)
  observed <- colSums(p_mat < alpha_mat)
  
  # ============================
  # Base plot
  # ============================
  plot(
    0,
    type = "n",
    xlim = c(0, nobj),
    ylim = c(0, nobj),
    xlab = "Expected extremes",
    ylab = "Observed extremes",
    cex.axis = val_cex,
    cex.lab = val_cex,
  )
  
  # ============================
  # Tolerance ellipse
  # ============================
  ellipse.col = "grey90"
  
  # Diagonal
  lines(c(0, nobj), c(0, nobj), col = ellipse.col)
  
  D <- 2 * sqrt(i * (1 - alpha))
  Nm <- i - D
  Np <- i + D
  
  segments(expected, Nm, expected, Np, col = ellipse.col)
  lines(c(0, expected), c(0, Nm), col = ellipse.col)
  lines(c(0, expected), c(0, Np), col = ellipse.col)
  
  # ============================
  # Points
  # ============================
  points(
    expected,
    observed,
    pch = 21,
    bg = mix_with_white("#e41a1c", alpha = 0.2),
    col = "#e41a1c",
    lwd = 0.5
  )
  
  invisible(list(
    expected = expected,
    observed = observed,
    alpha    = alpha
  ))
}


# ===============================
# Probabilities
# ===============================

get_prob <- function(simcacv, ncomp, q, h) {
  lim.type <- simcacv$method
  
  # ============================
  # Classical
  # ============================
  if (lim.type == "smcla") {
    nobj <- simcacv$calMet$T2lim[4, ncomp]
    eigenvals <- simcacv$calMet$eigenvals[-1]
    
    ## ---- smcla_prob ----
    t1 <- rev(cumsum(rev(eigenvals)))[ncomp]
    t2 <- rev(cumsum(rev(eigenvals)^2))[ncomp]
    t3 <- rev(cumsum(rev(eigenvals)^3))[ncomp]
    
    h0 <- 1 - 2 * t1 * t3 / (3 * t2^2)
    if (h0 < 0.001)
      h0 <- 0.001
    
    h1 <- (q / t1)^h0
    h2 <- t2 * h0 * (h0 - 1) / t1^2
    d  <- t1 * (h1 - 1 - h2) / (sqrt(2 * t2) * h0)
    
    p_q <- 0.5 * (1 + (1 - 2 * pnorm(-d)))
    
    ## ---- hot_prob ----
    p_h <- pf(h * (nobj - ncomp) / (ncomp * (nobj - 1)), ncomp, (nobj - ncomp))
    
    return(pmax(p_q, p_h))
  }
  
  # ============================
  # Data-driven
  # ============================
  else if (lim.type %in% c("ddcla", "ddrob")) {
    h0 <- simcacv$calMet$T2lim[3, ncomp]
    Nh <- round(simcacv$calMet$T2lim[4, ncomp])
    
    q0 <- simcacv$calMet$Qlim[3, ncomp]
    Nq <- round(simcacv$calMet$Qlim[4, ncomp])
    
    f <- Nh * h / h0 + Nq * q / q0
    
    return(pchisq(f, Nh + Nq))
  }
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.
# This code is inspired by and partially based on implementations from the mdatools project developed by Sergey Kucheryavskiy.
# Original source: https://github.com/svkucheryavski/mdatools