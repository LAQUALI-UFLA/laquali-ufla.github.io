plot_var_imprt <- function(mvmod,
                           plot_type = "coefficients",
                           xlabel = "Variables",
                           clas = NULL,
                           val_cex = 0.7,
                           bars = FALSE,
                           grids = FALSE,
                           orlines = FALSE) {
  plot_type <- match.arg(plot_type, c("VIP", "coefficients", "FR"))
  
  xvalues <- mvmod$val_col
  ncomp <- mvmod$ncomp_sel
  if (is.null(ncomp))
    ncomp <- 1
  
  if (plot_type == "VIP") {
    # --- VIP ---
    y <- calc_vip(mvmod, opt.comp = ncomp)
    ylab <- "VIP"
    
  } else if (plot_type == "coefficients") {
    # --- Coefficients ---
    cdim <- dim(mvmod$coefficients)
    
    # ---- Case 1: without LV (MLR / MLR-DA)
    if (length(cdim) < 3) {
      y <- as.numeric(mvmod$coefficients[, clas])
      
      # ---- Case 2: multi-class
    } else if (cdim[2] > 1) {
      y <- as.numeric(mvmod$coefficients[, clas, ncomp])
      
      # ---- Case 3: binary (1 column)
    } else {
      y <- as.numeric(mvmod$coefficients[, 1, ncomp])
    }
    
    ylab <- "Regression coefficients"
    
  } else if (plot_type == "FR") {
    # -------- Verification --------
    if (is.null(mvmod$groups)) {
      stop("Fisher Ratio (FR) requires mvmod$groups (class labels).")
    }
    
    X <- mvmod$df_train$xdat
    ygrp <- mvmod$df_train$groups
    classes <- levels(ygrp)
    
    n_var <- ncol(X)
    Fval <- numeric(n_var)
    
    for (j in 1:n_var) {
      xj <- X[, j]
      mean_total <- mean(xj)
      SB <- 0
      SW <- 0
      
      for (cl in classes) {
        idx <- which(ygrp == cl)
        x_cl <- xj[idx]
        
        n_cl <- length(x_cl)
        mean_cl <- mean(x_cl)
        
        SB <- SB + n_cl * (mean_cl - mean_total)^2
        SW <- SW + sum((x_cl - mean_cl)^2)
      }
      # Avoid division by zero
      Fval[j] <- ifelse(SW == 0, NA, SB / SW)
    }
    
    y <- Fval
    ylab <- "Fisher Ratio"
  }
  
  # -------- Selected variables case--------
  if (!is.null(mvmod$bestVars$vars)) {
    y_full <- rep(0, length(mvmod$xvals))
    y_full[mvmod$bestVars$vars] <- y
    y <- y_full
    xvalues <- mvmod$xvals
  }
  
  # -------- Variable labels --------
  p <- length(y)
  var_names <- mvmod$col_names
  if (is.null(var_names) || length(var_names) != p) {
    # Garante que os nomes alinhem com o tamanho do vetor (útil para p <= 20)
    var_names <- seq_along(y)
  }
  
  # -------- Plot base --------
  if (bars) {
    mids <- barplot(
      height = y,
      names.arg = if (p <= 20)
        var_names
      else
        NULL,
      xaxt = if (p <= 20)
        "s"
      else
        "n",
      xlab = if (p <= 20)
        ""
      else
        xlabel,
      col = if (p <= 20)
        "gray80"
      else
        "#619CFF",
      border = if (p <= 20)
        "black"
      else
        NA,
      ylab = ylab,
      las = 2,
      cex.names = val_cex,
      cex.lab = val_cex,
      cex.axis = val_cex
    )
    
    if (p > 20) {
      xticks <- pretty(xvalues)
      xticks <- xticks[xticks >= min(xvalues) &
                         xticks <= max(xvalues)]
      
      x_at <- approx(
        x = xvalues,
        y = mids,
        xout = xticks,
        rule = 2
      )$y
      
      axis(1,
           at = x_at,
           labels = xticks,
           cex.axis = val_cex)
      box()
    }
    
  } else {
    plot(
      xvalues,
      y,
      type = "n",
      las = 1,
      xlab = xlabel,
      ylab = ylab,
      cex.lab = val_cex,
      cex.axis = val_cex
    )
    
    lines(xvalues, y, col = "#619CFF", lwd = 1.5)
  }
  
  # -------- Origin line --------
  if (orlines && plot_type == "coefficients") {
    abline(h = 0,
           col = "gray60",
           lwd = 1)
  }
  
  # -------- Grid --------
  if (grids) {
    usr <- par("usr")
    abline(
      h = pretty(usr[3:4]),
      v = pretty(usr[1:2]),
      col = "gray90",
      lty = 3,
      lwd = 0.8
    )
  }
  
  invisible()
}