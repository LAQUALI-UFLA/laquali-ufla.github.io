cv_bveplsda <- function(df,
                        ncomp = 1,
                        vip_lim = 1,
                        scale = FALSE,
                        spl_type = "KS",
                        pro_test = 25,
                        cv = "LOO",
                        folds = 5)
{
  # ============================================================
  # Dataset split (balanced per class)
  # ============================================================
  
  classes <- levels(factor(df$groups))
  
  train_list <- list()
  test_list  <- list()
  
  for (cl in classes) {
    idx <- which(df$groups == cl)
    
    df_cl <- df
    df_cl$xdat   <- df$xdat[idx, , drop = FALSE]
    df_cl$groups <- df$groups[idx]
    
    if (!is.null(df$row_names)) {
      df_cl$row_names <- df$row_names[idx]
    }
    
    if (!is.null(df$split_info)) {
      df_cl$split_info <- df$split_info[idx]
    }
    
    df_spt_cl <- split_dataset(df_cl, spl_type = spl_type, pro_test = pro_test)
    
    train_list[[cl]] <- df_spt_cl$df_train
    test_list[[cl]]  <- df_spt_cl$df_test
  }
  
  df_train <- rbind_df(train_list)
  df_test  <- rbind_df(test_list)
  
  # ============================================================
  # Dummy Y
  # ============================================================
  
  if (length(unique(df_train$groups)) < 2)
    stop("PLS-DA requires at least two classes.")
  
  df_train$groups <- factor(df_train$groups, levels = classes)
  Y_dummy <- model.matrix(~ groups - 1, data = data.frame(groups = df_train$groups))
  colnames(Y_dummy) <- gsub("groups", "", colnames(Y_dummy))
  
  X <- as.matrix(df_train$xdat)
  Y <- as.matrix(Y_dummy)
  
  ncomp <- min(ncomp, nrow(X) - 1, ncol(X))
  
  # ============================================================
  # Evaluation function (ACU CV)
  # ============================================================
  
  get_acu <- function(Xm) {
    if (cv == "LOO") {
      mod <- pls::plsr(Y ~ Xm,
                       ncomp = ncomp,
                       scale = scale,
                       validation = "LOO")
    } else if (cv == "RND") {
      mod <- pls::plsr(
        Y ~ Xm,
        ncomp = ncomp,
        scale = scale,
        validation = "CV",
        segments = folds,
        segment.type = "random"
      )
    } else {
      mod <- pls::plsr(
        Y ~ Xm,
        ncomp = ncomp,
        scale = scale,
        validation = "CV",
        segments = folds,
        segment.type = "interleaved"
      )
    }
    
    pv <- mod$validation$pred
    lev <- colnames(Y_dummy)
    y_ref <- factor(df_train$groups, levels = lev)
    
    A <- dim(pv)[3]
    acu <- numeric(A)
    
    for (a in 1:A) {
      idx <- max.col(pv[, , a], ties.method = "first")
      y_hat <- factor(lev[idx], levels = lev)
      cm <- table(y_ref, y_hat)
      acu[a] <- cla_metrics(cm)$global["ACU"]
    }
    
    lv <- detect_optimal_comp(1 - acu + 1)
    
    list(lv = lv, acu = acu[lv], mod = mod)
  }
  
  # ============================================================
  # Global metrics
  # ============================================================
  
  glob <- get_acu(X)
  
  # ============================================================
  # BVE loop
  # ============================================================
  
  varMet <- list()
  current_vars <- 1:ncol(X)
  
  for (iter in 1:ncol(X)) {
    
    Xm <- X[, current_vars, drop = FALSE]
    met <- get_acu(Xm)
    
    varMet[[iter]] <- list(
      vars = current_vars,
      lv   = met$lv,
      acu  = met$acu
    )
    
    # Stop
    if (length(current_vars) <= (ncomp + 1)) break
    
    # VIP
    vip <- calc_vip(met$mod, opt.comp = met$lv)
    vip <- as.vector(vip)
    
    rem_idx <- which(vip < vip_lim)
    
    if (length(rem_idx) == 0) {
      rem_idx <- order(vip)[1]
    }
    
    if ((length(current_vars) - length(rem_idx)) < (ncomp + 1)) {
      rem_idx <- order(vip)[1:(length(current_vars) - (ncomp + 1))]
    }
    
    current_vars <- current_vars[-rem_idx]
  }
  
  # ============================================================
  # Choosing the best iteration
  # ============================================================
  
  acus <- sapply(varMet, function(x) x$acu)
  best_iter <- which.max(acus)
  
  selVar <- varMet[[best_iter]]$vars
  
  # ============================================================
  # Final model
  # ============================================================
  
  X <- X[, selVar, drop = FALSE]
  
  if (cv == "LOO") {
    bveplsdacv <- pls::plsr(Y ~ X,
                            ncomp = ncomp,
                            scale = scale,
                            validation = "LOO")
  } else if (cv == "RND") {
    bveplsdacv <- pls::plsr(
      Y ~ X,
      ncomp = ncomp,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "random"
    )
  } else {
    bveplsdacv <- pls::plsr(
      Y ~ X,
      ncomp = ncomp,
      scale = scale,
      validation = "CV",
      segments = folds,
      segment.type = "interleaved"
    )
  }
  
  # ============================================================
  # Storage
  # ============================================================
  
  fv <- bveplsdacv$fitted.values
  n  <- dim(fv)[1]
  A  <- dim(fv)[3]
  lev <- colnames(Y_dummy)
  
  rn <- rownames(fv)
  if (is.null(rn)) rn <- seq_len(n)
  
  class_hat <- array(NA, c(n, 1, A), dimnames = list(rn, "class", paste0("Comp_", 1:A)))
  
  for (a in 1:A) {
    idx <- max.col(fv[, , a], ties.method = "first")
    class_hat[, 1, a] <- lev[idx]
  }
  
  bveplsdacv$class.fitted.values <- class_hat
  
  # CV
  pv <- bveplsdacv$validation$pred
  class_cv <- array(NA, c(n, 1, A), dimnames = list(rn, "class", paste0("Comp_", 1:A)))
  
  for (a in 1:A) {
    idx <- max.col(pv[, , a], ties.method = "first")
    class_cv[, 1, a] <- lev[idx]
  }
  
  bveplsdacv$validation$class.fitted.values <- class_cv
  
  # ============================================================
  # Metrics
  # ============================================================
  
  y_ref <- factor(df_train$groups, levels = lev)
  
  metrics <- c("PRE","SPE","SEN","ACU","EFI","F1S","MCC")
  
  cal_metrics <- lapply(metrics, function(x) numeric(A))
  cv_metrics  <- lapply(metrics, function(x) numeric(A))
  names(cal_metrics) <- names(cv_metrics) <- metrics
  
  for (a in 1:A) {
    cm_cal <- table(y_ref, factor(class_hat[,1,a], levels = lev))
    cm_cv  <- table(y_ref, factor(class_cv[,1,a], levels = lev))
    
    mc_cal <- cla_metrics(cm_cal)$global
    mc_cv  <- cla_metrics(cm_cv)$global
    
    for (m in metrics) {
      cal_metrics[[m]][a] <- mc_cal[m]
      cv_metrics[[m]][a]  <- mc_cv[m]
    }
  }
  
  bveplsdacv$cal_metrics <- cal_metrics
  bveplsdacv$cv_metrics  <- cv_metrics
  
  acu <- bveplsdacv$cv_metrics$ACU
  bveplsdacv$opt_ncomp <- as.numeric(detect_optimal_comp(1 - acu + 1))
  
  # ============================================================
  # TEST
  # ============================================================
  
  if (pro_test > 0 && nrow(df_test$xdat) > 0) {
    X_test <- as.matrix(df_test$xdat[, selVar, drop = FALSE])
    pred_test <- predict(bveplsdacv, X_test, ncomp = seq_len(ncomp))
    
    A <- ncomp
    lev <- colnames(Y_dummy)
    
    class_test <- array(NA, c(nrow(X_test), 1, A))
    
    for (a in 1:A) {
      idx <- max.col(pred_test[,,a], ties.method="first")
      class_test[,1,a] <- lev[idx]
    }
    
    y_test <- factor(df_test$groups, levels = lev)
    
    test_metrics <- lapply(metrics, function(x) numeric(A))
    names(test_metrics) <- metrics
    
    for (a in 1:A) {
      cm <- table(y_test, factor(class_test[,1,a], levels = lev))
      mc <- cla_metrics(cm)$global
      
      for (m in metrics) {
        test_metrics[[m]][a] <- mc[m]
      }
    }
    
    bveplsdacv$test_metrics <- test_metrics
  }
  
  # ============================================================
  # METADATA
  # ============================================================
  
  bveplsdacv$xvals    <- df$val_col
  bveplsdacv$Xmean    <- colMeans(df$xdat)
  bveplsdacv$ncol     <- ncol(df$xdat)
  bveplsdacv$row_names <- df_train$row_names
  bveplsdacv$groups    <- df_train$groups
  bveplsdacv$val_col   <- df$val_col
  bveplsdacv$y_name    <- df$col_classes
  bveplsdacv$col_names <- colnames(df_train$xdat)
  
  bveplsdacv$sgstp <- df_train$sgstp
  bveplsdacv$ppmet <- df_train$ppmet
  bveplsdacv$mx    <- df_train$mx
  
  bveplsdacv$prop_var <- pls::explvar(bveplsdacv)
  
  bveplsdacv$spl_type <- spl_type
  bveplsdacv$pro_test <- pro_test
  bveplsdacv$cv       <- cv
  bveplsdacv$folds    <- folds
  bveplsdacv$vip_lim  <- vip_lim
  
  bveplsdacv$df_train <- df_train
  bveplsdacv$df_test  <- df_test
  
  bveplsdacv$model_type <- "BVE/PLS-DA"
  bveplsdacv$classes    <- lev
  
  # ============================================================
  # ARMAZENAMENTO
  # ============================================================
  
  bveplsdacv$varMet <- varMet
  
  bveplsdacv$bestVars <- list(
    vars = selVar,
    lv   = varMet[[best_iter]]$lv,
    acu  = varMet[[best_iter]]$acu
  )
  
  bveplsdacv$globMet <- list(
    lv  = glob$lv,
    acu = glob$acu
  )
  
  # ============================================================
  # Update columns
  # ============================================================
  
  bveplsdacv$col_names <- colnames(df_train$xdat)[selVar]
  
  if (!is.null(bveplsdacv$val_col)) {
    bveplsdacv$val_col <- bveplsdacv$val_col[selVar]
  }
  
  if (!is.null(bveplsdacv$mx)) {
    bveplsdacv$mxFull <- bveplsdacv$mx
    bveplsdacv$mx     <- bveplsdacv$mx[selVar]
  }
  
  bveplsdacv$df_train$xdat <- df_train$xdat[, selVar, drop = FALSE]
  
  if (!is.null(df_test)) {
    bveplsdacv$df_test$xdat <- df_test$xdat[, selVar, drop = FALSE]
  }
  
  return(bveplsdacv)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.