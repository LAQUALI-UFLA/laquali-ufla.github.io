plot_bvepls <- function(bveplscv,
                        xlabel = "Variables",
                        ylabel = "Signal",
                        val_cex = 0.7)
{

  # Data
  
  xvals <- bveplscv$xvals
  if (is.null(xvals)) {
    xvals <- 1:bveplscv$ncol
  }
  
  Xmean <- bveplscv$Xmean
  
  sel_vars <- bveplscv$bestVars$vars
  
  # Base plot (average spectrum)
  
  plot(xvals, Xmean,
       type = "l",
       # lwd = 2,
       col = "red",
       xlab = xlabel,
       ylab = ylabel,
       cex.lab = val_cex,
       cex.axis = val_cex)

  # Highlight selected variables
  
  points(xvals[sel_vars],
         Xmean[sel_vars],
         pch = 21,
         bg = rgb(0.65, 1.0, 0.75),
         col = "black",
         cex = 1.2)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.