mod_pca <- function(df,
                    ncomp = NULL,
                    center = TRUE,
                    scale = FALSE,
                    suprows = NULL,
                    supcols = NULL,
                    scalecol = NULL) {
  if (scale)
    center <- TRUE
  
  ## Initial validations
  
  if (!inherits(df, "list") || is.null(df$xdat)) {
    stop("df must be a list with element 'xdat'")
  }
  
  if (!is.null(df$groups) &&
      length(df$groups) != nrow(df$xdat)) {
    stop("df$groups must have the same length as nrow(df$xdat)")
  }
  
  ## scalecol validation and extraction
  if (!is.null(scalecol)) {
    if (!scalecol %in% colnames(df$xdat)) {
      stop("scalecol does not exist in df$xdat")
    }
    
    scalecol_all <- df$xdat[, scalecol]
    
    # Remove scalecol from eligible columns
    cols_allowed <- colnames(df$xdat) != scalecol
  } else {
    scalecol_all <- NULL
    cols_allowed <- rep(TRUE, ncol(df$xdat))
  }
  
  ## Row masks
  
  if (!is.null(suprows)) {
    if (is.null(df$groups)) {
      stop("suprows is defined, but df$groups is NULL.")
    }
    row_keep <- !(df$groups %in% suprows)
  } else {
    row_keep <- rep(TRUE, nrow(df$xdat))
  }
  
  ## Column masks
  
  if (!is.null(supcols)) {
    if (!all(supcols %in% colnames(df$xdat))) {
      stop("Some supcols do not exist in df$xdat.")
    }
    
    col_keep <- !(colnames(df$xdat) %in% supcols) & cols_allowed
  } else {
    col_keep <- cols_allowed
  }
  
  ## Active data
  x <- df$xdat[row_keep, col_keep, drop = FALSE]
  
  # Limit the maximum number of components
  if (is.null(ncomp)) {
    ncomp <- min(10, nrow(x) - 1, ncol(x))
  } else {
    ncomp <- min(ncomp, nrow(x) - 1, ncol(x))
  }
  
  ## PCA computation
  pcamod <- prcomp(x,
                   center = center,
                   scale. = scale,
                   rank = ncomp)
  
  ## Initialize optional outputs as NULL
  pcamod$prop_var       <- NULL
  pcamod$prop_var_cum   <- NULL
  pcamod$row_names      <- NULL
  pcamod$groups         <- NULL
  pcamod$val_col        <- NULL
  pcamod$col_names      <- NULL
  pcamod$suprows        <- NULL
  pcamod$supcols        <- NULL
  pcamod$supscor        <- NULL
  pcamod$sup_row_names  <- NULL
  pcamod$sup_groups     <- NULL
  pcamod$supload        <- NULL
  pcamod$sup_col_names  <- NULL
  pcamod$scalecol       <- NULL
  pcamod$scalecol_sup   <- NULL
  
  ## Explained variance
  variancias <- pcamod$sdev^2
  prop_var <- variancias / sum(variancias)
  
  pcamod$prop_var     <- prop_var * 100
  pcamod$prop_var_cum <- cumsum(prop_var) * 100
  
  ## Consistent metadata
  pcamod$row_names <- df$row_names[row_keep]
  pcamod$groups    <- if (!is.null(df$groups))
    df$groups[row_keep]
  else
    NULL
  pcamod$val_col   <- df$val_col[col_keep]
  pcamod$col_names <- colnames(df$xdat)[col_keep]
  pcamod$suprows <- NULL
  pcamod$supcols <- NULL
  
  ## Supplementary rows
  if (!is.null(suprows)) {
    Xsup_rows <- df$xdat[!row_keep, col_keep, drop = FALSE]
    
    pcamod$supscor <- predict(pcamod, Xsup_rows)
    pcamod$sup_row_names <- df$row_names[!row_keep]
    pcamod$sup_groups    <- df$groups[!row_keep]
    if (!is.null(suprows) && !is.null(supcols)) {
      pcamod$suprows_supcols <- as.matrix(df$xdat[!row_keep, !col_keep, drop = FALSE])
      rownames(pcamod$suprows_supcols) <- df$row_names[!row_keep]
      colnames(pcamod$suprows_supcols) <- colnames(df$xdat)[!col_keep]
    }
  }
  
  ## Supplementary columns
  if (!is.null(supcols)) {
    Xsup_cols <- df$xdat[row_keep, supcols, drop = FALSE]
    
    if (center) {
      mu_supcol <- colMeans(Xsup_cols, na.rm = TRUE)
      Xsup_cols <- scale(Xsup_cols, center = mu_supcol, scale = FALSE)
    }
    
    if (scale) {
      sd_supcol <- apply(Xsup_cols, 2, function(col) {
        s <- sd(col, na.rm = TRUE)
        if (s == 0 || !is.finite(s))
          1
        else
          s
      })
      Xsup_cols <- scale(Xsup_cols, center = FALSE, scale = sd_supcol)
    }
    
    pcamod$supload <- t(solve(t(pcamod$x) %*% pcamod$x) %*%
                          t(pcamod$x) %*%
                          Xsup_cols)
    
    pcamod$sup_col_names <- supcols
  }
  
  ## Store supplementary information
  pcamod$suprows <- suprows
  pcamod$supcols <- supcols
  
  ## Store scalecol
  if (!is.null(scalecol_all)) {
    # valores das linhas ativas
    pcamod$scalecol <- scalecol_all[row_keep]
    pcamod$scalecol_name <- scalecol
    
    # values of supplementary lines (if any)
    if (!is.null(suprows)) {
      pcamod$scalecol_sup <- scalecol_all[!row_keep]
    }
  }
  
  return(pcamod)
}

# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.