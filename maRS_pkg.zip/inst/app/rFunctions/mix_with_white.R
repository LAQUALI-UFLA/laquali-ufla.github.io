mix_with_white <- function(col, alpha) {
  # Convert the color to RGB
  rgb_col <- col2rgb(col)
  # Blends with white (255) based on the alpha value
  # If alpha = 0.7, uses 70% of the color and 30% white
  new_rgb <- rgb_col * alpha + 255 * (1 - alpha)
  # Returns a solid hexadecimal value
  rgb(new_rgb[1, ], new_rgb[2, ], new_rgb[3, ], maxColorValue = 255)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.