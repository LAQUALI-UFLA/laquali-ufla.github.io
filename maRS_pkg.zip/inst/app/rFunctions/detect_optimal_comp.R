detect_optimal_comp <- function(metric_values) {
  n_comp <- length(metric_values)
  
  log_rmse <- log(metric_values)
  
  if (n_comp < 2 || is.na(log_rmse[1]) || is.na(log_rmse[n_comp]))
    return(1)
  
  x <- 1:n_comp
  straight <- approx(c(1, n_comp), c(log_rmse[1], log_rmse[n_comp]), xout = x)$y
  dist_straight <- abs(log_rmse - straight)
  dist_straight[1] <- 0
  dist_straight[n_comp] <- 0
  
  which.max(dist_straight)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.