pred_mlr <- function(mlrmod, df, prepro = FALSE)
{
  stopifnot(inherits(mlrmod, "mlrmod"), is.data.frame(df$xdat))
  
  mlrpred <- list()
  
  # Apply preprocessing using the parameters from the training model
  if (prepro){
    df <- pre_pro(df,
                  ppmet = mlrmod$ppmet,
                  sgstp = mlrmod$sgstp,
                  mx = mlrmod$mx)
  }
  
  # ---------- X matrix ----------
  X <- as.matrix(df$xdat)
  
  # ---------- Centering ----------
  if (!is.null(mlrmod$Xmeans)) {
    X <- sweep(X, 2, mlrmod$Xmeans, "-")
  }
  
  # ---------- Scaling ----------
  if (!is.null(mlrmod$scale)) {
    X <- sweep(X, 2, mlrmod$scale, "/")
  }
  
  # ---------- Coefficients ----------
  b0 <- mlrmod$b0
  B  <- mlrmod$coefficients[, 1, 1, drop = FALSE]  # p x 1
  
  # ---------- Prediction ----------
  y_hat <- drop(b0 + X %*% B)
  mlrpred$y_hat <- as.numeric(y_hat)
  
  # ---------- If reference y exists ----------
  if (!is.null(df$resp)) {
    mlrpred$y_actual <- drop(df$resp[, 1])
  }
  
  return(mlrpred)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.