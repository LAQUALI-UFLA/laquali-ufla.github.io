make_palette <- function(n, colPa) {
  # Hue palette
  if (tolower(colPa) == "hue") {
    scales::hue_pal()(n)
  }
  
  # Dark palette - Based on the RColorBrewer Dark2 palette
  else if (tolower(colPa) == "dark") {
    colorset <- c(
      "#1b9e77",
      "#d95f02",
      "#7570b3",
      "#e7298a",
      "#66a61e",
      "#e6ab02",
      "#a6761d",
      "#666666"
    )
    if (n <= length(colorset))
      colorset[1:n]
    else
      grDevices::colorRampPalette(colorset)(n)
  }
  
  # Prism palette - Inspired by RColorBrewer Spectral palette
  else if (tolower(colPa) == "prism") {
    colorset <- c("#2679B2",
                  "#D22C2F",
                  "#EED524",
                  "#379531",
                  "#FB7F28",
                  "#1C9AA8")
    if (n <= length(colorset))
      colorset[1:n]
    else
      grDevices::colorRampPalette(colorset)(n)
  }
  
  # Spectral palette - Inspired by RColorBrewer Spectral palette
  else if (tolower(colPa) == "spec") {
    colorset <- c("#2679B2",
                  "#1C9AA8",
                  "#379531",
                  "#EED524",
                  "#FB7F28",
                  "#D22C2F")
    
    k <- length(colorset)
    
    if (n <= k) {
      # Select evenly spaced colors
      idx <- round(seq(1, k, length.out = n))
      colorset[idx]
    } else {
      grDevices::colorRampPalette(colorset)(n)
    }
  }
  
  # Set palette - Based on the RColorBrewer Set1 palette
  else if (tolower(colPa) == "set") {
    colorset <- c(
      "#377eb8",
      "#e41a1c",
      "#4daf4a",
      "#984ea3",
      "#ff7f00",
      "#ffff33",
      "#a65628",
      "#f781bf",
      "#999999"
    )
    if (n <= length(colorset))
      colorset[1:n]
    else
      grDevices::colorRampPalette(colorset)(n)
  }
  
  # Tab palette - Based on the Matplotlib tab10 palette
  else if (tolower(colPa) == "tab") {
    colorset <- c(
      "#1F77B4",
      "#FF7F0E",
      "#2CA02C",
      "#D62728",
      "#9467BD",
      "#8C564B",
      "#E377C2",
      "#7F7F7F",
      "#BCBD22",
      "#17BECF"
    )
    if (n <= length(colorset))
      colorset[1:n]
    else
      grDevices::colorRampPalette(colorset)(n)
  }
  
  # Fallback palette
  else {
    grDevices::rainbow(n)
  }
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.