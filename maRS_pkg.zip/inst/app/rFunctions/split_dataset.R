split_dataset <- function(df,
                          spl_type = "KS",
                          pro_test = 25) {
  # Data
  
  stopifnot(is.data.frame(df$xdat))
  
  spl_type <- toupper(spl_type)
  
  x <- as.matrix(df$xdat)
  y <- as.numeric(df$resp[[1]])
  
  n <- nrow(x)
  n_test <- ceiling(n * pro_test / 100)
  
  
  # Scaling for distance-based methods
  
  xsc <- scale(x)
  
  if (spl_type == "SPXY") {
    ysc <- scale(y)
  }
  
  # Distance matrix
  
  dist_x <- as.matrix(dist(xsc))
  
  if (spl_type == "SPXY") {
    dist_y <- as.matrix(dist(ysc))
    dist_xy <- dist_x / max(dist_x) + dist_y / max(dist_y)
  }
  
  # Split logic
  
  if (spl_type == "KS") {
    # Initial pair (max distance)
    idx <- which(dist_x == max(dist_x), arr.ind = TRUE)[1, ]
    sel <- unique(idx)
    
    while (length(sel) < (n - n_test)) {
      dmin <- apply(dist_x[, sel, drop = FALSE], 1, min)
      sel <- c(sel, which.max(dmin))
      sel <- unique(sel)
    }
    
    train_idx <- sort(sel)
    test_idx  <- setdiff(seq_len(n), train_idx)
    
  } else if (spl_type == "SPXY") {
    idx <- which(dist_xy == max(dist_xy), arr.ind = TRUE)[1, ]
    sel <- unique(idx)
    
    while (length(sel) < (n - n_test)) {
      dmin <- apply(dist_xy[, sel, drop = FALSE], 1, min)
      sel <- c(sel, which.max(dmin))
      sel <- unique(sel)
    }
    
    train_idx <- sort(sel)
    test_idx  <- setdiff(seq_len(n), train_idx)
    
  } else if (spl_type == "RND") {
    # set.seed(123)
    test_idx  <- sample(seq_len(n), n_test)
    train_idx <- setdiff(seq_len(n), test_idx)
    
  } else if (spl_type == "SPE") {
    if (length(unique(df$split_info)) != 2)
      stop("split_info must contain exactly two unique values")
    
    train_idx <- which(tolower(df$split_info) == "train")
    test_idx  <- which(tolower(df$split_info) == "test")
  } 
  else if (spl_type == "NONE") {
    train_idx <- seq_len(n)
    test_idx  <- integer(0)
    
  }
  
  else {
    stop("spl_type must be one of: 'None', KS', 'SPXY', 'RND', 'SPE'")
  }
  
  # Output
  df_train <- list(
    xdat = df$xdat[train_idx, , drop = FALSE],
    resp = df$resp[train_idx, , drop = FALSE],
    row_names = df$row_names[train_idx],
    groups = df$groups[train_idx],
    col_classes = df$col_classes,
    val_col = df$val_col,
    mx = df$mx,
    sgstp = df$sgstp,
    ppmet = df$ppmet,
    split_info = df$split_info
  )
  
  df_test <- list(
    xdat = df$xdat[test_idx, , drop = FALSE],
    resp  = df$resp[test_idx, , drop = FALSE],
    row_names  = df$row_names[test_idx],
    groups  = df$groups[test_idx],
    col_classes = df$col_classes,
    val_col = df$val_col,
    mx = df$mx,
    sgstp = df$sgstp,
    ppmet = df$ppmet,
    split_info = df$split_info
  )
  
  return(list(df_train = df_train, df_test  = df_test))
  
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.