cla_metrics <- function(cm, mod_typ = "NULL")
{
  cm <- as.matrix(cm)
  classes <- colnames(cm)
  K <- ncol(cm)
  N <- sum(cm)
  
  mets_class <- matrix(NA, nrow = K, ncol = 11)
  rownames(mets_class) <- classes
  colnames(mets_class) <- c("TP",
                            "TN",
                            "FP",
                            "FN",
                            "PRE",
                            "SPE",
                            "SEN",
                            "ACU",
                            "EFI",
                            "F1S",
                            "MCC")
  
  for (i in 1:K) {
    TP <- cm[i, i]
    FN <- sum(cm[i, -i])
    FP <- sum(cm[-i, i])
    TN <- N - TP - FN - FP
    
    PRE <- ifelse((TP + FP) == 0, NA, TP / (TP + FP))
    SPE <- ifelse((TN + FP) == 0, NA, TN / (TN + FP))
    SEN <- ifelse((TP + FN) == 0, NA, TP / (TP + FN))
    ACU <- (TP + TN) / N
    EFI <- (SEN + SPE) / 2
    F1S <- ifelse((2 * TP + FP + FN) == 0, NA, 2 * TP / (2 * TP + FP + FN))
    
    den <- sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
    MCC <- ifelse(den == 0, NA, (TP * TN - FP * FN) / den)
    
    mets_class[i, ] <- c(TP, TN, FP, FN, PRE, SPE, SEN, ACU, EFI, F1S, MCC)
  }
  
  mets_global <- colMeans(mets_class, na.rm = TRUE)
  mets_global[c("TP", "TN", "FP", "FN")] <- NA
  
  # Global accuracy
  mets_global["ACU"] <- sum(diag(cm)) / sum(cm)
  
  # Multiclass MCC
  c <- sum(diag(cm))
  s <- sum(cm)
  
  pk <- colSums(cm)
  tk <- rowSums(cm)
  
  den <- sqrt((s^2 - sum(pk^2)) *
                (s^2 - sum(tk^2)))
  
  mets_global["MCC"] <- ifelse(
    den == 0,
    NA,
    (c * s - sum(pk * tk)) / den
  )
  
  
  out <- list(per_class = mets_class,
              global    = mets_global,
              confusion = cm)
  
  if (mod_typ == "simca"){
    out$global <- out$per_class['in', ]
    out$per_class <- NULL
    
  }
  
  return(out)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.