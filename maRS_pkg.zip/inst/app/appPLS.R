# =========================
# UI
# =========================

appPLSUI <- div(
  id = "pls_module",
  
  compactNavbarStyle("pls_module"),
  
  navbarPage(
    "PLS",
    
    # CROSS-VALIDATION
    cvUI("pls_cv", mode = "reg"),

    # MODEL
    modelUI(
      "pls_model",
      engine = "pls",
      mode = "reg",
      title = "PLS settings"
    ),

    # DIAGNOSTICS
    diagnosticsUI("pls_diag", mode = "reg"),

    # PARITY
    parityUI("pls_par"),

    # IMPORTANCE
    importanceUI("pls_imp", mode = "pls"),

    # PREDICTION
    predictionUI("pls_pred", type = "reg")
    
  )
)

# =========================
# SERVER
# =========================

appPLSServer <- function(input, output, session, df_shared) {
  plscv <- reactiveVal(NULL)
  plsmod <- reactiveVal(NULL)
  
  # CROSS-VALIDATION
  cvServer(
    "pls_cv",
    df_reactive = df_shared,
    cv_fun = list(
      "PLS"     = cv_pls,
      "iPLS"    = cv_ipls,
      "BVE/PLS" = cv_bvepls
    ),
    cv_reactive = plscv,
    mode = "reg"
  )

  # MODEL
  modelServer(
    "pls_model",
    model_fun       = mod_pls,
    cv_reactive   = plscv,
    model_reactive  = plsmod,
    mode            = "reg",
    engine          = "pls"
  )

  # DIAGNOSTICS
  diagnosticsServer("pls_diag", model_reactive = plsmod, mode = "reg")

  # PARITY
  parityServer("pls_par", model_reactive = plsmod)

  # IMPORTANCE
  importanceServer("pls_imp", model_reactive = plsmod, mode = "pls")

  # PREDICTION
  predictionServer(
    "pls_pred",
    model_reactive = plsmod,
    cv_reactive   = plscv,
    model_setter   = function(x) {
      plsmod(x$plsmod)
      plscv(x$plscv)
    },
    pred_fun       = pred_pls,
    type           = "reg",
    output_fun     = make_reg_pred_output
  )
  
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.