make_da_mod_output <- function(mod) {
  sheets <- list()
  
  # HELPERS
  padronizar <- function(df, nome_titulo, max_cols) {
    matriz <- matrix(NA, nrow = nrow(df) + 2, ncol = max_cols)
    colnames(matriz) <- rep(" ", max_cols)
    
    matriz[1, 1] <- nome_titulo
    matriz[2, 1:ncol(df)] <- names(df)
    
    for (i in 1:nrow(df)) {
      matriz[i + 2, 1:ncol(df)] <- as.character(unlist(df[i, ]))
    }
    
    as.data.frame(matriz, stringsAsFactors = FALSE)
  }
  
  make_metrics_block <- function(metrics) {
    per_class_df <- as.data.frame(metrics$per_class)
    per_class_df <- cbind(Class = rownames(per_class_df), per_class_df)
    rownames(per_class_df) <- NULL
    
    global_df <- as.data.frame(t(metrics$global))
    global_df <- cbind(Class = "Global", global_df)
    global_df <- rbind(global_df, rep(" ", ncol(global_df)))
    colnames(global_df)[1:5] <- c(" ", "  ", "   ", "    ", "     ")
    
    confusion_df <- as.data.frame.matrix(metrics$confusion)
    confusion_df <- cbind(Ref = rownames(confusion_df), confusion_df)
    rownames(confusion_df) <- NULL
    
    max_cols <- max(ncol(per_class_df), ncol(global_df), ncol(confusion_df))
    
    per_class_pad <- padronizar(per_class_df, " ", max_cols)
    global_pad <- padronizar(global_df, " ", max_cols)
    confusion_pad <- padronizar(confusion_df, "CONFUSION MATRIX", max_cols)
    
    rbind(per_class_pad, global_pad, confusion_pad)
  }
  
  make_pred_block <- function(mvobj, row_names) {
    as.data.frame(cbind(
      obj = row_names,
      actual = as.character(mvobj$class_ref),
      predicted = as.character(mvobj$class_hat)
    ))
  }
  
  make_diag <- function(mdiag) {
    save_diag <- as.data.frame(mdiag)
    save_diag <- save_diag[, c(3, 1, 2)]
    colnames(save_diag) <- c("obj", "leverage", "levLim")
    save_diag
  }
  
  make_yrand_block <- function(mod) {
    save_yrand <- do.call(cbind, lapply(mod$mvyrand, as.character))
    save_yrand <- cbind(obj = mod$df_train$row_names, save_yrand)
    colnames(save_yrand)[2:3] <- c("actual", "predicted_cal")
    as.data.frame(save_yrand)
  }
  
  # COEFS
  sheets$coefs <- data.frame(
    Parameter = rownames(mod$coefs),
    mod$coefs,
    row.names = NULL,
    check.names = FALSE
  )
  
  # CAL
  sheets$cal <- make_pred_block(mod$mvcal, mod$df_train$row_names)
  
  # CALMET
  sheets$calMet <- make_metrics_block(mod$cal_metrics)
  
  # DIAG
  sheets$diag <- make_diag(mod$mdiag)
  
  # CV
  
  if (!is.null(mod$mvcv)) {
    sheets$cv <- make_pred_block(mod$mvcv, mod$df_train$row_names)
    sheets$cvMet <- make_metrics_block(mod$cv_metrics)
    
  }
  
  # Y-RANDOMIZATION
  if (!is.null(mod$mvyrand)) {
    sheets$yrand <- make_yrand_block(mod)
    sheets$yrandMet <- make_metrics_block(mod$yrand_metrics)
    
  }
  
  # TEST
  if (!is.null(mod$mvtes)) {
    sheets$test <- make_pred_block(mod$mvtes, mod$df_test$row_names)
    sheets$testMet <- make_metrics_block(mod$test_metrics)
    
  }
  
  return(sheets)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.