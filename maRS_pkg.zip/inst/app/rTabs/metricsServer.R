metricsServer <- function(id, model_reactive) {
  moduleServer(id, function(input, output, session) {
    make_table <- function(metrics) {
      if (is.null(metrics))
        return(NULL)
      
      rbind(metrics$per_class, Global = metrics$global)
    }
    
    # CALIBRATION
    output$met_cal <- renderUI({
      req(model_reactive())
      
      tagList(h4("Calibration"), tableOutput(session$ns("met_cal_tab")))
    })
    
    output$met_cal_tab <- renderTable({
      req(model_reactive())
      make_table(model_reactive()$cal_metrics)
    }, rownames = TRUE,
    na = "-")
    
    # TEST
    output$met_test <- renderUI({
      req(model_reactive())
      
      if (!is.null(model_reactive()$test_metrics)) {
        tagList(h4("Test"), tableOutput(session$ns("met_test_tab")))
      }
    })
    
    output$met_test_tab <- renderTable({
      req(model_reactive())
      make_table(model_reactive()$test_metrics)
    }, rownames = TRUE,
    na = "-")
    
    # CV
    output$met_cv <- renderUI({
      req(model_reactive())
      
      if (!is.null(model_reactive()$cv_metrics)) {
        tagList(h4("Cross-validation"), tableOutput(session$ns("met_cv_tab")))
      }
    })
    
    output$met_cv_tab <- renderTable({
      req(model_reactive())
      make_table(model_reactive()$cv_metrics)
    }, rownames = TRUE,
    na = "-")
    
    # Y-RANDOMIZATION
    output$met_yrand <- renderUI({
      req(model_reactive())
      
      if (!is.null(model_reactive()$yrand_metrics)) {
        tagList(h4("y-randomization"), tableOutput(session$ns("met_yrand_tab")))
      }
    })
    
    output$met_yrand_tab <- renderTable({
      req(model_reactive())
      make_table(model_reactive()$yrand_metrics)
    }, rownames = TRUE,
    na = "-")
    
  })
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.