make_da_pred_output <- function(pred, df_pred) {
  if (!is.null(df_pred$groups)) {
    out <- cbind(
      obj = df_pred$row_names,
      actual = as.character(pred$class_ref),
      predicted = as.character(pred$class_hat)
    )
    
  } else {
    out <- cbind(obj = df_pred$row_names,
                 predicted = as.character(pred$class_hat))
    
  }
  
  as.data.frame(out)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.