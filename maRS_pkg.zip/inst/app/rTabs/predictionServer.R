predictionServer <- function(id,
                             model_reactive,
                             cv_reactive,
                             model_setter = NULL,
                             pred_fun,
                             import_fun = import_df,
                             type = c("reg", "cla", "1cla"),
                             output_fun) {
  moduleServer(id, function(input, output, session) {
    # REACTIVES
    df0     <- reactiveVal(NULL)
    df_pred <- reactiveVal(NULL)
    pred    <- reactiveVal(NULL)
    
    # LOAD MODEL
    # observeEvent(input$model_file, {
    #   mod <- readRDS(input$model_file$datapath)
    #
    #   if (!is.null(model_setter))
    #     model_setter(mod)
    #
    #   df_pred(NULL)
    #   pred(NULL)
    #   showNotification("Model successfully loaded.", type = "message")
    #
    #   modTemp <- model_reactive()
    #   modTemp$loaded <- TRUE
    #   model_reactive(modTemp)
    #
    #   modTemp <- cv_reactive()
    #   modTemp$loaded <- TRUE
    #   cv_reactive(modTemp)
    #
    # })
    
    # LOAD DATA
    observeEvent(input$data_file, {
      df0(readxl::read_excel(input$data_file$datapath))
      df_pred(NULL)
      pred(NULL)
    })
    
    # SELECTS
    output$selects <- renderUI({
      cols <- if (is.null(df0()))
        "None"
      else
        c("None", names(df0()))
      
      tagList(
        selectInput(session$ns("rownames"), "Row names:", cols),
        selectInput(
          session$ns("ycol"),
          if (type == "reg")
            "Response:"
          else if (type == "cla" || type == "1cla")
            "Class column:",
          cols
        )
      )
    })
    
    # APPLY
    observeEvent(input$apply, {
      req(df0(), model_reactive())
      
      if (type == "reg") {
        df_tmp <- import_fun(
          df0(),
          col_names = if (input$rownames == "None")
            NULL
          else
            input$rownames,
          col_resp  = if (input$ycol == "None")
            NULL
          else
            input$ycol
        )
      } else if (type == "cla" || type == "1cla") {
        df_tmp <- import_fun(
          df0(),
          col_names = if (input$rownames == "None")
            NULL
          else
            input$rownames,
          col_classes = if (input$ycol == "None")
            NULL
          else
            input$ycol
        )
      }
      
      # Strutural validation
      if (ncol(df_tmp$xdat) != length(model_reactive()$xvals)) {
        showNotification("Number of predictors does not match active model.", type = "error")
        return(NULL)
      }
      
      df_pred(df_tmp)
      showNotification("Data successfully loaded.", type = "message")
    })
    
    
    # PREDICT
    observeEvent(input$run, {
      req(model_reactive(), df_pred())
      if (type == "1cla") {
        pred(
          pred_fun(
            model_reactive(),
            df_pred(),
            ncomp = model_reactive()$ncomp_sel,
            prepro = TRUE
          )
        )
      } else {
        pred(pred_fun(model_reactive(), df_pred(), prepro = TRUE))
      }
    })
    
    # RESET
    # observeEvent(input$reset, {
    #   req(cv_reactive(), model_reactive())
    #
    #   modTemp <- model_reactive()
    #   modTemp$loaded <- FALSE
    #   model_reactive(modTemp)
    #
    #   modTemp <- cv_reactive()
    #   modTemp$loaded <- FALSE
    #   cv_reactive(modTemp)
    #
    #   later::later(function() {
    #     model_reactive(NULL)
    #     cv_reactive(NULL)
    #   }, delay = 1)
    #
    # })
    
    # MODEL INFO
    output$model_info <- renderUI({
      req(model_reactive())
      
      fluidRow(column(6, h4("Active model:"), p({
        if (!is.null(cv_reactive) &&
            !is.null(cv_reactive()) &&
            !is.null(cv_reactive()$bestVars$vars)) {
          paste0(
            "Variables: ",
            length(model_reactive()$xvals),
            " (",
            length(cv_reactive()$bestVars$vars),
            " selected)"
          )
          
        } else {
          paste0("Variables: ", length(model_reactive()$xvals))
        }
        
      }), p(
        if (type == "reg")
          paste("Response:", model_reactive()$y_name)
        else if (type == "cla" || type == "1cla")
          paste("Classes:", model_reactive()$y_name)
      )), column(6, h4("Active prediction data:"), if (is.null(df_pred())) {
        tagList(p("Variables: -"), p(if (type == "reg")
          "Response: -"
          else
            "Classes: -"))
      } else {
        yname <- if (type == "reg") {
          if (!is.null(df_pred()$resp))
            colnames(df_pred()$resp)
          else
            "None"
        } else if (type == "cla" || type == "1cla") {
          if (!is.null(df_pred()$groups))
            input$ycol
          else
            "None"
        }
        
        tagList(p(paste(
          "Variables:", ncol(df_pred()$xdat)
        )), p(paste(
          if (type == "reg")
            "Response:"
          else if (type == "cla" || type == "1cla")
            "Classes:", yname
        )))
      }))
    })
    
    
    # PLOT
    if (type == "reg") {
      make_plot <- function() {
        plot_parity(pred(),
                    colPa  = input$palette,
                    val_cex = input$fontsize)
      }
      
      output$plot_main <- renderPlot({
        req(pred())
        make_plot()
      })
      
      exp <- exportPlotServer("plot_export", plot_fun = make_plot)
      
      output$plot_container <- renderUI({
        req(pred())
        plotOutput(
          session$ns("plot_main"),
          width  = paste0(exp$width(), "px"),
          height = paste0(exp$height(), "px")
        )
      })
    }
    
    if (type == "1cla") {
      make_plot <- function() {
        plot_accep(
          model_reactive(),
          pred(),
          group = if (!is.null(df_pred()$groups))
            input$group
          else
            FALSE,
          log_scale = input$log_scale,
          marker = input$marker,
          labels = input$labels,
          colPa = input$palette,
          val_cex = input$fontsize
        )
      }
      
      output$plot_main <- renderPlot({
        req(pred())
        make_plot()
      })
      
      exp <- exportPlotServer("plot_export", plot_fun = make_plot)
      
      output$plot_container <- renderUI({
        req(pred())
        plotOutput(
          session$ns("plot_main"),
          width  = paste0(exp$width(), "px"),
          height = paste0(exp$height(), "px")
        )
      })
    }
    # CENTER EXTRA
    output$center_extra <- renderUI({
      req(pred())
      
      if (type == "reg") {
        if (!is.null(df_pred()$resp)) {
          tagList(h4("Prediction metrics"), tableOutput(session$ns("metrics")))
        }
      } else if (type == "cla") {
        tagList(h4("Prediction distribution"),
                tableOutput(session$ns("dist")),
                br(),
                if (!is.null(df_pred()$groups)) {
                  tagList(
                    h4("Prediction metrics"),
                    tableOutput(session$ns("metrics")),
                    br(),
                    h4("Confusion matrix"),
                    tableOutput(session$ns("conf"))
                  )
                })
      } else if (type == "1cla") {
        tagList(h4("Prediction distribution"),
                tableOutput(session$ns("dist")),
                br(),
                if (!is.null(df_pred()$groups)) {
                  tagList(
                    h4("Prediction metrics"),
                    tableOutput(session$ns("metrics")),
                    br(),
                    h4("Confusion matrix"),
                    tableOutput(session$ns("conf"))
                  )
                })
      }
    })
    
    # METRICS
    output$metrics <- renderTable({
      req(pred())
      
      if (type == "reg") {
        if (is.null(pred()$y_actual))
          return(NULL)
        reg_metrics(pred())
      } else if (type == "1cla") {
        met <- cla_metrics(pred()$cm, mod_typ = "simca")
        t(met$global)
      } else if (type == "cla") {
        met <- cla_metrics(pred()$cm)
        rbind(met$per_class, Global = met$global)
      }
    }, rownames = (type %in% c("cla", "reg")), colnames = (type != "reg"))
    
    # CONFUSION / DIST
    if (type == "cla" || type == "1cla") {
      output$conf <- renderTable({
        as.data.frame.matrix(cla_metrics(pred()$cm)$confusion)
      }, rownames = TRUE)
      
      output$dist <- renderTable({
        tab <- table(pred()$class_hat)
        data.frame(Class = names(tab), Count = as.vector(tab))
      })
    }
    
    # SAVE
    output$save_ui <- renderUI({
      if (is.null(pred())) {
        downloadButton(
          session$ns("save_btn"),
          "Save results",
          class = "btn-success",
          onclick = "return false;",
          width = "100%"
        )
      } else {
        downloadButton(session$ns("save_btn"),
                       "Save results",
                       class = "btn-success",
                       width = "100%")
      }
    })
    
    output$save_btn <- downloadHandler(
      filename = function() {
        paste0("prediction_", Sys.Date(), ".xlsx")
      },
      content = function(file) {
        req(pred(), df_pred())
        out <- output_fun(pred(), df_pred())
        writexl::write_xlsx(as.data.frame(out), file)
      }
    )
    
  })
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.