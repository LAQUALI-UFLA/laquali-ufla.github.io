cvServer <- function(id,
                     df_reactive,
                     cv_fun,
                     cv_reactive,
                     mode = c("reg", "cla", "1clas")) {
  moduleServer(id, function(input, output, session) {
    # =========================
    # UPDATE UI FROM CV MODEL
    # =========================
    observe({
      req(cv_reactive())
      
      mod <- cv_reactive()
      if (isTRUE(mod$loaded)) {
        # SELECTS
        if (!is.null(mod$targetclass)) {
          updateSelectInput(
            session,
            "targetclass",
            choices  = as.character(mod$targetclass),
            selected = as.character(mod$targetclass)
          )
        }
        
        if (!is.null(mod$model_type)) {
          updateSelectInput(session, "sel_met", selected = mod$model_type)
        }
        
        if (!is.null(mod$spl_type)) {
          updateSelectInput(session, "spl_type", selected = mod$spl_type)
        }
        
        if (!is.null(mod$cv)) {
          updateSelectInput(session, "cv", selected = mod$cv)
        }
        
        if (mode == "1clas" && !is.null(mod$model_type)) {
          model_type   = switch(
            mod$model_type,
            "Classic" = "smcla",
            "DD-classic" = "ddcla",
            "DD-robust" = "ddrob"
          )
          
          updateSelectInput(session, "method", selected = model_type)
        }
        
        if (!is.null(mod$sel_mode)) {
          updateSelectInput(session, "sel_mode", selected = mod$sel_mode)
        }
        
        
        # NUMERIC
        if (!is.null(mod$ncomp)) {
          updateNumericInput(session, "ncomp", value = mod$ncomp)
        }
        
        if (!is.null(mod$pro_test)) {
          updateNumericInput(session, "pro_test", value = mod$pro_test)
        }
        
        if (!is.null(mod$folds)) {
          updateNumericInput(session, "folds", value = mod$folds)
        }
        
        if (!is.null(mod$alpha)) {
          updateNumericInput(session, "alpha", value = mod$alpha * 100)
        }
        
        if (!is.null(mod$gamma)) {
          updateNumericInput(session, "gamma", value = mod$gamma * 100)
        }
        
        if (!is.null(mod$nint)) {
          updateNumericInput(session, "nint", value = mod$nint)
        }
        
        if (!is.null(mod$vip_lim)) {
          updateNumericInput(session, "vip_lim", value = mod$vip_lim)
        }
        
        
        # CHECKBOX
        if (!is.null(mod$scale)) {
          updateCheckboxInput(session, "scale", value = mod$scale)
        }
        
        # LOCK
        session$sendCustomMessage("lockInput", list(id = session$ns(
          c(
            "targetclass",
            "sel_met",
            "spl_type",
            "cv",
            "method",
            "sel_mode",
            "ncomp",
            "pro_test",
            "folds",
            "alpha",
            "gamma",
            "nint",
            "vip_lim",
            "scale"
          )
        )))
        
      }
      
      else if (isFALSE(mod$loaded)) {
        session$sendCustomMessage("unlockInput", list(id = session$ns(
          c(
            "targetclass",
            "sel_met",
            "spl_type",
            "cv",
            "method",
            "sel_mode",
            "ncomp",
            "pro_test",
            "folds",
            "alpha",
            "gamma",
            "nint",
            "vip_lim",
            "scale"
          )
        )))
        
        
        # SELECTS
        updateSelectInput(session, "targetclass", choices = character(0))
        updateSelectInput(session, "sel_met", selected = "PLS")
        updateSelectInput(session, "spl_type", selected = "None")
        updateSelectInput(session, "cv", selected = "LOO")
        updateSelectInput(session, "method", selected = "smcla")
        updateSelectInput(session, "sel_mode", selected = "forward")
        
        
        # NUMERIC
        updateNumericInput(session, "ncomp", value = 2)
        updateNumericInput(session, "pro_test", value = 25)
        updateNumericInput(session, "folds", value = 5)
        updateNumericInput(session, "alpha", value = 5)
        updateNumericInput(session, "gamma", value = 1)
        updateNumericInput(session, "nint", value = 10)
        updateNumericInput(session, "vip_lim", value = 1)
        
        # CHECKBOX
        updateCheckboxInput(session, "scale", value = FALSE)
        
      }
      
    })
    
    # Auto update target (SIMCA only)
    observe({
      req(mode == "1clas")
      req(df_reactive())
      
      updateSelectInput(session, "targetclass", choices = unique(df_reactive()$groups))
    })
    
    # Left controls
    output$extra_controls <- renderUI({
      req(input$sel_met)
      ns <- session$ns
      
      # Isolates the reactive to capture the current state without creating loops
      mod <- isolate(cv_reactive())
      is_loaded <- !is.null(mod) && isTRUE(mod$loaded)
      
      if (input$sel_met %in% c("iPLS", "iPLS-DA")) {
        tagList(
          numericInput(
            ns("nint"),
            "Intervals:",
            value = if (is_loaded &&
                        !is.null(mod$nint))
              mod$nint
            else
              10,
            min = 3,
            max = 30,
            step = 1
          ),
          selectInput(
            ns("sel_mode"),
            "Mode:",
            choices = c("forward", "backward"),
            selected = if (is_loaded &&
                           !is.null(mod$sel_mode))
              mod$sel_mode
            else
              "forward"
          )
        )
      } else if (input$sel_met %in% c("BVE/PLS", "BVE/PLS-DA")) {
        numericInput(
          ns("vip_lim"),
          "VIP threshold:",
          value = if (is_loaded &&
                      !is.null(mod$vip_lim))
            mod$vip_lim
          else
            1,
          min = 0,
          step = 0.01
        )
      }
    })
    
    # Monitors and locks/unlocks dynamic controls as soon as they appear
    observe({
      req(cv_reactive())
      mod <- cv_reactive()
      
      dynamic_inputs <- c()
      if (!is.null(input$nint))
        dynamic_inputs <- c(dynamic_inputs, "nint")
      if (!is.null(input$sel_mode))
        dynamic_inputs <- c(dynamic_inputs, "sel_mode")
      if (!is.null(input$vip_lim))
        dynamic_inputs <- c(dynamic_inputs, "vip_lim")
      
      req(length(dynamic_inputs) > 0)
      
      if (isTRUE(mod$loaded)) {
        session$sendCustomMessage("lockInput", list(id = session$ns(dynamic_inputs)))
      } else {
        session$sendCustomMessage("unlockInput", list(id = session$ns(dynamic_inputs)))
      }
    })
    
    # Right controls
    output$right_panel <- renderUI({
      ns <- session$ns
      
      # iPLS / BVE
      if (!is.null(input$sel_met) &&
          input$sel_met %in% c("iPLS", "iPLS-DA", "BVE/PLS", "BVE/PLS-DA")) {
        tagList(
          wellPanel(
            selectInput(
              ns("plot_type"),
              "Plot:",
              c("Selection", "LV for the best")
            ),
            
            conditionalPanel(
              condition = sprintf("input['%s'] == 'Selection'", ns("plot_type")),
              
              # iPLS
              conditionalPanel(
                condition = sprintf(
                  "input['%s'] == 'iPLS' || input['%s'] == 'iPLS-DA'",
                  ns("sel_met"),
                  ns("sel_met")
                ),
                textInput(ns("xlabel"), "X label:", "Variables")
              ),
              
              # BVE
              conditionalPanel(
                condition = sprintf(
                  "input['%s'] == 'BVE/PLS' || input['%s'] == 'BVE/PLS-DA'",
                  ns("sel_met"),
                  ns("sel_met")
                ),
                tagList(
                  textInput(ns("xlabel"), "X label:", "Variables"),
                  textInput(ns("ylabel"), "Y label:", "Values")
                )
              )
            ),
            
            conditionalPanel(
              condition = sprintf("input['%s'] == 'LV for the best'", ns("plot_type")),
              checkboxInput(ns("plot_cal"), "Calibration", TRUE),
              checkboxInput(ns("plot_cv"), "Cross-validation", TRUE),
              checkboxInput(ns("plot_test"), "Test", FALSE),
              
              selectInput(
                ns("plot_metric"),
                "Metric:",
                if (mode == "reg")
                  c("RMSE", "R2")
                else
                  c("PRE", "SPE", "SEN", "ACU", "EFI", "F1S")
              )
            ),
            
          ),
          
          wellPanel(
            style = "padding-top:0px;",
            h3("Export graph"),
            numericInput(ns("fontsize"), "Font factor:", 0.7, 0.3, 2, 0.1),
            exportPlotUI(ns("cv_export"))
          )
        )
        
      } else {
        # REGULAR
        tagList(
          wellPanel(
            checkboxInput(ns("plot_cal"), "Calibration", TRUE),
            checkboxInput(ns("plot_cv"), "Cross-validation", TRUE),
            checkboxInput(ns("plot_test"), "Test", FALSE),
            
            if (mode != "1clas") {
              selectInput(
                ns("plot_type"),
                "Metric:",
                if (mode == "reg")
                  c("RMSE", "R2")
                else
                  c("PRE", "SPE", "SEN", "ACU", "EFI", "F1S")
              )
            },
          ),
          wellPanel(
            style = "padding-top:0px;",
            h3("Export graph"),
            numericInput(ns("fontsize"), "Font factor:", 0.7, 0.3, 2, 0.1),
            exportPlotUI(ns("cv_export"))
          )
        )
      }
    })
    
    # RUN
    observeEvent(input$run_btn, {
      req(df_reactive())
      
      id_notif <- showNotification("Running...", duration = NULL, type = "message")
      
      if (mode == "1clas") {
        cv_reactive(
          cv_fun(
            df_reactive(),
            ncomp   = input$ncomp,
            scale   = input$scale,
            spl_type = input$spl_type,
            pro_test = input$pro_test,
            cv      = input$cv,
            folds   = input$folds,
            targetclass = input$targetclass,
            method = input$method,
            alpha  = input$alpha / 100,
            gamma  = input$gamma / 100
          )
        )
      } else {
        cv_fun <- cv_fun[[input$sel_met]]
        
        if (input$sel_met %in% c("iPLS", "iPLS-DA")) {
          cv_reactive(
            cv_fun(
              df_reactive(),
              ncomp   = input$ncomp,
              nint    = input$nint,
              sel_mode = input$sel_mode,
              scale   = input$scale,
              spl_type = input$spl_type,
              pro_test = input$pro_test,
              cv      = input$cv,
              folds   = input$folds
            )
          )
          
        } else if (input$sel_met %in% c("BVE/PLS", "BVE/PLS-DA")) {
          cv_reactive(
            cv_fun(
              df_reactive(),
              ncomp   = input$ncomp,
              vip_lim = input$vip_lim,
              scale   = input$scale,
              spl_type = input$spl_type,
              pro_test = input$pro_test,
              cv      = input$cv,
              folds   = input$folds
            )
          )
          
        } else {
          cv_reactive(
            cv_fun(
              df_reactive(),
              ncomp   = input$ncomp,
              scale   = input$scale,
              spl_type = input$spl_type,
              pro_test = input$pro_test,
              cv      = input$cv,
              folds   = input$folds
            )
          )
          
        }
      }
      removeNotification(id_notif)
    })
    
    # PLOT
    make_cv_plot <- function() {
      req(cv_reactive())
      
      mod <- cv_reactive()
      
      req(!is.null(mod$model_type))
      
      # Verificação condicional baseada no modo
      if (mode == "1clas") {
        req(input$method)
      } else {
        req(!is.null(input$sel_met))
        req(mod$model_type == input$sel_met)
      }
      
      # SELECTION
      if (!is.null(input$plot_type) &&
          input$plot_type == "Selection") {
        if (input$sel_met %in% c("iPLS", "iPLS-DA")) {
          plot_ipls(cv_reactive(),
                    xlabel = input$xlabel,
                    val_cex   = input$fontsize)
          
        } else if (input$sel_met %in% c("BVE/PLS", "BVE/PLS-DA")) {
          plot_bvepls(
            cv_reactive(),
            xlabel = input$xlabel,
            ylabel = input$ylabel,
            val_cex   = input$fontsize
          )
        }
        
        # LV
      } else if (!is.null(input$plot_type) &&
                 input$plot_type == "LV for the best") {
        if (mode == "reg") {
          plot_lv_reg(
            cv_reactive(),
            plot_cal  = input$plot_cal,
            plot_cv   = input$plot_cv,
            plot_test = input$plot_test,
            plot_type = input$plot_metric,
            val_cex   = input$fontsize
          )
        } else if (mode == "cla") {
          plot_lv_da(
            cv_reactive(),
            plot_cal  = input$plot_cal,
            plot_cv   = input$plot_cv,
            plot_test = input$plot_test,
            plot_type = input$plot_metric,
            val_cex   = input$fontsize
          )
        }
        
        # REGULAR
      } else {
        if (mode == "reg") {
          plot_lv_reg(
            cv_reactive(),
            plot_cal  = input$plot_cal,
            plot_cv   = input$plot_cv,
            plot_test = input$plot_test,
            plot_type = input$plot_type,
            val_cex   = input$fontsize
          )
        } else if (mode == "cla") {
          plot_lv_da(
            cv_reactive(),
            plot_cal  = input$plot_cal,
            plot_cv   = input$plot_cv,
            plot_test = input$plot_test,
            plot_type = input$plot_type,
            val_cex   = input$fontsize
          )
        } else if (mode == "1clas") {
          plot_lv_da(
            cv_reactive(),
            plot_cal  = input$plot_cal,
            plot_cv   = input$plot_cv,
            plot_test = if (input$spl_type != "None" &&
                            input$pro_test > 0)
              input$plot_test
            else
              FALSE,
            val_cex   = input$fontsize
          )
        }
        
      }
    }
    
    output$main_cv_plot <- renderPlot({
      make_cv_plot()
    })
    
    exp_cv <- exportPlotServer("cv_export", plot_fun = make_cv_plot)
    
    output$cv_plot_container <- renderUI({
      ns <- session$ns
      
      w <- exp_cv$width()
      h <- exp_cv$height()
      
      if (is.null(w) || w == "")
        w <- 600
      if (is.null(h) || h == "")
        h <- 400
      
      div(style = paste0("width:", w, "px;"),
          
          plotOutput(
            ns("main_cv_plot"),
            width  = paste0(w, "px"),
            height = paste0(h, "px")
          ))
    })
    
  })
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.