make_reg_pred_output <- function(pred, df_pred) {
  if (!is.null(df_pred$resp)) {
    out <- cbind(
      obj       = df_pred$row_names,
      actual    = pred$y_actual,
      predicted = pred$y_hat
    )
    
  } else {
    out <- cbind(obj = df_pred$row_names, predicted = pred$y_hat)
    
  }
  
  as.data.frame(out)
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.