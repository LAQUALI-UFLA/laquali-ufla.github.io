parityServer <- function(id, model_reactive) {
  moduleServer(id, function(input, output, session) {
    make_par_plot <- function() {
      plot_parity(
        model_reactive(),
        cal      = input$par_cal,
        cv       = input$par_cv,
        test     = input$par_test,
        rnames   = input$rnames,
        colPa    = input$par_palette,
        val_cex  = input$par_fontsize
      )
    }
    
    output$main_par_plot <- renderPlot({
      req(model_reactive())
      make_par_plot()
    })
    
    exp_par <- exportPlotServer("par_export", plot_fun = make_par_plot)
    
    output$par_plot_container <- renderUI({
      ns <- session$ns
      
      w <- exp_par$width()
      h <- exp_par$height()
      
      if (is.null(w) || w == "")
        w <- 600
      if (is.null(h) || h == "")
        h <- 400
      
      div(style = paste0("width:", w, "px;"),
          
          plotOutput(
            ns("main_par_plot"),
            width  = paste0(w, "px"),
            height = paste0(h, "px")
          ))
    })
    
  })
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.