diagnosticsServer <- function(id, model_reactive, mode = NULL) {
  moduleServer(id, function(input, output, session) {
    make_diag_plot <- function() {
      args <- list(
        model_reactive(),
        marker  = input$marker,
        labels  = input$labels,
        val_cex = input$fontsize
      )
      
      if (mode == "reg") {
        args$x <- input$x
        args$y <- input$y
        args$orlines <- input$orlines
      } else {
        args$x <- "y_hat"
        args$y <- "leverage"
      }
      
      do.call(plot_diag, args)
    }
    
    output$main_diag_plot <- renderPlot({
      req(model_reactive())
      make_diag_plot()
    })
    
    exp_diag <- exportPlotServer("diag_export", plot_fun = make_diag_plot)
    
    output$diag_plot_container <- renderUI({
      ns <- session$ns
      
      w <- exp_diag$width()
      h <- exp_diag$height()
      
      if (is.null(w) || w == "")
        w <- 600
      if (is.null(h) || h == "")
        h <- 400
      
      div(style = paste0("width:", w, "px;"),
          
          plotOutput(
            ns("main_diag_plot"),
            width  = paste0(w, "px"),
            height = paste0(h, "px")
          ))
    })
    
  })
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.