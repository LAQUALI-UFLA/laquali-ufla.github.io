diagnosticsUI <- function(id, mode = NULL) {
  ns <- NS(id)
  
  tabPanel("Diagnostics", fluidRow(column(
    width = 3,
    wellPanel(
      style = "padding-top:0px;",
      
      if (mode == "reg") {
        tagList(
          selectInput(
            ns("x"),
            "x:",
            c(
              "Leverages" = "leverage",
              "Studentized residuals" = "r_student",
              "Residuals" = "residuals",
              "Predicted" = "y_hat",
              "Actual" = "y_actual"
            ),
            selected = "leverage"
          ),
          
          selectInput(
            ns("y"),
            "y:",
            c(
              "Leverages" = "leverage",
              "Studentized residuals" = "r_student",
              "Residuals" = "residuals",
              "Predicted" = "y_hat",
              "Actual" = "y_actual"
            ),
            selected = "r_student"
          )
        )
      },
      
      checkboxInput(ns("marker"), "Marker", TRUE),
      checkboxInput(ns("labels"), "Labels", TRUE),
      
      if (mode == "reg") {
        checkboxInput(ns("orlines"), "Origin line", FALSE)
      },
      
      
    )
  ), column(width = 9, fluidRow(
    column(9, uiOutput(ns(
      "diag_plot_container"
    ))), column(
      3,
      wellPanel(
        style = "padding-top:0px;",
        h3("Export graph"),
        numericInput(
          ns("fontsize"),
          "Font factor:",
          value = 0.7,
          min = 0.3,
          max = 2,
          step = 0.1
        ),
        exportPlotUI(ns("diag_export"))
      )
    )
  ))))
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.