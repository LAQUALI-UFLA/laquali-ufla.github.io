modelUI <- function(id,
                    engine = c("lm", "pls"),
                    mode = c("reg", "cla"),
                    title = "Model settings") {
  ns <- NS(id)
  
  tabPanel(
    "Model",
    # lockInput
    tags$script(
      HTML(
        "
        Shiny.addCustomMessageHandler('lockInput', function(x) {
          var ids = Array.isArray(x.id) ? x.id : [x.id];

          ids.forEach(function(id) {
            var el = document.getElementById(id);
            if (el) el.closest('.shiny-input-container').style.pointerEvents = 'none';
          });
        });
        "
      )
    ),
    
    tags$script(
      HTML(
        "
    Shiny.addCustomMessageHandler('unlockInput', function(x) {
      var ids = Array.isArray(x.id) ? x.id : [x.id];

      ids.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.closest('.shiny-input-container').style.pointerEvents = 'auto';
      });
    });
    "
      )
    ),
    
    fluidRow(
      # LEFT
      column(
        width = 3,
        wellPanel(
          style = "padding-top:0px;",
          
          h3(title),
          
          # LM (MLR / MLR-DA)
          if (engine == "lm") {
            tagList(
              checkboxInput(ns("scale"), "Scale", FALSE),
              
              selectInput(ns("spl_type"), "Split type:", choices = if (mode == "reg") {
                c(
                  "None" = "None",
                  "Kennard-Stone" = "KS",
                  "SPXY" = "SPXY",
                  "Randomized" = "RND",
                  "Split indicator" = "SPE"
                )
              } else {
                c(
                  "None" = "None",
                  "Kennard-Stone" = "KS",
                  "Randomized" = "RND",
                  "Split indicator" = "SPE"
                )
              }),
              
              numericInput(ns("pro_test"), "Test set (%):", 25, 0, 95, 1),
              
              selectInput(ns("cv"), "CV type:", choices = if (mode == "reg") {
                c(
                  "None" = "None",
                  "Leave-One-Out" = "LOO",
                  "Venetian Blinds" = "VB",
                  "Randomized" = "RND"
                )
              } else {
                c(
                  "None" = "None",
                  "Leave-One-Out" = "LOO",
                  "Randomized" = "RND"
                )
              }),
              
              numericInput(ns("folds"), "Folds:", 5, 1, 50, 1)
            )
          },
          
          # PLS / PLSDA
          if (engine == "pls") {
            numericInput(ns("ncomp"), "N of LVs:", 1, 1, 50, 1)
          },
          
          # y-randomization
          checkboxInput(ns("yrand"), "y-randomization", FALSE),
          numericInput(ns("nrep"), "N. of shuffles:", 10, 1, 100, 1),
          
          br(),
          
          # REPLICATIONS PER SAMPLE
          if (mode == "reg") {
            tagList(
              numericInput(ns("q_lod"), "Replications per sample:", 1, 1, 100, 1),
              p("To calculate LOD"),
              br()
            )
          },
          
          # Common
          div(
            style = "display:flex; gap:10px;",
            actionButton(
              ns("run_btn"),
              "Run",
              icon = icon("play"),
              class = "btn-primary",
              style = "flex: 1;"
            ),
            
            actionButton(
              ns("reset"),
              "Reset",
              icon = icon("sync"),
              class = "btn-primary",
              style = "flex: 1;"
            )
          ),
          
          br(),
          
          # div(style = "display:flex; gap:10px;", uiOutput(ns("save_results")), uiOutput(ns("save_model")))
          
          div(
            style = "display:flex; gap:10px;",
            uiOutput(ns("save_results"), style = "flex: 1;"),
            uiOutput(ns("save_model"), style = "flex: 1;")
          ),
          
          
          hr(),
          
          fileInput(ns("model_file"), "Load model (.rds)", accept = ".rds")
          
        )
      ),
      
      # RIGHT
      column(
        width = 9,
        
        uiOutput(ns("matrix_legend")),
        br(),
        
        fluidRow(column(6, uiOutput(ns(
          "cal_ui"
        ))), column(6, uiOutput(ns(
          "test_ui"
        )))),
        
        br(),
        
        fluidRow(column(6, uiOutput(ns(
          "yrand_ui"
        ))), column(6, uiOutput(ns(
          "cv_ui"
        ))))
      )
      
    )
  )
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.