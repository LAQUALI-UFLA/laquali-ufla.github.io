# =========================
# UI
# =========================

appPlotUI <- tagList(fluidRow(column(
  width = 3,
  wellPanel(
    style = "padding-top:0px;",
    h3("Plot settings"),
    checkboxInput("plot_center", "Center", FALSE),
    checkboxInput("plot_scale", "Scale", FALSE),
    textInput("plot_xlabel", "X label:", "Variables"),
    textInput("plot_ylabel", "Y label:", "Values"),
    checkboxInput("plot_color_groups", "Color by groups", FALSE),
    selectInput(
      "plot_palette",
      "Colors:",
      c("Hue", "Dark", "Prism", "Spec", "Set", "Tab")
    ),
    checkboxInput("plot_origin", "Origin line", FALSE),
    
  )
), column(width = 9, fluidRow(
  # Graph area
  column(width = 9, uiOutput("plot_container")),
  
  # Export area
  column(width = 3, 
         wellPanel(
           style = "padding-top:0px;",
           h3("Export graph"),
           numericInput(
             "plot_fontsize",
             "Font factor:",
             value = 0.7,
             min = 0.3,
             max = 2,
             step = 0.1
           ),
           exportPlotUI("plot_export")))
  
))))

# =========================
# SERVER
# =========================

appPlotServer <- function(input, output, session, df_shared) {
  # plot function
  make_plot <- function() {
    plot_lines(
      df = df_shared(),
      center = input$plot_center,
      scale = input$plot_scale,
      xlabel = input$plot_xlabel,
      ylabel = input$plot_ylabel,
      col_groups = input$plot_color_groups,
      colPa = input$plot_palette,
      val_cex = input$plot_fontsize,
      orlines = input$plot_origin
    )
  }
  
  # render plot
  output$main_plot <- renderPlot({
    req(df_shared())
    
    make_plot()
    
  })
  
  # update size
  export_controls <- exportPlotServer("plot_export", plot_fun = make_plot)
  
  output$plot_container <- renderUI({
    plotOutput(
      "main_plot",
      width  = paste0(export_controls$width(), "px"),
      height = paste0(export_controls$height(), "px")
    )
    
  })
  
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.