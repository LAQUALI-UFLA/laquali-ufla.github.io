# =========================
# UI
# =========================

appDataUI <- tagList(fluidRow(
  # Lefty
  column(
    width = 3,
    wellPanel(
      style = "padding-top:0px;",
      # Controls
      h3("Data input"),
      selectInput(
        "file_type",
        "File type:",
        choices = c(".xls, .xlsx", ".txt, .dat, .csv")
      ),
      uiOutput("text_import_ui"),
      p("The first row of the data file must contain column headers"),
      uiOutput("file_input_ui"),
      selectInput("object_names", "Object names:", choices = NULL),
      selectInput("object_classes", "Object classes:", choices = NULL),
      selectInput("response_y", "Numerical Response (y):", choices = NULL),
      selectInput("split_indicator", "Split indicator (train/test):", choices = NULL),
      
      fluidRow(column(
        width = 6,
        
        # View dataset
        checkboxInput("view_dataset", "View dataset", value = FALSE),
        
        # Apply
        div(
          style = "margin-bottom:10px;",
          actionButton(
            "apply_dat",
            "Apply",
            icon = icon("play"),
            class = "btn-primary"
          )
        ),
        
        # Save
        div(uiOutput("save_button_ui"))
        
      )),
      
    )
  ),
  # Center
  column(
    width = 6,
    
    # Data info
    verbatimTextOutput("dimensions"),
    
    # Table
    conditionalPanel(condition = "input.view_dataset == true", br(), DT::dataTableOutput("dataset_table")),
    br()
  ),
  
  # Right
  column(width = 3, wellPanel(
    style = "padding-top:0px;",
    # Preprocessing
    h3("Preprocessing"),
    
    wellPanel(
      uiOutput("method1_ui"),
      uiOutput("method2_ui"),
      uiOutput("method3_ui"),
      uiOutput("method4_ui"),
      uiOutput("sg_ui")
    )
  )),
))

# =========================
# SERVER
# =========================

appDataServer <- function(input, output, session, df_shared) {
  
  # Force R system messages and errors to be in English
  Sys.setenv(LANGUAGE = "en")
  
  ppmet_val <- reactiveVal(NULL)
  
  # Dynamic file input
  output$file_input_ui <- renderUI({
    if (input$file_type == ".xls, .xlsx") {
      fileInput("file", "Select file:", accept = c(".xls", ".xlsx"))
    } else {
      fileInput("file", "Select file:", accept = c(".txt", ".dat", ".csv"))
    }
  })
  
  # Text file options
  output$text_import_ui <- renderUI({
    req(input$file_type)
    
    if (input$file_type == ".txt, .dat, .csv") {
      tagList(
        selectInput(
          "dec_sep",
          "Decimal:",
          choices = c("dot (.)" = ".", "comma (,)" = ",")
        ),
        
        selectInput(
          "col_sep",
          "Separator:",
          choices = c(
            "comma (,)" = ",",
            "semicolon (;)" = ";",
            "tab" = "\t"
          )
        )
      )
    }
  })
  
  # =========================
  # DATA INPUT
  # =========================
  
  # Import file
  df0 <- reactive({
    req(input$file)
    req(input$file_type)
    
    # Extracts the file extension in lowercase
    ext <- tolower(tools::file_ext(input$file$name))
    
    if (input$file_type == ".xls, .xlsx") {
      # Prevents execution if the uploaded file is .txt, .csv, or .dat.
      req(ext %in% c("xls", "xlsx"))
      
      readxl::read_excel(input$file$datapath)
      
    } else {
      # Prevents execution if the file is an Excel file or if the selectors have not yet loaded.
      req(ext %in% c("txt", "dat", "csv"))
      req(input$col_sep, input$dec_sep)
      
      read.table(
        input$file$datapath,
        header = TRUE,
        sep = input$col_sep,
        dec = input$dec_sep,
        check.names = FALSE,
        stringsAsFactors = FALSE
      )
    }
  })
  
  # Update selectors
  observeEvent(df0(), {
    headers <- names(df0())
    updateSelectInput(session, "object_names", choices = c("None", headers))
    updateSelectInput(session, "object_classes", choices = c("None", headers))
    updateSelectInput(session, "response_y", choices = c("None", headers))
    updateSelectInput(session, "split_indicator", choices = c("None", headers))
  })
  
  # =========================
  # PREPROCESSING
  # =========================
  
  # Method selection UI
  method_choices <- c("None", "MSC", "SNV", "Savitzky-Golay", "L2-norm")
  
  output$method1_ui <- renderUI({
    req(input$file)
    selectInput("method1", label = NULL, choices = method_choices)
  })
  
  output$method2_ui <- renderUI({
    req(input$method1)
    if (input$method1 != "None") {
      selectInput("method2", label = NULL, choices = method_choices)
    }
  })
  
  output$method3_ui <- renderUI({
    req(input$method1, input$method2)
    if (input$method1 != "None" && input$method2 != "None") {
      selectInput("method3", label = NULL, choices = method_choices)
    }
  })
  
  output$method4_ui <- renderUI({
    req(input$method1, input$method2, input$method3)
    if (input$method1 != "None" &&
        input$method2 != "None" &&
        input$method3 != "None") {
      selectInput("method4", label = NULL, choices = method_choices)
    }
  })
  
  
  # Method reset logic
  observeEvent(input$method1, {
    if (input$method1 == "None") {
      updateSelectInput(session, "method2", selected = "None")
      updateSelectInput(session, "method3", selected = "None")
      updateSelectInput(session, "method4", selected = "None")
    }
  })
  
  observeEvent(input$method2, {
    if (input$method2 == "None") {
      updateSelectInput(session, "method3", selected = "None")
      updateSelectInput(session, "method4", selected = "None")
    }
  })
  
  observeEvent(input$method3, {
    if (input$method3 == "None") {
      updateSelectInput(session, "method4", selected = "None")
    }
  })
  
  # =========================
  # DATA PROCESSING
  # =========================
  
  # Assemble dataset
  df_final <- eventReactive(input$apply_dat, {
    req(df0())
    
    # Validation of the split Indicator column
    if (!is.null(input$split_indicator) &&
        input$split_indicator != "None") {
      split_vals <- unique(as.character(df0()[[input$split_indicator]]))
      
      invalid_vals <- setdiff(split_vals, c("train", "test"))
      
      if (length(invalid_vals) > 0) {
        showNotification(
          "The Split indicator column must contain only 'train' and 'test'.",
          type = "error",
          duration = 5
        )
        req(FALSE)
      }
    }
    
    # Get columns
    col_names   <- if (input$object_names    == "None")
      NULL
    else
      input$object_names
    
    col_classes <- if (input$object_classes  == "None")
      NULL
    else
      input$object_classes
    
    col_split    <- if (input$split_indicator == "None")
      NULL
    else
      input$split_indicator
    
    col_resp    <- if (input$response_y      == "None")
      NULL
    else
      input$response_y
    
    # Try running the import with error handling.
    df <- tryCatch({
      import_df(
        df0(),
        col_names   = col_names,
        col_classes = col_classes,
        col_resp    = col_resp,
        col_split   = col_split
      )
    }, error = function(e) {
      # Displays the error on the app screen
      showNotification(paste("Data import error:", e$message),
                       type = "error",
                       duration = 8)
      return(NULL)
    })
    
    # Silently interrupts execution if there is an error (df is NULL).
    req(df)
    
    methods <- c(input$method1,
                 input$method2,
                 input$method3,
                 input$method4)
    
    methods <- methods[!is.null(methods)]
    
    methods[methods == "None"] <- NA
    ppmet <- na.omit(methods)
    
    if (length(ppmet) == 0)
      ppmet <- NULL
    ppmet_val(ppmet)
    
    # Savitzky-Golay case
    if (!is.null(ppmet) && "Savitzky-Golay" %in% ppmet) {
      sgstp <- c(
        as.numeric(input$sg_width),
        as.numeric(input$sg_order),
        as.numeric(input$sg_deriv)
      )
      
    } else {
      sgstp <- NULL
      
    }
    
    # Apply preprocessing
    
    # Attempt to apply preprocessing with error handling
    df <- tryCatch({
      pre_pro(df, ppmet = ppmet, sgstp = sgstp)
    }, error = function(e) {
      # Display the error message in the app UI
      showNotification(
        paste("Error during preprocessing:", e$message),
        type = "error",
        duration = 8
      )
      return(NULL)
    })
    
    # Halt execution silently if an error occurred (df is NULL)
    req(df)
    
    if (!is.null(ppmet) && "Savitzky-Golay" %in% ppmet) {
      ppmet[ppmet == "Savitzky-Golay"] <- paste0(
        "Savitzky-Golay (",
        input$sg_width,
        ",",
        input$sg_order,
        ",",
        input$sg_deriv,
        ")"
      )
    }
    
    # Display success message if the code reaches this point without errors
    showNotification(
      "Data successfully processed!",
      type = "message", 
      duration = 5
    )
    
    list(
      df = df,
      response = input$response_y,
      groups = input$object_classes,
      split = input$split_indicator,
      ppmet = ppmet
    )
    
  })
  
  # =========================
  # UI OUTPUTS
  # =========================
  
  # Dimensions text
  output$dimensions <- renderText({
    req(df_final())
    
    res <- df_final()
    
    pp_txt <- if (is.null(res$ppmet))
      "None"
    else
      paste(res$ppmet, collapse = ", ")
    
    paste(
      "Active data:",
      "\n",
      "\nRows:",
      nrow(res$df$xdat),
      "\nColumns:",
      ncol(res$df$xdat),
      "\n",
      "\nNames column:",
      input$object_names,
      "\nResponse column:",
      res$response,
      "\nClasses column:",
      res$groups,
      "\nSplit column:",
      res$split,
      "\n",
      "\nPreprocessing:",
      pp_txt
    )
  })
  
  # Savitzky-Golay panel
  output$sg_ui <- renderUI({
    req(df0())
    n_num <- sum(sapply(df0(), is.numeric))
    max_width <- max(3, floor(n_num / 4))
    
    if (max_width %% 2 == 0)
      max_width <- max_width - 1
    
    m1 <- input$method1
    
    m2 <- if (!is.null(m1) && m1 != "None")
      input$method2
    else
      NULL
    m3 <- if (!is.null(m2) && m2 != "None")
      input$method3
    else
      NULL
    m4 <- if (!is.null(m3) && m3 != "None")
      input$method4
    else
      NULL
    
    active_methods <- c(m1, m2, m3, m4)
    active_methods <- active_methods[!is.null(active_methods)]
    active_methods <- active_methods[active_methods != "None"]
    
    if ("Savitzky-Golay" %in% active_methods) {
      wellPanel(
        style = "padding-top:0px;",
        h4("Savitzky-Golay setup"),
        sliderInput(
          "sg_width",
          "Width:",
          min = 3,
          max = max_width,
          step = 2,
          value = ifelse(is.null(input$sg_width), 3, input$sg_width)
        ),
        radioButtons(
          "sg_order",
          "Polynomial:",
          choices = c(1, 2),
          selected = ifelse(is.null(input$sg_order), 1, input$sg_order),
          inline = TRUE
        ),
        radioButtons(
          "sg_deriv",
          "Derivative:",
          choices = if (is.null(input$sg_order) ||
                        input$sg_order == 1) {
            c(0, 1)
          } else {
            c(0, 1, 2)
          },
          selected = {
            # ensure that invalid old selections do not remain
            if (is.null(input$sg_deriv)) {
              0
            } else if (input$sg_order == 1 && input$sg_deriv == 2) {
              1
            } else {
              input$sg_deriv
            }
          },
          inline = TRUE
        )
      )
    }
  })
  
  # Dataset table
  output$dataset_table <- DT::renderDataTable({
    req(df_final())
    
    df <- df_final()$df
    
    cols_list <- list()
    
    if (!is.null(df$row_names) &&
        !is.null(input$object_names) &&
        input$object_names != "None") {
      tmp <- data.frame(df$row_names)
      colnames(tmp) <- input$object_names
      cols_list[[1]] <- tmp
    }
    
    if (!is.null(df$groups)) {
      tmp <- data.frame(df$groups)
      colnames(tmp) <- input$object_classes
      cols_list[[length(cols_list) + 1]] <- tmp
    }
    
    if (!is.null(df$resp)) {
      tmp <- data.frame(df$resp)
      colnames(tmp) <- input$response_y
      cols_list[[length(cols_list) + 1]] <- tmp
    }
    
    if (!is.null(df$split_info)) {
      tmp <- data.frame(df$split_info)
      colnames(tmp) <- input$split_indicator
      cols_list[[length(cols_list) + 1]] <- tmp
    }
    
    cols_list[[length(cols_list) + 1]] <- as.data.frame(df$xdat)
    
    final_df <- do.call(cbind, cols_list)
    
    # Identify numeric columns and strip names to prevent the JSON error
    num_cols <- unname(which(sapply(final_df, is.numeric)))
    fixed_width <- "50px"
    
    DT::datatable(
      final_df,
      rownames = TRUE,
      selection = "none",
      # Disables row selection
      options = list(
        pageLength = 10,
        scrollX = TRUE,
        autoWidth = FALSE,
        searching = FALSE,
        ordering = FALSE,
        # Required to override default browser behavior
        columnDefs = list(
          list(
            targets = num_cols,
            width = fixed_width,
            render = htmlwidgets::JS(
              paste0(
                "function(data, type, row, meta) {",
                "  if(type === 'display' && data !== null){",
                "    return '<div style=\"width:",
                fixed_width,
                "; overflow:hidden; text-overflow:clip; white-space:nowrap;\">' + data + '</div>';",
                "  }",
                "  return data;",
                "}"
              )
            )
          )
        ),
        # Force fixed layout and block text selection via CSS
        initComplete = htmlwidgets::JS(
          "function(settings, json) {",
          "  $(this.api().table().node()).css('table-layout', 'fixed');",
          "  $(this.api().table().node()).css({",
          "    '-webkit-user-select': 'none',",
          "    '-moz-user-select': 'none',",
          "    '-ms-user-select': 'none',",
          "    'user-select': 'none',",
          "    'cursor': 'default'",
          "  });",
          "}"
        )
      )
    )
  }, server = TRUE)
  
  # =========================
  # DATA SHARING
  # =========================
  
  observeEvent(df_final(), {
    df_shared(df_final()$df)
  })
  
  # =========================
  # EXPORT
  # =========================
  
  # Save button UI
  output$save_button_ui <- renderUI({
    disabled <- input$apply_dat == 0
    
    tagList(div(
      style = "display:flex; gap:8px; align-items:flex-end;",
      
      if (disabled) {
        downloadButton(
          "save_dat",
          "Export dataset as",
          icon = icon("save"),
          class = "btn-success",
          onclick = "return false;"
        )
      } else {
        downloadButton("save_dat",
                       "Export dataset as",
                       icon = icon("save"),
                       class = "btn-success")
      },
      
      div(
        style = "flex-shrink:0; width:80px;",
        selectInput(
          "save_type",
          NULL,
          choices = c(".xlsx", ".txt"),
          width = "100%",
          selectize = FALSE
        )
      )
    ))
  })
  
  # Download handler
  output$save_dat <- downloadHandler(
    filename = function() {
      paste0("processed_data_", Sys.Date(), input$save_type)
    },
    
    content = function(file) {
      req(df_shared())
      df <- df_shared()
      req(df$xdat)
      
      final_df <- as.data.frame(df$xdat)
      n <- nrow(final_df)
      
      # Adds optional columns
      cols_list <- list()
      
      if (!is.null(df$row_names) &&
          !is.null(input$object_names) &&
          input$object_names != "None") {
        tmp <- data.frame(df$row_names)
        colnames(tmp) <- input$object_names
        cols_list[[1]] <- tmp
      }
      
      if (!is.null(df$groups)) {
        tmp <- data.frame(df$groups)
        colnames(tmp) <- input$object_classes
        cols_list[[length(cols_list) + 1]] <- tmp
      }
      
      if (!is.null(df$resp)) {
        tmp <- data.frame(df$resp)
        colnames(tmp) <- input$response_y
        cols_list[[length(cols_list) + 1]] <- tmp
      }
      
      if (!is.null(df$split_info)) {
        tmp <- data.frame(df$split_info)
        colnames(tmp) <- input$split_indicator
        cols_list[[length(cols_list) + 1]] <- tmp
      }
      
      # Add X
      cols_list[[length(cols_list) + 1]] <- as.data.frame(df$xdat)
      
      final_df <- do.call(cbind, cols_list)
      
      if (input$save_type == ".xlsx") {
        writexl::write_xlsx(final_df, file)
        
      } else {
        write.table(
          final_df,
          file,
          sep = "\t",
          dec = ".",
          row.names = FALSE,
          quote = FALSE
        )
        
      }
    }
  )
  
}

# Cleiton A. Nunes, 2026
# This code was developed with assistance from ChatGPT, Gemini, Microsoft Copilot, or DeepSeek.