.onLoad <- function(libname, pkgname) {

  path <- system.file(
    "app",
    "rFunctions",
    package = pkgname
  )

  files <- sort(list.files(
    path,
    pattern = "\\.R$",
    full.names = TRUE
  ))

  for (file in files) {
    sys.source(
      file,
      envir = asNamespace(pkgname)
    )
  }
}