# Main function exported to the user
run_mars <- function() {
  # Finds the app directory within the package installation
  appDir <- system.file("app", package = "maRS")
  
  if (appDir == "") {
    stop("The application directory could not be found. Try reinstalling the package `maRS`.", call. = FALSE)
  }
  
  # Run the application
  shiny::runApp(appDir, display.mode = "normal")
}

runmars  <- run_mars